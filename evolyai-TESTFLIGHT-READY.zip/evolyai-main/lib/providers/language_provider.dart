import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

class LanguageProvider extends ChangeNotifier {
  static const String _key = 'app_language';
  static final LanguageProvider _instance = LanguageProvider._internal();
  factory LanguageProvider() => _instance;
  LanguageProvider._internal();

  String _languageCode = 'en';

  String get languageCode => _languageCode;
  bool get isFrench => _languageCode == 'fr';
  bool get isEnglish => _languageCode == 'en';

  Future<void> init() async {
    final prefs = await SharedPreferences.getInstance();
    _languageCode = prefs.getString(_key) ?? 'en';
    notifyListeners();
  }

  Future<void> setLanguage(String code) async {
    if (_languageCode == code) return;
    _languageCode = code;
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_key, code);
    notifyListeners();
  }

  Future<void> toggleLanguage() async {
    await setLanguage(_languageCode == 'en' ? 'fr' : 'en');
  }

  /// Returns the correct string based on current language.
  String t(String en, String fr) => _languageCode == 'fr' ? fr : en;
}
