import 'package:flutter/material.dart';
import '../presentation/home_dashboard/home_dashboard.dart';
import '../presentation/ai_processing_screen/ai_processing_screen.dart';
import '../presentation/onboarding_hero_screen/onboarding_hero_screen.dart';
import '../presentation/goal_selection_screen/goal_selection_screen.dart';
import '../presentation/gender_selection_screen/gender_selection_screen.dart';
import '../presentation/age_input_screen/age_input_screen.dart';
import '../presentation/height_input_screen/height_input_screen.dart';
import '../presentation/weight_input_screen/weight_input_screen.dart';
import '../presentation/great_start_dopamine_screen/great_start_dopamine_screen.dart';
import '../presentation/target_body_fat_screen/target_body_fat_screen.dart';
import '../presentation/activity_level_screen/activity_level_screen.dart';
import '../presentation/motivation_screen/motivation_screen.dart';
import '../presentation/social_proof_screen/social_proof_screen.dart';
import '../presentation/camera_instructions_screen/camera_instructions_screen.dart';
import '../presentation/camera_capture_screen/camera_capture_screen.dart';
import '../presentation/onboarding_finale_screen/onboarding_finale_screen.dart';
import '../presentation/results_explanation_screen/results_explanation_screen.dart';
import '../presentation/notifications_permission_screen/notifications_permission_screen.dart';
import '../presentation/auth_screen/auth_screen.dart';
import '../presentation/compare_scans_screen/compare_scans_screen.dart';
import '../presentation/scan_detail_screen/scan_detail_screen.dart';
import '../presentation/paywall_screen/paywall_screen.dart';
import '../presentation/paywall_fallback_screen/paywall_fallback_screen.dart';
import '../presentation/rescan_result_screen/rescan_result_screen.dart';
import '../presentation/legal_screens/legal_screens.dart';
import '../presentation/science_screen/science_screen.dart';
import '../presentation/science_screen/science_screen.dart';
import '../models/onboarding_data.dart';

class AppRoutes {
  static const String initial = '/';
  static const String auth = '/auth';
  static const String homeDashboard = '/home-dashboard';
  static const String aiProcessing = '/ai-processing-screen';
  static const String onboardingHero = '/onboarding-hero-screen';
  static const String goalSelection = '/goal-selection-screen';
  static const String genderSelection = '/gender-selection-screen';
  static const String ageInput = '/age-input-screen';
  static const String heightInput = '/height-input-screen';
  static const String weightInput = '/weight-input-screen';
  static const String targetBodyFat = '/target-body-fat-screen';
  static const String greatStartDopamine = '/great-start-dopamine-screen';
  static const String activityLevel = '/activity-level-screen';
  static const String motivationScreen = '/motivation-screen';
  static const String socialProof = '/social-proof-screen';
  static const String resultsExplanation = '/results-explanation-screen';
  static const String notificationsPermission =
      '/notifications-permission-screen';
  static const String cameraInstructions = '/camera-instructions-screen';
  static const String cameraCapture = '/camera-capture-screen';
  static const String onboardingFinale = '/onboarding-finale-screen';
  static const String compareScans = '/compare-scans';
  static const String scanDetail = '/scan-detail';
  static const String paywall = '/paywall';
  static const String paywallFallback = '/paywall-fallback';
  static const String rescanResult = '/rescan-result-screen';
  static const String privacyPolicy = '/privacy-policy';
  static const String termsOfUse = '/terms-of-use';
  static const String support = '/support';
  static const String science = '/science';

  static Map<String, WidgetBuilder> routes = {
    initial: (context) => const OnboardingHeroScreen(),
    auth: (context) {
      final data =
          ModalRoute.of(context)?.settings.arguments as OnboardingData?;
      return AuthScreen(onboardingData: data);
    },
    homeDashboard: (context) {
      final data =
          ModalRoute.of(context)?.settings.arguments as OnboardingData?;
      return HomeDashboard(onboardingData: data);
    },
    aiProcessing: (context) => const AiProcessingScreen(),
    onboardingHero: (context) => const OnboardingHeroScreen(),
    goalSelection: (context) {
      final data =
          ModalRoute.of(context)?.settings.arguments as OnboardingData?;
      return GoalSelectionScreen(onboardingData: data);
    },
    genderSelection: (context) {
      final data =
          ModalRoute.of(context)?.settings.arguments as OnboardingData?;
      return GenderSelectionScreen(onboardingData: data);
    },
    ageInput: (context) {
      final data =
          ModalRoute.of(context)?.settings.arguments as OnboardingData?;
      return AgeInputScreen(onboardingData: data);
    },
    heightInput: (context) {
      final data =
          ModalRoute.of(context)?.settings.arguments as OnboardingData?;
      return HeightInputScreen(onboardingData: data);
    },
    weightInput: (context) {
      final data =
          ModalRoute.of(context)?.settings.arguments as OnboardingData?;
      return WeightInputScreen(onboardingData: data);
    },
    targetBodyFat: (context) {
      final data =
          ModalRoute.of(context)?.settings.arguments as OnboardingData?;
      return TargetBodyFatScreen(onboardingData: data);
    },
    greatStartDopamine: (context) {
      final data =
          ModalRoute.of(context)?.settings.arguments as OnboardingData?;
      return GreatStartDopamineScreen(onboardingData: data);
    },
    activityLevel: (context) {
      final data =
          ModalRoute.of(context)?.settings.arguments as OnboardingData?;
      return ActivityLevelScreen(onboardingData: data);
    },
    motivationScreen: (context) {
      final data =
          ModalRoute.of(context)?.settings.arguments as OnboardingData?;
      return MotivationScreen(onboardingData: data);
    },
    socialProof: (context) {
      final data =
          ModalRoute.of(context)?.settings.arguments as OnboardingData?;
      return SocialProofScreen(onboardingData: data);
    },
    resultsExplanation: (context) {
      final data =
          ModalRoute.of(context)?.settings.arguments as OnboardingData?;
      return ResultsExplanationScreen(onboardingData: data);
    },
    notificationsPermission: (context) {
      final data =
          ModalRoute.of(context)?.settings.arguments as OnboardingData?;
      return NotificationsPermissionScreen(onboardingData: data);
    },
    cameraInstructions: (context) {
      final data =
          ModalRoute.of(context)?.settings.arguments as OnboardingData?;
      return CameraInstructionsScreen(onboardingData: data);
    },
    cameraCapture: (context) {
      final data =
          ModalRoute.of(context)?.settings.arguments as OnboardingData?;
      return CameraCaptureScreen(
        onboardingData: data,
        standaloneMode: data?.standaloneMode ?? false,
      );
    },
    onboardingFinale: (context) {
      final data =
          ModalRoute.of(context)?.settings.arguments as OnboardingData?;
      return OnboardingFinaleScreen(onboardingData: data);
    },
    paywall: (context) {
      final data =
          ModalRoute.of(context)?.settings.arguments as OnboardingData?;
      return PaywallScreen(onboardingData: data);
    },
    paywallFallback: (context) {
      final data =
          ModalRoute.of(context)?.settings.arguments as OnboardingData?;
      return PaywallFallbackScreen(onboardingData: data);
    },
    rescanResult: (context) => const RescanResultScreen(),
    compareScans: (context) => const CompareScansScreen(),
    scanDetail: (context) => const ScanDetailScreen(),
    privacyPolicy: (context) => const PrivacyPolicyScreen(),
    termsOfUse: (context) => const TermsOfUseScreen(),
    support: (context) => const SupportScreen(),
    science: (context) => const ScienceScreen(),
  };
}
