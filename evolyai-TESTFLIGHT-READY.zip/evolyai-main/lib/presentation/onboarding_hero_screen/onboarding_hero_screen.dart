import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:simple_animations/simple_animations.dart';
import 'package:sizer/sizer.dart';

import '../../core/app_export.dart';
import '../../services/supabase_service.dart';
import '../../widgets/custom_icon_widget.dart';
import '../../providers/language_provider.dart';

class OnboardingHeroScreen extends StatefulWidget {
  const OnboardingHeroScreen({super.key});

  @override
  State<OnboardingHeroScreen> createState() => _OnboardingHeroScreenState();
}

class _OnboardingHeroScreenState extends State<OnboardingHeroScreen>
    with TickerProviderStateMixin {
  late AnimationController _glowController;
  late AnimationController _fadeController;
  late Animation<double> _glowAnimation;
  late Animation<double> _fadeAnimation;
  bool _isLoading = false;

  @override
  void initState() {
    super.initState();
    _glowController = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 2),
    )..repeat(reverse: true);

    _fadeController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 800),
    )..forward();

    _glowAnimation = Tween<double>(begin: 0.4, end: 1.0).animate(
      CurvedAnimation(parent: _glowController, curve: Curves.easeInOut),
    );

    _fadeAnimation = Tween<double>(
      begin: 0.0,
      end: 1.0,
    ).animate(CurvedAnimation(parent: _fadeController, curve: Curves.easeOut));

    // ── CRITICAL FIX: redirect returning logged-in users to dashboard ──
    WidgetsBinding.instance.addPostFrameCallback((_) => _checkAuthAndRedirect());
  }

  Future<void> _checkAuthAndRedirect() async {
    if (!SupabaseService.instance.isAuthenticated) return;
    try {
      final profile = await SupabaseService.instance.fetchProfile();
      if (!mounted) return;
      if (profile?.onboardingCompleted == true) {
        debugPrint('[Hero] Returning user — redirecting to dashboard');
        Navigator.of(context).pushNamedAndRemoveUntil(
          '/home-dashboard',
          (route) => false,
        );
      }
    } catch (e) {
      debugPrint('[Hero] Auth redirect check failed: $e');
    }
  }

  @override
  void dispose() {
    _glowController.dispose();
    _fadeController.dispose();
    super.dispose();
  }

  Future<void> _onStartPressed() async {
    HapticFeedback.lightImpact();
    setState(() => _isLoading = true);
    await Future.delayed(const Duration(milliseconds: 300));
    if (mounted) {
      Navigator.of(
        context,
        rootNavigator: true,
      ).pushNamed('/goal-selection-screen');
    }
    setState(() => _isLoading = false);
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return Scaffold(
      backgroundColor: Colors.white,
      body: SafeArea(
        child: Padding(
          padding: EdgeInsets.symmetric(vertical: 2.h, horizontal: 4.w),
          child: FadeTransition(
            opacity: _fadeAnimation,
            child: Column(
              children: [
                // Language toggle row at top
                Align(
                  alignment: Alignment.topRight,
                  child: _LanguageToggleButton(),
                ),
                Expanded(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      _ParticleBackground(),
                      SizedBox(height: 2.h),
                      _LogoWidget(glowAnimation: _glowAnimation),
                      SizedBox(height: 4.h),
                      _HeroTitleWidget(theme: theme),
                      SizedBox(height: 2.h),
                      _HeroSubtitleWidget(theme: theme),
                      SizedBox(height: 4.h),
                      _TrustBadgesWidget(theme: theme),
                    ],
                  ),
                ),
                _StartButtonWidget(
                  isLoading: _isLoading,
                  onPressed: _onStartPressed,
                ),
                SizedBox(height: 2.h),
                _PrivacyNoteWidget(theme: theme),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

// ─── Language Toggle Button ───────────────────────────────────────────────────

class _LanguageToggleButton extends StatefulWidget {
  @override
  State<_LanguageToggleButton> createState() => _LanguageToggleButtonState();
}

class _LanguageToggleButtonState extends State<_LanguageToggleButton> {
  final _lang = LanguageProvider();

  @override
  void initState() {
    super.initState();
    _lang.addListener(_rebuild);
  }

  @override
  void dispose() {
    _lang.removeListener(_rebuild);
    super.dispose();
  }

  void _rebuild() => setState(() {});

  @override
  Widget build(BuildContext context) {
    final isFr = _lang.isFrench;
    return GestureDetector(
      onTap: () {
        HapticFeedback.selectionClick();
        _lang.toggleLanguage();
      },
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
        decoration: BoxDecoration(
          color: const Color(0xFFF8F9FA),
          borderRadius: BorderRadius.circular(20),
          border: Border.all(color: const Color(0xFFE2E8F0)),
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text(isFr ? '🇫🇷' : '🇬🇧', style: const TextStyle(fontSize: 16)),
            const SizedBox(width: 5),
            Text(
              isFr ? 'FR' : 'EN',
              style: const TextStyle(
                fontSize: 12,
                fontWeight: FontWeight.w700,
                color: Color(0xFF2D3436),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _ParticleBackground extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: 20.h,
      width: double.infinity,
      child: Stack(
        alignment: Alignment.center,
        children: [
          PlayAnimationBuilder<double>(
            tween: Tween(begin: 0.0, end: 1.0),
            duration: const Duration(seconds: 3),
            builder: (context, value, child) {
              return CustomPaint(
                size: Size(80.w, 20.h),
                painter: _ParticlePainter(progress: value),
              );
            },
          ),
        ],
      ),
    );
  }
}

class _ParticlePainter extends CustomPainter {
  final double progress;
  _ParticlePainter({required this.progress});

  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()..style = PaintingStyle.fill;
    final particles = [
      Offset(size.width * 0.1, size.height * 0.3),
      Offset(size.width * 0.85, size.height * 0.2),
      Offset(size.width * 0.2, size.height * 0.8),
      Offset(size.width * 0.75, size.height * 0.7),
      Offset(size.width * 0.5, size.height * 0.15),
      Offset(size.width * 0.4, size.height * 0.9),
      Offset(size.width * 0.9, size.height * 0.5),
    ];
    final colors = [
      const Color(0xFF6C5CE7),
      const Color(0xFF74B9FF),
      const Color(0xFF00CEC9),
      const Color(0xFF6C5CE7),
      const Color(0xFF74B9FF),
      const Color(0xFF00CEC9),
      const Color(0xFF6C5CE7),
    ];
    for (int i = 0; i < particles.length; i++) {
      paint.color = colors[i % colors.length].withValues(alpha: 0.3 * progress);
      canvas.drawCircle(particles[i], 3 + (i % 3).toDouble(), paint);
    }
  }

  @override
  bool shouldRepaint(_ParticlePainter oldDelegate) =>
      oldDelegate.progress != progress;
}

class _LogoWidget extends StatelessWidget {
  final Animation<double> glowAnimation;
  const _LogoWidget({required this.glowAnimation});

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: glowAnimation,
      builder: (context, child) {
        return Container(
          width: 22.w,
          height: 22.w,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            gradient: const LinearGradient(
              colors: [Color(0xFF6C5CE7), Color(0xFF74B9FF)],
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
            ),
            boxShadow: [
              BoxShadow(
                color: const Color(
                  0xFF6C5CE7,
                ).withValues(alpha: 0.4 * glowAnimation.value),
                blurRadius: 30 * glowAnimation.value,
                spreadRadius: 5 * glowAnimation.value,
              ),
            ],
          ),
          child: Center(
            child: CustomIconWidget(
              iconName: 'accessibility_new',
              color: Colors.white,
              size: 10.w,
            ),
          ),
        );
      },
    );
  }
}

class _HeroTitleWidget extends StatefulWidget {
  final ThemeData theme;
  const _HeroTitleWidget({required this.theme});

  @override
  State<_HeroTitleWidget> createState() => _HeroTitleWidgetState();
}

class _HeroTitleWidgetState extends State<_HeroTitleWidget> {
  final _lang = LanguageProvider();

  @override
  void initState() {
    super.initState();
    _lang.addListener(_rebuild);
  }

  @override
  void dispose() {
    _lang.removeListener(_rebuild);
    super.dispose();
  }

  void _rebuild() => setState(() {});

  @override
  Widget build(BuildContext context) {
    return ShaderMask(
      shaderCallback: (bounds) => const LinearGradient(
        colors: [Color(0xFF1B365D), Color(0xFF6C5CE7)],
        begin: Alignment.centerLeft,
        end: Alignment.centerRight,
      ).createShader(bounds),
      child: Text(
        _lang.t(
          'Scan your body fat\nwith AI',
          'Scannez votre\ncomposition corporelle',
        ),
        textAlign: TextAlign.center,
        style: widget.theme.textTheme.headlineMedium?.copyWith(
          fontWeight: FontWeight.w800,
          color: Colors.white,
          height: 1.2,
          fontSize: 26.sp > 32 ? 32 : 26.sp,
        ),
      ),
    );
  }
}

class _HeroSubtitleWidget extends StatefulWidget {
  final ThemeData theme;
  const _HeroSubtitleWidget({required this.theme});

  @override
  State<_HeroSubtitleWidget> createState() => _HeroSubtitleWidgetState();
}

class _HeroSubtitleWidgetState extends State<_HeroSubtitleWidget> {
  final _lang = LanguageProvider();

  @override
  void initState() {
    super.initState();
    _lang.addListener(_rebuild);
  }

  @override
  void dispose() {
    _lang.removeListener(_rebuild);
    super.dispose();
  }

  void _rebuild() => setState(() {});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsets.symmetric(horizontal: 4.w),
      child: Text(
        _lang.t(
          'Discover your body composition instantly\nfrom two photos',
          'Découvrez votre composition corporelle\ninstantanément en deux photos',
        ),
        textAlign: TextAlign.center,
        style: widget.theme.textTheme.bodyLarge?.copyWith(
          color: const Color(0xFF636E72),
          height: 1.6,
          fontSize: 14.sp > 18 ? 18 : 14.sp,
        ),
      ),
    );
  }
}

class _TrustBadgesWidget extends StatelessWidget {
  final ThemeData theme;
  const _TrustBadgesWidget({required this.theme});

  @override
  Widget build(BuildContext context) {
    final badges = [
      {'icon': 'analytics', 'label': 'Analyse IA'},
      {'icon': 'lock', 'label': 'Données privées'},
      {'icon': 'security', 'label': 'GDPR Safe'},
    ];
    return Wrap(
      alignment: WrapAlignment.center,
      spacing: 2.w,
      runSpacing: 1.h,
      children: badges.map((badge) {
        return Container(
          padding: EdgeInsets.symmetric(horizontal: 3.w, vertical: 0.8.h),
          decoration: BoxDecoration(
            color: const Color(0xFFF8F9FA),
            borderRadius: BorderRadius.circular(20),
            border: Border.all(color: const Color(0xFFE2E8F0)),
          ),
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              CustomIconWidget(
                iconName: badge['icon']!,
                color: const Color(0xFF6C5CE7),
                size: 14,
              ),
              SizedBox(width: 1.w),
              Text(
                badge['label']!,
                style: theme.textTheme.labelSmall?.copyWith(
                  color: const Color(0xFF2D3436),
                  fontWeight: FontWeight.w600,
                  fontSize: 10.sp > 12 ? 12 : 10.sp,
                ),
              ),
            ],
          ),
        );
      }).toList(),
    );
  }
}

class _StartButtonWidget extends StatefulWidget {
  final bool isLoading;
  final VoidCallback onPressed;
  const _StartButtonWidget({required this.isLoading, required this.onPressed});

  @override
  State<_StartButtonWidget> createState() => _StartButtonWidgetState();
}

class _StartButtonWidgetState extends State<_StartButtonWidget> {
  final _lang = LanguageProvider();

  @override
  void initState() {
    super.initState();
    _lang.addListener(_rebuild);
  }

  @override
  void dispose() {
    _lang.removeListener(_rebuild);
    super.dispose();
  }

  void _rebuild() => setState(() {});

  @override
  Widget build(BuildContext context) {
    return Semantics(
      label: 'Start body composition analysis',
      button: true,
      child: GestureDetector(
        onTap: widget.isLoading ? null : widget.onPressed,
        child: Container(
          width: double.infinity,
          height: 7.h,
          decoration: BoxDecoration(
            gradient: const LinearGradient(
              colors: [Color(0xFF6C5CE7), Color(0xFF74B9FF)],
              begin: Alignment.centerLeft,
              end: Alignment.centerRight,
            ),
            borderRadius: BorderRadius.circular(16),
            boxShadow: [
              BoxShadow(
                color: const Color(0xFF6C5CE7).withValues(alpha: 0.4),
                blurRadius: 20,
                offset: const Offset(0, 8),
              ),
            ],
          ),
          child: Center(
            child: widget.isLoading
                ? const SizedBox(
                    width: 24,
                    height: 24,
                    child: CircularProgressIndicator(
                      color: Colors.white,
                      strokeWidth: 2,
                    ),
                  )
                : Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Text(
                        _lang.t('Start', 'Commencer'),
                        style: TextStyle(
                          color: Colors.white,
                          fontSize: 16.sp > 20 ? 20 : 16.sp,
                          fontWeight: FontWeight.w700,
                          letterSpacing: 0.5,
                        ),
                      ),
                      SizedBox(width: 2.w),
                      CustomIconWidget(
                        iconName: 'arrow_forward',
                        color: Colors.white,
                        size: 20,
                      ),
                    ],
                  ),
          ),
        ),
      ),
    );
  }
}

class _PrivacyNoteWidget extends StatefulWidget {
  final ThemeData theme;
  const _PrivacyNoteWidget({required this.theme});

  @override
  State<_PrivacyNoteWidget> createState() => _PrivacyNoteWidgetState();
}

class _PrivacyNoteWidgetState extends State<_PrivacyNoteWidget> {
  final _lang = LanguageProvider();

  @override
  void initState() {
    super.initState();
    _lang.addListener(_rebuild);
  }

  @override
  void dispose() {
    _lang.removeListener(_rebuild);
    super.dispose();
  }

  void _rebuild() => setState(() {});

  @override
  Widget build(BuildContext context) {
    return Text(
      _lang.t(
        'By continuing, you agree to our Terms & Privacy Policy',
        'En continuant, vous acceptez nos Conditions & Politique de confidentialité',
      ),
      textAlign: TextAlign.center,
      style: widget.theme.textTheme.labelSmall?.copyWith(
        color: const Color(0xFFB2BEC3),
        fontSize: 10.sp > 12 ? 12 : 10.sp,
      ),
    );
  }
}
