import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:sizer/sizer.dart';

import '../../services/supabase_service.dart';

/// Arguments passed when navigating to ScanDetailScreen
class ScanDetailArgs {
  final String date;
  final double bodyFatPercent;
  final double? leanMassPercent;
  final double? fatMassPercent;
  final String physiqueProfile;
  final double? confidenceScore;
  final Map<String, double> zonePercentages;

  const ScanDetailArgs({
    required this.date,
    required this.bodyFatPercent,
    this.leanMassPercent,
    this.fatMassPercent,
    required this.physiqueProfile,
    this.confidenceScore,
    this.zonePercentages = const {},
  });
}

class ScanDetailScreen extends StatefulWidget {
  const ScanDetailScreen({super.key});

  @override
  State<ScanDetailScreen> createState() => _ScanDetailScreenState();
}

class _ScanDetailScreenState extends State<ScanDetailScreen> {
  static const List<String> _zoneOrder = [
    'Bras Gauche',
    'Bras Droit',
    'Haut du Corps',
    'Jambe Gauche',
    'Jambe Droite',
  ];

  ScanDetailArgs? _resolvedArgs;
  bool _isLoading = false;
  bool _hydrationAttempted = false;

  bool _isArgsComplete(ScanDetailArgs? args) {
    if (args == null) return false;
    return args.leanMassPercent != null && args.fatMassPercent != null;
  }

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    if (!_hydrationAttempted) {
      _hydrationAttempted = true;
      _hydrateArgs();
    }
  }

  Future<void> _hydrateArgs() async {
    final passedArgs =
        ModalRoute.of(context)?.settings.arguments as ScanDetailArgs?;

    if (_isArgsComplete(passedArgs)) {
      setState(() {
        _resolvedArgs = passedArgs;
      });
      return;
    }

    // Args are missing lean mass or fat mass — fetch latest from Supabase
    setState(() => _isLoading = true);
    try {
      final fetched = await SupabaseService.instance.fetchLatestScanResult();
      if (mounted) {
        if (fetched != null &&
            fetched.bodyFatPercent != null &&
            fetched.leanMassEstimate != null &&
            fetched.fatMass != null) {
          // Build resolved args from fetched result, keeping passed date/profile if available
          final zones = <String, double>{};
          if (fetched.leftArmPercent != null) {
            zones['Bras Gauche'] = fetched.leftArmPercent!;
          }
          if (fetched.rightArmPercent != null) {
            zones['Bras Droit'] = fetched.rightArmPercent!;
          }
          if (fetched.upperBodyPercent != null) {
            zones['Haut du Corps'] = fetched.upperBodyPercent!;
          }
          if (fetched.leftLegPercent != null) {
            zones['Jambe Gauche'] = fetched.leftLegPercent!;
          }
          if (fetched.rightLegPercent != null) {
            zones['Jambe Droite'] = fetched.rightLegPercent!;
          }

          setState(() {
            _resolvedArgs = ScanDetailArgs(
              date:
                  passedArgs?.date ??
                  (fetched.createdAt != null
                      ? _formatDate(fetched.createdAt!)
                      : 'Dernier Scan'),
              bodyFatPercent: fetched.bodyFatPercent!,
              leanMassPercent: fetched.leanMassEstimate,
              fatMassPercent: fetched.fatMass,
              physiqueProfile:
                  passedArgs?.physiqueProfile ??
                  fetched.physiqueProfile ??
                  '--',
              confidenceScore:
                  passedArgs?.confidenceScore ?? fetched.confidenceScore,
              zonePercentages: passedArgs?.zonePercentages.isNotEmpty == true
                  ? passedArgs!.zonePercentages
                  : zones,
            );
            _isLoading = false;
          });
        } else {
          // Use passed args as fallback even if incomplete
          setState(() {
            _resolvedArgs = passedArgs;
            _isLoading = false;
          });
        }
      }
    } catch (e) {
      debugPrint('[ScanDetailScreen] hydration error: $e');
      if (mounted) {
        setState(() {
          _resolvedArgs = passedArgs;
          _isLoading = false;
        });
      }
    }
  }

  String _formatDate(DateTime dt) {
    const months = [
      'Jan',
      'Feb',
      'Mar',
      'Apr',
      'May',
      'Jun',
      'Jul',
      'Aug',
      'Sep',
      'Oct',
      'Nov',
      'Dec',
    ];
    return '${months[dt.month - 1]} ${dt.day}, ${dt.year}';
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final isDark = theme.brightness == Brightness.dark;

    if (_isLoading) {
      return Scaffold(
        backgroundColor: theme.scaffoldBackgroundColor,
        body: SafeArea(
          child: Padding(
            padding: EdgeInsets.symmetric(horizontal: 4.w, vertical: 2.h),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                _buildHeader(context, theme, ''),
                SizedBox(height: 2.5.h),
                _buildSkeletonHeroCard(theme, isDark),
                SizedBox(height: 2.h),
                _buildSkeletonSection(theme, isDark),
              ],
            ),
          ),
        ),
      );
    }

    final args = _resolvedArgs;
    if (args == null) {
      return Scaffold(
        appBar: AppBar(title: const Text('Détail du Scan')),
        body: const Center(child: Text('Aucune donnée de scan disponible.')),
      );
    }

    return Scaffold(
      backgroundColor: theme.scaffoldBackgroundColor,
      body: SafeArea(
        child: CustomScrollView(
          physics: const BouncingScrollPhysics(),
          slivers: [
            SliverToBoxAdapter(
              child: Padding(
                padding: EdgeInsets.symmetric(horizontal: 4.w, vertical: 2.h),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    _buildHeader(context, theme, args.date),
                    SizedBox(height: 2.5.h),
                    _buildHeroCard(theme, isDark, args),
                    SizedBox(height: 2.h),
                    _buildBodyCompositionSection(theme, isDark, args),
                    SizedBox(height: 2.h),
                    _buildZonesSection(theme, isDark, args.zonePercentages),
                    SizedBox(height: 2.h),
                    _buildPhysiqueSection(theme, isDark, args),
                    SizedBox(height: 10.h),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildHeader(BuildContext context, ThemeData theme, String date) {
    final canPop = !_isLoading && _isArgsComplete(_resolvedArgs);
    return Row(
      children: [
        GestureDetector(
          onTap: canPop
              ? () {
                  HapticFeedback.lightImpact();
                  Navigator.of(context).pop();
                }
              : null,
          child: Container(
            padding: const EdgeInsets.all(8),
            decoration: BoxDecoration(
              color: theme.colorScheme.outline.withValues(
                alpha: canPop ? 0.1 : 0.05,
              ),
              borderRadius: BorderRadius.circular(10.0),
            ),
            child: Icon(
              Icons.arrow_back_ios_new_rounded,
              size: 16,
              color: canPop
                  ? theme.colorScheme.onSurface
                  : theme.colorScheme.onSurface.withValues(alpha: 0.3),
            ),
          ),
        ),
        SizedBox(width: 3.w),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                'Détail du Scan',
                style: GoogleFonts.dmSans(
                  fontSize: 18.sp,
                  fontWeight: FontWeight.w700,
                  color: theme.colorScheme.onSurface,
                ),
              ),
              if (date.isNotEmpty)
                Text(
                  date,
                  style: GoogleFonts.dmSans(
                    fontSize: 11.sp,
                    color: theme.colorScheme.onSurfaceVariant,
                  ),
                ),
            ],
          ),
        ),
        if (_isLoading) ...[
          SizedBox(
            width: 16,
            height: 16,
            child: CircularProgressIndicator(
              strokeWidth: 2,
              color: theme.colorScheme.primary,
            ),
          ),
        ],
      ],
    );
  }

  // ── Skeleton widgets ──────────────────────────────────────────────────────

  Widget _buildSkeletonHeroCard(ThemeData theme, bool isDark) {
    return Container(
      padding: EdgeInsets.all(4.w),
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          colors: [Color(0xFF1B365D), Color(0xFF6C5CE7)],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(20.0),
        boxShadow: [
          BoxShadow(
            color: const Color(0xFF6C5CE7).withValues(alpha: 0.35),
            blurRadius: 24,
            offset: const Offset(0, 8),
          ),
        ],
      ),
      child: Column(
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceAround,
            children: [
              _SkeletonStat(),
              Container(
                width: 1,
                height: 8.h,
                color: Colors.white.withValues(alpha: 0.2),
              ),
              _SkeletonStat(),
              Container(
                width: 1,
                height: 8.h,
                color: Colors.white.withValues(alpha: 0.2),
              ),
              _SkeletonStat(),
            ],
          ),
          SizedBox(height: 2.h),
          Center(
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                SizedBox(
                  width: 14,
                  height: 14,
                  child: CircularProgressIndicator(
                    strokeWidth: 2,
                    color: Colors.white.withValues(alpha: 0.7),
                  ),
                ),
                SizedBox(width: 2.w),
                Text(
                  'Chargement de vos résultats…',
                  style: GoogleFonts.dmSans(
                    fontSize: 11.sp,
                    fontWeight: FontWeight.w600,
                    color: Colors.white.withValues(alpha: 0.8),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildSkeletonSection(ThemeData theme, bool isDark) {
    return Container(
      padding: EdgeInsets.all(4.w),
      decoration: BoxDecoration(
        color: isDark ? const Color(0xFF1E2E4A) : Colors.white,
        borderRadius: BorderRadius.circular(16.0),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: 0.05),
            blurRadius: 12,
            offset: const Offset(0, 3),
          ),
        ],
      ),
      child: Column(
        children: List.generate(3, (i) {
          return Padding(
            padding: EdgeInsets.only(bottom: i < 2 ? 1.5.h : 0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    _ShimmerBox(width: 20.w, height: 1.5.h),
                    _ShimmerBox(width: 10.w, height: 1.5.h),
                  ],
                ),
                SizedBox(height: 0.6.h),
                _ShimmerBox(width: double.infinity, height: 1.h),
              ],
            ),
          );
        }),
      ),
    );
  }

  // ── Real content widgets ──────────────────────────────────────────────────

  Widget _buildHeroCard(ThemeData theme, bool isDark, ScanDetailArgs args) {
    return Container(
      padding: EdgeInsets.all(4.w),
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          colors: [Color(0xFF1B365D), Color(0xFF6C5CE7)],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(20.0),
        boxShadow: [
          BoxShadow(
            color: const Color(0xFF6C5CE7).withValues(alpha: 0.35),
            blurRadius: 24,
            offset: const Offset(0, 8),
          ),
        ],
      ),
      child: Column(
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceAround,
            children: [
              _HeroStat(
                label: 'Masse Grasse',
                value: '${args.bodyFatPercent.toStringAsFixed(1)}%',
                icon: Icons.water_drop_rounded,
              ),
              Container(
                width: 1,
                height: 8.h,
                color: Colors.white.withValues(alpha: 0.2),
              ),
              _HeroStat(
                label: 'Masse Maigre',
                value: args.leanMassPercent != null
                    ? '${args.leanMassPercent!.toStringAsFixed(1)}%'
                    : '--',
                icon: Icons.fitness_center_rounded,
              ),
              Container(
                width: 1,
                height: 8.h,
                color: Colors.white.withValues(alpha: 0.2),
              ),
              _HeroStat(
                label: 'Masse Grasse kg',
                value: args.fatMassPercent != null
                    ? '${args.fatMassPercent!.toStringAsFixed(1)}%'
                    : '--',
                icon: Icons.monitor_weight_outlined,
              ),
            ],
          ),
          if (args.confidenceScore != null) ...[
            SizedBox(height: 2.h),
            Container(
              padding: EdgeInsets.symmetric(horizontal: 3.w, vertical: 0.8.h),
              decoration: BoxDecoration(
                color: Colors.white.withValues(alpha: 0.12),
                borderRadius: BorderRadius.circular(20.0),
              ),
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  const Icon(
                    Icons.verified_rounded,
                    color: Colors.white,
                    size: 14,
                  ),
                  SizedBox(width: 1.5.w),
                  Text(
                    'Précision : ${(args.confidenceScore! * 100).toStringAsFixed(0)}%',
                    style: GoogleFonts.dmSans(
                      fontSize: 11.sp,
                      fontWeight: FontWeight.w600,
                      color: Colors.white,
                    ),
                  ),
                ],
              ),
            ),
          ],
        ],
      ),
    );
  }

  Widget _buildBodyCompositionSection(
    ThemeData theme,
    bool isDark,
    ScanDetailArgs args,
  ) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          'BODY COMPOSITION',
          style: GoogleFonts.dmSans(
            fontSize: 10.sp,
            fontWeight: FontWeight.w700,
            color: theme.colorScheme.onSurfaceVariant,
            letterSpacing: 1.2,
          ),
        ),
        SizedBox(height: 1.h),
        Container(
          padding: EdgeInsets.all(4.w),
          decoration: BoxDecoration(
            color: isDark ? const Color(0xFF1E2E4A) : Colors.white,
            borderRadius: BorderRadius.circular(16.0),
            boxShadow: [
              BoxShadow(
                color: Colors.black.withValues(alpha: 0.05),
                blurRadius: 12,
                offset: const Offset(0, 3),
              ),
            ],
          ),
          child: Column(
            children: [
              _CompositionBar(
                label: 'Masse Grasse',
                percent: args.bodyFatPercent,
                maxPercent: 50.0,
                color: const Color(0xFFE53E3E),
                theme: theme,
              ),
              SizedBox(height: 1.5.h),
              _CompositionBar(
                label: 'Masse Maigre',
                percent: args.leanMassPercent ?? (100 - args.bodyFatPercent),
                maxPercent: 100.0,
                color: const Color(0xFF6C5CE7),
                theme: theme,
              ),
              if (args.fatMassPercent != null) ...[
                SizedBox(height: 1.5.h),
                _CompositionBar(
                  label: 'Masse Grasse kg',
                  percent: args.fatMassPercent!,
                  maxPercent: 50.0,
                  color: const Color(0xFFE17055),
                  theme: theme,
                ),
              ],
            ],
          ),
        ),
      ],
    );
  }

  Widget _buildZonesSection(
    ThemeData theme,
    bool isDark,
    Map<String, double> zones,
  ) {
    if (zones.isEmpty) return const SizedBox.shrink();

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          'BODY ZONES',
          style: GoogleFonts.dmSans(
            fontSize: 10.sp,
            fontWeight: FontWeight.w700,
            color: theme.colorScheme.onSurfaceVariant,
            letterSpacing: 1.2,
          ),
        ),
        SizedBox(height: 1.h),
        Container(
          padding: EdgeInsets.all(4.w),
          decoration: BoxDecoration(
            color: isDark ? const Color(0xFF1E2E4A) : Colors.white,
            borderRadius: BorderRadius.circular(16.0),
            boxShadow: [
              BoxShadow(
                color: Colors.black.withValues(alpha: 0.05),
                blurRadius: 12,
                offset: const Offset(0, 3),
              ),
            ],
          ),
          child: Column(
            children: _zoneOrder.where((z) => zones.containsKey(z)).map((zone) {
              final pct = zones[zone]!;
              final isLast =
                  _zoneOrder.where((z) => zones.containsKey(z)).last == zone;
              return Column(
                children: [
                  _ZoneRow(zone: zone, percent: pct, theme: theme),
                  if (!isLast) ...[
                    SizedBox(height: 1.h),
                    Divider(
                      height: 1,
                      color: theme.colorScheme.outline.withValues(alpha: 0.12),
                    ),
                    SizedBox(height: 1.h),
                  ],
                ],
              );
            }).toList(),
          ),
        ),
      ],
    );
  }

  Widget _buildPhysiqueSection(
    ThemeData theme,
    bool isDark,
    ScanDetailArgs args,
  ) {
    final profile = args.physiqueProfile;
    if (profile.isEmpty || profile == '--') return const SizedBox.shrink();

    final (color, icon) = _profileStyle(profile);

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          'PHYSIQUE PROFILE',
          style: GoogleFonts.dmSans(
            fontSize: 10.sp,
            fontWeight: FontWeight.w700,
            color: theme.colorScheme.onSurfaceVariant,
            letterSpacing: 1.2,
          ),
        ),
        SizedBox(height: 1.h),
        Container(
          padding: EdgeInsets.all(4.w),
          decoration: BoxDecoration(
            color: isDark ? const Color(0xFF1E2E4A) : Colors.white,
            borderRadius: BorderRadius.circular(16.0),
            border: Border.all(color: color.withValues(alpha: 0.25)),
            boxShadow: [
              BoxShadow(
                color: Colors.black.withValues(alpha: 0.05),
                blurRadius: 12,
                offset: const Offset(0, 3),
              ),
            ],
          ),
          child: Row(
            children: [
              Container(
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(
                  color: color.withValues(alpha: 0.12),
                  borderRadius: BorderRadius.circular(14.0),
                ),
                child: Icon(icon, color: color, size: 28),
              ),
              SizedBox(width: 4.w),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      profile,
                      style: GoogleFonts.dmSans(
                        fontSize: 16.sp,
                        fontWeight: FontWeight.w700,
                        color: color,
                      ),
                    ),
                    Text(
                      _profileDescription(profile),
                      style: GoogleFonts.dmSans(
                        fontSize: 11.sp,
                        color: theme.colorScheme.onSurfaceVariant,
                        height: 1.4,
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }

  (Color, IconData) _profileStyle(String profile) {
    switch (profile.toLowerCase()) {
      case 'athletic':
        return (const Color(0xFF6C5CE7), Icons.bolt_rounded);
      case 'fit':
        return (const Color(0xFF00B894), Icons.fitness_center_rounded);
      case 'average':
        return (const Color(0xFF74B9FF), Icons.person_rounded);
      case 'overfat':
        return (const Color(0xFFE17055), Icons.monitor_weight_outlined);
      case 'obese':
        return (const Color(0xFFE53E3E), Icons.warning_rounded);
      case 'lean':
        return (const Color(0xFF00CEC9), Icons.star_rounded);
      default:
        return (const Color(0xFF6C5CE7), Icons.person_rounded);
    }
  }

  String _profileDescription(String profile) {
    switch (profile.toLowerCase()) {
      case 'athletic':
        return 'Excellent muscle definition with very low body fat. Peak performance range.';
      case 'fit':
        return 'Good muscle tone with healthy body fat levels. Active lifestyle reflected.';
      case 'lean':
        return 'Very low body fat with visible muscle definition. Highly conditioned physique.';
      case 'average':
        return 'Typical body composition for your demographic. Room for improvement.';
      case 'overfat':
        return 'Body fat above optimal range. Focused training and nutrition recommended.';
      case 'obese':
        return 'Elevated body fat levels. Consult a healthcare professional for guidance.';
      default:
        return 'Body composition analysis complete.';
    }
  }
}

// ─── Skeleton helpers ─────────────────────────────────────────────────────────

class _ShimmerBox extends StatelessWidget {
  final double width;
  final double height;

  const _ShimmerBox({required this.width, required this.height});

  @override
  Widget build(BuildContext context) {
    return Container(
      width: width,
      height: height,
      decoration: BoxDecoration(
        color: Colors.white.withValues(alpha: 0.15),
        borderRadius: BorderRadius.circular(6.0),
      ),
    );
  }
}

class _SkeletonStat extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Container(
          width: 18,
          height: 18,
          decoration: BoxDecoration(
            color: Colors.white.withValues(alpha: 0.2),
            shape: BoxShape.circle,
          ),
        ),
        const SizedBox(height: 6),
        Container(
          width: 40,
          height: 14,
          decoration: BoxDecoration(
            color: Colors.white.withValues(alpha: 0.25),
            borderRadius: BorderRadius.circular(4.0),
          ),
        ),
        const SizedBox(height: 4),
        Container(
          width: 30,
          height: 10,
          decoration: BoxDecoration(
            color: Colors.white.withValues(alpha: 0.15),
            borderRadius: BorderRadius.circular(4.0),
          ),
        ),
      ],
    );
  }
}

// ─── Sub-widgets ─────────────────────────────────────────────────────────────

class _HeroStat extends StatelessWidget {
  final String label;
  final String value;
  final IconData icon;

  const _HeroStat({
    required this.label,
    required this.value,
    required this.icon,
  });

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Icon(icon, color: Colors.white.withValues(alpha: 0.7), size: 18),
        SizedBox(height: 0.8.h),
        Text(
          value,
          style: GoogleFonts.dmSans(
            fontSize: 16.sp,
            fontWeight: FontWeight.w800,
            color: Colors.white,
          ),
        ),
        Text(
          label,
          style: GoogleFonts.dmSans(
            fontSize: 10.sp,
            color: Colors.white.withValues(alpha: 0.7),
          ),
        ),
      ],
    );
  }
}

class _CompositionBar extends StatelessWidget {
  final String label;
  final double percent;
  final double maxPercent;
  final Color color;
  final ThemeData theme;

  const _CompositionBar({
    required this.label,
    required this.percent,
    required this.maxPercent,
    required this.color,
    required this.theme,
  });

  @override
  Widget build(BuildContext context) {
    final fraction = (percent / maxPercent).clamp(0.0, 1.0);
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Text(
              label,
              style: GoogleFonts.dmSans(
                fontSize: 12.sp,
                fontWeight: FontWeight.w600,
                color: theme.colorScheme.onSurface,
              ),
            ),
            Text(
              '${percent.toStringAsFixed(1)}%',
              style: GoogleFonts.dmSans(
                fontSize: 12.sp,
                fontWeight: FontWeight.w700,
                color: color,
              ),
            ),
          ],
        ),
        SizedBox(height: 0.6.h),
        ClipRRect(
          borderRadius: BorderRadius.circular(6.0),
          child: LinearProgressIndicator(
            value: fraction,
            minHeight: 8,
            backgroundColor: color.withValues(alpha: 0.12),
            valueColor: AlwaysStoppedAnimation<Color>(color),
          ),
        ),
      ],
    );
  }
}

class _ZoneRow extends StatelessWidget {
  final String zone;
  final double percent;
  final ThemeData theme;

  const _ZoneRow({
    required this.zone,
    required this.percent,
    required this.theme,
  });

  @override
  Widget build(BuildContext context) {
    final fraction = (percent / 50.0).clamp(0.0, 1.0);
    final color = _zoneColor(zone);
    return Row(
      children: [
        Container(
          width: 8,
          height: 8,
          decoration: BoxDecoration(shape: BoxShape.circle, color: color),
        ),
        SizedBox(width: 2.w),
        Expanded(
          flex: 3,
          child: Text(
            zone,
            style: GoogleFonts.dmSans(
              fontSize: 12.sp,
              fontWeight: FontWeight.w500,
              color: theme.colorScheme.onSurface,
            ),
          ),
        ),
        Expanded(
          flex: 5,
          child: ClipRRect(
            borderRadius: BorderRadius.circular(4.0),
            child: LinearProgressIndicator(
              value: fraction,
              minHeight: 6,
              backgroundColor: color.withValues(alpha: 0.12),
              valueColor: AlwaysStoppedAnimation<Color>(color),
            ),
          ),
        ),
        SizedBox(width: 2.w),
        SizedBox(
          width: 10.w,
          child: Text(
            '${percent.toStringAsFixed(1)}%',
            textAlign: TextAlign.end,
            style: GoogleFonts.dmSans(
              fontSize: 11.sp,
              fontWeight: FontWeight.w700,
              color: color,
            ),
          ),
        ),
      ],
    );
  }

  Color _zoneColor(String zone) {
    switch (zone) {
      case 'Bras Gauche':
        return const Color(0xFF6C5CE7);
      case 'Bras Droit':
        return const Color(0xFF74B9FF);
      case 'Haut du Corps':
        return const Color(0xFF00B894);
      case 'Jambe Gauche':
        return const Color(0xFFFDCB6E);
      case 'Jambe Droite':
        return const Color(0xFFE17055);
      default:
        return const Color(0xFF6C5CE7);
    }
  }
}
