import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:sizer/sizer.dart';
import 'package:share_plus/share_plus.dart';
import 'package:webview_flutter/webview_flutter.dart';

import '../../services/supabase_service.dart';
import '../../services/local_cache_service.dart';
import '../../services/sync_service.dart';
import '../../routes/app_routes.dart';
import '../../providers/language_provider.dart';

class SettingsScreen extends StatefulWidget {
  const SettingsScreen({super.key});

  @override
  State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  // Profile state
  String _name = '';
  String _email = '';
  String _goal = '';

  // Unit preferences
  bool _useKg = true;
  bool _useCm = true;

  // Edit mode
  bool _isEditMode = false;
  bool _isSaving = false;
  late TextEditingController _nameCtrl;
  late TextEditingController _emailCtrl;
  String _editGoal = '';

  // Notifications
  bool _progressReminders = true;

  // Subscription
  String _currentPlan = 'Gratuit';
  bool _isPremium = false;
  bool _isLoading = true;

  // Export
  bool _isExporting = false;

  // Delete
  bool _isDeleting = false;

  static const List<String> _goalOptions = [
    'Perdre de la graisse',
    'Prendre du muscle',
    'Maintenir',
    'Performance athlétique',
  ];

  static const String _appInviteLink =
      'https://evolyai.com';

  @override
  void initState() {
    super.initState();
    _nameCtrl = TextEditingController();
    _emailCtrl = TextEditingController();
    _loadProfile();
  }

  @override
  void dispose() {
    _nameCtrl.dispose();
    _emailCtrl.dispose();
    super.dispose();
  }

  Future<void> _loadProfile() async {
    setState(() => _isLoading = true);
    try {
      final results = await Future.wait([
        SupabaseService.instance.fetchProfile(),
        SupabaseService.instance.checkSubscriptionStatus(),
        SupabaseService.instance.loadOnboardingAnswers(),
      ]);
      final profile = results[0] as ProfileModel?;
      final isPremium = results[1] as bool;
      final onboarding = results[2] as OnboardingAnswersModel?;

      if (profile != null) {
        await LocalCacheService.instance.cacheProfile(profile.toJson());
      }
      if (onboarding != null) {
        await LocalCacheService.instance.cacheOnboarding(onboarding.toJson());
      }

      if (mounted) {
        setState(() {
          _name = profile?.fullName ?? '';
          _email =
              profile?.email ??
              SupabaseService.instance.currentUser?.email ??
              '';
          _useKg = (profile?.weightUnit ?? 'kg') == 'kg';
          _useCm = (profile?.heightUnit ?? 'cm') == 'cm';
          _goal = _normalizeGoal(onboarding?.goal ?? '');
          _isPremium = isPremium;
          _currentPlan = isPremium ? 'Premium' : 'Gratuit';
          _isLoading = false;
        });
      }
    } catch (e) {
      final cachedProfile = await LocalCacheService.instance.getCachedProfile();
      final cachedOnboarding = await LocalCacheService.instance
          .getCachedOnboarding();
      if (mounted) {
        setState(() {
          if (cachedProfile != null) {
            _name = cachedProfile['full_name'] as String? ?? '';
            _email =
                cachedProfile['email'] as String? ??
                SupabaseService.instance.currentUser?.email ??
                '';
            _useKg = (cachedProfile['weight_unit'] as String? ?? 'kg') == 'kg';
            _useCm = (cachedProfile['height_unit'] as String? ?? 'cm') == 'cm';
          } else {
            _email = SupabaseService.instance.currentUser?.email ?? '';
          }
          if (cachedOnboarding != null) {
            _goal = _normalizeGoal(cachedOnboarding['goal'] as String? ?? '');
          }
          _isLoading = false;
        });
      }
    }
  }

  String _normalizeGoal(String raw) {
    switch (raw.toLowerCase().replaceAll('_', ' ').trim()) {
      case 'lose fat':
        return 'Perdre de la graisse';
      case 'build muscle':
        return 'Prendre du muscle';
      case 'maintain':
        return 'Maintenir';
      case 'athletic performance':
        return 'Performance athlétique';
      default:
        return raw.isEmpty ? '' : raw;
    }
  }

  void _enterEditMode() {
    setState(() {
      _isEditMode = true;
      _nameCtrl.text = _name;
      _emailCtrl.text = _email;
      _editGoal = _goal;
    });
  }

  void _cancelEdit() {
    setState(() {
      _isEditMode = false;
    });
  }

  Future<void> _saveChanges() async {
    if (_isSaving) return;
    setState(() => _isSaving = true);
    HapticFeedback.mediumImpact();

    final newName = _nameCtrl.text.trim();
    final newEmail = _emailCtrl.text.trim();
    final newGoal = _editGoal;
    final isOnline = SyncService.instance.isOnline;

    try {
      if (isOnline) {
        final profileUpdates = <String, dynamic>{
          'weight_unit': _useKg ? 'kg' : 'lbs',
          'height_unit': _useCm ? 'cm' : 'ft',
        };
        if (newName.isNotEmpty) profileUpdates['full_name'] = newName;
        if (newEmail.isNotEmpty) profileUpdates['email'] = newEmail;

        await SupabaseService.instance.updateProfile(profileUpdates);

        if (newGoal.isNotEmpty) {
          final goalKey = newGoal.toLowerCase().replaceAll(' ', '_');
          await SupabaseService.instance.updateOnboardingAnswers({
            'goal': goalKey,
          });
        }

        final cachedProfile =
            await LocalCacheService.instance.getCachedProfile() ?? {};
        cachedProfile['full_name'] = newName.isNotEmpty ? newName : _name;
        cachedProfile['email'] = newEmail.isNotEmpty ? newEmail : _email;
        cachedProfile['weight_unit'] = _useKg ? 'kg' : 'lbs';
        cachedProfile['height_unit'] = _useCm ? 'cm' : 'ft';
        await LocalCacheService.instance.cacheProfile(cachedProfile);
      } else {
        final profileUpdates = <String, dynamic>{
          'weight_unit': _useKg ? 'kg' : 'lbs',
          'height_unit': _useCm ? 'cm' : 'ft',
        };
        if (newName.isNotEmpty) profileUpdates['full_name'] = newName;
        if (newEmail.isNotEmpty) profileUpdates['email'] = newEmail;

        await LocalCacheService.instance.enqueueAction({
          'type': 'updateProfile',
          'updates': profileUpdates,
        });
        if (newGoal.isNotEmpty) {
          await LocalCacheService.instance.enqueueAction({
            'type': 'updateOnboarding',
            'updates': {'goal': newGoal.toLowerCase().replaceAll(' ', '_')},
          });
        }
      }

      if (mounted) {
        setState(() {
          if (newName.isNotEmpty) _name = newName;
          if (newEmail.isNotEmpty) _email = newEmail;
          if (newGoal.isNotEmpty) _goal = newGoal;
          _isEditMode = false;
          _isSaving = false;
        });
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(
              isOnline
                  ? 'Profile saved!'
                  : 'Sauvegardé localement — sync dès la reconnexion',
            ),
            behavior: SnackBarBehavior.floating,
            backgroundColor: const Color(0xFF6C5CE7),
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(10),
            ),
            duration: const Duration(seconds: 2),
          ),
        );
      }
    } catch (e) {
      if (mounted) {
        setState(() => _isSaving = false);
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: const Text('Échec de la sauvegarde. Veuillez réessayer.'),
            behavior: SnackBarBehavior.floating,
            backgroundColor: const Color(0xFFE53E3E),
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(10),
            ),
          ),
        );
      }
    }
  }

  Future<void> _saveUnitPreferences() async {
    try {
      await SupabaseService.instance.updateProfile({
        'weight_unit': _useKg ? 'kg' : 'lbs',
        'height_unit': _useCm ? 'cm' : 'ft',
      });
    } catch (e) {
      debugPrint('saveUnitPreferences error: $e');
    }
  }

  Future<void> _signOut() async {
    try {
      await SupabaseService.instance.signOut();
      if (mounted) {
        Navigator.of(
          context,
        ).pushNamedAndRemoveUntil(AppRoutes.initial, (route) => false);
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Échec de la déconnexion : $e'),
            behavior: SnackBarBehavior.floating,
          ),
        );
      }
    }
  }

  // ─── Export ───────────────────────────────────────────────────────────────

  Future<void> _exportData() async {
    if (_isExporting) return;
    setState(() => _isExporting = true);
    HapticFeedback.mediumImpact();

    try {
      // Fetch all data
      final scanResults = await SupabaseService.instance.fetchScanResultHistory(
        limit: 100,
      );
      final profile = await SupabaseService.instance.fetchProfile();
      final onboarding = await SupabaseService.instance.loadOnboardingAnswers();

      final buffer = StringBuffer();

      // Profile section
      buffer.writeln('=== Evoly AI — Export de mes données ===');
      buffer.writeln('Exported: ${DateTime.now().toLocal()}');
      buffer.writeln();
      buffer.writeln('--- Profile ---');
      buffer.writeln('Name: ${profile?.fullName ?? _name}');
      buffer.writeln('Email: ${profile?.email ?? _email}');
      buffer.writeln('Plan: $_currentPlan');
      buffer.writeln('Weight Unit: ${_useKg ? 'kg' : 'lbs'}');
      buffer.writeln('Height Unit: ${_useCm ? 'cm' : 'ft'}');
      if (onboarding != null) {
        buffer.writeln('Goal: ${_normalizeGoal(onboarding.goal ?? '')}');
        buffer.writeln('Gender: ${onboarding.gender ?? ''}');
        buffer.writeln('Age: ${onboarding.age ?? ''}');
        buffer.writeln(
          'Height: ${onboarding.heightValue?.toStringAsFixed(1) ?? ''} ${onboarding.heightUnit ?? ''}',
        );
        buffer.writeln(
          'Weight: ${onboarding.weightValue?.toStringAsFixed(1) ?? ''} ${onboarding.weightUnit ?? ''}',
        );
        buffer.writeln('Activity Level: ${onboarding.activityLevel ?? ''}');
      }
      buffer.writeln();

      // Scan history section
      buffer.writeln('--- Scan History (${scanResults.length} scans) ---');
      if (scanResults.isEmpty) {
        buffer.writeln('No scans recorded yet.');
      } else {
        buffer.writeln('Date,Body Fat %,Lean Mass (kg),Category,Score');
        for (final r in scanResults) {
          final date = r.createdAt != null
              ? '${r.createdAt!.year}-${r.createdAt!.month.toString().padLeft(2, '0')}-${r.createdAt!.day.toString().padLeft(2, '0')}'
              : 'Unknown';
          buffer.writeln(
            '$date,${r.bodyFatPercent?.toStringAsFixed(1) ?? ''},${r.leanMassEstimate?.toStringAsFixed(1) ?? ''},${r.bodyCategory ?? ''},${r.bodyScore?.toStringAsFixed(1) ?? ''}',
          );
        }
      }
      buffer.writeln();
      buffer.writeln('--- Body Fat Results ---');
      if (scanResults.isNotEmpty) {
        final latest = scanResults.first;
        final first = scanResults.last;
        buffer.writeln(
          'Latest Body Fat: ${latest.bodyFatPercent?.toStringAsFixed(1) ?? 'N/A'}%',
        );
        buffer.writeln(
          'Starting Body Fat: ${first.bodyFatPercent?.toStringAsFixed(1) ?? 'N/A'}%',
        );
        if (latest.bodyFatPercent != null && first.bodyFatPercent != null) {
          final change = latest.bodyFatPercent! - first.bodyFatPercent!;
          buffer.writeln(
            'Change: ${change >= 0 ? '+' : ''}${change.toStringAsFixed(1)}%',
          );
        }
        buffer.writeln(
          'Latest Lean Mass: ${latest.leanMassEstimate?.toStringAsFixed(1) ?? 'N/A'} kg',
        );
        buffer.writeln('Physique Profile: ${latest.bodyCategory ?? 'N/A'}');
      }

      final exportText = buffer.toString();

      if (mounted) {
        setState(() => _isExporting = false);
        await Share.share(
          exportText,
          subject: 'Evoly AI — Mes données de composition corporelle',
        );
      }
    } catch (e) {
      if (mounted) {
        setState(() => _isExporting = false);
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: const Text('Exportation échouée. Veuillez réessayer.'),
            behavior: SnackBarBehavior.floating,
            backgroundColor: const Color(0xFFE53E3E),
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(10),
            ),
          ),
        );
      }
    }
  }

  // ─── Invite Friends ───────────────────────────────────────────────────────

  Future<void> _shareInviteLink() async {
    HapticFeedback.mediumImpact();
    try {
      await Share.share(
        'Découvre Evoly AI — the AI-powered body composition scanner! 💪\n\n$_appInviteLink',
        subject: 'Rejoins-moi sur Evoly AI',
      );
    } catch (e) {
      debugPrint('shareInviteLink error: $e');
    }
  }

  // ─── Delete Account ───────────────────────────────────────────────────────

  Future<void> _deleteAccount() async {
    if (_isDeleting) return;
    setState(() => _isDeleting = true);
    HapticFeedback.heavyImpact();

    try {
      await SupabaseService.instance.deleteAccount();
      if (mounted) {
        Navigator.of(
          context,
        ).pushNamedAndRemoveUntil(AppRoutes.initial, (route) => false);
      }
    } catch (e) {
      // Even if admin delete fails, sign out the user
      try {
        await SupabaseService.instance.signOut();
        if (mounted) {
          Navigator.of(
            context,
          ).pushNamedAndRemoveUntil(AppRoutes.initial, (route) => false);
        }
      } catch (_) {
        if (mounted) {
          setState(() => _isDeleting = false);
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(
              content: const Text(
                'Échec de la suppression. Veuillez contacter le support.',
              ),
              behavior: SnackBarBehavior.floating,
              backgroundColor: const Color(0xFFE53E3E),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(10),
              ),
            ),
          );
        }
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    if (_isLoading) {
      return Scaffold(
        backgroundColor: theme.scaffoldBackgroundColor,
        body: const Center(
          child: CircularProgressIndicator(color: Color(0xFF6C5CE7)),
        ),
      );
    }

    return Scaffold(
      backgroundColor: theme.scaffoldBackgroundColor,
      body: SafeArea(
        child: CustomScrollView(
          physics: const BouncingScrollPhysics(),
          slivers: [
            SliverToBoxAdapter(
              child: Padding(
                padding: EdgeInsets.symmetric(horizontal: 4.w, vertical: 2.h),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    _buildHeader(theme),
                    SizedBox(height: 2.5.h),
                    _buildProfileCard(theme),
                    SizedBox(height: 2.h),
                    if (_isEditMode) ...[
                      _buildEditForm(theme),
                      SizedBox(height: 2.h),
                    ],
                    _buildSectionLabel('Compte', theme),
                    _buildAccountSection(theme),
                    SizedBox(height: 2.h),
                    _buildSectionLabel('Abonnement', theme),
                    _buildSubscriptionSection(theme),
                    SizedBox(height: 2.h),
                    _buildSectionLabel('Notifications', theme),
                    _buildNotificationsSection(theme),
                    SizedBox(height: 2.h),
                    _buildSectionLabel('Parrainer des amis', theme),
                    _buildInviteFriendsSection(theme),
                    SizedBox(height: 2.h),
                    _buildSectionLabel('Programme Créateur', theme),
                    _buildCreatorProgramSection(theme),
                    SizedBox(height: 2.h),
                    _buildSectionLabel('Légal & Support', theme),
                    _buildLegalSection(theme),
                    SizedBox(height: 2.h),
                    _buildSectionLabel('Langue', theme),
                    _buildLanguageSection(theme),
                    SizedBox(height: 2.h),
                    _buildSignOutButton(theme),
                    SizedBox(height: 1.h),
                    _buildDeleteAccountButton(theme),
                    SizedBox(height: 12.h),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildHeader(ThemeData theme) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Text(
          'Paramètres',
          style: GoogleFonts.dmSans(
            fontSize: 18.sp,
            fontWeight: FontWeight.w700,
            color: theme.colorScheme.onSurface,
          ),
        ),
        ListenableBuilder(
          listenable: SyncService.instance,
          builder: (_, __) =>
              _SyncStatusChip(status: SyncService.instance.status),
        ),
      ],
    );
  }

  Widget _buildProfileCard(ThemeData theme) {
    return Container(
      padding: EdgeInsets.all(4.w),
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          colors: [Color(0xFF1B365D), Color(0xFF6C5CE7)],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(18.0),
        boxShadow: [
          BoxShadow(
            color: const Color(0xFF6C5CE7).withValues(alpha: 0.3),
            blurRadius: 20,
            offset: const Offset(0, 6),
          ),
        ],
      ),
      child: Row(
        children: [
          Container(
            width: 14.w,
            height: 14.w,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: Colors.white.withValues(alpha: 0.2),
              border: Border.all(
                color: Colors.white.withValues(alpha: 0.4),
                width: 2,
              ),
            ),
            child: const Icon(
              Icons.person_rounded,
              color: Colors.white,
              size: 28,
            ),
          ),
          SizedBox(width: 3.w),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  _name.isEmpty ? 'Votre nom' : _name,
                  style: GoogleFonts.dmSans(
                    fontSize: 14.sp,
                    fontWeight: FontWeight.w700,
                    color: Colors.white,
                  ),
                ),
                Text(
                  _email,
                  style: GoogleFonts.dmSans(
                    fontSize: 11.sp,
                    color: Colors.white.withValues(alpha: 0.75),
                  ),
                  overflow: TextOverflow.ellipsis,
                ),
                if (_goal.isNotEmpty) ...[
                  SizedBox(height: 0.3.h),
                  Text(
                    'Objectif : $_goal',
                    style: GoogleFonts.dmSans(
                      fontSize: 10.sp,
                      color: Colors.white.withValues(alpha: 0.65),
                    ),
                  ),
                ],
                SizedBox(height: 0.5.h),
                Container(
                  padding: EdgeInsets.symmetric(
                    horizontal: 2.w,
                    vertical: 0.3.h,
                  ),
                  decoration: BoxDecoration(
                    color: _isPremium
                        ? const Color(0xFFFFD700).withValues(alpha: 0.25)
                        : Colors.white.withValues(alpha: 0.2),
                    borderRadius: BorderRadius.circular(8.0),
                    border: _isPremium
                        ? Border.all(
                            color: const Color(
                              0xFFFFD700,
                            ).withValues(alpha: 0.5),
                          )
                        : null,
                  ),
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      if (_isPremium) ...[
                        const Icon(
                          Icons.workspace_premium_rounded,
                          color: Color(0xFFFFD700),
                          size: 12,
                        ),
                        SizedBox(width: 1.w),
                      ],
                      Text(
                        'Plan $_currentPlan',
                        style: GoogleFonts.dmSans(
                          fontSize: 10.sp,
                          fontWeight: FontWeight.w600,
                          color: _isPremium
                              ? const Color(0xFFFFD700)
                              : Colors.white,
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
          GestureDetector(
            onTap: _isEditMode ? _cancelEdit : _enterEditMode,
            child: Container(
              padding: const EdgeInsets.all(8),
              decoration: BoxDecoration(
                color: Colors.white.withValues(alpha: 0.2),
                borderRadius: BorderRadius.circular(10.0),
              ),
              child: Icon(
                _isEditMode ? Icons.close_rounded : Icons.edit_rounded,
                color: Colors.white,
                size: 18,
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildEditForm(ThemeData theme) {
    final isDark = theme.brightness == Brightness.dark;
    return Container(
      padding: EdgeInsets.all(4.w),
      decoration: BoxDecoration(
        color: isDark ? const Color(0xFF1E2E4A) : Colors.white,
        borderRadius: BorderRadius.circular(16.0),
        border: Border.all(
          color: const Color(0xFF6C5CE7).withValues(alpha: 0.3),
        ),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: 0.05),
            blurRadius: 12,
            offset: const Offset(0, 3),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'Edit Profile',
            style: GoogleFonts.dmSans(
              fontSize: 14.sp,
              fontWeight: FontWeight.w700,
              color: theme.colorScheme.onSurface,
            ),
          ),
          SizedBox(height: 2.h),
          TextField(
            controller: _nameCtrl,
            decoration: InputDecoration(
              labelText: 'Nom complet',
              prefixIcon: const Icon(Icons.person_outline_rounded),
              border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(12),
              ),
              contentPadding: const EdgeInsets.symmetric(
                horizontal: 16,
                vertical: 14,
              ),
            ),
          ),
          SizedBox(height: 1.5.h),
          TextField(
            controller: _emailCtrl,
            keyboardType: TextInputType.emailAddress,
            decoration: InputDecoration(
              labelText: 'Email',
              prefixIcon: const Icon(Icons.email_outlined),
              border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(12),
              ),
              contentPadding: const EdgeInsets.symmetric(
                horizontal: 16,
                vertical: 14,
              ),
            ),
          ),
          SizedBox(height: 1.5.h),
          Text(
            'Objectif',
            style: GoogleFonts.dmSans(
              fontSize: 12.sp,
              fontWeight: FontWeight.w600,
              color: theme.colorScheme.onSurfaceVariant,
            ),
          ),
          SizedBox(height: 0.8.h),
          Wrap(
            spacing: 2.w,
            runSpacing: 0.8.h,
            children: _goalOptions.map((g) {
              final selected = _editGoal == g;
              return GestureDetector(
                onTap: () {
                  HapticFeedback.lightImpact();
                  setState(() => _editGoal = g);
                },
                child: AnimatedContainer(
                  duration: const Duration(milliseconds: 200),
                  padding: EdgeInsets.symmetric(
                    horizontal: 3.w,
                    vertical: 0.8.h,
                  ),
                  decoration: BoxDecoration(
                    color: selected
                        ? const Color(0xFF6C5CE7)
                        : theme.colorScheme.outline.withValues(alpha: 0.1),
                    borderRadius: BorderRadius.circular(20.0),
                    border: Border.all(
                      color: selected
                          ? const Color(0xFF6C5CE7)
                          : theme.colorScheme.outline.withValues(alpha: 0.2),
                    ),
                  ),
                  child: Text(
                    g,
                    style: GoogleFonts.dmSans(
                      fontSize: 11.sp,
                      fontWeight: FontWeight.w600,
                      color: selected
                          ? Colors.white
                          : theme.colorScheme.onSurfaceVariant,
                    ),
                  ),
                ),
              );
            }).toList(),
          ),
          SizedBox(height: 1.5.h),
          Text(
            'Unités',
            style: GoogleFonts.dmSans(
              fontSize: 12.sp,
              fontWeight: FontWeight.w600,
              color: theme.colorScheme.onSurfaceVariant,
            ),
          ),
          SizedBox(height: 0.8.h),
          Row(
            children: [
              Expanded(
                child: _SettingsToggleRow(
                  label: 'Poids',
                  leftOption: 'kg',
                  rightOption: 'lbs',
                  isLeft: _useKg,
                  onChanged: (val) {
                    HapticFeedback.lightImpact();
                    setState(() => _useKg = val);
                  },
                  theme: theme,
                ),
              ),
              SizedBox(width: 2.w),
              Expanded(
                child: _SettingsToggleRow(
                  label: 'Taille',
                  leftOption: 'cm',
                  rightOption: 'ft',
                  isLeft: _useCm,
                  onChanged: (val) {
                    HapticFeedback.lightImpact();
                    setState(() => _useCm = val);
                  },
                  theme: theme,
                ),
              ),
            ],
          ),
          SizedBox(height: 2.h),
          GestureDetector(
            onTap: _isSaving ? null : _saveChanges,
            child: AnimatedContainer(
              duration: const Duration(milliseconds: 200),
              width: double.infinity,
              padding: EdgeInsets.symmetric(vertical: 1.6.h),
              decoration: BoxDecoration(
                gradient: _isSaving
                    ? null
                    : const LinearGradient(
                        colors: [Color(0xFF1B365D), Color(0xFF6C5CE7)],
                      ),
                color: _isSaving
                    ? const Color(0xFF6C5CE7).withValues(alpha: 0.4)
                    : null,
                borderRadius: BorderRadius.circular(14.0),
              ),
              child: Center(
                child: _isSaving
                    ? const SizedBox(
                        width: 20,
                        height: 20,
                        child: CircularProgressIndicator(
                          color: Colors.white,
                          strokeWidth: 2,
                        ),
                      )
                    : Text(
                        'Sauvegarder',
                        style: GoogleFonts.dmSans(
                          fontSize: 14.sp,
                          fontWeight: FontWeight.w600,
                          color: Colors.white,
                        ),
                      ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildSectionLabel(String label, ThemeData theme) {
    return Padding(
      padding: EdgeInsets.only(bottom: 1.h),
      child: Text(
        label.toUpperCase(),
        style: GoogleFonts.dmSans(
          fontSize: 10.sp,
          fontWeight: FontWeight.w700,
          color: theme.colorScheme.onSurfaceVariant,
          letterSpacing: 1.2,
        ),
      ),
    );
  }

  Widget _buildAccountSection(ThemeData theme) {
    return _SettingsCard(
      theme: theme,
      children: [
        _SettingsTile(
          icon: Icons.person_outline_rounded,
          label: 'Edit Profile',
          onTap: _isEditMode ? _cancelEdit : _enterEditMode,
          theme: theme,
        ),
        _SettingsDivider(theme: theme),
        _SettingsToggleRow(
          label: 'Weight Unit',
          leftOption: 'kg',
          rightOption: 'lbs',
          isLeft: _useKg,
          onChanged: (val) {
            HapticFeedback.lightImpact();
            setState(() => _useKg = val);
            _saveUnitPreferences();
          },
          theme: theme,
        ),
        _SettingsDivider(theme: theme),
        _SettingsToggleRow(
          label: 'Height Unit',
          leftOption: 'cm',
          rightOption: 'ft',
          isLeft: _useCm,
          onChanged: (val) {
            HapticFeedback.lightImpact();
            setState(() => _useCm = val);
            _saveUnitPreferences();
          },
          theme: theme,
        ),
        _SettingsDivider(theme: theme),
        _SettingsTile(
          icon: Icons.download_outlined,
          label: _isExporting ? 'Exportation…' : 'Exporter mes données',
          onTap: _isExporting ? () {} : _exportData,
          theme: theme,
        ),
      ],
    );
  }

  Widget _buildSubscriptionSection(ThemeData theme) {
    return _SettingsCard(
      theme: theme,
      children: [
        Padding(
          padding: EdgeInsets.all(3.5.w),
          child: Row(
            children: [
              Container(
                padding: const EdgeInsets.all(8),
                decoration: BoxDecoration(
                  gradient: const LinearGradient(
                    colors: [Color(0xFF6C5CE7), Color(0xFF74B9FF)],
                  ),
                  borderRadius: BorderRadius.circular(10.0),
                ),
                child: const Icon(
                  Icons.workspace_premium_rounded,
                  color: Colors.white,
                  size: 18,
                ),
              ),
              SizedBox(width: 3.w),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      _isPremium
                          ? 'Plan actuel : Premium'
                          : 'Plan actuel : Gratuit',
                      style: GoogleFonts.dmSans(
                        fontSize: 13.sp,
                        fontWeight: FontWeight.w600,
                        color: theme.colorScheme.onSurface,
                      ),
                    ),
                    Text(
                      _isPremium
                          ? 'You have full access to all features'
                          : 'Passez Premium pour des scans illimités et rapports complets',
                      style: GoogleFonts.dmSans(
                        fontSize: 10.sp,
                        color: theme.colorScheme.onSurfaceVariant,
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
        if (!_isPremium)
          Padding(
            padding: EdgeInsets.fromLTRB(3.5.w, 0, 3.5.w, 3.5.w),
            child: GestureDetector(
              onTap: () {
                HapticFeedback.mediumImpact();
                _showUpgradeDialog(theme);
              },
              child: Container(
                width: double.infinity,
                padding: EdgeInsets.symmetric(vertical: 1.4.h),
                decoration: BoxDecoration(
                  gradient: const LinearGradient(
                    colors: [Color(0xFF6C5CE7), Color(0xFF74B9FF)],
                  ),
                  borderRadius: BorderRadius.circular(12.0),
                ),
                child: Center(
                  child: Text(
                    'Passer à Premium',
                    style: GoogleFonts.dmSans(
                      fontSize: 13.sp,
                      fontWeight: FontWeight.w600,
                      color: Colors.white,
                    ),
                  ),
                ),
              ),
            ),
          ),
        if (_isPremium)
          Padding(
            padding: EdgeInsets.fromLTRB(3.5.w, 0, 3.5.w, 3.5.w),
            child: Container(
              width: double.infinity,
              padding: EdgeInsets.symmetric(vertical: 1.2.h),
              decoration: BoxDecoration(
                color: const Color(0xFFFFD700).withValues(alpha: 0.1),
                borderRadius: BorderRadius.circular(12.0),
                border: Border.all(
                  color: const Color(0xFFFFD700).withValues(alpha: 0.4),
                ),
              ),
              child: Center(
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    const Icon(
                      Icons.check_circle_rounded,
                      color: Color(0xFFFFD700),
                      size: 16,
                    ),
                    SizedBox(width: 2.w),
                    Text(
                      'Premium Active',
                      style: GoogleFonts.dmSans(
                        fontSize: 13.sp,
                        fontWeight: FontWeight.w600,
                        color: const Color(0xFFFFD700),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
      ],
    );
  }

  Widget _buildNotificationsSection(ThemeData theme) {
    return _SettingsCard(
      theme: theme,
      children: [
        Padding(
          padding: EdgeInsets.symmetric(horizontal: 3.5.w, vertical: 1.h),
          child: Row(
            children: [
              Container(
                padding: const EdgeInsets.all(8),
                decoration: BoxDecoration(
                  color: const Color(0xFF00B894).withValues(alpha: 0.12),
                  borderRadius: BorderRadius.circular(10.0),
                ),
                child: const Icon(
                  Icons.notifications_outlined,
                  color: Color(0xFF00B894),
                  size: 18,
                ),
              ),
              SizedBox(width: 3.w),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'Progress Reminders',
                      style: GoogleFonts.dmSans(
                        fontSize: 13.sp,
                        fontWeight: FontWeight.w600,
                        color: theme.colorScheme.onSurface,
                      ),
                    ),
                    Text(
                      'Weekly scan reminders & milestone alerts',
                      style: GoogleFonts.dmSans(
                        fontSize: 10.sp,
                        color: theme.colorScheme.onSurfaceVariant,
                      ),
                    ),
                  ],
                ),
              ),
              Switch(
                value: _progressReminders,
                onChanged: (val) {
                  HapticFeedback.lightImpact();
                  setState(() => _progressReminders = val);
                },
                activeThumbColor: const Color(0xFF6C5CE7),
              ),
            ],
          ),
        ),
      ],
    );
  }

  Widget _buildInviteFriendsSection(ThemeData theme) {
    final isDark = theme.brightness == Brightness.dark;
    return Container(
      decoration: BoxDecoration(
        color: isDark ? const Color(0xFF1E2E4A) : Colors.white,
        borderRadius: BorderRadius.circular(16.0),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: 0.05),
            blurRadius: 12,
            offset: const Offset(0, 3),
          ),
        ],
      ),
      child: Padding(
        padding: EdgeInsets.all(4.w),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Container(
                  padding: const EdgeInsets.all(8),
                  decoration: BoxDecoration(
                    gradient: const LinearGradient(
                      colors: [Color(0xFFFF7675), Color(0xFFE17055)],
                    ),
                    borderRadius: BorderRadius.circular(10.0),
                  ),
                  child: const Icon(
                    Icons.card_giftcard_rounded,
                    color: Colors.white,
                    size: 18,
                  ),
                ),
                SizedBox(width: 3.w),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'Invitez des amis, gagnez 5€',
                        style: GoogleFonts.dmSans(
                          fontSize: 13.sp,
                          fontWeight: FontWeight.w700,
                          color: theme.colorScheme.onSurface,
                        ),
                      ),
                      Text(
                        'Vous et votre ami recevez chacun 5€ de crédit',
                        style: GoogleFonts.dmSans(
                          fontSize: 10.sp,
                          color: theme.colorScheme.onSurfaceVariant,
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
            SizedBox(height: 1.5.h),
            Container(
              padding: EdgeInsets.symmetric(horizontal: 3.w, vertical: 1.2.h),
              decoration: BoxDecoration(
                color: theme.colorScheme.outline.withValues(alpha: 0.08),
                borderRadius: BorderRadius.circular(10.0),
                border: Border.all(
                  color: theme.colorScheme.outline.withValues(alpha: 0.2),
                ),
              ),
              child: Row(
                children: [
                  Expanded(
                    child: Text(
                      _appInviteLink,
                      style: GoogleFonts.dmSans(
                        fontSize: 11.sp,
                        color: theme.colorScheme.onSurface,
                        fontWeight: FontWeight.w500,
                      ),
                      overflow: TextOverflow.ellipsis,
                    ),
                  ),
                  GestureDetector(
                    onTap: () {
                      HapticFeedback.lightImpact();
                      Clipboard.setData(
                        const ClipboardData(text: _appInviteLink),
                      );
                      ScaffoldMessenger.of(context).showSnackBar(
                        SnackBar(
                          content: const Text('Invite link copied!'),
                          behavior: SnackBarBehavior.floating,
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(10),
                          ),
                          duration: const Duration(seconds: 2),
                        ),
                      );
                    },
                    child: const Icon(Icons.copy_rounded, size: 18),
                  ),
                ],
              ),
            ),
            SizedBox(height: 1.h),
            GestureDetector(
              onTap: _shareInviteLink,
              child: Container(
                width: double.infinity,
                padding: EdgeInsets.symmetric(vertical: 1.2.h),
                decoration: BoxDecoration(
                  gradient: const LinearGradient(
                    colors: [Color(0xFFFF7675), Color(0xFFE17055)],
                  ),
                  borderRadius: BorderRadius.circular(10.0),
                ),
                child: Center(
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      const Icon(
                        Icons.share_rounded,
                        color: Colors.white,
                        size: 16,
                      ),
                      SizedBox(width: 2.w),
                      Text(
                        'Partager le lien d\'invitation',
                        style: GoogleFonts.dmSans(
                          fontSize: 12.sp,
                          fontWeight: FontWeight.w600,
                          color: Colors.white,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildCreatorProgramSection(ThemeData theme) {
    final isDark = theme.brightness == Brightness.dark;
    return Container(
      decoration: BoxDecoration(
        color: isDark ? const Color(0xFF1E2E4A) : Colors.white,
        borderRadius: BorderRadius.circular(16.0),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: 0.05),
            blurRadius: 12,
            offset: const Offset(0, 3),
          ),
        ],
      ),
      child: Padding(
        padding: EdgeInsets.all(4.w),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Container(
                  padding: const EdgeInsets.all(8),
                  decoration: BoxDecoration(
                    gradient: const LinearGradient(
                      colors: [Color(0xFFFDCB6E), Color(0xFFE17055)],
                    ),
                    borderRadius: BorderRadius.circular(10.0),
                  ),
                  child: const Icon(
                    Icons.videocam_rounded,
                    color: Colors.white,
                    size: 18,
                  ),
                ),
                SizedBox(width: 3.w),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'Become a Creator Partner',
                        style: GoogleFonts.dmSans(
                          fontSize: 13.sp,
                          fontWeight: FontWeight.w700,
                          color: theme.colorScheme.onSurface,
                        ),
                      ),
                      Text(
                        'Earn 40% revenue share on referrals',
                        style: GoogleFonts.dmSans(
                          fontSize: 10.sp,
                          color: theme.colorScheme.onSurfaceVariant,
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
            SizedBox(height: 1.5.h),
            GestureDetector(
              onTap: () => _showCreatorProgramForm(theme),
              child: Container(
                width: double.infinity,
                padding: EdgeInsets.symmetric(vertical: 1.2.h),
                decoration: BoxDecoration(
                  gradient: const LinearGradient(
                    colors: [Color(0xFFFDCB6E), Color(0xFFE17055)],
                  ),
                  borderRadius: BorderRadius.circular(10.0),
                ),
                child: Center(
                  child: Text(
                    'Apply Now',
                    style: GoogleFonts.dmSans(
                      fontSize: 12.sp,
                      fontWeight: FontWeight.w600,
                      color: Colors.white,
                    ),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildLegalSection(ThemeData theme) {
    return _SettingsCard(
      theme: theme,
      children: [
        _SettingsTile(
          icon: Icons.privacy_tip_outlined,
          label: 'Politique de confidentialité',
          onTap: () {
            HapticFeedback.lightImpact();
            Navigator.of(context).pushNamed(AppRoutes.privacyPolicy);
          },
          theme: theme,
          showArrow: true,
        ),
        _SettingsDivider(theme: theme),
        _SettingsTile(
          icon: Icons.description_outlined,
          label: 'Conditions d\'utilisation',
          onTap: () {
            HapticFeedback.lightImpact();
            Navigator.of(context).pushNamed(AppRoutes.termsOfUse);
          },
          theme: theme,
          showArrow: true,
        ),
        _SettingsDivider(theme: theme),
        _SettingsTile(
          icon: Icons.support_agent_outlined,
          label: 'Support',
          onTap: () {
            HapticFeedback.lightImpact();
            Navigator.of(context).pushNamed(AppRoutes.support);
          },
          theme: theme,
          showArrow: true,
        ),
        _SettingsDivider(theme: theme),
        _SettingsTile(
          icon: Icons.science_rounded,
          label: 'Base scientifique',
          onTap: () {
            HapticFeedback.lightImpact();
            Navigator.of(context).pushNamed(AppRoutes.science);
          },
          theme: theme,
          showArrow: true,
        ),
      ],
    );
  }

  Widget _buildLanguageSection(ThemeData theme) {
    return _SettingsCard(
      theme: theme,
      children: [_LanguageToggleTile(theme: theme)],
    );
  }

  void _openWebView(BuildContext context, String title, String url) {
    HapticFeedback.lightImpact();
    Navigator.of(context).push(
      MaterialPageRoute(
        builder: (_) => _InAppWebViewScreen(title: title, url: url),
      ),
    );
  }

  Widget _buildDeleteAccountButton(ThemeData theme) {
    return GestureDetector(
      onTap: _isDeleting ? null : () => _showDeleteAccountDialog(theme),
      child: Container(
        width: double.infinity,
        padding: EdgeInsets.symmetric(vertical: 1.6.h),
        decoration: BoxDecoration(
          color: const Color(0xFFE53E3E).withValues(alpha: 0.08),
          borderRadius: BorderRadius.circular(14.0),
          border: Border.all(
            color: const Color(0xFFE53E3E).withValues(alpha: 0.3),
          ),
        ),
        child: Center(
          child: _isDeleting
              ? const SizedBox(
                  width: 20,
                  height: 20,
                  child: CircularProgressIndicator(
                    color: Color(0xFFE53E3E),
                    strokeWidth: 2,
                  ),
                )
              : Text(
                  'Supprimer le compte',
                  style: GoogleFonts.dmSans(
                    fontSize: 13.sp,
                    fontWeight: FontWeight.w600,
                    color: const Color(0xFFE53E3E),
                  ),
                ),
        ),
      ),
    );
  }

  Widget _buildSignOutButton(ThemeData theme) {
    return GestureDetector(
      onTap: () {
        HapticFeedback.mediumImpact();
        showDialog(
          context: context,
          builder: (ctx) => AlertDialog(
            title: const Text('Déconnexion'),
            content: const Text('Voulez-vous vraiment vous déconnecter ?'),
            actions: [
              TextButton(
                onPressed: () => Navigator.of(ctx).pop(),
                child: const Text('Annuler'),
              ),
              TextButton(
                onPressed: () {
                  Navigator.of(ctx).pop();
                  _signOut();
                },
                child: Text(
                  'Déconnexion',
                  style: TextStyle(color: theme.colorScheme.error),
                ),
              ),
            ],
          ),
        );
      },
      child: Container(
        width: double.infinity,
        padding: EdgeInsets.symmetric(vertical: 1.6.h),
        decoration: BoxDecoration(
          color: theme.colorScheme.surface,
          borderRadius: BorderRadius.circular(14.0),
          border: Border.all(
            color: theme.colorScheme.outline.withValues(alpha: 0.3),
          ),
        ),
        child: Center(
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              Icon(
                Icons.logout_rounded,
                color: theme.colorScheme.onSurfaceVariant,
                size: 18,
              ),
              SizedBox(width: 2.w),
              Text(
                'Déconnexion',
                style: GoogleFonts.dmSans(
                  fontSize: 13.sp,
                  fontWeight: FontWeight.w600,
                  color: theme.colorScheme.onSurfaceVariant,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  // ─── Dialogs ──────────────────────────────────────────────────────────────

  void _showUpgradeDialog(ThemeData theme) {
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        title: Text(
          '⭐ Upgrade to Premium',
          style: GoogleFonts.dmSans(fontWeight: FontWeight.w700),
        ),
        content: Text(
          'Unlock unlimited scans, full body composition reports, advanced trend analysis, and priority support.',
          style: GoogleFonts.dmSans(fontSize: 13.sp),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx),
            child: Text(
              'Maybe later',
              style: GoogleFonts.dmSans(
                color: theme.colorScheme.onSurfaceVariant,
              ),
            ),
          ),
          ElevatedButton(
            onPressed: () {
              HapticFeedback.mediumImpact();
              Navigator.pop(ctx);
            },
            style: ElevatedButton.styleFrom(
              backgroundColor: const Color(0xFF6C5CE7),
              minimumSize: Size.zero,
              padding: EdgeInsets.symmetric(horizontal: 4.w, vertical: 1.h),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(10),
              ),
            ),
            child: Text(
              'Passer Premium',
              style: GoogleFonts.dmSans(
                color: Colors.white,
                fontWeight: FontWeight.w600,
              ),
            ),
          ),
        ],
      ),
    );
  }

  void _showCreatorProgramForm(ThemeData theme) {
    final isDark = theme.brightness == Brightness.dark;
    final nameCtrl = TextEditingController();
    final platformCtrl = TextEditingController();
    final usernameCtrl = TextEditingController();
    final followersCtrl = TextEditingController();
    final avgViewsCtrl = TextEditingController();
    final bestVideoCtrl = TextEditingController();
    final worstVideoCtrl = TextEditingController();
    final emailCtrl = TextEditingController();
    bool acceptedTerms = false;

    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setModalState) => DraggableScrollableSheet(
          initialChildSize: 0.92,
          maxChildSize: 0.95,
          minChildSize: 0.5,
          builder: (_, scrollCtrl) => Container(
            decoration: BoxDecoration(
              color: isDark ? const Color(0xFF1A2744) : Colors.white,
              borderRadius: const BorderRadius.vertical(
                top: Radius.circular(24),
              ),
            ),
            child: Column(
              children: [
                Padding(
                  padding: EdgeInsets.symmetric(vertical: 1.5.h),
                  child: Container(
                    width: 10.w,
                    height: 4,
                    decoration: BoxDecoration(
                      color: theme.colorScheme.outline.withValues(alpha: 0.3),
                      borderRadius: BorderRadius.circular(2),
                    ),
                  ),
                ),
                Padding(
                  padding: EdgeInsets.symmetric(horizontal: 5.w),
                  child: Row(
                    children: [
                      Container(
                        padding: const EdgeInsets.all(8),
                        decoration: BoxDecoration(
                          gradient: const LinearGradient(
                            colors: [Color(0xFFFDCB6E), Color(0xFFE17055)],
                          ),
                          borderRadius: BorderRadius.circular(10.0),
                        ),
                        child: const Icon(
                          Icons.videocam_rounded,
                          color: Colors.white,
                          size: 18,
                        ),
                      ),
                      SizedBox(width: 3.w),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              'Creator Partner Application',
                              style: GoogleFonts.dmSans(
                                fontSize: 14.sp,
                                fontWeight: FontWeight.w700,
                                color: theme.colorScheme.onSurface,
                              ),
                            ),
                            Text(
                              'Earn 40% revenue share',
                              style: GoogleFonts.dmSans(
                                fontSize: 10.sp,
                                color: theme.colorScheme.onSurfaceVariant,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
                Expanded(
                  child: ListView(
                    controller: scrollCtrl,
                    padding: EdgeInsets.all(5.w),
                    children: [
                      _CreatorField(
                        ctrl: nameCtrl,
                        label: 'Nom complet',
                        icon: Icons.person_outline_rounded,
                      ),
                      SizedBox(height: 1.5.h),
                      _CreatorField(
                        ctrl: platformCtrl,
                        label: 'Platform (YouTube, TikTok, Instagram…)',
                        icon: Icons.play_circle_outline_rounded,
                      ),
                      SizedBox(height: 1.5.h),
                      _CreatorField(
                        ctrl: usernameCtrl,
                        label: 'Username / Handle',
                        icon: Icons.alternate_email_rounded,
                      ),
                      SizedBox(height: 1.5.h),
                      _CreatorField(
                        ctrl: followersCtrl,
                        label: 'Followers / Subscribers',
                        icon: Icons.people_outline_rounded,
                        keyboardType: TextInputType.number,
                      ),
                      SizedBox(height: 1.5.h),
                      _CreatorField(
                        ctrl: avgViewsCtrl,
                        label: 'Average Views per Video',
                        icon: Icons.visibility_outlined,
                        keyboardType: TextInputType.number,
                      ),
                      SizedBox(height: 1.5.h),
                      _CreatorField(
                        ctrl: bestVideoCtrl,
                        label: 'Best-Performing Video URL',
                        icon: Icons.star_outline_rounded,
                      ),
                      SizedBox(height: 1.5.h),
                      _CreatorField(
                        ctrl: worstVideoCtrl,
                        label: 'Worst-Performing Video URL',
                        icon: Icons.trending_down_outlined,
                      ),
                      SizedBox(height: 1.5.h),
                      _CreatorField(
                        ctrl: emailCtrl,
                        label: 'Contact Email',
                        icon: Icons.email_outlined,
                        keyboardType: TextInputType.emailAddress,
                      ),
                      SizedBox(height: 2.h),
                      GestureDetector(
                        onTap: () {
                          HapticFeedback.lightImpact();
                          setModalState(() => acceptedTerms = !acceptedTerms);
                        },
                        child: Row(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Checkbox(
                              value: acceptedTerms,
                              onChanged: (v) {
                                HapticFeedback.lightImpact();
                                setModalState(() => acceptedTerms = v ?? false);
                              },
                              activeColor: const Color(0xFF6C5CE7),
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(4),
                              ),
                            ),
                            Expanded(
                              child: Padding(
                                padding: EdgeInsets.only(top: 1.h),
                                child: Text(
                                  'I accept the 40% revenue share agreement and Creator Partner Terms & Conditions',
                                  style: GoogleFonts.dmSans(
                                    fontSize: 11.sp,
                                    color: theme.colorScheme.onSurface,
                                    height: 1.4,
                                  ),
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                      SizedBox(height: 2.h),
                      GestureDetector(
                        onTap: acceptedTerms
                            ? () {
                                HapticFeedback.mediumImpact();
                                Navigator.pop(ctx);
                                ScaffoldMessenger.of(context).showSnackBar(
                                  SnackBar(
                                    content: const Text(
                                      'Application submitted! We\'ll be in touch.',
                                    ),
                                    behavior: SnackBarBehavior.floating,
                                    shape: RoundedRectangleBorder(
                                      borderRadius: BorderRadius.circular(10),
                                    ),
                                  ),
                                );
                              }
                            : null,
                        child: AnimatedContainer(
                          duration: const Duration(milliseconds: 200),
                          width: double.infinity,
                          padding: EdgeInsets.symmetric(vertical: 1.6.h),
                          decoration: BoxDecoration(
                            gradient: acceptedTerms
                                ? const LinearGradient(
                                    colors: [
                                      Color(0xFFFDCB6E),
                                      Color(0xFFE17055),
                                    ],
                                  )
                                : null,
                            color: acceptedTerms
                                ? null
                                : theme.colorScheme.outline.withValues(
                                    alpha: 0.2,
                                  ),
                            borderRadius: BorderRadius.circular(14.0),
                          ),
                          child: Center(
                            child: Text(
                              'Submit Application',
                              style: GoogleFonts.dmSans(
                                fontSize: 14.sp,
                                fontWeight: FontWeight.w600,
                                color: acceptedTerms
                                    ? Colors.white
                                    : theme.colorScheme.onSurfaceVariant,
                              ),
                            ),
                          ),
                        ),
                      ),
                      SizedBox(height: 2.h),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  void _showDeleteAccountDialog(ThemeData theme) {
    bool termsAccepted = false;

    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setDialogState) => Dialog(
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(20),
          ),
          child: Padding(
            padding: EdgeInsets.all(5.w),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // Header
                Row(
                  children: [
                    Container(
                      padding: const EdgeInsets.all(8),
                      decoration: BoxDecoration(
                        color: const Color(0xFFE53E3E).withValues(alpha: 0.1),
                        borderRadius: BorderRadius.circular(10.0),
                      ),
                      child: const Icon(
                        Icons.warning_rounded,
                        color: Color(0xFFE53E3E),
                        size: 20,
                      ),
                    ),
                    SizedBox(width: 3.w),
                    Expanded(
                      child: Text(
                        'Supprimer le compte',
                        style: GoogleFonts.dmSans(
                          fontSize: 15.sp,
                          fontWeight: FontWeight.w700,
                          color: const Color(0xFFE53E3E),
                        ),
                      ),
                    ),
                  ],
                ),
                SizedBox(height: 2.h),
                Text(
                  'Voulez-vous vraiment supprimer votre compte ?',
                  style: GoogleFonts.dmSans(
                    fontSize: 13.sp,
                    fontWeight: FontWeight.w600,
                    color: const Color(0xFF1B365D),
                    height: 1.4,
                  ),
                ),
                SizedBox(height: 1.h),
                Text(
                  'Cela supprimera définitivement votre compte, tout votre historique de scans et vos données de composition corporelle.',
                  style: GoogleFonts.dmSans(
                    fontSize: 11.sp,
                    color: const Color(0xFF636E72),
                    height: 1.5,
                  ),
                ),
                SizedBox(height: 2.h),
                // Checkbox
                GestureDetector(
                  onTap: () {
                    HapticFeedback.lightImpact();
                    setDialogState(() => termsAccepted = !termsAccepted);
                  },
                  child: Container(
                    padding: EdgeInsets.all(3.w),
                    decoration: BoxDecoration(
                      color: termsAccepted
                          ? const Color(0xFFE53E3E).withValues(alpha: 0.06)
                          : const Color(0xFFF8F9FA),
                      borderRadius: BorderRadius.circular(12.0),
                      border: Border.all(
                        color: termsAccepted
                            ? const Color(0xFFE53E3E).withValues(alpha: 0.4)
                            : const Color(0xFFE2E8F0),
                        width: 1.5,
                      ),
                    ),
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        SizedBox(
                          width: 20,
                          height: 20,
                          child: Checkbox(
                            value: termsAccepted,
                            onChanged: (v) {
                              HapticFeedback.lightImpact();
                              setDialogState(() => termsAccepted = v ?? false);
                            },
                            activeColor: const Color(0xFFE53E3E),
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(4),
                            ),
                            materialTapTargetSize:
                                MaterialTapTargetSize.shrinkWrap,
                          ),
                        ),
                        SizedBox(width: 2.w),
                        Expanded(
                          child: Text(
                            'J\'accepte les conditions et comprends que cette action est irréversible.',
                            style: GoogleFonts.dmSans(
                              fontSize: 11.sp,
                              color: const Color(0xFF1B365D),
                              height: 1.4,
                              fontWeight: FontWeight.w500,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
                SizedBox(height: 2.5.h),
                // Buttons
                Row(
                  children: [
                    Expanded(
                      child: GestureDetector(
                        onTap: () => Navigator.pop(ctx),
                        child: Container(
                          padding: EdgeInsets.symmetric(vertical: 1.4.h),
                          decoration: BoxDecoration(
                            color: const Color(0xFFF8F9FA),
                            borderRadius: BorderRadius.circular(12.0),
                            border: Border.all(color: const Color(0xFFE2E8F0)),
                          ),
                          child: Center(
                            child: Text(
                              'Annuler',
                              style: GoogleFonts.dmSans(
                                fontSize: 13.sp,
                                fontWeight: FontWeight.w600,
                                color: const Color(0xFF636E72),
                              ),
                            ),
                          ),
                        ),
                      ),
                    ),
                    SizedBox(width: 3.w),
                    Expanded(
                      child: GestureDetector(
                        onTap: termsAccepted
                            ? () {
                                Navigator.pop(ctx);
                                _deleteAccount();
                              }
                            : null,
                        child: AnimatedContainer(
                          duration: const Duration(milliseconds: 200),
                          padding: EdgeInsets.symmetric(vertical: 1.4.h),
                          decoration: BoxDecoration(
                            color: termsAccepted
                                ? const Color(0xFFE53E3E)
                                : const Color(
                                    0xFFE53E3E,
                                  ).withValues(alpha: 0.3),
                            borderRadius: BorderRadius.circular(12.0),
                          ),
                          child: Center(
                            child: Text(
                              'Supprimer le compte',
                              style: GoogleFonts.dmSans(
                                fontSize: 13.sp,
                                fontWeight: FontWeight.w600,
                                color: Colors.white,
                              ),
                            ),
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

// ─── Delete Bullet ────────────────────────────────────────────────────────────

class _DeleteBullet extends StatelessWidget {
  final String text;
  const _DeleteBullet(this.text);

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 2),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text('• ', style: TextStyle(color: Color(0xFFE53E3E))),
          Expanded(
            child: Text(text, style: GoogleFonts.dmSans(fontSize: 12.sp)),
          ),
        ],
      ),
    );
  }
}

// ─── Sync Status Chip ─────────────────────────────────────────────────────────

class _SyncStatusChip extends StatelessWidget {
  final SyncStatus status;
  const _SyncStatusChip({required this.status});

  @override
  Widget build(BuildContext context) {
    Color color;
    String label;
    IconData icon;
    switch (status) {
      case SyncStatus.syncing:
        color = const Color(0xFFFDCB6E);
        label = 'Syncing';
        icon = Icons.sync_rounded;
        break;
      case SyncStatus.offline:
        color = const Color(0xFFE53E3E);
        label = 'Offline';
        icon = Icons.cloud_off_rounded;
        break;
      case SyncStatus.synced:
        color = const Color(0xFF00B894);
        label = 'Synced';
        icon = Icons.cloud_done_rounded;
        break;
      case SyncStatus.pending:
        color = const Color(0xFFFDCB6E);
        label = 'Pending';
        icon = Icons.cloud_upload_rounded;
        break;
    }
    return Container(
      padding: EdgeInsets.symmetric(horizontal: 2.5.w, vertical: 0.5.h),
      decoration: BoxDecoration(
        color: color.withValues(alpha: 0.12),
        borderRadius: BorderRadius.circular(20.0),
        border: Border.all(color: color.withValues(alpha: 0.3)),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon, size: 12, color: color),
          SizedBox(width: 1.w),
          Text(
            label,
            style: GoogleFonts.dmSans(
              fontSize: 10.sp,
              fontWeight: FontWeight.w600,
              color: color,
            ),
          ),
        ],
      ),
    );
  }
}

// ─── Reusable Settings Widgets ───────────────────────────────────────────────

class _SettingsCard extends StatelessWidget {
  final ThemeData theme;
  final List<Widget> children;
  const _SettingsCard({required this.theme, required this.children});

  @override
  Widget build(BuildContext context) {
    final isDark = theme.brightness == Brightness.dark;
    return Container(
      decoration: BoxDecoration(
        color: isDark ? const Color(0xFF1E2E4A) : Colors.white,
        borderRadius: BorderRadius.circular(16.0),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: 0.05),
            blurRadius: 12,
            offset: const Offset(0, 3),
          ),
        ],
      ),
      child: Column(children: children),
    );
  }
}

class _SettingsTile extends StatelessWidget {
  final IconData icon;
  final String label;
  final VoidCallback onTap;
  final ThemeData theme;
  final bool showArrow;

  const _SettingsTile({
    required this.icon,
    required this.label,
    required this.onTap,
    required this.theme,
    this.showArrow = false,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () {
        HapticFeedback.lightImpact();
        onTap();
      },
      behavior: HitTestBehavior.opaque,
      child: Padding(
        padding: EdgeInsets.symmetric(horizontal: 3.5.w, vertical: 1.4.h),
        child: Row(
          children: [
            Icon(icon, size: 20, color: theme.colorScheme.onSurfaceVariant),
            SizedBox(width: 3.w),
            Expanded(
              child: Text(
                label,
                style: GoogleFonts.dmSans(
                  fontSize: 13.sp,
                  fontWeight: FontWeight.w500,
                  color: theme.colorScheme.onSurface,
                ),
              ),
            ),
            Icon(
              showArrow
                  ? Icons.arrow_forward_ios_rounded
                  : Icons.chevron_right_rounded,
              size: showArrow ? 14 : 20,
              color: theme.colorScheme.onSurfaceVariant,
            ),
          ],
        ),
      ),
    );
  }
}

class _SettingsDivider extends StatelessWidget {
  final ThemeData theme;
  const _SettingsDivider({required this.theme});

  @override
  Widget build(BuildContext context) {
    return Divider(
      height: 1,
      indent: 3.5.w + 20 + 3.w,
      color: theme.colorScheme.outline.withValues(alpha: 0.15),
    );
  }
}

class _SettingsToggleRow extends StatelessWidget {
  final String label;
  final String leftOption;
  final String rightOption;
  final bool isLeft;
  final ValueChanged<bool> onChanged;
  final ThemeData theme;

  const _SettingsToggleRow({
    required this.label,
    required this.leftOption,
    required this.rightOption,
    required this.isLeft,
    required this.onChanged,
    required this.theme,
  });

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsets.symmetric(horizontal: 3.5.w, vertical: 1.h),
      child: Row(
        children: [
          Icon(
            Icons.straighten_outlined,
            size: 20,
            color: theme.colorScheme.onSurfaceVariant,
          ),
          SizedBox(width: 3.w),
          Expanded(
            child: Text(
              label,
              style: GoogleFonts.dmSans(
                fontSize: 13.sp,
                fontWeight: FontWeight.w500,
                color: theme.colorScheme.onSurface,
              ),
            ),
          ),
          Container(
            decoration: BoxDecoration(
              color: theme.colorScheme.outline.withValues(alpha: 0.1),
              borderRadius: BorderRadius.circular(20.0),
            ),
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                _ToggleOption(
                  label: leftOption,
                  isSelected: isLeft,
                  onTap: () => onChanged(true),
                  theme: theme,
                ),
                _ToggleOption(
                  label: rightOption,
                  isSelected: !isLeft,
                  onTap: () => onChanged(false),
                  theme: theme,
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _ToggleOption extends StatelessWidget {
  final String label;
  final bool isSelected;
  final VoidCallback onTap;
  final ThemeData theme;

  const _ToggleOption({
    required this.label,
    required this.isSelected,
    required this.onTap,
    required this.theme,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 200),
        padding: EdgeInsets.symmetric(horizontal: 3.w, vertical: 0.6.h),
        decoration: BoxDecoration(
          color: isSelected ? const Color(0xFF6C5CE7) : Colors.transparent,
          borderRadius: BorderRadius.circular(20.0),
        ),
        child: Text(
          label,
          style: GoogleFonts.dmSans(
            fontSize: 11.sp,
            fontWeight: FontWeight.w600,
            color: isSelected
                ? Colors.white
                : theme.colorScheme.onSurfaceVariant,
          ),
        ),
      ),
    );
  }
}

class _CreatorField extends StatelessWidget {
  final TextEditingController ctrl;
  final String label;
  final IconData icon;
  final TextInputType keyboardType;

  const _CreatorField({
    required this.ctrl,
    required this.label,
    required this.icon,
    this.keyboardType = TextInputType.text,
  });

  @override
  Widget build(BuildContext context) {
    return TextField(
      controller: ctrl,
      keyboardType: keyboardType,
      decoration: InputDecoration(
        labelText: label,
        prefixIcon: Icon(icon, size: 20),
        border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
        contentPadding: const EdgeInsets.symmetric(
          horizontal: 16,
          vertical: 14,
        ),
      ),
    );
  }
}

// ─── In-App WebView Screen ────────────────────────────────────────────────────

class _InAppWebViewScreen extends StatefulWidget {
  final String title;
  final String url;

  const _InAppWebViewScreen({required this.title, required this.url});

  @override
  State<_InAppWebViewScreen> createState() => _InAppWebViewScreenState();
}

class _InAppWebViewScreenState extends State<_InAppWebViewScreen> {
  late final WebViewController _controller;
  bool _isLoading = true;
  bool _hasError = false;

  @override
  void initState() {
    super.initState();
    _controller = WebViewController()
      ..setJavaScriptMode(JavaScriptMode.unrestricted)
      ..setNavigationDelegate(
        NavigationDelegate(
          onPageStarted: (_) {
            if (mounted) {
              setState(() {
                _isLoading = true;
                _hasError = false;
              });
            }
          },
          onPageFinished: (_) {
            if (mounted) setState(() => _isLoading = false);
          },
          onWebResourceError: (_) {
            if (mounted) {
              setState(() {
                _isLoading = false;
                _hasError = true;
              });
            }
          },
        ),
      )
      ..loadRequest(Uri.parse(widget.url));
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Scaffold(
      backgroundColor: theme.scaffoldBackgroundColor,
      appBar: AppBar(
        backgroundColor: theme.scaffoldBackgroundColor,
        elevation: 0,
        leading: GestureDetector(
          onTap: () {
            HapticFeedback.lightImpact();
            Navigator.of(context).pop();
          },
          child: Container(
            margin: const EdgeInsets.all(8),
            decoration: BoxDecoration(
              color: const Color(0xFFF8F9FA),
              borderRadius: BorderRadius.circular(10.0),
              border: Border.all(color: const Color(0xFFE2E8F0)),
            ),
            child: const Icon(
              Icons.arrow_back_ios_new_rounded,
              color: Color(0xFF1B365D),
              size: 16,
            ),
          ),
        ),
        title: Text(
          widget.title,
          style: GoogleFonts.dmSans(
            fontSize: 15.sp,
            fontWeight: FontWeight.w700,
            color: theme.colorScheme.onSurface,
          ),
        ),
        centerTitle: true,
      ),
      body: Stack(
        children: [
          if (_hasError)
            Center(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Icon(
                    Icons.wifi_off_rounded,
                    size: 48,
                    color: theme.colorScheme.onSurfaceVariant,
                  ),
                  const SizedBox(height: 12),
                  Text(
                    'Could not load page.\nPlease check your connection.',
                    textAlign: TextAlign.center,
                    style: GoogleFonts.dmSans(
                      fontSize: 13.sp,
                      color: theme.colorScheme.onSurfaceVariant,
                    ),
                  ),
                  const SizedBox(height: 16),
                  ElevatedButton(
                    onPressed: () => _controller.reload(),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: const Color(0xFF6C5CE7),
                    ),
                    child: Text(
                      'Retry',
                      style: GoogleFonts.dmSans(color: Colors.white),
                    ),
                  ),
                ],
              ),
            )
          else
            WebViewWidget(controller: _controller),
          if (_isLoading && !_hasError)
            const Center(
              child: CircularProgressIndicator(color: Color(0xFF6C5CE7)),
            ),
        ],
      ),
    );
  }
}

// ─── Language Toggle Tile ─────────────────────────────────────────────────────

class _LanguageToggleTile extends StatefulWidget {
  final ThemeData theme;
  const _LanguageToggleTile({required this.theme});

  @override
  State<_LanguageToggleTile> createState() => _LanguageToggleTileState();
}

class _LanguageToggleTileState extends State<_LanguageToggleTile> {
  final _lang = LanguageProvider();

  @override
  void initState() {
    super.initState();
    _lang.addListener(_rebuild);
  }

  @override
  void dispose() {
    _lang.removeListener(_rebuild);
    super.dispose();
  }

  void _rebuild() => setState(() {});

  @override
  Widget build(BuildContext context) {
    final isFr = _lang.isFrench;
    return Padding(
      padding: EdgeInsets.symmetric(horizontal: 3.5.w, vertical: 1.h),
      child: Row(
        children: [
          Container(
            width: 9.w,
            height: 9.w,
            decoration: BoxDecoration(
              color: const Color(0xFF6C5CE7).withValues(alpha: 0.1),
              borderRadius: BorderRadius.circular(10.0),
            ),
            child: const Icon(
              Icons.language_rounded,
              color: Color(0xFF6C5CE7),
              size: 20,
            ),
          ),
          SizedBox(width: 3.w),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'App Language',
                  style: GoogleFonts.dmSans(
                    fontSize: 13.sp,
                    fontWeight: FontWeight.w600,
                    color: widget.theme.colorScheme.onSurface,
                  ),
                ),
                Text(
                  isFr ? 'Français' : 'English',
                  style: GoogleFonts.dmSans(
                    fontSize: 10.sp,
                    color: const Color(0xFF636E72),
                  ),
                ),
              ],
            ),
          ),
          GestureDetector(
            onTap: () {
              HapticFeedback.selectionClick();
              _lang.toggleLanguage();
            },
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
              decoration: BoxDecoration(
                color: const Color(0xFFF8F9FA),
                borderRadius: BorderRadius.circular(20),
                border: Border.all(color: const Color(0xFFE2E8F0)),
              ),
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Text(
                    isFr ? '🇫🇷' : '🇬🇧',
                    style: const TextStyle(fontSize: 16),
                  ),
                  const SizedBox(width: 5),
                  Text(
                    isFr ? 'FR' : 'EN',
                    style: const TextStyle(
                      fontSize: 12,
                      fontWeight: FontWeight.w700,
                      color: Color(0xFF2D3436),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}