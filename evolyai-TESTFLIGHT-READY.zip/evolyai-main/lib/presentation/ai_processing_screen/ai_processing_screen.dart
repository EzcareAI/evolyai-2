import 'dart:convert';
import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:sizer/sizer.dart';

import '../../core/services/aiIntegrations/chat_completion_service.dart';
import '../../models/onboarding_data.dart';
import '../../services/supabase_service.dart';
import '../../presentation/rescan_result_screen/rescan_result_screen.dart';
import './widgets/particle_widget.dart';
import './widgets/progress_ring_widget.dart';
import './widgets/scanning_body_widget.dart';

// Minimum confidence score to accept a scan result (0–100 scale)
const double _kMinConfidenceScore = 25.0;

class AiProcessingScreen extends ConsumerStatefulWidget {
  const AiProcessingScreen({super.key});

  @override
  ConsumerState<AiProcessingScreen> createState() => _AiProcessingScreenState();
}

class _AiProcessingScreenState extends ConsumerState<AiProcessingScreen>
    with TickerProviderStateMixin {
  late AnimationController _progressController;
  late AnimationController _pulseController;
  late AnimationController _messageController;
  late AnimationController _particleController;
  late AnimationController _breathController;

  late Animation<double> _progressAnimation;
  late Animation<double> _pulseAnimation;
  late Animation<double> _messageOpacity;
  late Animation<double> _breathAnimation;

  int _currentMessageIndex = 0;
  bool _isCompleted = false;
  bool _lowConfidence = false;

  final List<String> _messages = [
    'Analyzing body shape',
    'Estimating body fat',
    'Generating body report',
    'Building your body profile',
  ];

  final List<ParticleData> _particles = [];
  final math.Random _random = math.Random();

  @override
  void initState() {
    super.initState();
    _generateParticles();
    _initAnimations();
    _startProcessing();
  }

  void _generateParticles() {
    for (int i = 0; i < 30; i++) {
      _particles.add(
        ParticleData(
          x: _random.nextDouble(),
          y: _random.nextDouble(),
          size: _random.nextDouble() * 4 + 1,
          speed: _random.nextDouble() * 0.3 + 0.1,
          opacity: _random.nextDouble() * 0.6 + 0.2,
        ),
      );
    }
  }

  void _initAnimations() {
    _progressController = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 25),
    );
    _progressAnimation = Tween<double>(begin: 0.0, end: 0.95).animate(
      CurvedAnimation(parent: _progressController, curve: Curves.easeInOut),
    );

    _pulseController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1500),
    )..repeat(reverse: true);
    _pulseAnimation = Tween<double>(begin: 0.95, end: 1.05).animate(
      CurvedAnimation(parent: _pulseController, curve: Curves.easeInOut),
    );

    _messageController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 600),
    );
    _messageOpacity = Tween<double>(begin: 0.0, end: 1.0).animate(
      CurvedAnimation(parent: _messageController, curve: Curves.easeIn),
    );

    _particleController = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 4),
    )..repeat();

    _breathController = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 3),
    )..repeat(reverse: true);
    _breathAnimation = Tween<double>(begin: 0.97, end: 1.03).animate(
      CurvedAnimation(parent: _breathController, curve: Curves.easeInOut),
    );
  }

  void _startProcessing() {
    _progressController.forward();
    _messageController.forward();
    _rotateMessages();

    Future.delayed(const Duration(milliseconds: 500), () {
      if (mounted) _runGeminiAnalysis();
    });
  }

  void _rotateMessages() {
    Future.delayed(const Duration(milliseconds: 2500), () {
      if (!mounted || _isCompleted) return;
      _messageController.reverse().then((_) {
        if (!mounted) return;
        setState(() {
          _currentMessageIndex = (_currentMessageIndex + 1) % _messages.length;
        });
        _messageController.forward();
        HapticFeedback.lightImpact();
        _rotateMessages();
      });
    });
  }

  Future<void> _runGeminiAnalysis() async {
    OnboardingData? onboardingData;
    if (mounted) {
      onboardingData =
          ModalRoute.of(context)?.settings.arguments as OnboardingData?;
    }

    final uid = SupabaseService.instance.currentUser?.id;
    final isStandalone = onboardingData?.standaloneMode ?? false;
    debugPrint('[AiProcessing] Current user id: $uid');
    debugPrint('[AiProcessing] Standalone mode: $isStandalone');
    debugPrint(
      '[AiProcessing] Front photo available: ${onboardingData?.frontPhotoPath?.isNotEmpty == true}',
    );
    debugPrint(
      '[AiProcessing] Side photo available: ${onboardingData?.sidePhotoPath?.isNotEmpty == true}',
    );

    // ── For standalone rescans, enrich onboardingData with saved answers ──
    if (isStandalone && uid != null) {
      try {
        final savedAnswers = await SupabaseService.instance
            .fetchOnboardingAnswers();
        if (savedAnswers != null) {
          debugPrint(
            '[AiProcessing] Enriching standalone scan with saved onboarding answers',
          );
          onboardingData = (onboardingData ?? OnboardingData()).copyWith(
            goal: onboardingData?.goal ?? savedAnswers.goal,
            gender: onboardingData?.gender ?? savedAnswers.gender,
            age: onboardingData?.age ?? savedAnswers.age,
            heightCm: onboardingData?.heightCm ?? savedAnswers.heightValue,
            heightUnit: onboardingData?.heightUnit ?? savedAnswers.heightUnit,
            weightKg: onboardingData?.weightKg ?? savedAnswers.weightValue,
            weightUnit: onboardingData?.weightUnit ?? savedAnswers.weightUnit,
            activityLevel:
                onboardingData?.activityLevel ?? savedAnswers.activityLevel,
            motivation: onboardingData?.motivation ?? savedAnswers.motivation,
            targetBodyFatPercent:
                onboardingData?.targetBodyFatPercent ??
                savedAnswers.targetBodyFatPercent,
            standaloneMode: true,
          );
          debugPrint(
            '[AiProcessing] Standalone onboarding context: gender=${onboardingData.gender}, age=${onboardingData.age}, weight=${onboardingData.weightKg}kg, targetBF=${onboardingData.targetBodyFatPercent}%',
          );
        }
      } catch (e) {
        debugPrint(
          '[AiProcessing] Could not fetch onboarding answers for standalone scan: $e',
        );
      }
    }

    // ── Always save onboarding answers for onboarding flow (not standalone) ──
    if (!isStandalone) {
      await _saveOnboardingAnswersUnconditionally(onboardingData);
    }

    // For standalone rescans, fetch the previous scan result for comparison
    ScanResultModel? previousResult;
    if (isStandalone) {
      try {
        previousResult = await SupabaseService.instance.fetchLatestScanResult();
        debugPrint(
          '[AiProcessing] Previous scan result for comparison: ${previousResult?.bodyFatPercent}',
        );
      } catch (_) {}
    }

    try {
      final result = await _callGeminiAnalysis(onboardingData);
      debugPrint('[AiProcessing] Gemini response received: $result');

      if (!mounted) return;

      // Validate confidence score before saving
      final rawConfidence = _toDouble(result['confidence_score']) ?? 0.0;
      debugPrint('[AiProcessing] Confidence score: $rawConfidence');

      if (rawConfidence < _kMinConfidenceScore) {
        debugPrint(
          '[AiProcessing] Confidence too low ($rawConfidence < $_kMinConfidenceScore) — prompting retake',
        );
        if (!mounted) return;
        setState(() {
          _lowConfidence = true;
          _isCompleted = true;
        });
        _progressController.stop();
        await Future.delayed(const Duration(milliseconds: 600));
        if (!mounted) return;
        _showLowConfidenceDialog(onboardingData, isStandalone);
        return;
      }

      // Stabilize / clamp result values before saving
      final stabilizedResult = _stabilizeResult(result, onboardingData);

      final savedResult = await _saveResultToSupabase(
        stabilizedResult,
        onboardingData,
      );
      if (!mounted) return;

      _progressController.stop();
      _progressController.animateTo(
        1.0,
        duration: const Duration(milliseconds: 800),
      );

      setState(() => _isCompleted = true);
      HapticFeedback.mediumImpact();

      await Future.delayed(const Duration(milliseconds: 1000));
      if (!mounted) return;

      _navigateAfterScan(
        onboardingData,
        isStandalone,
        savedResult: savedResult,
        previousResult: previousResult,
      );
    } catch (e) {
      debugPrint('[AiProcessing] Gemini analysis error: $e');
      if (!mounted) return;

      final fallbackResult = await _createFallbackScanRecord(onboardingData);
      if (!mounted) return;

      setState(() => _isCompleted = true);
      HapticFeedback.mediumImpact();

      await Future.delayed(const Duration(milliseconds: 800));
      if (!mounted) return;

      _navigateAfterScan(
        onboardingData,
        isStandalone,
        savedResult: fallbackResult,
        previousResult: previousResult,
      );
    }
  }

  /// Unconditionally saves onboarding answers for the authenticated user.
  /// Re-fetches the user ID at call time to handle cases where auth wasn't
  /// ready at the start of _runGeminiAnalysis.
  Future<void> _saveOnboardingAnswersUnconditionally(
    OnboardingData? onboardingData,
  ) async {
    // Re-fetch uid at call time — auth may have resolved since _runGeminiAnalysis started
    final uid = SupabaseService.instance.currentUser?.id;
    debugPrint(
      '[AiProcessing] saveOnboardingAnswers — uid=$uid, onboardingData=${onboardingData != null}',
    );

    if (uid == null) {
      debugPrint(
        '[AiProcessing] ERROR: Cannot save onboarding answers — user not authenticated',
      );
      return;
    }

    if (onboardingData == null) {
      debugPrint(
        '[AiProcessing] WARNING: onboardingData is null — skipping onboarding answers save',
      );
      return;
    }

    try {
      final answers = OnboardingAnswersModel(
        userId: uid,
        goal: onboardingData.goal,
        gender: onboardingData.gender,
        age: onboardingData.age,
        heightValue: onboardingData.heightCm,
        heightUnit: onboardingData.heightUnit,
        weightValue: onboardingData.weightKg,
        weightUnit: onboardingData.weightUnit,
        activityLevel: onboardingData.activityLevel,
        motivation: onboardingData.motivation,
        notificationsEnabled: true,
        targetBodyFatPercent: onboardingData.targetBodyFatPercent,
      );
      debugPrint(
        '[AiProcessing] Upserting onboarding answers: ${answers.toJson()}',
      );
      final saved = await SupabaseService.instance.saveOnboardingAnswers(
        answers,
      );
      debugPrint('[AiProcessing] Onboarding answers upserted — success=$saved');
    } catch (e, st) {
      debugPrint('[AiProcessing] ERROR saving onboarding answers: $e\n$st');
    }
  }

  /// Navigate after scan based on whether this is a standalone (dashboard) scan
  /// or an onboarding scan.
  void _navigateAfterScan(
    OnboardingData? data,
    bool isStandalone, {
    ScanResultModel? savedResult,
    ScanResultModel? previousResult,
  }) {
    // Ensure the result has the required fields before navigating
    _ensureValidScanResult(savedResult).then((confirmedResult) {
      if (!mounted) return;
      if (isStandalone) {
        // Dashboard Scan Again: go to rescan result screen, then home
        debugPrint(
          '[AiProcessing] Standalone scan complete — routing to rescan result screen',
        );
        if (confirmedResult != null) {
          Navigator.of(context, rootNavigator: true).pushNamedAndRemoveUntil(
            '/rescan-result-screen',
            (route) => false,
            arguments: RescanResultArgs(
              newResult: confirmedResult,
              previousResult: previousResult,
            ),
          );
        } else {
          // No saved result — go straight to dashboard
          Navigator.of(context, rootNavigator: true).pushNamedAndRemoveUntil(
            '/home-dashboard',
            (route) => false,
            arguments: data,
          );
        }
      } else {
        // Onboarding scan: go to rescan result screen (same as standalone)
        debugPrint(
          '[AiProcessing] Onboarding scan complete — routing to rescan result screen',
        );
        // Attach the confirmed scan result to onboardingData so it travels through
        // result screen → dashboard without needing a Supabase re-fetch.
        final dataWithResult = confirmedResult != null
            ? (data ?? OnboardingData()).copyWith(scanResult: confirmedResult)
            : data;
        debugPrint(
          '[AiProcessing] Navigating to rescan result with scanResult: bodyFat=${confirmedResult?.bodyFatPercent}, leanMass=${confirmedResult?.leanMassEstimate}, fatMass=${confirmedResult?.fatMass}',
        );
        if (confirmedResult != null) {
          Navigator.of(context, rootNavigator: true).pushNamedAndRemoveUntil(
            '/rescan-result-screen',
            (route) => false,
            arguments: RescanResultArgs(
              newResult: confirmedResult,
              onboardingData: dataWithResult,
            ),
          );
        } else {
          // No confirmed result — go to paywall with onboardingData
          Navigator.of(context, rootNavigator: true).pushNamedAndRemoveUntil(
            '/paywall',
            (route) => false,
            arguments: dataWithResult,
          );
        }
      }
    });
  }

  /// Ensures the scan result has valid body fat, lean mass, and fat mass values.
  /// If the provided result is missing these, fetches the latest from Supabase.
  /// Returns a confirmed result or null if unavailable.
  Future<ScanResultModel?> _ensureValidScanResult(
    ScanResultModel? result,
  ) async {
    final bool hasRequiredFields =
        result != null &&
        result.bodyFatPercent != null &&
        result.bodyFatPercent! > 0 &&
        result.leanMassEstimate != null &&
        result.leanMassEstimate! > 0 &&
        result.fatMass != null &&
        result.fatMass! > 0;

    if (hasRequiredFields) {
      debugPrint(
        '[AiProcessing] Scan result confirmed: bodyFat=${result.bodyFatPercent}, leanMass=${result.leanMassEstimate}, fatMass=${result.fatMass}',
      );
      return result;
    }

    debugPrint(
      '[AiProcessing] Scan result missing required fields — fetching latest from Supabase',
    );

    try {
      final fetched = await SupabaseService.instance.fetchLatestScanResult();
      if (fetched != null &&
          fetched.bodyFatPercent != null &&
          fetched.bodyFatPercent! > 0 &&
          fetched.leanMassEstimate != null &&
          fetched.leanMassEstimate! > 0 &&
          fetched.fatMass != null &&
          fetched.fatMass! > 0) {
        debugPrint(
          '[AiProcessing] Fetched confirmed scan result from Supabase: bodyFat=${fetched.bodyFatPercent}',
        );
        return fetched;
      }
    } catch (e) {
      debugPrint('[AiProcessing] Error fetching latest scan result: $e');
    }

    // Return the original result even if incomplete — better than null
    debugPrint(
      '[AiProcessing] Could not confirm scan result fields — using original result',
    );
    return result;
  }

  /// Show dialog asking user to retake scan due to low confidence
  void _showLowConfidenceDialog(OnboardingData? data, bool isStandalone) {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (ctx) => AlertDialog(
        backgroundColor: const Color(0xFF1A1A2E),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        title: const Text(
          'Low Quality Scan',
          style: TextStyle(color: Colors.white, fontWeight: FontWeight.w700),
        ),
        content: const Text(
          'The AI could not analyze your body with sufficient confidence. '
          'Please retake the scan with better lighting and ensure your full body is visible.',
          style: TextStyle(color: Color(0xFFB2BEC3)),
        ),
        actions: [
          TextButton(
            onPressed: () {
              Navigator.of(ctx).pop();
              // Go back to camera
              Navigator.of(
                context,
                rootNavigator: true,
              ).pushNamedAndRemoveUntil(
                '/camera-capture-screen',
                (route) => false,
                arguments: data,
              );
            },
            child: const Text(
              'Retake Scan',
              style: TextStyle(
                color: Color(0xFF6C5CE7),
                fontWeight: FontWeight.w700,
              ),
            ),
          ),
          TextButton(
            onPressed: () {
              Navigator.of(ctx).pop();
              // Continue anyway with fallback
              _createFallbackScanRecord(data).then((_) {
                if (mounted) _navigateAfterScan(data, isStandalone);
              });
            },
            child: Text(
              'Continue Anyway',
              style: TextStyle(color: Colors.white.withValues(alpha: 0.5)),
            ),
          ),
        ],
      ),
    );
  }

  /// Stabilize AI result: clamp unrealistic values and smooth zone percentages.
  Map<String, dynamic> _stabilizeResult(
    Map<String, dynamic> raw,
    OnboardingData? data,
  ) {
    final isMale = data?.gender?.toLowerCase() == 'male';

    // ── Body fat clamping ──────────────────────────────────────────────────
    // Male: 4–40%, Female: 10–50%
    final double rawBf = _toDouble(raw['body_fat_percent']) ?? 20.0;
    final double minBf = isMale ? 4.0 : 10.0;
    final double maxBf = isMale ? 40.0 : 50.0;
    final double bodyFat = rawBf.clamp(minBf, maxBf);

    // ── Weight-derived lean/fat mass ───────────────────────────────────────
    final double weight = data?.weightKg ?? 70.0;
    final double fatMass = (weight * bodyFat / 100).clamp(1.0, weight * 0.7);
    final double leanMass = (weight - fatMass).clamp(weight * 0.3, weight);

    // ── Zone percentages clamping ──────────────────────────────────────────
    // Each zone should be between 15–60% (realistic body fat distribution)
    double clampZone(dynamic v, {double min = 15.0, double max = 60.0}) {
      return (_toDouble(v) ?? 30.0).clamp(min, max);
    }

    final double leftArm = clampZone(
      raw['left_arm_percent'],
      min: 10.0,
      max: 55.0,
    );
    final double rightArm = clampZone(
      raw['right_arm_percent'],
      min: 10.0,
      max: 55.0,
    );
    // Upper body: realistic range 15–50%
    final double upperBody = clampZone(
      raw['upper_body_percent'],
      min: 15.0,
      max: 50.0,
    );
    final double leftLeg = clampZone(
      raw['left_leg_percent'],
      min: 15.0,
      max: 55.0,
    );
    final double rightLeg = clampZone(
      raw['right_leg_percent'],
      min: 15.0,
      max: 55.0,
    );

    // ── Confidence score clamping ──────────────────────────────────────────
    final double confidence = (_toDouble(raw['confidence_score']) ?? 70.0)
        .clamp(0.0, 100.0);

    // ── Physique profile validation ────────────────────────────────────────
    const validProfiles = ['Lean', 'Athletic', 'Balanced', 'Overfat'];
    String profile = raw['physique_profile'] as String? ?? 'Balanced';
    if (!validProfiles.contains(profile)) {
      profile = _bodyCategory(bodyFat, isMale);
    }

    final stabilized = Map<String, dynamic>.from(raw);
    stabilized['body_fat_percent'] = bodyFat;
    stabilized['lean_mass'] = leanMass;
    stabilized['fat_mass'] = fatMass;
    stabilized['physique_profile'] = profile;
    stabilized['left_arm_percent'] = leftArm;
    stabilized['right_arm_percent'] = rightArm;
    stabilized['upper_body_percent'] = upperBody;
    stabilized['left_leg_percent'] = leftLeg;
    stabilized['right_leg_percent'] = rightLeg;
    stabilized['confidence_score'] = confidence;

    debugPrint(
      '[AiProcessing] Stabilized result: bodyFat=$bodyFat, upperBody=$upperBody, confidence=$confidence',
    );

    return stabilized;
  }

  Future<Map<String, dynamic>> _callGeminiAnalysis(OnboardingData? data) async {
    final frontBase64 = data?.frontPhotoPath;
    final sideBase64 = data?.sidePhotoPath;
    final userContext = _buildUserContext(data);

    final bool hasFront = frontBase64 != null && frontBase64.isNotEmpty;
    final bool hasSide = sideBase64 != null && sideBase64.isNotEmpty;

    final List<Map<String, dynamic>> contentParts = [
      {
        'type': 'text',

        'text':
            '''You are an expert body composition analyst with deep knowledge of physiology and body fat estimation. TASK: Analyze the provided body photo(s) together with the user's complete profile data to estimate body composition metrics. USER PROFILE (use ALL fields to calibrate your analysis): $userContext ANALYSIS INSTRUCTIONS: 1. Examine the front and/or side body photos carefully — look at muscle definition, fat distribution, body shape, and proportions 2. Cross-reference visual observations with the user's exact weight, height, age, gender, and activity level to produce accurate estimates 3. Use the user's goal and target body fat to contextualize the physique profile label 4. Body fat percent MUST be physically consistent with the user's stated weight and height — do not produce values that would imply an impossible lean mass or fat mass 5. Lean mass = weight × (1 − body_fat/100); Fat mass = weight × (body_fat/100) — your numbers must satisfy these equations 6. Zone percentages represent the estimated body fat % in each body region — they should be consistent with the overall body fat percent 7. Return ONLY a valid JSON object — no markdown, no explanation, no code blocks 8. All numeric values must be numbers (not strings) 9. Be conservative and realistic — avoid extreme values REQUIRED JSON (all fields mandatory): { "body_fat_percent": <number — male 4–40, female 10–50; must match visual + weight/height>, "lean_mass": <number in kg — must equal weight × (1 − body_fat/100)>, "fat_mass": <number in kg — must equal weight × (body_fat/100)>, "physique_profile": <"Lean" | "Athletic" | "Balanced" | "Overfat" — based on body fat and goal>, "left_arm_percent": <body fat % in left arm, 10–55>, "right_arm_percent": <body fat % in right arm, 10–55>, "upper_body_percent": <body fat % in upper body/torso, 15–50>, "left_leg_percent": <body fat % in left leg, 15–55>, "right_leg_percent": <body fat % in right leg, 15–55>, "confidence_score": <0–100, how confident you are given photo quality and profile data>, "summary_text": <1–2 sentence description of body composition based on photos and profile> }''',
      },
    ];

    if (hasFront) {
      contentParts.add({
        'type': 'file',
        'file': {
          'file_data': 'data:image/jpeg;base64,$frontBase64',
          'filename': 'front_body.jpg',
          'format': 'image/jpeg',
        },
      });
      debugPrint(
        '[AiProcessing] Front photo added to request (base64 length: ${frontBase64.length})',
      );
    }

    if (hasSide) {
      contentParts.add({
        'type': 'file',
        'file': {
          'file_data': 'data:image/jpeg;base64,$sideBase64',
          'filename': 'side_body.jpg',
          'format': 'image/jpeg',
        },
      });
      debugPrint(
        '[AiProcessing] Side photo added to request (base64 length: ${sideBase64.length})',
      );
    }

    final messages = [
      {'role': 'user', 'content': contentParts},
    ];

    debugPrint(
      '[AiProcessing] AI request sent to Gemini (hasFront=$hasFront, hasSide=$hasSide)',
    );

    final response = await getChatCompletion(
      'GEMINI',
      'gemini/gemini-2.5-flash',
      messages,
      parameters: {'temperature': 0.3, 'max_tokens': 1000},
    );

    debugPrint('[AiProcessing] AI response received from Lambda');

    final content = response['choices']?[0]?['message']?['content'] as String?;
    if (content == null || content.isEmpty) {
      throw Exception('Empty response from Gemini');
    }

    debugPrint('[AiProcessing] Gemini raw content: $content');
    return _parseGeminiResponse(content);
  }

  Map<String, dynamic> _parseGeminiResponse(String content) {
    String cleaned = content.trim();
    if (cleaned.startsWith('```')) {
      cleaned = cleaned.replaceAll(RegExp(r'```json\s*|```\s*'), '').trim();
    }

    try {
      final parsed = jsonDecode(cleaned) as Map<String, dynamic>;
      return parsed;
    } catch (e) {
      final jsonMatch = RegExp(r'\{[\s\S]*\}').firstMatch(cleaned);
      if (jsonMatch != null) {
        return jsonDecode(jsonMatch.group(0)!) as Map<String, dynamic>;
      }
      throw Exception('Could not parse Gemini response as JSON: $content');
    }
  }

  String _buildUserContext(OnboardingData? data) {
    if (data == null) return 'No profile data available.';
    final parts = <String>[];
    if (data.gender != null) parts.add('Gender: ${data.gender}');
    if (data.age != null) parts.add('Age: ${data.age} years');
    if (data.heightCm != null) {
      parts.add('Height: ${data.heightCm!.toStringAsFixed(1)} cm');
    }
    if (data.weightKg != null) {
      parts.add('Weight: ${data.weightKg!.toStringAsFixed(1)} kg');
    }
    if (data.activityLevel != null) {
      parts.add('Activity Level: ${data.activityLevel}');
    }
    if (data.goal != null) parts.add('Fitness Goal: ${data.goal}');
    if (data.motivation != null) parts.add('Motivation: ${data.motivation}');
    if (data.targetBodyFatPercent != null) {
      parts.add(
        'Target Body Fat: ${data.targetBodyFatPercent!.toStringAsFixed(1)}%',
      );
    }
    // Derived BMI for additional context
    if (data.weightKg != null && data.heightCm != null && data.heightCm! > 0) {
      final heightM = data.heightCm! / 100.0;
      final bmi = data.weightKg! / (heightM * heightM);
      parts.add('BMI: ${bmi.toStringAsFixed(1)}');
    }
    return parts.isEmpty ? 'No profile data available.' : parts.join('\n');
  }

  Future<ScanResultModel?> _saveResultToSupabase(
    Map<String, dynamic> geminiResult,
    OnboardingData? data,
  ) async {
    try {
      if (!SupabaseService.instance.isAuthenticated) {
        debugPrint(
          '[AiProcessing] scans insert FAILED: user not authenticated',
        );
        return null;
      }
      final uid = SupabaseService.instance.currentUser!.id;
      debugPrint('[AiProcessing] Saving scan for user: $uid');

      final bodyFat = _toDouble(geminiResult['body_fat_percent']) ?? 20.0;
      final leanMass =
          _toDouble(geminiResult['lean_mass']) ??
          ((data?.weightKg ?? 70.0) * (1 - bodyFat / 100));
      final fatMass =
          _toDouble(geminiResult['fat_mass']) ??
          ((data?.weightKg ?? 70.0) * (bodyFat / 100));
      final physiqueProfile =
          geminiResult['physique_profile'] as String? ?? 'Balanced';
      final confidenceScore =
          (_toDouble(geminiResult['confidence_score']) ?? 75.0) / 100.0;
      final summaryText =
          geminiResult['summary_text'] as String? ??
          'Body composition analysis complete.';

      final scan = await SupabaseService.instance.createScan(
        frontImageUrl: 'scan_front_${DateTime.now().millisecondsSinceEpoch}',
        sideImageUrl: 'scan_side_${DateTime.now().millisecondsSinceEpoch}',
        scanStatus: 'completed',
      );

      if (scan == null) {
        debugPrint(
          '[AiProcessing] scans insert FAILED: createScan returned null',
        );
        return null;
      }
      debugPrint('[AiProcessing] scans insert SUCCESS: scanId=${scan.id}');

      final resultModel = ScanResultModel(
        id: '',
        scanId: scan.id,
        userId: uid,
        bodyFatPercent: bodyFat,
        leanMassEstimate: leanMass,
        fatMass: fatMass,
        bodyCategory: physiqueProfile,
        physiqueProfile: physiqueProfile,
        bodyScore: confidenceScore * 100,
        confidenceScore: confidenceScore,
        summaryText: summaryText,
        leftArmPercent: _toDouble(geminiResult['left_arm_percent']),
        rightArmPercent: _toDouble(geminiResult['right_arm_percent']),
        upperBodyPercent: _toDouble(geminiResult['upper_body_percent']),
        leftLegPercent: _toDouble(geminiResult['left_leg_percent']),
        rightLegPercent: _toDouble(geminiResult['right_leg_percent']),
      );

      final savedResult = await SupabaseService.instance.saveScanResult(
        resultModel,
      );

      if (savedResult != null) {
        debugPrint(
          '[AiProcessing] scan_results insert SUCCESS: id=${savedResult.id}',
        );
        debugPrint('[AiProcessing] scan saved successfully');
        return savedResult;
      } else {
        debugPrint(
          '[AiProcessing] scan_results insert FAILED: saveScanResult returned null — attempting rescue fetch',
        );
        // ── CRITICAL FIX: the insert may have succeeded server-side even if
        // the client-side response was null.  Wait briefly and fetch the latest
        // row; if it matches (body fat / lean mass / fat mass close enough),
        // use it so we never propagate id:''.
        await Future.delayed(const Duration(milliseconds: 1500));
        try {
          final fetched = await SupabaseService.instance.fetchLatestScanResult();
          if (fetched != null &&
              fetched.bodyFatPercent != null &&
              (fetched.bodyFatPercent! - (resultModel.bodyFatPercent ?? 0)).abs() < 5.0) {
            debugPrint(
              '[AiProcessing] Rescue fetch succeeded: id=${fetched.id}, bodyFat=${fetched.bodyFatPercent}',
            );
            return fetched;
          }
        } catch (e) {
          debugPrint('[AiProcessing] Rescue fetch failed: $e');
        }
        // Fall back to in-memory model — result screen can still display values
        // even without a real DB id; dashboard retry loop will eventually sync.
        debugPrint('[AiProcessing] Using in-memory resultModel as last resort');
        return resultModel;
      }
    } catch (e) {
      debugPrint('[AiProcessing] _saveResultToSupabase error: $e');
      return null;
    }
  }

  double? _toDouble(dynamic value) {
    if (value == null) return null;
    if (value is double) return value;
    if (value is int) return value.toDouble();
    return double.tryParse(value.toString());
  }

  Future<ScanResultModel?> _createFallbackScanRecord(
    OnboardingData? data,
  ) async {
    try {
      if (!SupabaseService.instance.isAuthenticated) {
        debugPrint(
          '[AiProcessing] fallback scan FAILED: user not authenticated',
        );
        return null;
      }
      final uid = SupabaseService.instance.currentUser!.id;
      debugPrint('[AiProcessing] Creating fallback scan for user: $uid');

      final isMale = data?.gender?.toLowerCase() == 'male';
      final baseBodyFat = isMale ? 18.0 : 25.0;
      final activityBonus = _activityBonus(data?.activityLevel);
      final bodyFat = (baseBodyFat - activityBonus).clamp(8.0, 40.0);
      final weight = data?.weightKg ?? 75.0;
      final leanMass = weight * (1 - bodyFat / 100);
      final fatMass = weight * (bodyFat / 100);
      final bodyCategory = _bodyCategory(bodyFat, isMale);

      final scan = await SupabaseService.instance.createScan(
        frontImageUrl: 'scan_placeholder',
        sideImageUrl: null,
        scanStatus: 'completed',
      );

      if (scan == null) {
        debugPrint('[AiProcessing] fallback scans insert FAILED');
        return null;
      }
      debugPrint(
        '[AiProcessing] fallback scans insert SUCCESS: scanId=${scan.id}',
      );

      final resultModel = ScanResultModel(
        id: '',
        scanId: scan.id,
        userId: uid,
        bodyFatPercent: bodyFat,
        leanMassEstimate: leanMass,
        fatMass: fatMass,
        bodyCategory: bodyCategory,
        physiqueProfile: bodyCategory,
        bodyScore: 65.0,
        confidenceScore: 0.65,
        summaryText: 'Body composition estimate based on your profile data.',
        leftArmPercent: 30.0,
        rightArmPercent: 30.0,
        upperBodyPercent: 28.0,
        leftLegPercent: 28.0,
        rightLegPercent: 28.0,
      );

      final savedResult = await SupabaseService.instance.saveScanResult(
        resultModel,
      );

      if (savedResult != null) {
        debugPrint(
          '[AiProcessing] fallback scan_results insert SUCCESS: id=${savedResult.id}',
        );
        debugPrint('[AiProcessing] scan saved successfully (fallback)');
        return savedResult;
      } else {
        debugPrint('[AiProcessing] fallback scan_results insert FAILED — rescue fetch');
        await Future.delayed(const Duration(milliseconds: 1500));
        try {
          final fetched = await SupabaseService.instance.fetchLatestScanResult();
          if (fetched != null && fetched.bodyFatPercent != null) {
            debugPrint('[AiProcessing] Fallback rescue fetch succeeded: id=${fetched.id}');
            return fetched;
          }
        } catch (_) {}
        return resultModel;
      }
    } catch (e) {
      debugPrint('[AiProcessing] _createFallbackScanRecord error: $e');
      return null;
    }
  }

  double _activityBonus(String? activity) {
    if (activity == null) return 0;
    if (activity.contains('5')) return 4.0;
    if (activity.contains('3') || activity.contains('4')) return 2.5;
    if (activity.contains('1') || activity.contains('2')) return 1.0;
    return 0;
  }

  String _bodyCategory(double bodyFat, bool isMale) {
    if (isMale) {
      if (bodyFat < 14) return 'Athletic';
      if (bodyFat < 18) return 'Lean';
      if (bodyFat < 25) return 'Balanced';
      return 'Overfat';
    } else {
      if (bodyFat < 21) return 'Athletic';
      if (bodyFat < 25) return 'Lean';
      if (bodyFat < 32) return 'Balanced';
      return 'Overfat';
    }
  }

  @override
  void dispose() {
    _progressController.dispose();
    _pulseController.dispose();
    _messageController.dispose();
    _particleController.dispose();
    _breathController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return PopScope(
      canPop: false,
      child: Scaffold(
        backgroundColor: Colors.transparent,
        body: Container(
          width: double.infinity,
          height: double.infinity,
          decoration: const BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topCenter,
              end: Alignment.bottomCenter,
              colors: [Color(0xFF0A0E1A), Color(0xFF0D1B2E), Color(0xFF0A0E1A)],
            ),
          ),
          child: SafeArea(
            child: Padding(
              padding: EdgeInsets.symmetric(vertical: 2.h, horizontal: 4.w),
              child: Column(
                children: [
                  SizedBox(height: 2.h),
                  _buildHeader(),
                  SizedBox(height: 3.h),
                  _buildProgressRing(),
                  SizedBox(height: 3.h),
                  _buildScanningBody(),
                  SizedBox(height: 3.h),
                  _buildMessageArea(),
                  SizedBox(height: 2.h),
                  _buildParticles(),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildHeader() {
    return Column(
      children: [
        Text(
          _isCompleted
              ? (_lowConfidence
                    ? 'Low Confidence Detected'
                    : 'Analysis Complete!')
              : 'Analyzing your body...',
          style: TextStyle(
            fontSize: 16.sp > 22 ? 22 : 16.sp,
            fontWeight: FontWeight.w700,
            color: Colors.white,
          ),
          textAlign: TextAlign.center,
        ),
        SizedBox(height: 1.h),
        Text(
          _isCompleted
              ? (_lowConfidence
                    ? 'Checking scan quality...'
                    : 'Your results are ready')
              : 'AI is processing your photos',
          style: TextStyle(
            fontSize: 11.sp > 14 ? 14 : 11.sp,
            color: Colors.white.withValues(alpha: 0.6),
          ),
          textAlign: TextAlign.center,
        ),
        SizedBox(height: 2.h),
        _buildLinearProgress(),
      ],
    );
  }

  Widget _buildLinearProgress() {
    return AnimatedBuilder(
      animation: _progressAnimation,
      builder: (context, child) {
        final double progress = _isCompleted ? 1.0 : _progressAnimation.value;
        final int percent = (progress * 100).round();
        return Column(
          children: [
            // Percentage label
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  'Processing',
                  style: TextStyle(
                    fontSize: 10.sp > 13 ? 13 : 10.sp,
                    color: Colors.white.withValues(alpha: 0.45),
                    fontWeight: FontWeight.w500,
                    letterSpacing: 0.5,
                  ),
                ),
                Text(
                  '$percent%',
                  style: TextStyle(
                    fontSize: 14.sp > 18 ? 18 : 14.sp,
                    fontWeight: FontWeight.w800,
                    color: const Color(0xFF6C5CE7),
                    letterSpacing: 1.0,
                  ),
                ),
              ],
            ),
            SizedBox(height: 0.8.h),
            // Progress bar track
            ClipRRect(
              borderRadius: BorderRadius.circular(100.0),
              child: Container(
                height: 6,
                width: double.infinity,
                color: Colors.white.withValues(alpha: 0.08),
                child: FractionallySizedBox(
                  alignment: Alignment.centerLeft,
                  widthFactor: progress.clamp(0.0, 1.0),
                  child: Container(
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(100.0),
                      gradient: const LinearGradient(
                        colors: [Color(0xFF8B7CF6), Color(0xFF6C5CE7)],
                      ),
                      boxShadow: [
                        BoxShadow(
                          color: const Color(
                            0xFF6C5CE7,
                          ).withValues(alpha: 0.55),
                          blurRadius: 8,
                          spreadRadius: 0,
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ),
          ],
        );
      },
    );
  }

  Widget _buildProgressRing() {
    return AnimatedBuilder(
      animation: Listenable.merge([_progressAnimation, _pulseAnimation]),
      builder: (context, child) {
        return Transform.scale(
          scale: _pulseAnimation.value,
          child: ProgressRingWidget(
            progress: _isCompleted ? 1.0 : _progressAnimation.value,
          ),
        );
      },
    );
  }

  Widget _buildScanningBody() {
    return AnimatedBuilder(
      animation: _breathAnimation,
      builder: (context, child) {
        return Transform.scale(
          scale: _breathAnimation.value,
          child: ScanningBodyWidget(
            progress: _isCompleted ? 1.0 : _progressAnimation.value,
            pulseValue: _breathAnimation.value,
          ),
        );
      },
    );
  }

  Widget _buildMessageArea() {
    return AnimatedBuilder(
      animation: _messageOpacity,
      builder: (context, child) {
        return Opacity(
          opacity: _messageOpacity.value,
          child: Container(
            padding: EdgeInsets.symmetric(horizontal: 6.w, vertical: 1.5.h),
            decoration: BoxDecoration(
              color: Colors.white.withValues(alpha: 0.05),
              borderRadius: BorderRadius.circular(16.0),
              border: Border.all(
                color: const Color(0xFF6C5CE7).withValues(alpha: 0.3),
              ),
            ),
            child: Text(
              _isCompleted
                  ? 'Body composition analysis complete'
                  : _messages[_currentMessageIndex],
              style: TextStyle(
                fontSize: 12.sp > 15 ? 15 : 12.sp,
                color: Colors.white.withValues(alpha: 0.85),
                fontWeight: FontWeight.w500,
              ),
              textAlign: TextAlign.center,
            ),
          ),
        );
      },
    );
  }

  Widget _buildParticles() {
    return AnimatedBuilder(
      animation: _particleController,
      builder: (context, child) {
        return SizedBox(
          height: 8.h,
          child: Stack(
            children: _particles.take(15).map((p) {
              final animatedY =
                  (p.y - _particleController.value * p.speed) % 1.0;
              return Positioned(
                left: p.x * 80.w,
                top: animatedY * 8.h,
                child: Opacity(
                  opacity: p.opacity * (1 - _particleController.value * 0.3),
                  child: Container(
                    width: p.size,
                    height: p.size,
                    decoration: BoxDecoration(
                      color: Colors.white.withValues(alpha: p.opacity),
                      shape: BoxShape.circle,
                    ),
                  ),
                ),
              );
            }).toList(),
          ),
        );
      },
    );
  }
}
