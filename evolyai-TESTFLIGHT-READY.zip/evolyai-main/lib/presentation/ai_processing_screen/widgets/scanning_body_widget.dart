import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

class ScanningBodyWidget extends StatelessWidget {
  final double progress;
  final double pulseValue;

  const ScanningBodyWidget({
    super.key,
    required this.progress,
    required this.pulseValue,
  });

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: 40.w,
      height: 30.h,
      child: CustomPaint(
        painter: _ScanningBodyPainter(
          progress: progress,
          pulseValue: pulseValue,
        ),
      ),
    );
  }
}

class _ScanningBodyPainter extends CustomPainter {
  final double progress;
  final double pulseValue;

  _ScanningBodyPainter({required this.progress, required this.pulseValue});

  @override
  void paint(Canvas canvas, Size size) {
    final cx = size.width / 2;
    final cy = size.height / 2;

    // Draw body silhouette
    _drawBodySilhouette(canvas, size, cx, cy);

    // Draw scanning line
    _drawScanLine(canvas, size, cx, cy);

    // Draw grid lines
    _drawGridLines(canvas, size, cx, cy);
  }

  void _drawBodySilhouette(Canvas canvas, Size size, double cx, double cy) {
    final paint = Paint()
      ..color = const Color(0xFF6C5CE7).withValues(alpha: 0.15)
      ..style = PaintingStyle.fill;

    final strokePaint = Paint()
      ..color = const Color(0xFF6C5CE7).withValues(alpha: 0.5)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1.5;

    final path = Path();
    final headR = size.width * 0.12;
    final headCy = cy - size.height * 0.32;

    // Head
    canvas.drawCircle(Offset(cx, headCy), headR, paint);
    canvas.drawCircle(Offset(cx, headCy), headR, strokePaint);

    // Body
    path.moveTo(cx - size.width * 0.18, headCy + headR);
    path.cubicTo(
      cx - size.width * 0.22,
      cy - size.height * 0.05,
      cx - size.width * 0.2,
      cy + size.height * 0.05,
      cx - size.width * 0.12,
      cy + size.height * 0.35,
    );
    path.lineTo(cx + size.width * 0.12, cy + size.height * 0.35);
    path.cubicTo(
      cx + size.width * 0.2,
      cy + size.height * 0.05,
      cx + size.width * 0.22,
      cy - size.height * 0.05,
      cx + size.width * 0.18,
      headCy + headR,
    );
    path.close();
    canvas.drawPath(path, paint);
    canvas.drawPath(path, strokePaint);

    // Arms
    final armPaint = Paint()
      ..color = const Color(0xFF6C5CE7).withValues(alpha: 0.15)
      ..style = PaintingStyle.fill;
    final armStroke = Paint()
      ..color = const Color(0xFF6C5CE7).withValues(alpha: 0.5)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1.5;

    // Left arm
    final leftArm = Path();
    leftArm.moveTo(cx - size.width * 0.18, headCy + headR + 4);
    leftArm.cubicTo(
      cx - size.width * 0.35,
      cy - size.height * 0.1,
      cx - size.width * 0.38,
      cy + size.height * 0.05,
      cx - size.width * 0.3,
      cy + size.height * 0.15,
    );
    leftArm.lineTo(cx - size.width * 0.22, cy + size.height * 0.15);
    leftArm.cubicTo(
      cx - size.width * 0.28,
      cy + size.height * 0.05,
      cx - size.width * 0.25,
      cy - size.height * 0.1,
      cx - size.width * 0.12,
      headCy + headR + 4,
    );
    leftArm.close();
    canvas.drawPath(leftArm, armPaint);
    canvas.drawPath(leftArm, armStroke);

    // Right arm
    final rightArm = Path();
    rightArm.moveTo(cx + size.width * 0.12, headCy + headR + 4);
    rightArm.cubicTo(
      cx + size.width * 0.25,
      cy - size.height * 0.1,
      cx + size.width * 0.28,
      cy + size.height * 0.05,
      cx + size.width * 0.22,
      cy + size.height * 0.15,
    );
    rightArm.lineTo(cx + size.width * 0.3, cy + size.height * 0.15);
    rightArm.cubicTo(
      cx + size.width * 0.38,
      cy + size.height * 0.05,
      cx + size.width * 0.35,
      cy - size.height * 0.1,
      cx + size.width * 0.18,
      headCy + headR + 4,
    );
    rightArm.close();
    canvas.drawPath(rightArm, armPaint);
    canvas.drawPath(rightArm, armStroke);
  }

  void _drawScanLine(Canvas canvas, Size size, double cx, double cy) {
    final scanY = size.height * 0.1 + (size.height * 0.8) * progress;
    final scanPaint = Paint()
      ..shader = LinearGradient(
        colors: [
          Colors.transparent,
          const Color(0xFF74B9FF).withValues(alpha: 0.8),
          Colors.transparent,
        ],
      ).createShader(Rect.fromLTWH(0, scanY - 1, size.width, 2))
      ..strokeWidth = 2
      ..style = PaintingStyle.stroke;

    canvas.drawLine(Offset(0, scanY), Offset(size.width, scanY), scanPaint);

    // Glow on scan line
    final glowPaint = Paint()
      ..color = const Color(0xFF74B9FF).withValues(alpha: 0.2)
      ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 8);
    canvas.drawLine(Offset(0, scanY), Offset(size.width, scanY), glowPaint);
  }

  void _drawGridLines(Canvas canvas, Size size, double cx, double cy) {
    final gridPaint = Paint()
      ..color = const Color(0xFF74B9FF).withValues(alpha: 0.08)
      ..strokeWidth = 0.5;

    // Horizontal lines
    for (int i = 0; i < 8; i++) {
      final y = size.height * i / 8;
      canvas.drawLine(Offset(0, y), Offset(size.width, y), gridPaint);
    }

    // Vertical lines
    for (int i = 0; i < 6; i++) {
      final x = size.width * i / 6;
      canvas.drawLine(Offset(x, 0), Offset(x, size.height), gridPaint);
    }
  }

  @override
  bool shouldRepaint(_ScanningBodyPainter oldDelegate) =>
      oldDelegate.progress != progress || oldDelegate.pulseValue != pulseValue;
}
