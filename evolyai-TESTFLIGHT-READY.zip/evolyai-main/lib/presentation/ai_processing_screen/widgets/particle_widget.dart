import 'package:flutter/material.dart';

class ParticleData {
  final double x;
  final double y;
  final double size;
  final double speed;
  final double opacity;

  ParticleData({
    required this.x,
    required this.y,
    required this.size,
    required this.speed,
    required this.opacity,
  });
}

class ParticlePainter extends CustomPainter {
  final List<ParticleData> particles;
  final double progress;

  ParticlePainter({required this.particles, required this.progress});

  @override
  void paint(Canvas canvas, Size size) {
    for (final particle in particles) {
      final dy = (particle.y + progress * particle.speed) % 1.0;
      final paint = Paint()
        ..color = _getParticleColor(particle.opacity)
        ..style = PaintingStyle.fill;

      final offset = Offset(particle.x * size.width, dy * size.height);
      canvas.drawCircle(offset, particle.size, paint);

      // Draw glow
      final glowPaint = Paint()
        ..color = _getParticleColor(particle.opacity * 0.3)
        ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 4);
      canvas.drawCircle(offset, particle.size * 2, glowPaint);
    }
  }

  Color _getParticleColor(double opacity) {
    final colors = [
      Color.fromRGBO(108, 92, 231, opacity.clamp(0.0, 1.0)),
      Color.fromRGBO(116, 185, 255, opacity.clamp(0.0, 1.0)),
      Color.fromRGBO(255, 255, 255, opacity.clamp(0.0, 1.0)),
    ];
    final index = (opacity * 10).toInt() % colors.length;
    return colors[index];
  }

  @override
  bool shouldRepaint(ParticlePainter oldDelegate) =>
      oldDelegate.progress != progress;
}
