import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:sizer/sizer.dart';

import '../../models/onboarding_data.dart';
import '../goal_selection_screen/widgets/onboarding_progress_widget.dart';
import './widgets/age_picker_widget.dart';

class AgeInputScreen extends StatefulWidget {
  final OnboardingData? onboardingData;

  const AgeInputScreen({super.key, this.onboardingData});

  @override
  State<AgeInputScreen> createState() => _AgeInputScreenState();
}

class _AgeInputScreenState extends State<AgeInputScreen>
    with SingleTickerProviderStateMixin {
  int _selectedAge = 25;
  late AnimationController _fadeController;
  late Animation<double> _fadeAnimation;

  @override
  void initState() {
    super.initState();
    _selectedAge = widget.onboardingData?.age ?? 25;
    _fadeController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 600),
    )..forward();
    _fadeAnimation = CurvedAnimation(
      parent: _fadeController,
      curve: Curves.easeOut,
    );
  }

  @override
  void dispose() {
    _fadeController.dispose();
    super.dispose();
  }

  void _onContinue() {
    HapticFeedback.mediumImpact();
    final data = (widget.onboardingData ?? OnboardingData()).copyWith(
      age: _selectedAge,
    );
    Navigator.of(context).pushNamed('/height-input-screen', arguments: data);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: SafeArea(
        child: FadeTransition(
          opacity: _fadeAnimation,
          child: Padding(
            padding: EdgeInsets.symmetric(horizontal: 4.w, vertical: 2.h),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                _buildHeader(),
                SizedBox(height: 4.h),
                _buildTitleSection(),
                SizedBox(height: 2.h),
                _buildAgeDisplay(),
                Expanded(
                  child: Center(
                    child: AgePickerWidget(
                      selectedAge: _selectedAge,
                      onAgeChanged: (age) {
                        setState(() => _selectedAge = age);
                      },
                    ),
                  ),
                ),
                _buildAgeValidationNote(),
                SizedBox(height: 2.h),
                _buildContinueButton(),
                SizedBox(height: 1.h),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildHeader() {
    return Row(
      children: [
        GestureDetector(
          onTap: () => Navigator.of(context).pop(),
          child: Container(
            width: 10.w,
            height: 10.w,
            decoration: BoxDecoration(
              color: const Color(0xFFF8F9FA),
              borderRadius: BorderRadius.circular(12.0),
              border: Border.all(color: const Color(0xFFE2E8F0)),
            ),
            child: const Icon(
              Icons.arrow_back_ios_new_rounded,
              color: Color(0xFF1B365D),
              size: 18,
            ),
          ),
        ),
        SizedBox(width: 3.w),
        Expanded(
          child: OnboardingProgressWidget(currentStep: 4, totalSteps: 8),
        ),
      ],
    );
  }

  Widget _buildTitleSection() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        ShaderMask(
          shaderCallback: (bounds) => const LinearGradient(
            colors: [Color(0xFF1B365D), Color(0xFF6C5CE7)],
            begin: Alignment.centerLeft,
            end: Alignment.centerRight,
          ).createShader(bounds),
          child: Text(
            "What's your age?",
            style: GoogleFonts.plusJakartaSans(
              fontSize: 20.sp > 28 ? 28 : 20.sp,
              fontWeight: FontWeight.w800,
              color: Colors.white,
              height: 1.2,
            ),
          ),
        ),
        SizedBox(height: 1.h),
        Text(
          'Your age helps us personalize your body\ncomposition analysis and fitness insights.',
          style: GoogleFonts.plusJakartaSans(
            fontSize: 12.sp > 15 ? 15 : 12.sp,
            fontWeight: FontWeight.w400,
            color: const Color(0xFF636E72),
            height: 1.5,
          ),
        ),
      ],
    );
  }

  Widget _buildAgeDisplay() {
    return Center(
      child: AnimatedSwitcher(
        duration: const Duration(milliseconds: 200),
        transitionBuilder: (child, animation) =>
            ScaleTransition(scale: animation, child: child),
        child: Container(
          key: ValueKey(_selectedAge),
          padding: EdgeInsets.symmetric(horizontal: 8.w, vertical: 1.5.h),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(20.0),
            gradient: const LinearGradient(
              colors: [Color(0xFF6C5CE7), Color(0xFF74B9FF)],
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
            ),
            boxShadow: [
              BoxShadow(
                color: const Color(0xFF6C5CE7).withValues(alpha: 0.3),
                blurRadius: 20,
                offset: const Offset(0, 8),
              ),
            ],
          ),
          child: Text(
            '$_selectedAge',
            style: GoogleFonts.plusJakartaSans(
              fontSize: 22.sp > 36 ? 36 : 22.sp,
              fontWeight: FontWeight.w900,
              color: Colors.white,
              letterSpacing: -1,
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildAgeValidationNote() {
    return Center(
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          const Icon(
            Icons.info_outline_rounded,
            size: 14,
            color: Color(0xFF636E72),
          ),
          SizedBox(width: 1.w),
          Text(
            'Minimum age is 13 years',
            style: GoogleFonts.plusJakartaSans(
              fontSize: 10.sp > 12 ? 12 : 10.sp,
              fontWeight: FontWeight.w400,
              color: const Color(0xFF636E72),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildContinueButton() {
    return GestureDetector(
      onTap: _onContinue,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 200),
        width: double.infinity,
        height: 7.h > 60 ? 60 : 7.h,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(16.0),
          gradient: const LinearGradient(
            colors: [Color(0xFF6C5CE7), Color(0xFF74B9FF)],
            begin: Alignment.centerLeft,
            end: Alignment.centerRight,
          ),
          boxShadow: [
            BoxShadow(
              color: const Color(0xFF6C5CE7).withValues(alpha: 0.35),
              blurRadius: 16,
              offset: const Offset(0, 6),
            ),
          ],
        ),
        child: Center(
          child: Text(
            'Continue',
            style: GoogleFonts.plusJakartaSans(
              fontSize: 14.sp > 17 ? 17 : 14.sp,
              fontWeight: FontWeight.w700,
              color: Colors.white,
            ),
          ),
        ),
      ),
    );
  }
}
