import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:sizer/sizer.dart';

class AgePickerWidget extends StatefulWidget {
  final int selectedAge;
  final ValueChanged<int> onAgeChanged;

  const AgePickerWidget({
    super.key,
    required this.selectedAge,
    required this.onAgeChanged,
  });

  @override
  State<AgePickerWidget> createState() => _AgePickerWidgetState();
}

class _AgePickerWidgetState extends State<AgePickerWidget> {
  late FixedExtentScrollController _scrollController;
  static const int _minAge = 13;
  static const int _maxAge = 100;

  @override
  void initState() {
    super.initState();
    final initialIndex = widget.selectedAge.clamp(_minAge, _maxAge) - _minAge;
    _scrollController = FixedExtentScrollController(initialItem: initialIndex);
  }

  @override
  void didUpdateWidget(AgePickerWidget oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (oldWidget.selectedAge != widget.selectedAge) {
      final index = widget.selectedAge.clamp(_minAge, _maxAge) - _minAge;
      WidgetsBinding.instance.addPostFrameCallback((_) {
        if (_scrollController.hasClients) {
          _scrollController.jumpToItem(index);
        }
      });
    }
  }

  @override
  void dispose() {
    _scrollController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    const double itemExtent = 52.0;
    const double pickerHeight = 240.0;

    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Icon(Icons.cake_outlined, size: 16, color: Color(0xFF6C5CE7)),
            const SizedBox(width: 6),
            Text(
              'Age (years)',
              style: GoogleFonts.plusJakartaSans(
                fontSize: 13,
                fontWeight: FontWeight.w600,
                color: const Color(0xFF636E72),
              ),
            ),
          ],
        ),
        const SizedBox(height: 12),
        SizedBox(
          height: pickerHeight,
          child: Stack(
            alignment: Alignment.center,
            children: [
              // Selection highlight band
              Container(
                height: itemExtent,
                margin: EdgeInsets.symmetric(horizontal: 8.w),
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(14.0),
                  gradient: const LinearGradient(
                    colors: [Color(0xFFF0EDFF), Color(0xFFE8F4FF)],
                    begin: Alignment.centerLeft,
                    end: Alignment.centerRight,
                  ),
                  border: Border.all(
                    color: const Color(0xFF6C5CE7).withValues(alpha: 0.25),
                    width: 1.5,
                  ),
                ),
              ),
              // Picker
              ListWheelScrollView.useDelegate(
                controller: _scrollController,
                itemExtent: itemExtent,
                perspective: 0.001,
                diameterRatio: 4.0,
                overAndUnderCenterOpacity: 1.0,
                physics: const BouncingScrollPhysics(),
                onSelectedItemChanged: (index) {
                  HapticFeedback.selectionClick();
                  widget.onAgeChanged(index + _minAge);
                },
                childDelegate: ListWheelChildBuilderDelegate(
                  childCount: _maxAge - _minAge + 1,
                  builder: (context, index) {
                    final age = index + _minAge;
                    final isSelected = age == widget.selectedAge;
                    return Center(
                      child: AnimatedDefaultTextStyle(
                        duration: const Duration(milliseconds: 150),
                        style: isSelected
                            ? GoogleFonts.plusJakartaSans(
                                fontSize: 22,
                                fontWeight: FontWeight.w800,
                                color: const Color(0xFF6C5CE7),
                              )
                            : GoogleFonts.plusJakartaSans(
                                fontSize: 16,
                                fontWeight: FontWeight.w400,
                                color: const Color(0xFFB2BEC3),
                              ),
                        child: Text('$age'),
                      ),
                    );
                  },
                ),
              ),
              // Top fade — subtle white
              Positioned(
                top: 0,
                left: 0,
                right: 0,
                height: 70,
                child: IgnorePointer(
                  child: Container(
                    decoration: const BoxDecoration(
                      gradient: LinearGradient(
                        begin: Alignment.topCenter,
                        end: Alignment.bottomCenter,
                        colors: [Color(0xFFFFFFFF), Color(0x00FFFFFF)],
                      ),
                    ),
                  ),
                ),
              ),
              // Bottom fade — subtle white
              Positioned(
                bottom: 0,
                left: 0,
                right: 0,
                height: 70,
                child: IgnorePointer(
                  child: Container(
                    decoration: const BoxDecoration(
                      gradient: LinearGradient(
                        begin: Alignment.bottomCenter,
                        end: Alignment.topCenter,
                        colors: [Color(0xFFFFFFFF), Color(0x00FFFFFF)],
                      ),
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }
}
