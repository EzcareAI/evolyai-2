import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:sizer/sizer.dart';

import '../../services/supabase_service.dart';
import '../../routes/app_routes.dart';
import '../../models/onboarding_data.dart';

/// Arguments passed to RescanResultScreen via Navigator.
class RescanResultArgs {
  final ScanResultModel newResult;
  final ScanResultModel? previousResult;
  final OnboardingData? onboardingData;

  const RescanResultArgs({
    required this.newResult,
    this.previousResult,
    this.onboardingData,
  });
}

class RescanResultScreen extends StatefulWidget {
  const RescanResultScreen({super.key});

  @override
  State<RescanResultScreen> createState() => _RescanResultScreenState();
}

class _RescanResultScreenState extends State<RescanResultScreen>
    with SingleTickerProviderStateMixin {
  late AnimationController _entryController;
  late Animation<double> _fadeAnimation;
  late Animation<Offset> _slideAnimation;

  ScanResultModel? _resolvedResult;
  bool _isLoading = false;
  bool _hydrationAttempted = false;

  @override
  void initState() {
    super.initState();
    _entryController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 700),
    )..forward();
    _fadeAnimation = CurvedAnimation(
      parent: _entryController,
      curve: Curves.easeOut,
    );
    _slideAnimation =
        Tween<Offset>(begin: const Offset(0, 0.06), end: Offset.zero).animate(
          CurvedAnimation(parent: _entryController, curve: Curves.easeOutCubic),
        );
  }

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    if (!_hydrationAttempted) {
      _hydrationAttempted = true;
      _hydrateResult();
    }
  }

  bool _isResultComplete(ScanResultModel? result) {
    if (result == null) return false;
    return result.bodyFatPercent != null &&
        result.leanMassEstimate != null &&
        result.fatMass != null;
  }

  Future<void> _hydrateResult() async {
    final args =
        ModalRoute.of(context)?.settings.arguments as RescanResultArgs?;
    final passedResult = args?.newResult;

    if (_isResultComplete(passedResult)) {
      setState(() {
        _resolvedResult = passedResult;
      });
      return;
    }

    // Result is null or incomplete — fetch latest from Supabase
    setState(() => _isLoading = true);
    try {
      final fetched = await SupabaseService.instance.fetchLatestScanResult();
      if (mounted) {
        setState(() {
          _resolvedResult = _isResultComplete(fetched) ? fetched : passedResult;
          _isLoading = false;
        });
      }
    } catch (e) {
      debugPrint('[RescanResultScreen] hydration error: $e');
      if (mounted) {
        setState(() {
          _resolvedResult = passedResult;
          _isLoading = false;
        });
      }
    }
  }

  @override
  void dispose() {
    _entryController.dispose();
    super.dispose();
  }

  void _goToDashboard() {
    if (_isLoading) return;
    HapticFeedback.mediumImpact();
    final args =
        ModalRoute.of(context)?.settings.arguments as RescanResultArgs?;
    Navigator.of(context, rootNavigator: true).pushNamedAndRemoveUntil(
      AppRoutes.homeDashboard,
      (route) => false,
      arguments: args?.onboardingData,
    );
  }

  Color _bodyFatColor(double? bf) {
    if (bf == null) return const Color(0xFF6C5CE7);
    if (bf < 15) return const Color(0xFF00B894);
    if (bf < 25) return const Color(0xFF0984E3);
    if (bf < 32) return const Color(0xFFF39C12);
    return const Color(0xFFE17055);
  }

  String _changeLabel(double? current, double? previous) {
    if (current == null || previous == null) return '';
    final diff = current - previous;
    if (diff.abs() < 0.1) return 'Stable';
    final sign = diff > 0 ? '+' : '';
    return '$sign${diff.toStringAsFixed(1)}%';
  }

  Color _changeColor(double? current, double? previous) {
    if (current == null || previous == null) return Colors.grey;
    final diff = current - previous;
    if (diff.abs() < 0.1) return Colors.grey;
    // Lower body fat = better
    return diff < 0 ? const Color(0xFF00B894) : const Color(0xFFE17055);
  }

  @override
  Widget build(BuildContext context) {
    final args =
        ModalRoute.of(context)?.settings.arguments as RescanResultArgs?;
    final newResult = _resolvedResult ?? args?.newResult;
    final prevResult = args?.previousResult;

    return Scaffold(
      backgroundColor: Colors.white,
      body: SafeArea(
        child: _isLoading
            ? _buildLoadingState()
            : FadeTransition(
                opacity: _fadeAnimation,
                child: SlideTransition(
                  position: _slideAnimation,
                  child: Column(
                    children: [
                      _buildHeader(),
                      Expanded(
                        child: SingleChildScrollView(
                          padding: EdgeInsets.symmetric(horizontal: 4.w),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              SizedBox(height: 1.h),
                              _buildHeroCard(newResult),
                              SizedBox(height: 2.h),
                              if (prevResult != null) ...[
                                _buildComparisonCard(newResult, prevResult),
                                SizedBox(height: 2.h),
                              ],
                              _buildZoneBreakdown(newResult),
                              SizedBox(height: 2.h),
                              if (newResult?.summaryText != null)
                                _buildSummaryCard(newResult!.summaryText!),
                              SizedBox(height: 3.h),
                            ],
                          ),
                        ),
                      ),
                      Padding(
                        padding: EdgeInsets.fromLTRB(4.w, 1.h, 4.w, 3.h),
                        child: _buildCta(),
                      ),
                    ],
                  ),
                ),
              ),
      ),
    );
  }

  Widget _buildLoadingState() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Container(
            width: 18.w,
            height: 18.w,
            decoration: BoxDecoration(
              gradient: const LinearGradient(
                colors: [Color(0xFF6C5CE7), Color(0xFF8B5CF6)],
              ),
              borderRadius: BorderRadius.circular(20.0),
            ),
            child: const Center(
              child: CircularProgressIndicator(
                color: Colors.white,
                strokeWidth: 2.5,
              ),
            ),
          ),
          SizedBox(height: 3.h),
          Text(
            'Chargement de vos résultats…',
            style: GoogleFonts.plusJakartaSans(
              fontSize: 15.sp > 18 ? 18 : 15.sp,
              fontWeight: FontWeight.w700,
              color: const Color(0xFF1B365D),
            ),
          ),
          SizedBox(height: 1.h),
          Text(
            'Récupération de votre analyse corporelle',
            style: GoogleFonts.plusJakartaSans(
              fontSize: 11.sp > 13 ? 13 : 11.sp,
              color: const Color(0xFF636E72),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildHeader() {
    return Padding(
      padding: EdgeInsets.symmetric(horizontal: 4.w, vertical: 2.h),
      child: Row(
        children: [
          Container(
            width: 10.w,
            height: 10.w,
            decoration: BoxDecoration(
              gradient: const LinearGradient(
                colors: [Color(0xFF00B894), Color(0xFF00CEC9)],
              ),
              borderRadius: BorderRadius.circular(12.0),
            ),
            child: const Icon(
              Icons.check_rounded,
              color: Colors.white,
              size: 20,
            ),
          ),
          SizedBox(width: 3.w),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'Scan Terminé',
                  style: GoogleFonts.plusJakartaSans(
                    fontSize: 16.sp > 20 ? 20 : 16.sp,
                    fontWeight: FontWeight.w800,
                    color: const Color(0xFF1B365D),
                  ),
                ),
                Text(
                  'Résultats de votre dernière analyse',
                  style: GoogleFonts.plusJakartaSans(
                    fontSize: 11.sp > 13 ? 13 : 11.sp,
                    color: const Color(0xFF636E72),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildHeroCard(ScanResultModel? result) {
    final bf = result?.bodyFatPercent;
    final profile =
        result?.physiqueProfile ?? result?.bodyCategory ?? 'Balanced';
    final leanMass = result?.leanMassEstimate;
    final fatMass = result?.fatMass;
    final bfColor = _bodyFatColor(bf);

    return Container(
      width: double.infinity,
      padding: EdgeInsets.all(4.w),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [
            const Color(0xFF1B365D),
            const Color(0xFF6C5CE7).withValues(alpha: 0.9),
          ],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(20.0),
        boxShadow: [
          BoxShadow(
            color: const Color(0xFF6C5CE7).withValues(alpha: 0.3),
            blurRadius: 20,
            offset: const Offset(0, 8),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                padding: EdgeInsets.symmetric(
                  horizontal: 2.5.w,
                  vertical: 0.5.h,
                ),
                decoration: BoxDecoration(
                  color: Colors.white.withValues(alpha: 0.15),
                  borderRadius: BorderRadius.circular(8.0),
                ),
                child: Text(
                  profile,
                  style: GoogleFonts.plusJakartaSans(
                    fontSize: 11.sp > 13 ? 13 : 11.sp,
                    fontWeight: FontWeight.w700,
                    color: Colors.white,
                  ),
                ),
              ),
              const Spacer(),
              Text(
                'Dernier Scan',
                style: GoogleFonts.plusJakartaSans(
                  fontSize: 10.sp > 12 ? 12 : 10.sp,
                  color: Colors.white.withValues(alpha: 0.7),
                ),
              ),
            ],
          ),
          SizedBox(height: 2.h),
          Row(
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              Text(
                bf != null ? '${bf.toStringAsFixed(1)}%' : '--',
                style: GoogleFonts.plusJakartaSans(
                  fontSize: 28.sp > 42 ? 42 : 28.sp,
                  fontWeight: FontWeight.w800,
                  color: Colors.white,
                  height: 1.0,
                ),
              ),
              SizedBox(width: 2.w),
              Padding(
                padding: const EdgeInsets.only(bottom: 6),
                child: Text(
                  'Masse Grasse',
                  style: GoogleFonts.plusJakartaSans(
                    fontSize: 12.sp > 15 ? 15 : 12.sp,
                    color: Colors.white.withValues(alpha: 0.8),
                    fontWeight: FontWeight.w500,
                  ),
                ),
              ),
            ],
          ),
          SizedBox(height: 2.h),
          Row(
            children: [
              _buildStatChip(
                label: 'Masse Maigre',
                value: leanMass != null
                    ? '${leanMass.toStringAsFixed(1)} kg'
                    : '--',
              ),
              SizedBox(width: 2.w),
              _buildStatChip(
                label: 'Masse Grasse kg',
                value: fatMass != null
                    ? '${fatMass.toStringAsFixed(1)} kg'
                    : '--',
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildStatChip({required String label, required String value}) {
    return Expanded(
      child: Container(
        padding: EdgeInsets.symmetric(horizontal: 2.w, vertical: 1.h),
        decoration: BoxDecoration(
          color: Colors.white.withValues(alpha: 0.12),
          borderRadius: BorderRadius.circular(10.0),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              label,
              style: GoogleFonts.plusJakartaSans(
                fontSize: 9.sp > 11 ? 11 : 9.sp,
                color: Colors.white.withValues(alpha: 0.7),
              ),
            ),
            Text(
              value,
              style: GoogleFonts.plusJakartaSans(
                fontSize: 12.sp > 15 ? 15 : 12.sp,
                fontWeight: FontWeight.w700,
                color: Colors.white,
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildComparisonCard(
    ScanResultModel? newResult,
    ScanResultModel prevResult,
  ) {
    final newBf = newResult?.bodyFatPercent;
    final prevBf = prevResult.bodyFatPercent;
    final changeLabel = _changeLabel(newBf, prevBf);
    final changeColor = _changeColor(newBf, prevBf);
    final isImprovement = newBf != null && prevBf != null && newBf < prevBf;

    return Container(
      width: double.infinity,
      padding: EdgeInsets.all(4.w),
      decoration: BoxDecoration(
        color: const Color(0xFFF8F9FA),
        borderRadius: BorderRadius.circular(16.0),
        border: Border.all(color: const Color(0xFFE2E8F0)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              const Icon(
                Icons.compare_arrows_rounded,
                color: Color(0xFF6C5CE7),
                size: 18,
              ),
              SizedBox(width: 2.w),
              Text(
                'vs Scan Précédent',
                style: GoogleFonts.plusJakartaSans(
                  fontSize: 13.sp > 16 ? 16 : 13.sp,
                  fontWeight: FontWeight.w700,
                  color: const Color(0xFF1B365D),
                ),
              ),
            ],
          ),
          SizedBox(height: 1.5.h),
          Row(
            children: [
              Expanded(
                child: _buildCompareColumn(
                  label: 'Avant',
                  value: prevBf != null
                      ? '${prevBf.toStringAsFixed(1)}%'
                      : '--',
                  subLabel:
                      prevResult.physiqueProfile ??
                      prevResult.bodyCategory ??
                      '',
                  color: const Color(0xFF636E72),
                ),
              ),
              Container(
                padding: EdgeInsets.symmetric(horizontal: 3.w, vertical: 0.8.h),
                decoration: BoxDecoration(
                  color: changeColor.withValues(alpha: 0.1),
                  borderRadius: BorderRadius.circular(10.0),
                ),
                child: Column(
                  children: [
                    Icon(
                      isImprovement
                          ? Icons.trending_down_rounded
                          : (newBf == prevBf
                                ? Icons.trending_flat_rounded
                                : Icons.trending_up_rounded),
                      color: changeColor,
                      size: 20,
                    ),
                    Text(
                      changeLabel,
                      style: GoogleFonts.plusJakartaSans(
                        fontSize: 10.sp > 12 ? 12 : 10.sp,
                        fontWeight: FontWeight.w700,
                        color: changeColor,
                      ),
                    ),
                  ],
                ),
              ),
              Expanded(
                child: _buildCompareColumn(
                  label: 'Maintenant',
                  value: newBf != null ? '${newBf.toStringAsFixed(1)}%' : '--',
                  subLabel:
                      newResult?.physiqueProfile ??
                      newResult?.bodyCategory ??
                      '',
                  color: const Color(0xFF1B365D),
                  isHighlighted: true,
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildCompareColumn({
    required String label,
    required String value,
    required String subLabel,
    required Color color,
    bool isHighlighted = false,
  }) {
    return Column(
      children: [
        Text(
          label,
          style: GoogleFonts.plusJakartaSans(
            fontSize: 10.sp > 12 ? 12 : 10.sp,
            color: const Color(0xFF636E72),
          ),
        ),
        SizedBox(height: 0.4.h),
        Text(
          value,
          style: GoogleFonts.plusJakartaSans(
            fontSize: 16.sp > 22 ? 22 : 16.sp,
            fontWeight: FontWeight.w800,
            color: color,
          ),
        ),
        if (subLabel.isNotEmpty)
          Text(
            subLabel,
            style: GoogleFonts.plusJakartaSans(
              fontSize: 9.sp > 11 ? 11 : 9.sp,
              color: const Color(0xFF636E72),
            ),
            overflow: TextOverflow.ellipsis,
          ),
      ],
    );
  }

  Widget _buildZoneBreakdown(ScanResultModel? result) {
    if (result == null) return const SizedBox.shrink();

    final zones = [
      {'label': 'Bras Gauche', 'value': result.leftArmPercent, 'icon': Icons.fitness_center_rounded},
      {'label': 'Bras Droit', 'value': result.rightArmPercent, 'icon': Icons.fitness_center_rounded},
      {'label': 'Haut du Corps', 'value': result.upperBodyPercent, 'icon': Icons.accessibility_new_rounded},
      {'label': 'Jambe Gauche', 'value': result.leftLegPercent, 'icon': Icons.directions_walk_rounded},
      {'label': 'Jambe Droite', 'value': result.rightLegPercent, 'icon': Icons.directions_walk_rounded},
    ];

    return Container(
      width: double.infinity,
      padding: EdgeInsets.all(4.w),
      decoration: BoxDecoration(
        color: const Color(0xFFFAFAFF),
        borderRadius: BorderRadius.circular(16.0),
        border: Border.all(color: const Color(0xFFE2E8F0)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'Répartition par Zones',
            style: GoogleFonts.plusJakartaSans(
              fontSize: 13.sp > 16 ? 16 : 13.sp,
              fontWeight: FontWeight.w700,
              color: const Color(0xFF1B365D),
            ),
          ),
          SizedBox(height: 1.5.h),
          ...zones.map((zone) {
            final value = zone['value'] as double?;
            final label = zone['label'] as String;
            final icon = zone['icon'] as IconData;
            final pct = value ?? 0.0;
            final barColor = _bodyFatColor(pct);

            return Padding(
              padding: EdgeInsets.only(bottom: 1.2.h),
              child: Row(
                children: [
                  Icon(icon, color: const Color(0xFF6C5CE7), size: 16),
                  SizedBox(width: 2.w),
                  SizedBox(
                    width: 20.w,
                    child: Text(
                      label,
                      style: GoogleFonts.plusJakartaSans(
                        fontSize: 10.sp > 12 ? 12 : 10.sp,
                        color: const Color(0xFF636E72),
                      ),
                    ),
                  ),
                  Expanded(
                    child: ClipRRect(
                      borderRadius: BorderRadius.circular(4.0),
                      child: LinearProgressIndicator(
                        value: (pct / 60.0).clamp(0.0, 1.0),
                        backgroundColor: const Color(0xFFE2E8F0),
                        valueColor: AlwaysStoppedAnimation<Color>(barColor),
                        minHeight: 6,
                      ),
                    ),
                  ),
                  SizedBox(width: 2.w),
                  SizedBox(
                    width: 12.w,
                    child: Text(
                      value != null ? '${value.toStringAsFixed(1)}%' : '--',
                      style: GoogleFonts.plusJakartaSans(
                        fontSize: 10.sp > 12 ? 12 : 10.sp,
                        fontWeight: FontWeight.w700,
                        color: const Color(0xFF1B365D),
                      ),
                      textAlign: TextAlign.right,
                    ),
                  ),
                ],
              ),
            );
          }),
        ],
      ),
    );
  }

  Widget _buildSummaryCard(String summaryText) {
    return Container(
      width: double.infinity,
      padding: EdgeInsets.all(4.w),
      decoration: BoxDecoration(
        color: const Color(0xFF6C5CE7).withValues(alpha: 0.06),
        borderRadius: BorderRadius.circular(16.0),
        border: Border.all(
          color: const Color(0xFF6C5CE7).withValues(alpha: 0.2),
        ),
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Icon(
            Icons.auto_awesome_rounded,
            color: Color(0xFF6C5CE7),
            size: 18,
          ),
          SizedBox(width: 2.w),
          Expanded(
            child: Text(
              summaryText,
              style: GoogleFonts.plusJakartaSans(
                fontSize: 11.sp > 14 ? 14 : 11.sp,
                color: const Color(0xFF2D3436),
                height: 1.5,
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildCta() {
    final hasRealData = _isResultComplete(_resolvedResult);
    final isReady = !_isLoading && hasRealData;

    return SizedBox(
      width: double.infinity,
      height: 6.5.h,
      child: DecoratedBox(
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(16.0),
          gradient: LinearGradient(
            colors: isReady
                ? [const Color(0xFF6C5CE7), const Color(0xFF8B5CF6)]
                : [const Color(0xFFB2BEC3), const Color(0xFFDFE6E9)],
            begin: Alignment.centerLeft,
            end: Alignment.centerRight,
          ),
          boxShadow: isReady
              ? [
                  BoxShadow(
                    color: const Color(0xFF6C5CE7).withValues(alpha: 0.4),
                    blurRadius: 16,
                    offset: const Offset(0, 6),
                  ),
                ]
              : [],
        ),
        child: ElevatedButton.icon(
          onPressed: isReady ? _goToDashboard : null,
          icon: _isLoading
              ? const SizedBox(
                  width: 18,
                  height: 18,
                  child: CircularProgressIndicator(
                    color: Colors.white,
                    strokeWidth: 2,
                  ),
                )
              : const Icon(Icons.home_rounded, color: Colors.white, size: 20),
          label: Text(
            _isLoading ? 'Chargement…' : 'Voir mon Tableau de Bord',
            style: GoogleFonts.plusJakartaSans(
              fontSize: 14.sp > 17 ? 17 : 14.sp,
              fontWeight: FontWeight.w700,
              color: Colors.white,
              letterSpacing: 0.3,
            ),
          ),
          style: ElevatedButton.styleFrom(
            backgroundColor: Colors.transparent,
            shadowColor: Colors.transparent,
            disabledBackgroundColor: Colors.transparent,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(16.0),
            ),
          ),
        ),
      ),
    );
  }
}
