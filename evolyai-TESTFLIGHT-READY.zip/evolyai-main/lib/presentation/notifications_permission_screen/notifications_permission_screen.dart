import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:sizer/sizer.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:flutter/foundation.dart';

import '../../models/onboarding_data.dart';
import '../goal_selection_screen/widgets/onboarding_progress_widget.dart';
import '../../routes/app_routes.dart';

class NotificationsPermissionScreen extends StatefulWidget {
  final OnboardingData? onboardingData;

  const NotificationsPermissionScreen({super.key, this.onboardingData});

  @override
  State<NotificationsPermissionScreen> createState() =>
      _NotificationsPermissionScreenState();
}

class _NotificationsPermissionScreenState
    extends State<NotificationsPermissionScreen>
    with SingleTickerProviderStateMixin {
  late AnimationController _entryController;
  late Animation<double> _fadeAnimation;
  late Animation<Offset> _slideAnimation;
  bool _isRequesting = false;

  final List<Map<String, dynamic>> _benefits = [
    {
      'icon': Icons.monitor_weight_rounded,
      'text': 'Weekly body composition updates',
      'color': const Color(0xFF6C5CE7),
    },
    {
      'icon': Icons.trending_up_rounded,
      'text': 'Progress milestone celebrations',
      'color': const Color(0xFF00B894),
    },
    {
      'icon': Icons.tips_and_updates_rounded,
      'text': 'Personalized health tips & reminders',
      'color': const Color(0xFF0984E3),
    },
  ];

  @override
  void initState() {
    super.initState();
    _entryController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 600),
    )..forward();
    _fadeAnimation = CurvedAnimation(
      parent: _entryController,
      curve: Curves.easeOut,
    );
    _slideAnimation =
        Tween<Offset>(begin: const Offset(0.05, 0), end: Offset.zero).animate(
          CurvedAnimation(parent: _entryController, curve: Curves.easeOutCubic),
        );
  }

  @override
  void dispose() {
    _entryController.dispose();
    super.dispose();
  }

  Future<void> _onAllowNotifications() async {
    HapticFeedback.mediumImpact();
    setState(() => _isRequesting = true);

    try {
      if (!kIsWeb) {
        // Request real OS notification permission
        final status = await Permission.notification.request();
        debugPrint('[Notifications] Permission status: $status');
      }
      // On web, browser handles permissions — just proceed
    } catch (e) {
      debugPrint('[Notifications] Permission request error: $e');
    }

    if (mounted) {
      setState(() => _isRequesting = false);
      _navigateNext();
    }
  }

  void _onSkip() {
    HapticFeedback.lightImpact();
    _navigateNext();
  }

  void _navigateNext() {
    Navigator.of(
      context,
    ).pushNamed(AppRoutes.cameraInstructions, arguments: widget.onboardingData);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: SafeArea(
        child: FadeTransition(
          opacity: _fadeAnimation,
          child: SlideTransition(
            position: _slideAnimation,
            child: Padding(
              padding: EdgeInsets.symmetric(horizontal: 4.w, vertical: 2.h),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  _buildHeader(),
                  SizedBox(height: 3.h),
                  _buildIllustration(),
                  SizedBox(height: 3.h),
                  _buildTitleSection(),
                  SizedBox(height: 2.5.h),
                  _buildBenefitsList(),
                  const Spacer(),
                  _buildAllowButton(),
                  SizedBox(height: 1.5.h),
                  _buildSkipButton(),
                  SizedBox(height: 1.h),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildHeader() {
    return Row(
      children: [
        GestureDetector(
          onTap: () {
            HapticFeedback.lightImpact();
            Navigator.of(context).pop();
          },
          child: Container(
            width: 10.w,
            height: 10.w,
            decoration: BoxDecoration(
              color: const Color(0xFFF8F9FA),
              borderRadius: BorderRadius.circular(12.0),
              border: Border.all(color: const Color(0xFFE2E8F0)),
            ),
            child: const Icon(
              Icons.arrow_back_ios_new_rounded,
              color: Color(0xFF1B365D),
              size: 18,
            ),
          ),
        ),
        SizedBox(width: 3.w),
        Expanded(
          child: OnboardingProgressWidget(currentStep: 13, totalSteps: 16),
        ),
      ],
    );
  }

  Widget _buildIllustration() {
    return Center(
      child: Container(
        width: 28.w,
        height: 28.w,
        decoration: BoxDecoration(
          gradient: const LinearGradient(
            colors: [Color(0xFFF0EEFF), Color(0xFFE8F4FF)],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
          shape: BoxShape.circle,
          boxShadow: [
            BoxShadow(
              color: const Color(0xFF6C5CE7).withValues(alpha: 0.15),
              blurRadius: 24,
              offset: const Offset(0, 8),
            ),
          ],
        ),
        child: Stack(
          alignment: Alignment.center,
          children: [
            Positioned(
              top: 6.w * 0.3,
              right: 6.w * 0.3,
              child: Container(
                width: 5.w,
                height: 5.w,
                decoration: const BoxDecoration(
                  color: Color(0xFF6C5CE7),
                  shape: BoxShape.circle,
                ),
                child: const Icon(
                  Icons.notifications_rounded,
                  color: Colors.white,
                  size: 12,
                ),
              ),
            ),
            const Icon(
              Icons.notifications_active_rounded,
              color: Color(0xFF6C5CE7),
              size: 48,
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildTitleSection() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        ShaderMask(
          shaderCallback: (bounds) => const LinearGradient(
            colors: [Color(0xFF1B365D), Color(0xFF6C5CE7)],
            begin: Alignment.centerLeft,
            end: Alignment.centerRight,
          ).createShader(bounds),
          child: Text(
            'Stay updated with\nyour body progress',
            style: GoogleFonts.plusJakartaSans(
              fontSize: 20.sp > 28 ? 28 : 20.sp,
              fontWeight: FontWeight.w800,
              color: Colors.white,
              height: 1.2,
            ),
          ),
        ),
        SizedBox(height: 1.h),
        Text(
          'Enable notifications to stay on track and never miss a milestone on your fitness journey.',
          style: GoogleFonts.plusJakartaSans(
            fontSize: 12.sp > 15 ? 15 : 12.sp,
            fontWeight: FontWeight.w400,
            color: const Color(0xFF636E72),
            height: 1.5,
          ),
        ),
      ],
    );
  }

  Widget _buildBenefitsList() {
    return Container(
      padding: EdgeInsets.all(4.w),
      decoration: BoxDecoration(
        color: const Color(0xFFFAFAFF),
        borderRadius: BorderRadius.circular(16.0),
        border: Border.all(color: const Color(0xFFE2E8F0)),
      ),
      child: Column(
        children: _benefits.map((benefit) {
          return Padding(
            padding: EdgeInsets.symmetric(vertical: 0.8.h),
            child: Row(
              children: [
                Container(
                  width: 9.w,
                  height: 9.w,
                  decoration: BoxDecoration(
                    color: (benefit['color'] as Color).withValues(alpha: 0.1),
                    borderRadius: BorderRadius.circular(10.0),
                  ),
                  child: Icon(
                    benefit['icon'] as IconData,
                    color: benefit['color'] as Color,
                    size: 18,
                  ),
                ),
                SizedBox(width: 3.w),
                Expanded(
                  child: Text(
                    benefit['text'] as String,
                    style: GoogleFonts.plusJakartaSans(
                      fontSize: 11.sp > 14 ? 14 : 11.sp,
                      color: const Color(0xFF2D3436),
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                ),
              ],
            ),
          );
        }).toList(),
      ),
    );
  }

  Widget _buildAllowButton() {
    return SizedBox(
      width: double.infinity,
      height: 6.5.h,
      child: DecoratedBox(
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(16.0),
          gradient: const LinearGradient(
            colors: [Color(0xFF6C5CE7), Color(0xFF8B5CF6)],
            begin: Alignment.centerLeft,
            end: Alignment.centerRight,
          ),
          boxShadow: [
            BoxShadow(
              color: const Color(0xFF6C5CE7).withValues(alpha: 0.4),
              blurRadius: 16,
              offset: const Offset(0, 6),
            ),
          ],
        ),
        child: ElevatedButton(
          onPressed: _isRequesting ? null : _onAllowNotifications,
          style: ElevatedButton.styleFrom(
            backgroundColor: Colors.transparent,
            shadowColor: Colors.transparent,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(16.0),
            ),
          ),
          child: _isRequesting
              ? const SizedBox(
                  width: 22,
                  height: 22,
                  child: CircularProgressIndicator(
                    color: Colors.white,
                    strokeWidth: 2.5,
                  ),
                )
              : Text(
                  'Allow Notifications',
                  style: GoogleFonts.plusJakartaSans(
                    fontSize: 14.sp > 17 ? 17 : 14.sp,
                    fontWeight: FontWeight.w700,
                    color: Colors.white,
                  ),
                ),
        ),
      ),
    );
  }

  Widget _buildSkipButton() {
    return Center(
      child: GestureDetector(
        onTap: _onSkip,
        child: Text(
          'Skip for now',
          style: GoogleFonts.plusJakartaSans(
            fontSize: 12.sp > 15 ? 15 : 12.sp,
            color: const Color(0xFF636E72),
            fontWeight: FontWeight.w500,
          ),
        ),
      ),
    );
  }
}
