import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:sizer/sizer.dart';
import 'package:url_launcher/url_launcher.dart';

class ScienceScreen extends StatefulWidget {
  const ScienceScreen({super.key});
  @override
  State<ScienceScreen> createState() => _ScienceScreenState();
}

class _ScienceScreenState extends State<ScienceScreen>
    with SingleTickerProviderStateMixin {
  late AnimationController _ctrl;
  late Animation<double> _fade;

  @override
  void initState() {
    super.initState();
    _ctrl = AnimationController(vsync: this, duration: const Duration(milliseconds: 500))..forward();
    _fade = CurvedAnimation(parent: _ctrl, curve: Curves.easeOut);
  }

  @override
  void dispose() { _ctrl.dispose(); super.dispose(); }

  Future<void> _open(String url) async {
    HapticFeedback.lightImpact();
    final uri = Uri.parse(url);
    if (await canLaunchUrl(uri)) await launchUrl(uri, mode: LaunchMode.externalApplication);
  }

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final bg = isDark ? const Color(0xFF0A0A14) : const Color(0xFFF8F9FC);
    final surface = isDark ? Colors.white.withValues(alpha: 0.05) : Colors.white;
    final border = isDark ? Colors.white.withValues(alpha: 0.08) : const Color(0xFFE2E8F0);
    final textPrimary = isDark ? Colors.white : const Color(0xFF1B365D);
    final textSub = isDark ? Colors.white.withValues(alpha: 0.6) : const Color(0xFF636E72);

    return Scaffold(
      backgroundColor: bg,
      body: FadeTransition(
        opacity: _fade,
        child: CustomScrollView(
          slivers: [
            SliverAppBar(
              expandedHeight: 17.h,
              pinned: true,
              backgroundColor: const Color(0xFF1B365D),
              leading: IconButton(
                icon: const Icon(Icons.arrow_back_ios_rounded, color: Colors.white),
                onPressed: () => Navigator.of(context).pop(),
              ),
              flexibleSpace: FlexibleSpaceBar(
                background: Container(
                  decoration: const BoxDecoration(
                    gradient: LinearGradient(
                      colors: [Color(0xFF1B365D), Color(0xFF6C5CE7)],
                      begin: Alignment.topLeft,
                      end: Alignment.bottomRight,
                    ),
                  ),
                  child: SafeArea(
                    child: Padding(
                      padding: EdgeInsets.fromLTRB(5.w, 5.h, 5.w, 2.h),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        mainAxisAlignment: MainAxisAlignment.end,
                        children: [
                          Row(children: [
                            Container(
                              padding: const EdgeInsets.all(8),
                              decoration: BoxDecoration(color: Colors.white.withValues(alpha: 0.15), borderRadius: BorderRadius.circular(10)),
                              child: const Icon(Icons.science_rounded, color: Colors.white, size: 20),
                            ),
                            SizedBox(width: 3.w),
                            Text('Base Scientifique', style: GoogleFonts.manrope(fontSize: 16.sp > 22 ? 22 : 16.sp, fontWeight: FontWeight.w800, color: Colors.white)),
                          ]),
                          SizedBox(height: 0.6.h),
                          Text('Méthodologie & références publiées', style: GoogleFonts.dmSans(fontSize: 11.sp > 13 ? 13 : 11.sp, color: Colors.white.withValues(alpha: 0.75))),
                        ],
                      ),
                    ),
                  ),
                ),
              ),
            ),
            SliverToBoxAdapter(
              child: Padding(
                padding: EdgeInsets.symmetric(horizontal: 4.w, vertical: 2.h),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    // Hero card
                    Container(
                      width: double.infinity,
                      padding: EdgeInsets.all(4.w),
                      decoration: BoxDecoration(
                        gradient: const LinearGradient(colors: [Color(0xFF1B365D), Color(0xFF6C5CE7)], begin: Alignment.topLeft, end: Alignment.bottomRight),
                        borderRadius: BorderRadius.circular(18),
                        boxShadow: [BoxShadow(color: const Color(0xFF6C5CE7).withValues(alpha: 0.3), blurRadius: 20, offset: const Offset(0, 6))],
                      ),
                      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                        const Text('🔬', style: TextStyle(fontSize: 26)),
                        SizedBox(height: 1.h),
                        Text('Evoly AI utilise des modèles entraînés sur des études cliniques DXA (gold standard). Précision : ±3–5% pour la masse grasse. Idéal pour suivre les tendances de recomposition corporelle.', 
                          style: GoogleFonts.dmSans(fontSize: 11.sp > 13 ? 13 : 11.sp, color: Colors.white.withValues(alpha: 0.9), height: 1.6)),
                      ]),
                    ),
                    SizedBox(height: 3.h),

                    // How it works
                    _SectionLabel(icon: Icons.biotech_rounded, title: 'Fonctionnement', color: const Color(0xFF6C5CE7), textPrimary: textPrimary),
                    SizedBox(height: 1.5.h),
                    Container(
                      padding: EdgeInsets.all(4.w),
                      decoration: BoxDecoration(color: surface, borderRadius: BorderRadius.circular(16), border: Border.all(color: border)),
                      child: Column(children: [
                        _Step(n: '01', title: 'Analyse morphologique IA', body: 'L\'IA analyse les contours corporels, la distribution du tissu adipeux et la silhouette musculaire à partir de 1–2 photos.', textPrimary: textPrimary, textSub: textSub, last: false),
                        _Step(n: '02', title: 'Corrélation biométrique', body: 'Les mesures sont croisées avec vos données (poids, taille, âge, sexe, activité) via des modèles entraînés sur des études DXA validées.', textPrimary: textPrimary, textSub: textSub, last: false),
                        _Step(n: '03', title: 'Estimation de composition', body: 'L\'algorithme produit une estimation de masse grasse (±3–5% vs DXA), masse maigre et répartition par segment corporel.', textPrimary: textPrimary, textSub: textSub, last: true),
                      ]),
                    ),
                    SizedBox(height: 3.h),

                    // Accuracy
                    _SectionLabel(icon: Icons.track_changes_rounded, title: 'Précision & limites', color: const Color(0xFF00B894), textPrimary: textPrimary),
                    SizedBox(height: 1.5.h),
                    Container(
                      padding: EdgeInsets.all(4.w),
                      decoration: BoxDecoration(color: surface, borderRadius: BorderRadius.circular(16), border: Border.all(color: border)),
                      child: Column(children: [
                        _MetricRow(label: 'Précision masse grasse', value: '±3–5%', sub: 'vs DXA gold standard', color: const Color(0xFF00B894), textPrimary: textPrimary, textSub: textSub),
                        Divider(height: 2.h, color: border),
                        _MetricRow(label: 'Fiabilité suivi tendances', value: 'Élevée', sub: 'Pour tracker l\'évolution dans le temps', color: const Color(0xFF6C5CE7), textPrimary: textPrimary, textSub: textSub),
                        Divider(height: 2.h, color: border),
                        _MetricRow(label: 'Fréquence recommandée', value: '2–4 semaines', sub: 'Pour un suivi de recomposition optimal', color: const Color(0xFFFFB347), textPrimary: textPrimary, textSub: textSub),
                      ]),
                    ),
                    SizedBox(height: 3.h),

                    // French institutions
                    _SectionLabel(icon: Icons.flag_rounded, title: 'Institutions françaises', color: const Color(0xFF0052CC), textPrimary: textPrimary),
                    SizedBox(height: 1.5.h),
                    _RefCard(isDark: isDark, surface: surface, flag: '🇫🇷', title: 'INSERM', sub: 'Institut National de la Santé et de la Recherche Médicale', body: 'Études sur l\'obésité, la composition corporelle et le métabolisme lipidique en population française.', url: 'https://www.inserm.fr/dossier/obesite/', color: const Color(0xFF0052CC), onTap: _open),
                    SizedBox(height: 1.5.h),
                    _RefCard(isDark: isDark, surface: surface, flag: '🇫🇷', title: 'ANSES', sub: 'Agence Nationale de Sécurité Sanitaire Alimentaire', body: 'Références nutritionnelles officielles pour la population française — protéines, lipides et composition corporelle.', url: 'https://www.anses.fr/fr/content/les-references-nutritionnelles-en-vitamines-et-mineraux', color: const Color(0xFF0052CC), onTap: _open),
                    SizedBox(height: 1.5.h),
                    _RefCard(isDark: isDark, surface: surface, flag: '🇫🇷', title: 'Haute Autorité de Santé', sub: 'HAS — Recommandations cliniques', body: 'Guide de bonnes pratiques sur la prise en charge du surpoids et l\'évaluation de la composition corporelle.', url: 'https://www.has-sante.fr/jcms/c_931261/fr/surpoids-et-obesite-de-l-adulte', color: const Color(0xFF0052CC), onTap: _open),
                    SizedBox(height: 3.h),

                    // American institutions
                    _SectionLabel(icon: Icons.public_rounded, title: 'Institutions américaines', color: const Color(0xFFE53E3E), textPrimary: textPrimary),
                    SizedBox(height: 1.5.h),
                    _RefCard(isDark: isDark, surface: surface, flag: '🇺🇸', title: 'NIH — NIDDK', sub: 'National Institute of Diabetes, Digestive and Kidney Diseases', body: 'Recherches publiées sur la mesure du tissu adipeux, l\'IMC et les méthodes d\'estimation de composition corporelle.', url: 'https://www.niddk.nih.gov/health-information/weight-management/adult-overweight-obesity', color: const Color(0xFFE53E3E), onTap: _open),
                    SizedBox(height: 1.5.h),
                    _RefCard(isDark: isDark, surface: surface, flag: '🇺🇸', title: 'CDC', sub: 'Centers for Disease Control and Prevention', body: 'Standards de mesure corporelle et données épidémiologiques sur la composition corporelle aux États-Unis.', url: 'https://www.cdc.gov/healthyweight/assessing/bmi/index.html', color: const Color(0xFFE53E3E), onTap: _open),
                    SizedBox(height: 1.5.h),
                    _RefCard(isDark: isDark, surface: surface, flag: '🇺🇸', title: 'ACSM', sub: 'American College of Sports Medicine', body: 'Guidelines sur les normes de masse grasse par âge et sexe, et recommandations pour la recomposition corporelle.', url: 'https://www.acsm.org/education-resources/trending-topics-resources/physical-activity-guidelines', color: const Color(0xFFE53E3E), onTap: _open),
                    SizedBox(height: 3.h),

                    // Norms table
                    _SectionLabel(icon: Icons.bar_chart_rounded, title: 'Normes de référence ACSM', color: const Color(0xFF6C5CE7), textPrimary: textPrimary),
                    SizedBox(height: 1.5.h),
                    Container(
                      padding: EdgeInsets.all(4.w),
                      decoration: BoxDecoration(color: surface, borderRadius: BorderRadius.circular(16), border: Border.all(color: border)),
                      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                        _NormsGroup(title: '👩 Femmes', rows: const [
                          ('Essentielle', '10–13%', Color(0xFF6C5CE7)),
                          ('Athlétique', '14–20%', Color(0xFF00B894)),
                          ('Fit', '21–24%', Color(0xFF74B9FF)),
                          ('Moyenne', '25–31%', Color(0xFFFFB347)),
                          ('Obésité', '> 32%', Color(0xFFE53E3E)),
                        ], textPrimary: textPrimary, textSub: textSub),
                        SizedBox(height: 2.h),
                        _NormsGroup(title: '👨 Hommes', rows: const [
                          ('Essentielle', '2–5%', Color(0xFF6C5CE7)),
                          ('Athlétique', '6–13%', Color(0xFF00B894)),
                          ('Fit', '14–17%', Color(0xFF74B9FF)),
                          ('Moyenne', '18–24%', Color(0xFFFFB347)),
                          ('Obésité', '> 25%', Color(0xFFE53E3E)),
                        ], textPrimary: textPrimary, textSub: textSub),
                        SizedBox(height: 1.h),
                        Text('Source : ACSM Guidelines for Exercise Testing and Prescription', style: GoogleFonts.dmSans(fontSize: 9.sp > 10 ? 10 : 9.sp, color: textSub, fontStyle: FontStyle.italic)),
                      ]),
                    ),
                    SizedBox(height: 3.h),

                    // Disclaimer
                    Container(
                      padding: EdgeInsets.all(4.w),
                      decoration: BoxDecoration(
                        color: isDark ? Colors.white.withValues(alpha: 0.04) : const Color(0xFFF0F4FF),
                        borderRadius: BorderRadius.circular(14),
                        border: Border.all(color: const Color(0xFF6C5CE7).withValues(alpha: 0.2)),
                      ),
                      child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
                        const Icon(Icons.info_outline_rounded, color: Color(0xFF6C5CE7), size: 18),
                        SizedBox(width: 3.w),
                        Expanded(
                          child: Text(
                            'Evoly AI est un outil de suivi de forme physique. Les résultats sont des estimations et ne constituent pas un avis médical. Consultez un professionnel de santé pour toute décision médicale.',
                            style: GoogleFonts.dmSans(fontSize: 10.sp > 12 ? 12 : 10.sp, color: textSub, height: 1.5),
                          ),
                        ),
                      ]),
                    ),
                    SizedBox(height: 4.h),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _SectionLabel extends StatelessWidget {
  final IconData icon; final String title; final Color color; final Color textPrimary;
  const _SectionLabel({required this.icon, required this.title, required this.color, required this.textPrimary});
  @override
  Widget build(BuildContext context) => Row(children: [
    Container(padding: const EdgeInsets.all(7), decoration: BoxDecoration(color: color.withValues(alpha: 0.12), borderRadius: BorderRadius.circular(10)), child: Icon(icon, color: color, size: 16)),
    SizedBox(width: 3.w),
    Text(title, style: GoogleFonts.manrope(fontSize: 13.sp > 17 ? 17 : 13.sp, fontWeight: FontWeight.w700, color: textPrimary)),
  ]);
}

class _Step extends StatelessWidget {
  final String n, title, body; final Color textPrimary, textSub; final bool last;
  const _Step({required this.n, required this.title, required this.body, required this.textPrimary, required this.textSub, required this.last});
  @override
  Widget build(BuildContext context) => Column(children: [
    Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Container(width: 8.w, height: 8.w, decoration: const BoxDecoration(gradient: LinearGradient(colors: [Color(0xFF6C5CE7), Color(0xFF74B9FF)]), shape: BoxShape.circle), child: Center(child: Text(n, style: GoogleFonts.manrope(fontSize: 8.sp > 10 ? 10 : 8.sp, fontWeight: FontWeight.w800, color: Colors.white)))),
      SizedBox(width: 3.w),
      Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text(title, style: GoogleFonts.manrope(fontSize: 11.sp > 14 ? 14 : 11.sp, fontWeight: FontWeight.w700, color: textPrimary)),
        SizedBox(height: 0.3.h),
        Text(body, style: GoogleFonts.dmSans(fontSize: 10.sp > 12 ? 12 : 10.sp, color: textSub, height: 1.5)),
      ])),
    ]),
    if (!last) Padding(padding: EdgeInsets.only(left: 4.w, top: 4, bottom: 4), child: Container(height: 16, width: 2, color: const Color(0xFF6C5CE7).withValues(alpha: 0.2))),
  ]);
}

class _MetricRow extends StatelessWidget {
  final String label, value, sub; final Color color, textPrimary, textSub;
  const _MetricRow({required this.label, required this.value, required this.sub, required this.color, required this.textPrimary, required this.textSub});
  @override
  Widget build(BuildContext context) => Row(children: [
    Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Text(label, style: GoogleFonts.dmSans(fontSize: 11.sp > 13 ? 13 : 11.sp, fontWeight: FontWeight.w600, color: textPrimary)),
      Text(sub, style: GoogleFonts.dmSans(fontSize: 9.sp > 11 ? 11 : 9.sp, color: textSub)),
    ])),
    Container(padding: EdgeInsets.symmetric(horizontal: 3.w, vertical: 0.5.h), decoration: BoxDecoration(color: color.withValues(alpha: 0.12), borderRadius: BorderRadius.circular(8), border: Border.all(color: color.withValues(alpha: 0.25))), child: Text(value, style: GoogleFonts.manrope(fontSize: 10.sp > 12 ? 12 : 10.sp, fontWeight: FontWeight.w700, color: color))),
  ]);
}

class _RefCard extends StatelessWidget {
  final bool isDark; final Color surface, color; final String flag, title, sub, body, url; final Future<void> Function(String) onTap;
  const _RefCard({required this.isDark, required this.surface, required this.flag, required this.title, required this.sub, required this.body, required this.url, required this.color, required this.onTap});
  @override
  Widget build(BuildContext context) => GestureDetector(
    onTap: () => onTap(url),
    child: Container(
      padding: EdgeInsets.all(4.w),
      decoration: BoxDecoration(color: surface, borderRadius: BorderRadius.circular(16), border: Border.all(color: color.withValues(alpha: 0.2)), boxShadow: isDark ? [] : [BoxShadow(color: Colors.black.withValues(alpha: 0.04), blurRadius: 8, offset: const Offset(0, 3))]),
      child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Column(children: [
          Text(flag, style: const TextStyle(fontSize: 22)),
          SizedBox(height: 0.8.h),
          Container(width: 3, height: 5.h, decoration: BoxDecoration(color: color.withValues(alpha: 0.4), borderRadius: BorderRadius.circular(2))),
        ]),
        SizedBox(width: 3.w),
        Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Row(children: [
            Expanded(child: Text(title, style: GoogleFonts.manrope(fontSize: 12.sp > 15 ? 15 : 12.sp, fontWeight: FontWeight.w700, color: isDark ? Colors.white : const Color(0xFF1B365D)))),
            Icon(Icons.open_in_new_rounded, size: 14, color: color.withValues(alpha: 0.7)),
          ]),
          SizedBox(height: 0.2.h),
          Text(sub, style: GoogleFonts.dmSans(fontSize: 9.sp > 11 ? 11 : 9.sp, color: color, fontWeight: FontWeight.w600)),
          SizedBox(height: 0.6.h),
          Text(body, style: GoogleFonts.dmSans(fontSize: 10.sp > 12 ? 12 : 10.sp, color: isDark ? Colors.white.withValues(alpha: 0.6) : const Color(0xFF636E72), height: 1.5)),
        ])),
      ]),
    ),
  );
}

class _NormsGroup extends StatelessWidget {
  final String title; final List<(String, String, Color)> rows; final Color textPrimary, textSub;
  const _NormsGroup({required this.title, required this.rows, required this.textPrimary, required this.textSub});
  @override
  Widget build(BuildContext context) => Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
    Text(title, style: GoogleFonts.manrope(fontSize: 11.sp > 13 ? 13 : 11.sp, fontWeight: FontWeight.w600, color: textPrimary)),
    SizedBox(height: 0.8.h),
    ...rows.map((r) => Padding(padding: EdgeInsets.only(bottom: 0.5.h), child: Row(children: [
      Container(width: 8, height: 8, decoration: BoxDecoration(color: r.$3, shape: BoxShape.circle)),
      SizedBox(width: 2.w),
      Expanded(child: Text(r.$1, style: GoogleFonts.dmSans(fontSize: 10.sp > 12 ? 12 : 10.sp, color: textSub))),
      Container(padding: EdgeInsets.symmetric(horizontal: 2.w, vertical: 0.2.h), decoration: BoxDecoration(color: r.$3.withValues(alpha: 0.1), borderRadius: BorderRadius.circular(6)), child: Text(r.$2, style: GoogleFonts.manrope(fontSize: 10.sp > 12 ? 12 : 10.sp, fontWeight: FontWeight.w600, color: r.$3))),
    ]))),
  ]);
}
