import 'dart:async';
import 'dart:convert';
import 'package:camera/camera.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:image_picker/image_picker.dart';
import 'package:sizer/sizer.dart';

import '../../core/services/aiIntegrations/chat_completion_service.dart';
import '../../models/onboarding_data.dart';
import '../../routes/app_routes.dart';

class CameraCaptureScreen extends StatefulWidget {
  final OnboardingData? onboardingData;

  /// When true, this is a standalone rescan from the dashboard (no onboarding flow).
  final bool standaloneMode;

  const CameraCaptureScreen({
    super.key,
    this.onboardingData,
    this.standaloneMode = false,
  });

  @override
  State<CameraCaptureScreen> createState() => _CameraCaptureScreenState();
}

enum PhotoMode { front, side }

enum CaptureState { idle, countdown, validating, captured, error }

enum PhotoValidation { pending, ok, retakeRecommended, invalidBody }

class _CameraCaptureScreenState extends State<CameraCaptureScreen>
    with TickerProviderStateMixin {
  PhotoMode _currentMode = PhotoMode.front;
  CaptureState _frontState = CaptureState.idle;
  CaptureState _sideState = CaptureState.idle;

  String? _frontPhotoBase64;
  String? _sidePhotoBase64;

  Uint8List? _frontPhotoBytes;
  Uint8List? _sidePhotoBytes;

  PhotoValidation _frontValidation = PhotoValidation.pending;
  PhotoValidation _sideValidation = PhotoValidation.pending;

  // Validation messages
  String? _frontValidationMessage;
  String? _sideValidationMessage;

  int _countdownValue = 0;
  Timer? _countdownTimer;

  CameraController? _cameraController;
  List<CameraDescription> _cameras = [];
  bool _cameraInitialized = false;
  bool _cameraError = false;
  bool _isUsingFrontCamera = false;

  final ImagePicker _imagePicker = ImagePicker();

  late AnimationController _pulseController;
  late AnimationController _entryController;
  late AnimationController _checkController;
  late Animation<double> _pulseAnimation;
  late Animation<double> _fadeAnimation;
  late Animation<Offset> _slideAnimation;
  late Animation<double> _checkAnimation;

  bool get _frontCaptured => _frontState == CaptureState.captured;
  bool get _sideCaptured => _sideState == CaptureState.captured;
  bool get _bothCaptured => _frontCaptured && _sideCaptured;

  CaptureState get _currentState =>
      _currentMode == PhotoMode.front ? _frontState : _sideState;

  Uint8List? get _currentPhotoBytes =>
      _currentMode == PhotoMode.front ? _frontPhotoBytes : _sidePhotoBytes;

  PhotoValidation get _currentValidation =>
      _currentMode == PhotoMode.front ? _frontValidation : _sideValidation;

  String? get _currentValidationMessage => _currentMode == PhotoMode.front
      ? _frontValidationMessage
      : _sideValidationMessage;

  @override
  void initState() {
    super.initState();
    _initAnimations();
    _initCamera();
  }

  void _initAnimations() {
    _entryController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 500),
    )..forward();
    _fadeAnimation = CurvedAnimation(
      parent: _entryController,
      curve: Curves.easeOut,
    );
    _slideAnimation =
        Tween<Offset>(begin: const Offset(0, 0.04), end: Offset.zero).animate(
          CurvedAnimation(parent: _entryController, curve: Curves.easeOutCubic),
        );

    _pulseController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1500),
    )..repeat(reverse: true);
    _pulseAnimation = Tween<double>(begin: 0.95, end: 1.05).animate(
      CurvedAnimation(parent: _pulseController, curve: Curves.easeInOut),
    );

    _checkController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 400),
    );
    _checkAnimation = CurvedAnimation(
      parent: _checkController,
      curve: Curves.elasticOut,
    );
  }

  Future<void> _initCamera() async {
    try {
      _cameras = await availableCameras();
      if (_cameras.isEmpty) {
        debugPrint('[CameraCapture] No cameras available');
        if (mounted) setState(() => _cameraError = true);
        return;
      }

      CameraDescription selectedCamera;
      if (kIsWeb) {
        selectedCamera = _cameras.firstWhere(
          (c) => c.lensDirection == CameraLensDirection.front,
          orElse: () => _cameras.first,
        );
        _isUsingFrontCamera = true;
      } else {
        selectedCamera = _isUsingFrontCamera
            ? _cameras.firstWhere(
                (c) => c.lensDirection == CameraLensDirection.front,
                orElse: () => _cameras.first,
              )
            : _cameras.firstWhere(
                (c) => c.lensDirection == CameraLensDirection.back,
                orElse: () => _cameras.first,
              );
      }

      _cameraController = CameraController(
        selectedCamera,
        kIsWeb ? ResolutionPreset.medium : ResolutionPreset.high,
        enableAudio: false,
        imageFormatGroup: ImageFormatGroup.jpeg,
      );

      await _cameraController!.initialize();

      try {
        await _cameraController!.setFocusMode(FocusMode.auto);
      } catch (_) {}
      if (!kIsWeb) {
        try {
          await _cameraController!.setFlashMode(FlashMode.off);
        } catch (_) {}
      }

      if (mounted) {
        setState(() => _cameraInitialized = true);
        debugPrint('[CameraCapture] Camera initialized successfully');
      }
    } catch (e) {
      debugPrint('[CameraCapture] Camera init error: $e');
      if (mounted) setState(() => _cameraError = true);
    }
  }

  /// Toggle between front and back camera
  Future<void> _toggleCamera() async {
    if (kIsWeb || _cameras.length < 2) return;
    HapticFeedback.selectionClick();
    await _cameraController?.dispose();
    _cameraController = null;
    setState(() {
      _isUsingFrontCamera = !_isUsingFrontCamera;
      _cameraInitialized = false;
    });
    await _initCamera();
  }

  @override
  void dispose() {
    _countdownTimer?.cancel();
    _pulseController.dispose();
    _entryController.dispose();
    _checkController.dispose();
    _cameraController?.dispose();
    super.dispose();
  }

  Future<void> _onCapture() async {
    if (_currentState == CaptureState.countdown ||
        _currentState == CaptureState.validating) {
      return;
    }
    HapticFeedback.mediumImpact();

    setState(() {
      _countdownValue = 10;
      if (_currentMode == PhotoMode.front) {
        _frontState = CaptureState.countdown;
      } else {
        _sideState = CaptureState.countdown;
      }
    });

    _countdownTimer?.cancel();
    _countdownTimer = Timer.periodic(const Duration(seconds: 1), (timer) async {
      if (!mounted) {
        timer.cancel();
        return;
      }
      setState(() => _countdownValue--);
      HapticFeedback.lightImpact();

      if (_countdownValue <= 0) {
        timer.cancel();
        await _capturePhoto();
      }
    });
  }

  /// Pick a photo from the device gallery and run the same AI validation.
  Future<void> _onChooseFromGallery() async {
    HapticFeedback.lightImpact();
    try {
      final XFile? picked = await _imagePicker.pickImage(
        source: ImageSource.gallery,
        imageQuality: 85,
      );
      if (picked == null) return;

      final Uint8List bytes = await picked.readAsBytes();
      final String base64Image = base64Encode(bytes);

      if (!mounted) return;

      // Show validating state
      setState(() {
        if (_currentMode == PhotoMode.front) {
          _frontState = CaptureState.validating;
          _frontPhotoBytes = bytes;
        } else {
          _sideState = CaptureState.validating;
          _sidePhotoBytes = bytes;
        }
      });

      // Run AI validation on gallery photo
      final (validation, message) = await _validatePhotoWithAI(bytes);

      if (!mounted) return;

      _checkController.forward(from: 0);

      setState(() {
        if (_currentMode == PhotoMode.front) {
          _frontPhotoBase64 = base64Image;
          _frontValidation = validation;
          _frontValidationMessage = message.isNotEmpty ? message : null;
          if (validation == PhotoValidation.invalidBody) {
            _frontState = CaptureState.idle;
            _frontPhotoBytes = null;
            _frontPhotoBase64 = null;
          } else {
            _frontState = CaptureState.captured;
          }
        } else {
          _sidePhotoBase64 = base64Image;
          _sideValidation = validation;
          _sideValidationMessage = message.isNotEmpty ? message : null;
          if (validation == PhotoValidation.invalidBody) {
            _sideState = CaptureState.idle;
            _sidePhotoBytes = null;
            _sidePhotoBase64 = null;
          } else {
            _sideState = CaptureState.captured;
          }
        }
      });

      if (validation == PhotoValidation.invalidBody && mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(message),
            backgroundColor: const Color(0xFFE17055),
            behavior: SnackBarBehavior.floating,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(12),
            ),
            duration: const Duration(seconds: 4),
          ),
        );
        return;
      }

      // Auto-switch to side mode after front capture
      if (_currentMode == PhotoMode.front &&
          _frontState == CaptureState.captured &&
          !_sideCaptured) {
        await Future.delayed(const Duration(milliseconds: 1800));
        if (!mounted) return;
        HapticFeedback.lightImpact();
        setState(() => _currentMode = PhotoMode.side);
      }

      // Auto-advance when both captured
      if (_bothCaptured) {
        await Future.delayed(const Duration(milliseconds: 1200));
        if (!mounted) return;
        _navigateNext();
      }
    } catch (e) {
      debugPrint('[CameraCapture] Gallery pick error: $e');
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('Could not open gallery. Please try again.'),
            backgroundColor: Colors.red,
            duration: Duration(seconds: 2),
          ),
        );
      }
    }
  }

  /// Multi-factor photo validation using Gemini vision.
  /// Checks: human presence, full body framing, pose, lighting.
  /// Returns (validation, message).
  Future<(PhotoValidation, String)> _validatePhotoWithAI(
    Uint8List bytes,
  ) async {
    // First: basic byte size check — very small = dark/blurry/empty
    if (bytes.isEmpty || bytes.length < 5000) {
      debugPrint(
        '[CameraCapture] Validation: image too small (${bytes.length} bytes)',
      );
      return (
        PhotoValidation.retakeRecommended,
        'Photo appears dark or blurry. Please retake.',
      );
    }

    try {
      final base64Image = base64Encode(bytes);
      final messages = [
        {
          'role': 'user',
          'content': [
            {
              'type': 'text',
              'text': '''Analyze this image for body scan validation. 
Return ONLY a JSON object with these fields:
{
  "human_detected": true/false,
  "full_body_visible": true/false,
  "body_centered": true/false,
  "upright_pose": true/false,
  "acceptable_lighting": true/false,
  "is_partial_body_only": true/false,
  "is_object_or_environment": true/false,
  "validation_status": "ok" | "no_human" | "partial_body" | "bad_framing" | "bad_lighting",
  "message": "<short user-facing message if invalid, empty string if ok>"
}
Rules:
- human_detected: true only if a full or mostly full human body is visible
- full_body_visible: true only if head to feet are visible
- is_partial_body_only: true if only feet, legs, head, or torso visible without full body
- is_object_or_environment: true if image shows a lamp, wall, floor, object, or non-human scene
- validation_status "ok" only if human_detected AND full_body_visible AND body_centered AND upright_pose AND acceptable_lighting
''',
            },
            {
              'type': 'file',
              'file': {
                'file_data': 'data:image/jpeg;base64,$base64Image',
                'filename': 'scan_photo.jpg',
                'format': 'image/jpeg',
              },
            },
          ],
        },
      ];

      final response = await getChatCompletion(
        'GEMINI',
        'gemini/gemini-2.5-flash',
        messages,
        parameters: {'temperature': 0.1, 'max_tokens': 300},
      );

      final content =
          response['choices']?[0]?['message']?['content'] as String?;
      if (content == null || content.isEmpty) {
        throw Exception('Empty validation response');
      }

      debugPrint('[CameraCapture] AI validation response: $content');

      String cleaned = content.trim();
      if (cleaned.startsWith('```')) {
        cleaned = cleaned.replaceAll(RegExp(r'```json\s*|```\s*'), '').trim();
      }

      Map<String, dynamic> result;
      try {
        result = jsonDecode(cleaned) as Map<String, dynamic>;
      } catch (_) {
        final jsonMatch = RegExp(r'\{[\s\S]*\}').firstMatch(cleaned);
        if (jsonMatch != null) {
          result = jsonDecode(jsonMatch.group(0)!) as Map<String, dynamic>;
        } else {
          throw Exception('Could not parse validation JSON');
        }
      }

      final status = result['validation_status'] as String? ?? 'ok';
      final isObjectOrEnv =
          result['is_object_or_environment'] as bool? ?? false;
      final isPartialBody = result['is_partial_body_only'] as bool? ?? false;
      final humanDetected = result['human_detected'] as bool? ?? false;
      final aiMessage = result['message'] as String? ?? '';

      debugPrint(
        '[CameraCapture] Validation: status=$status, humanDetected=$humanDetected, isPartial=$isPartialBody, isObject=$isObjectOrEnv',
      );

      // Only hard-reject if it's clearly a non-human object/environment
      if (isObjectOrEnv && !humanDetected) {
        return (
          PhotoValidation.invalidBody,
          'Full human body not detected. Please retake the photo.',
        );
      }

      // Partial body: recommend retake but don't hard-block
      if (isPartialBody || status == 'partial_body') {
        return (
          PhotoValidation.retakeRecommended,
          'Try to include your full body from head to toe for best results.',
        );
      }

      if (status == 'bad_framing') {
        return (
          PhotoValidation.retakeRecommended,
          'Body not properly framed. Stand 2 meters away and keep your full body inside the frame.',
        );
      }

      if (status == 'bad_lighting') {
        return (
          PhotoValidation.retakeRecommended,
          'Lighting is too dark. Move to a brighter area and retake.',
        );
      }

      if (status == 'ok') {
        return (PhotoValidation.ok, '');
      }

      // Fallback: use AI message if provided
      if (aiMessage.isNotEmpty) {
        return (PhotoValidation.retakeRecommended, aiMessage);
      }

      return (PhotoValidation.ok, '');
    } catch (e) {
      debugPrint(
        '[CameraCapture] AI validation error: $e — falling back to size check',
      );
      // Fallback: if AI fails, accept the photo (don't block the user)
      return (PhotoValidation.ok, '');
    }
  }

  Future<void> _capturePhoto() async {
    try {
      if (_cameraController == null ||
          !_cameraController!.value.isInitialized) {
        throw Exception('Camera not ready');
      }

      final XFile photo = await _cameraController!.takePicture();
      debugPrint(
        '[CameraCapture] ${_currentMode == PhotoMode.front ? "Front" : "Side"} photo captured: ${photo.path}',
      );

      final Uint8List bytes = await photo.readAsBytes();
      final String base64Image = base64Encode(bytes);

      HapticFeedback.heavyImpact();

      // Show validating state
      setState(() {
        _countdownValue = 0;
        if (_currentMode == PhotoMode.front) {
          _frontState = CaptureState.validating;
          _frontPhotoBytes = bytes;
        } else {
          _sideState = CaptureState.validating;
          _sidePhotoBytes = bytes;
        }
      });

      // Run AI validation
      final (validation, message) = await _validatePhotoWithAI(bytes);

      if (!mounted) return;

      _checkController.forward(from: 0);

      setState(() {
        if (_currentMode == PhotoMode.front) {
          _frontPhotoBase64 = base64Image;
          _frontValidation = validation;
          _frontValidationMessage = message.isNotEmpty ? message : null;
          if (validation == PhotoValidation.invalidBody) {
            _frontState = CaptureState.idle;
            _frontPhotoBytes = null;
            _frontPhotoBase64 = null;
          } else {
            _frontState = CaptureState.captured;
          }
          debugPrint(
            '[CameraCapture] Front photo validation: ${validation.name} — $message',
          );
        } else {
          _sidePhotoBase64 = base64Image;
          _sideValidation = validation;
          _sideValidationMessage = message.isNotEmpty ? message : null;
          if (validation == PhotoValidation.invalidBody) {
            _sideState = CaptureState.idle;
            _sidePhotoBytes = null;
            _sidePhotoBase64 = null;
          } else {
            _sideState = CaptureState.captured;
          }
          debugPrint(
            '[CameraCapture] Side photo validation: ${validation.name} — $message',
          );
        }
      });

      // Show invalid body message as snackbar
      if (validation == PhotoValidation.invalidBody && mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(message),
            backgroundColor: const Color(0xFFE17055),
            behavior: SnackBarBehavior.floating,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(12),
            ),
            duration: const Duration(seconds: 4),
          ),
        );
        return;
      }

      // Auto-switch to side mode after front capture
      if (_currentMode == PhotoMode.front &&
          _frontState == CaptureState.captured &&
          !_sideCaptured) {
        await Future.delayed(const Duration(milliseconds: 1800));
        if (!mounted) return;
        HapticFeedback.lightImpact();
        setState(() => _currentMode = PhotoMode.side);
      }

      // Auto-advance when both captured
      if (_bothCaptured) {
        await Future.delayed(const Duration(milliseconds: 1200));
        if (!mounted) return;
        _navigateNext();
      }
    } catch (e) {
      debugPrint('[CameraCapture] Capture error: $e');
      if (!mounted) return;
      setState(() {
        _countdownValue = 0;
        if (_currentMode == PhotoMode.front) {
          _frontState = CaptureState.idle;
        } else {
          _sideState = CaptureState.idle;
        }
      });
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('Capture failed. Please try again.'),
            backgroundColor: Colors.red,
            duration: Duration(seconds: 2),
          ),
        );
      }
    }
  }

  void _onRetake() {
    HapticFeedback.lightImpact();
    _countdownTimer?.cancel();
    setState(() {
      _countdownValue = 0;
      if (_currentMode == PhotoMode.front) {
        _frontState = CaptureState.idle;
        _frontPhotoBase64 = null;
        _frontPhotoBytes = null;
        _frontValidation = PhotoValidation.pending;
        _frontValidationMessage = null;
      } else {
        _sideState = CaptureState.idle;
        _sidePhotoBase64 = null;
        _sidePhotoBytes = null;
        _sideValidation = PhotoValidation.pending;
        _sideValidationMessage = null;
      }
    });
  }

  void _navigateNext() {
    final updatedData = (widget.onboardingData ?? OnboardingData()).copyWith(
      frontPhotoPath: _frontPhotoBase64 ?? '',
      sidePhotoPath: _sidePhotoBase64 ?? '',
    );
    // Pass standaloneMode flag via arguments map
    Navigator.of(
      context,
    ).pushNamed(AppRoutes.aiProcessing, arguments: updatedData);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF0A0A0F),
      body: SafeArea(
        child: FadeTransition(
          opacity: _fadeAnimation,
          child: SlideTransition(
            position: _slideAnimation,
            child: Column(
              children: [
                _buildHeader(),
                _buildModeSelector(),
                Expanded(child: _buildViewfinder()),
                _buildControls(),
                SizedBox(height: 2.h),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildHeader() {
    return Padding(
      padding: EdgeInsets.symmetric(horizontal: 4.w, vertical: 1.5.h),
      child: Row(
        children: [
          GestureDetector(
            onTap: () {
              HapticFeedback.lightImpact();
              _countdownTimer?.cancel();
              Navigator.of(context).pop();
            },
            child: Container(
              width: 10.w,
              height: 10.w,
              decoration: BoxDecoration(
                color: Colors.white.withValues(alpha: 0.1),
                borderRadius: BorderRadius.circular(12.0),
                border: Border.all(color: Colors.white.withValues(alpha: 0.15)),
              ),
              child: const Icon(
                Icons.arrow_back_ios_new_rounded,
                color: Colors.white,
                size: 18,
              ),
            ),
          ),
          SizedBox(width: 3.w),
          Expanded(
            child: Text(
              _currentMode == PhotoMode.front ? 'Front Photo' : 'Side Photo',
              style: GoogleFonts.plusJakartaSans(
                fontSize: 14.sp > 18 ? 18 : 14.sp,
                fontWeight: FontWeight.w700,
                color: Colors.white,
              ),
              textAlign: TextAlign.center,
            ),
          ),
          // Camera flip button (hidden on web or single-camera devices)
          if (!kIsWeb && _cameras.length >= 2)
            GestureDetector(
              onTap:
                  (_currentState == CaptureState.countdown ||
                      _currentState == CaptureState.validating)
                  ? null
                  : _toggleCamera,
              child: Container(
                width: 10.w,
                height: 10.w,
                decoration: BoxDecoration(
                  color: Colors.white.withValues(alpha: 0.1),
                  borderRadius: BorderRadius.circular(12.0),
                  border: Border.all(
                    color: Colors.white.withValues(alpha: 0.15),
                  ),
                ),
                child: Icon(
                  Icons.flip_camera_ios_rounded,
                  color: Colors.white.withValues(alpha: 0.85),
                  size: 20,
                ),
              ),
            )
          else
            SizedBox(width: 10.w),
        ],
      ),
    );
  }

  Widget _buildModeSelector() {
    return Padding(
      padding: EdgeInsets.symmetric(horizontal: 4.w, vertical: 0.5.h),
      child: Container(
        padding: EdgeInsets.all(1.w),
        decoration: BoxDecoration(
          color: Colors.white.withValues(alpha: 0.08),
          borderRadius: BorderRadius.circular(14.0),
          border: Border.all(color: Colors.white.withValues(alpha: 0.1)),
        ),
        child: Row(
          children: [
            _buildModeTab(PhotoMode.front, 'Front Photo', Icons.person_rounded),
            _buildModeTab(
              PhotoMode.side,
              'Side Photo',
              Icons.accessibility_new_rounded,
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildModeTab(PhotoMode mode, String label, IconData icon) {
    final isActive = _currentMode == mode;
    final isCaptured = mode == PhotoMode.front ? _frontCaptured : _sideCaptured;

    return Expanded(
      child: GestureDetector(
        onTap: () {
          HapticFeedback.selectionClick();
          setState(() => _currentMode = mode);
        },
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 250),
          padding: EdgeInsets.symmetric(vertical: 1.2.h),
          decoration: BoxDecoration(
            color: isActive ? const Color(0xFF6C5CE7) : Colors.transparent,
            borderRadius: BorderRadius.circular(12.0),
          ),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              if (isCaptured)
                Container(
                  width: 5.w,
                  height: 5.w,
                  decoration: const BoxDecoration(
                    color: Color(0xFF00B894),
                    shape: BoxShape.circle,
                  ),
                  child: const Icon(
                    Icons.check_rounded,
                    color: Colors.white,
                    size: 12,
                  ),
                )
              else
                Icon(
                  icon,
                  color: isActive
                      ? Colors.white
                      : Colors.white.withValues(alpha: 0.5),
                  size: 16,
                ),
              SizedBox(width: 2.w),
              Text(
                label,
                style: GoogleFonts.plusJakartaSans(
                  fontSize: 11.sp > 14 ? 14 : 11.sp,
                  fontWeight: isActive ? FontWeight.w700 : FontWeight.w500,
                  color: isActive
                      ? Colors.white
                      : Colors.white.withValues(alpha: 0.5),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildViewfinder() {
    return Padding(
      padding: EdgeInsets.symmetric(horizontal: 4.w, vertical: 1.h),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(20.0),
        child: Stack(
          fit: StackFit.expand,
          children: [
            _buildCameraOrPreview(),
            // Corner guides only — no silhouette overlay
            _buildCornerGuides(),
            if (_currentState == CaptureState.countdown)
              _buildCountdownOverlay(),
            if (_currentState == CaptureState.validating)
              _buildValidatingOverlay(),
            if (_currentState == CaptureState.captured)
              _buildCapturedPhotoOverlay(),
          ],
        ),
      ),
    );
  }

  Widget _buildCameraOrPreview() {
    if (_currentState == CaptureState.captured && _currentPhotoBytes != null) {
      return Image.memory(_currentPhotoBytes!, fit: BoxFit.cover);
    }

    if (_cameraError) {
      return Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            colors: [Color(0xFF0D1117), Color(0xFF161B22), Color(0xFF0D1117)],
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
          ),
        ),
        child: Center(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Icon(
                Icons.camera_alt_outlined,
                color: Colors.white.withValues(alpha: 0.4),
                size: 48,
              ),
              SizedBox(height: 1.h),
              Text(
                'Camera unavailable',
                style: GoogleFonts.plusJakartaSans(
                  color: Colors.white.withValues(alpha: 0.5),
                  fontSize: 12.sp,
                ),
              ),
              SizedBox(height: 2.h),
              GestureDetector(
                onTap: _onChooseFromGallery,
                child: Container(
                  padding: EdgeInsets.symmetric(
                    horizontal: 4.w,
                    vertical: 1.2.h,
                  ),
                  decoration: BoxDecoration(
                    color: const Color(0xFF6C5CE7).withValues(alpha: 0.2),
                    borderRadius: BorderRadius.circular(12.0),
                    border: Border.all(
                      color: const Color(0xFF6C5CE7).withValues(alpha: 0.5),
                    ),
                  ),
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      const Icon(
                        Icons.photo_library_rounded,
                        color: Color(0xFF6C5CE7),
                        size: 18,
                      ),
                      SizedBox(width: 2.w),
                      Text(
                        'Choose from Gallery',
                        style: GoogleFonts.plusJakartaSans(
                          color: const Color(0xFF6C5CE7),
                          fontSize: 12.sp,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      );
    }

    if (!_cameraInitialized || _cameraController == null) {
      return Container(
        color: const Color(0xFF0D1117),
        child: Center(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const CircularProgressIndicator(
                color: Color(0xFF6C5CE7),
                strokeWidth: 2,
              ),
              SizedBox(height: 1.5.h),
              Text(
                'Initializing camera...',
                style: GoogleFonts.plusJakartaSans(
                  color: Colors.white.withValues(alpha: 0.5),
                  fontSize: 11.sp,
                ),
              ),
            ],
          ),
        ),
      );
    }

    return CameraPreview(_cameraController!);
  }

  Widget _buildCornerGuides() {
    return Positioned.fill(child: CustomPaint(painter: _CornerGuidePainter()));
  }

  Widget _buildCountdownOverlay() {
    return Positioned.fill(
      child: Container(
        color: Colors.black.withValues(alpha: 0.4),
        child: Center(
          child: AnimatedBuilder(
            animation: _pulseAnimation,
            builder: (context, child) {
              return Transform.scale(
                scale: _pulseAnimation.value,
                child: Container(
                  width: 22.w,
                  height: 22.w,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    color: const Color(0xFF6C5CE7).withValues(alpha: 0.9),
                    boxShadow: [
                      BoxShadow(
                        color: const Color(0xFF6C5CE7).withValues(alpha: 0.6),
                        blurRadius: 30,
                        spreadRadius: 8,
                      ),
                    ],
                  ),
                  child: Center(
                    child: Text(
                      '$_countdownValue',
                      style: GoogleFonts.plusJakartaSans(
                        fontSize: 22.sp > 32 ? 32 : 22.sp,
                        fontWeight: FontWeight.w900,
                        color: Colors.white,
                      ),
                    ),
                  ),
                ),
              );
            },
          ),
        ),
      ),
    );
  }

  Widget _buildValidatingOverlay() {
    return Positioned.fill(
      child: Container(
        color: Colors.black.withValues(alpha: 0.6),
        child: Center(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const CircularProgressIndicator(
                color: Color(0xFF6C5CE7),
                strokeWidth: 3,
              ),
              SizedBox(height: 2.h),
              Text(
                'Validating photo...',
                style: GoogleFonts.plusJakartaSans(
                  fontSize: 13.sp > 16 ? 16 : 13.sp,
                  fontWeight: FontWeight.w600,
                  color: Colors.white,
                ),
              ),
              SizedBox(height: 0.5.h),
              Text(
                'Checking body detection',
                style: GoogleFonts.plusJakartaSans(
                  fontSize: 10.sp > 13 ? 13 : 10.sp,
                  color: Colors.white.withValues(alpha: 0.6),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildCapturedPhotoOverlay() {
    final validation = _currentValidation;
    final message = _currentValidationMessage;

    Color badgeColor;
    IconData badgeIcon;
    String badgeText;

    switch (validation) {
      case PhotoValidation.ok:
        badgeColor = const Color(0xFF00B894);
        badgeIcon = Icons.check_circle_rounded;
        badgeText = 'Photo OK';
        break;
      case PhotoValidation.retakeRecommended:
        badgeColor = const Color(0xFFE17055);
        badgeIcon = Icons.warning_rounded;
        badgeText = 'Retake recommended';
        break;
      default:
        badgeColor = const Color(0xFF6C5CE7);
        badgeIcon = Icons.check_rounded;
        badgeText = 'Captured';
    }

    return Positioned(
      top: 12,
      left: 12,
      right: 12,
      child: Column(
        children: [
          AnimatedBuilder(
            animation: _checkAnimation,
            builder: (context, child) {
              return Transform.scale(
                scale: _checkAnimation.value,
                child: Container(
                  padding: EdgeInsets.symmetric(
                    horizontal: 3.w,
                    vertical: 0.8.h,
                  ),
                  decoration: BoxDecoration(
                    color: badgeColor.withValues(alpha: 0.9),
                    borderRadius: BorderRadius.circular(20.0),
                    boxShadow: [
                      BoxShadow(
                        color: badgeColor.withValues(alpha: 0.4),
                        blurRadius: 12,
                        spreadRadius: 2,
                      ),
                    ],
                  ),
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Icon(badgeIcon, color: Colors.white, size: 16),
                      SizedBox(width: 1.5.w),
                      Text(
                        badgeText,
                        style: GoogleFonts.plusJakartaSans(
                          fontSize: 10.sp > 13 ? 13 : 10.sp,
                          fontWeight: FontWeight.w700,
                          color: Colors.white,
                        ),
                      ),
                    ],
                  ),
                ),
              );
            },
          ),
          if (message != null && message.isNotEmpty) ...[
            SizedBox(height: 0.8.h),
            Container(
              padding: EdgeInsets.symmetric(horizontal: 3.w, vertical: 0.8.h),
              decoration: BoxDecoration(
                color: Colors.black.withValues(alpha: 0.7),
                borderRadius: BorderRadius.circular(12.0),
              ),
              child: Text(
                message,
                style: GoogleFonts.plusJakartaSans(
                  fontSize: 9.sp > 12 ? 12 : 9.sp,
                  color: Colors.white.withValues(alpha: 0.9),
                ),
                textAlign: TextAlign.center,
              ),
            ),
          ],
        ],
      ),
    );
  }

  Widget _buildInstructionBanner() {
    String text;
    Color color;

    if (_currentState == CaptureState.validating) {
      text = 'Checking photo...';
      color = const Color(0xFF6C5CE7);
    } else if (_currentState == CaptureState.captured) {
      final validation = _currentValidation;
      if (validation == PhotoValidation.ok) {
        text = '✓ Photo accepted';
        color = const Color(0xFF00B894);
      } else {
        text = _currentValidationMessage ?? 'Retake recommended';
        color = const Color(0xFFE17055);
      }
    } else if (_currentState == CaptureState.countdown) {
      text = 'Hold still — $_countdownValue';
      color = const Color(0xFF6C5CE7);
    } else {
      text = _currentMode == PhotoMode.front
          ? 'Full body in frame, face camera'
          : 'Turn sideways, full body in frame';
      color = Colors.white.withValues(alpha: 0.7);
    }

    return Padding(
      padding: EdgeInsets.symmetric(horizontal: 4.w, vertical: 0.5.h),
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 300),
        width: double.infinity,
        padding: EdgeInsets.symmetric(horizontal: 4.w, vertical: 0.7.h),
        decoration: BoxDecoration(
          color: color.withValues(alpha: 0.12),
          borderRadius: BorderRadius.circular(10.0),
          border: Border.all(color: color.withValues(alpha: 0.3)),
        ),
        child: Text(
          text,
          style: GoogleFonts.plusJakartaSans(
            fontSize: 10.sp > 12 ? 12 : 10.sp,
            color: color,
            fontWeight: FontWeight.w500,
          ),
          textAlign: TextAlign.center,
          maxLines: 1,
          overflow: TextOverflow.ellipsis,
        ),
      ),
    );
  }

  Widget _buildControls() {
    final bool isValidating = _currentState == CaptureState.validating;
    final bool isCaptured = _currentState == CaptureState.captured;
    final bool isCountdown = _currentState == CaptureState.countdown;
    final bool isRetakeRecommended =
        isCaptured && _currentValidation == PhotoValidation.retakeRecommended;

    return Padding(
      padding: EdgeInsets.symmetric(horizontal: 6.w),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              if (isCaptured) ...[
                Expanded(
                  child: GestureDetector(
                    onTap: _onRetake,
                    child: Container(
                      padding: EdgeInsets.symmetric(vertical: 1.8.h),
                      decoration: BoxDecoration(
                        color: Colors.white.withValues(alpha: 0.08),
                        borderRadius: BorderRadius.circular(16.0),
                        border: Border.all(
                          color: Colors.white.withValues(alpha: 0.2),
                        ),
                      ),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          const Icon(
                            Icons.refresh_rounded,
                            color: Colors.white,
                            size: 20,
                          ),
                          SizedBox(width: 2.w),
                          Text(
                            'Retake',
                            style: GoogleFonts.plusJakartaSans(
                              fontSize: 12.sp > 15 ? 15 : 12.sp,
                              fontWeight: FontWeight.w600,
                              color: Colors.white,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
                SizedBox(width: 3.w),
                Expanded(
                  flex: 2,
                  child: GestureDetector(
                    onTap: _bothCaptured
                        ? _navigateNext
                        : () {
                            setState(() => _currentMode = PhotoMode.side);
                          },
                    child: Container(
                      padding: EdgeInsets.symmetric(vertical: 1.8.h),
                      decoration: BoxDecoration(
                        gradient: const LinearGradient(
                          colors: [Color(0xFF6C5CE7), Color(0xFF74B9FF)],
                        ),
                        borderRadius: BorderRadius.circular(16.0),
                        boxShadow: [
                          BoxShadow(
                            color: const Color(
                              0xFF6C5CE7,
                            ).withValues(alpha: 0.4),
                            blurRadius: 16,
                            offset: const Offset(0, 4),
                          ),
                        ],
                      ),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Text(
                            _bothCaptured ? 'Analyze Now' : 'Next: Side Photo',
                            style: GoogleFonts.plusJakartaSans(
                              fontSize: 12.sp > 15 ? 15 : 12.sp,
                              fontWeight: FontWeight.w700,
                              color: Colors.white,
                            ),
                          ),
                          SizedBox(width: 2.w),
                          const Icon(
                            Icons.arrow_forward_rounded,
                            color: Colors.white,
                            size: 18,
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
              ] else ...[
                Expanded(
                  child: GestureDetector(
                    onTap: (isCountdown || isValidating) ? null : _onCapture,
                    child: AnimatedBuilder(
                      animation: _pulseAnimation,
                      builder: (context, child) {
                        return Transform.scale(
                          scale: isCountdown ? _pulseAnimation.value : 1.0,
                          child: Container(
                            padding: EdgeInsets.symmetric(vertical: 1.8.h),
                            decoration: BoxDecoration(
                              gradient: (isCountdown || isValidating)
                                  ? const LinearGradient(
                                      colors: [
                                        Color(0xFF636E72),
                                        Color(0xFF636E72),
                                      ],
                                    )
                                  : const LinearGradient(
                                      colors: [
                                        Color(0xFF6C5CE7),
                                        Color(0xFF74B9FF),
                                      ],
                                    ),
                              borderRadius: BorderRadius.circular(16.0),
                              boxShadow: [
                                if (!isCountdown && !isValidating)
                                  BoxShadow(
                                    color: const Color(
                                      0xFF6C5CE7,
                                    ).withValues(alpha: 0.4),
                                    blurRadius: 16,
                                    offset: const Offset(0, 4),
                                  ),
                              ],
                            ),
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                if (isValidating)
                                  const SizedBox(
                                    width: 18,
                                    height: 18,
                                    child: CircularProgressIndicator(
                                      color: Colors.white,
                                      strokeWidth: 2,
                                    ),
                                  )
                                else
                                  Icon(
                                    isCountdown
                                        ? Icons.timer_rounded
                                        : Icons.camera_alt_rounded,
                                    color: Colors.white,
                                    size: 20,
                                  ),
                                SizedBox(width: 2.w),
                                Text(
                                  isValidating
                                      ? 'Validating...'
                                      : isCountdown
                                      ? 'Capturing in $_countdownValue...'
                                      : _currentMode == PhotoMode.front
                                      ? 'Capture Front'
                                      : 'Capture Side',
                                  style: GoogleFonts.plusJakartaSans(
                                    fontSize: 12.sp > 15 ? 15 : 12.sp,
                                    fontWeight: FontWeight.w700,
                                    color: Colors.white,
                                  ),
                                ),
                              ],
                            ),
                          ),
                        );
                      },
                    ),
                  ),
                ),
              ],
            ],
          ),
          // Gallery fallback button — shown when idle or retake recommended
          if (!isCountdown && !isValidating && !isCaptured ||
              isRetakeRecommended) ...[
            SizedBox(height: 1.h),
            GestureDetector(
              onTap: _onChooseFromGallery,
              child: Container(
                width: double.infinity,
                padding: EdgeInsets.symmetric(vertical: 1.4.h),
                decoration: BoxDecoration(
                  color: Colors.white.withValues(alpha: 0.05),
                  borderRadius: BorderRadius.circular(14.0),
                  border: Border.all(
                    color: Colors.white.withValues(alpha: 0.15),
                  ),
                ),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Icon(
                      Icons.photo_library_rounded,
                      color: Colors.white.withValues(alpha: 0.6),
                      size: 18,
                    ),
                    SizedBox(width: 2.w),
                    Text(
                      'Choose from Gallery',
                      style: GoogleFonts.plusJakartaSans(
                        fontSize: 11.sp > 14 ? 14 : 11.sp,
                        fontWeight: FontWeight.w500,
                        color: Colors.white.withValues(alpha: 0.6),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ],
      ),
    );
  }
}

// ─── Painters ────────────────────────────────────────────────────────────────

class _CornerGuidePainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = const Color(0xFF6C5CE7).withValues(alpha: 0.8)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 3
      ..strokeCap = StrokeCap.round;

    const double len = 24;
    const double margin = 12;

    // Top-left
    canvas.drawLine(
      const Offset(margin, margin + len),
      const Offset(margin, margin),
      paint,
    );
    canvas.drawLine(
      const Offset(margin, margin),
      const Offset(margin + len, margin),
      paint,
    );

    // Top-right
    canvas.drawLine(
      Offset(size.width - margin - len, margin),
      Offset(size.width - margin, margin),
      paint,
    );
    canvas.drawLine(
      Offset(size.width - margin, margin),
      Offset(size.width - margin, margin + len),
      paint,
    );

    // Bottom-left
    canvas.drawLine(
      Offset(margin, size.height - margin - len),
      Offset(margin, size.height - margin),
      paint,
    );
    canvas.drawLine(
      Offset(margin, size.height - margin),
      Offset(margin + len, size.height - margin),
      paint,
    );

    // Bottom-right
    canvas.drawLine(
      Offset(size.width - margin - len, size.height - margin),
      Offset(size.width - margin, size.height - margin),
      paint,
    );
    canvas.drawLine(
      Offset(size.width - margin, size.height - margin - len),
      Offset(size.width - margin, size.height - margin),
      paint,
    );
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}
