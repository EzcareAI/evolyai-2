import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:sizer/sizer.dart';

import '../../models/onboarding_data.dart';
import '../goal_selection_screen/widgets/onboarding_progress_widget.dart';
import '../../routes/app_routes.dart';

class ResultsExplanationScreen extends StatefulWidget {
  final OnboardingData? onboardingData;

  const ResultsExplanationScreen({super.key, this.onboardingData});

  @override
  State<ResultsExplanationScreen> createState() =>
      _ResultsExplanationScreenState();
}

class _ResultsExplanationScreenState extends State<ResultsExplanationScreen>
    with SingleTickerProviderStateMixin {
  late AnimationController _entryController;
  late Animation<double> _fadeAnimation;
  late Animation<Offset> _slideAnimation;

  final List<Map<String, dynamic>> _features = [
    {
      'icon': Icons.percent_rounded,
      'label': '% Masse Grasse',
      'description': 'Precise fat percentage measured from your scan',
      'color': const Color(0xFF6C5CE7),
      'bgColor': const Color(0xFFF0EEFF),
    },
    {
      'icon': Icons.accessibility_new_rounded,
      'label': 'Composition Corporelle',
      'description': 'Muscle, fat, and lean mass breakdown',
      'color': const Color(0xFF00B894),
      'bgColor': const Color(0xFFE8FBF5),
    },
    {
      'icon': Icons.category_rounded,
      'label': 'Body Category',
      'description': 'Your body type classification and profile',
      'color': const Color(0xFF0984E3),
      'bgColor': const Color(0xFFE8F4FF),
    },
    {
      'icon': Icons.trending_up_rounded,
      'label': 'Progress Tracking',
      'description': 'Monitor changes over time with visual charts',
      'color': const Color(0xFFE17055),
      'bgColor': const Color(0xFFFFF0ED),
    },
    {
      'icon': Icons.assignment_rounded,
      'label': 'Full Body Report',
      'description': 'Comprehensive AI-generated health insights',
      'color': const Color(0xFFF39C12),
      'bgColor': const Color(0xFFFFF8E8),
    },
  ];

  @override
  void initState() {
    super.initState();
    _entryController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 600),
    )..forward();
    _fadeAnimation = CurvedAnimation(
      parent: _entryController,
      curve: Curves.easeOut,
    );
    _slideAnimation =
        Tween<Offset>(begin: const Offset(0.05, 0), end: Offset.zero).animate(
          CurvedAnimation(parent: _entryController, curve: Curves.easeOutCubic),
        );
  }

  @override
  void dispose() {
    _entryController.dispose();
    super.dispose();
  }

  void _onContinue() {
    HapticFeedback.mediumImpact();
    Navigator.of(context).pushNamed(
      AppRoutes.notificationsPermission,
      arguments: widget.onboardingData,
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: SafeArea(
        child: FadeTransition(
          opacity: _fadeAnimation,
          child: SlideTransition(
            position: _slideAnimation,
            child: Padding(
              padding: EdgeInsets.symmetric(horizontal: 4.w, vertical: 2.h),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  _buildHeader(),
                  SizedBox(height: 2.5.h),
                  _buildTitleSection(),
                  SizedBox(height: 2.h),
                  _buildPremiumBadge(),
                  SizedBox(height: 2.h),
                  Expanded(child: _buildFeaturesList()),
                  SizedBox(height: 2.h),
                  _buildContinueButton(),
                  SizedBox(height: 1.h),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildHeader() {
    return Row(
      children: [
        GestureDetector(
          onTap: () {
            HapticFeedback.lightImpact();
            Navigator.of(context).pop();
          },
          child: Container(
            width: 10.w,
            height: 10.w,
            decoration: BoxDecoration(
              color: const Color(0xFFF8F9FA),
              borderRadius: BorderRadius.circular(12.0),
              border: Border.all(color: const Color(0xFFE2E8F0)),
            ),
            child: const Icon(
              Icons.arrow_back_ios_new_rounded,
              color: Color(0xFF1B365D),
              size: 18,
            ),
          ),
        ),
        SizedBox(width: 3.w),
        Expanded(
          child: OnboardingProgressWidget(currentStep: 12, totalSteps: 16),
        ),
      ],
    );
  }

  Widget _buildTitleSection() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        ShaderMask(
          shaderCallback: (bounds) => const LinearGradient(
            colors: [Color(0xFF1B365D), Color(0xFF6C5CE7)],
            begin: Alignment.centerLeft,
            end: Alignment.centerRight,
          ).createShader(bounds),
          child: Text(
            'Your scan will reveal',
            style: GoogleFonts.plusJakartaSans(
              fontSize: 20.sp > 28 ? 28 : 20.sp,
              fontWeight: FontWeight.w800,
              color: Colors.white,
              height: 1.2,
            ),
          ),
        ),
        SizedBox(height: 0.8.h),
        Text(
          'A single scan unlocks powerful insights about your body composition and health.',
          style: GoogleFonts.plusJakartaSans(
            fontSize: 12.sp > 15 ? 15 : 12.sp,
            fontWeight: FontWeight.w400,
            color: const Color(0xFF636E72),
            height: 1.5,
          ),
        ),
      ],
    );
  }

  Widget _buildPremiumBadge() {
    return Container(
      padding: EdgeInsets.symmetric(horizontal: 4.w, vertical: 1.2.h),
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          colors: [Color(0xFF6C5CE7), Color(0xFF8B5CF6)],
          begin: Alignment.centerLeft,
          end: Alignment.centerRight,
        ),
        borderRadius: BorderRadius.circular(14.0),
        boxShadow: [
          BoxShadow(
            color: const Color(0xFF6C5CE7).withValues(alpha: 0.25),
            blurRadius: 12,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: Row(
        children: [
          Container(
            padding: const EdgeInsets.all(6),
            decoration: BoxDecoration(
              color: Colors.white.withValues(alpha: 0.2),
              borderRadius: BorderRadius.circular(8.0),
            ),
            child: const Icon(
              Icons.auto_awesome_rounded,
              color: Colors.white,
              size: 18,
            ),
          ),
          SizedBox(width: 3.w),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'AI-Powered Premium Analysis',
                  style: GoogleFonts.plusJakartaSans(
                    fontSize: 12.sp > 14 ? 14 : 12.sp,
                    fontWeight: FontWeight.w700,
                    color: Colors.white,
                  ),
                ),
                Text(
                  'Everything you need to understand your body',
                  style: GoogleFonts.plusJakartaSans(
                    fontSize: 9.sp > 11 ? 11 : 9.sp,
                    fontWeight: FontWeight.w400,
                    color: Colors.white.withValues(alpha: 0.85),
                  ),
                ),
              ],
            ),
          ),
          Container(
            padding: EdgeInsets.symmetric(horizontal: 2.w, vertical: 0.4.h),
            decoration: BoxDecoration(
              color: Colors.white.withValues(alpha: 0.2),
              borderRadius: BorderRadius.circular(20.0),
            ),
            child: Text(
              'FREE',
              style: GoogleFonts.plusJakartaSans(
                fontSize: 9.sp > 11 ? 11 : 9.sp,
                fontWeight: FontWeight.w800,
                color: Colors.white,
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildFeaturesList() {
    return Container(
      padding: EdgeInsets.all(3.w),
      decoration: BoxDecoration(
        color: const Color(0xFFFAFAFF),
        borderRadius: BorderRadius.circular(20.0),
        border: Border.all(color: const Color(0xFFE2E8F0)),
      ),
      child: ListView.separated(
        physics: const NeverScrollableScrollPhysics(),
        shrinkWrap: true,
        itemCount: _features.length,
        separatorBuilder: (_, __) => Padding(
          padding: EdgeInsets.symmetric(vertical: 0.8.h),
          child: const Divider(color: Color(0xFFEEF0F5), height: 1),
        ),
        itemBuilder: (context, index) {
          final feature = _features[index];
          return _buildFeatureRow(
            icon: feature['icon'] as IconData,
            label: feature['label'] as String,
            description: feature['description'] as String,
            iconColor: feature['color'] as Color,
            bgColor: feature['bgColor'] as Color,
          );
        },
      ),
    );
  }

  Widget _buildFeatureRow({
    required IconData icon,
    required String label,
    required String description,
    required Color iconColor,
    required Color bgColor,
  }) {
    return Padding(
      padding: EdgeInsets.symmetric(vertical: 0.6.h),
      child: Row(
        children: [
          Container(
            width: 11.w,
            height: 11.w,
            decoration: BoxDecoration(
              color: bgColor,
              borderRadius: BorderRadius.circular(12.0),
            ),
            child: Icon(icon, color: iconColor, size: 20),
          ),
          SizedBox(width: 3.w),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  label,
                  style: GoogleFonts.plusJakartaSans(
                    fontSize: 12.sp > 15 ? 15 : 12.sp,
                    fontWeight: FontWeight.w700,
                    color: const Color(0xFF1B365D),
                  ),
                ),
                SizedBox(height: 0.2.h),
                Text(
                  description,
                  style: GoogleFonts.plusJakartaSans(
                    fontSize: 10.sp > 12 ? 12 : 10.sp,
                    fontWeight: FontWeight.w400,
                    color: const Color(0xFF636E72),
                  ),
                  overflow: TextOverflow.ellipsis,
                  maxLines: 1,
                ),
              ],
            ),
          ),
          Icon(Icons.check_circle_rounded, color: iconColor, size: 20),
        ],
      ),
    );
  }

  Widget _buildContinueButton() {
    return SizedBox(
      width: double.infinity,
      height: 6.5.h,
      child: DecoratedBox(
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(16.0),
          gradient: const LinearGradient(
            colors: [Color(0xFF6C5CE7), Color(0xFF8B5CF6)],
            begin: Alignment.centerLeft,
            end: Alignment.centerRight,
          ),
          boxShadow: [
            BoxShadow(
              color: const Color(0xFF6C5CE7).withValues(alpha: 0.4),
              blurRadius: 16,
              offset: const Offset(0, 6),
            ),
          ],
        ),
        child: ElevatedButton(
          onPressed: _onContinue,
          style: ElevatedButton.styleFrom(
            backgroundColor: Colors.transparent,
            shadowColor: Colors.transparent,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(16.0),
            ),
          ),
          child: Text(
            'Continue',
            style: GoogleFonts.plusJakartaSans(
              fontSize: 13.sp > 16 ? 16 : 13.sp,
              fontWeight: FontWeight.w700,
              color: Colors.white,
            ),
          ),
        ),
      ),
    );
  }
}
