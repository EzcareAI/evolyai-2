import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:sizer/sizer.dart';

class ReviewCardWidget extends StatelessWidget {
  final String quote;
  final String reviewerName;
  final String avatarInitials;
  final Color avatarColor;
  final int starCount;

  const ReviewCardWidget({
    super.key,
    required this.quote,
    required this.reviewerName,
    required this.avatarInitials,
    required this.avatarColor,
    this.starCount = 5,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: EdgeInsets.all(4.w),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16.0),
        border: Border.all(color: const Color(0xFFE2E8F0), width: 1.5),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: 0.05),
            blurRadius: 10,
            offset: const Offset(0, 3),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              ...List.generate(
                starCount,
                (i) => Padding(
                  padding: const EdgeInsets.only(right: 2),
                  child: Icon(
                    Icons.star_rounded,
                    color: const Color(0xFFFFC107),
                    size: 14.sp > 18 ? 18 : 14.sp,
                  ),
                ),
              ),
              const Spacer(),
              Container(
                padding: EdgeInsets.symmetric(horizontal: 2.w, vertical: 0.4.h),
                decoration: BoxDecoration(
                  color: const Color(0xFF6C5CE7).withValues(alpha: 0.08),
                  borderRadius: BorderRadius.circular(20.0),
                ),
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Icon(
                      Icons.verified_rounded,
                      color: const Color(0xFF6C5CE7),
                      size: 10.sp > 13 ? 13 : 10.sp,
                    ),
                    SizedBox(width: 1.w),
                    Text(
                      'Verified',
                      style: GoogleFonts.plusJakartaSans(
                        fontSize: 9.sp > 11 ? 11 : 9.sp,
                        fontWeight: FontWeight.w600,
                        color: const Color(0xFF6C5CE7),
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
          SizedBox(height: 1.2.h),
          Text(
            '"$quote"',
            style: GoogleFonts.plusJakartaSans(
              fontSize: 12.sp > 15 ? 15 : 12.sp,
              fontWeight: FontWeight.w500,
              color: const Color(0xFF1B365D),
              height: 1.5,
            ),
          ),
          SizedBox(height: 1.5.h),
          Row(
            children: [
              Container(
                width: 9.w,
                height: 9.w,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: avatarColor.withValues(alpha: 0.15),
                ),
                child: Center(
                  child: Text(
                    avatarInitials,
                    style: GoogleFonts.plusJakartaSans(
                      fontSize: 11.sp > 13 ? 13 : 11.sp,
                      fontWeight: FontWeight.w700,
                      color: avatarColor,
                    ),
                  ),
                ),
              ),
              SizedBox(width: 2.w),
              Text(
                reviewerName,
                style: GoogleFonts.plusJakartaSans(
                  fontSize: 11.sp > 13 ? 13 : 11.sp,
                  fontWeight: FontWeight.w600,
                  color: const Color(0xFF636E72),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}
