import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:sizer/sizer.dart';

import '../../models/onboarding_data.dart';
import '../goal_selection_screen/widgets/onboarding_progress_widget.dart';
import './widgets/weight_unit_toggle_widget.dart';
import './widgets/weight_picker_widget.dart';

class WeightInputScreen extends StatefulWidget {
  final OnboardingData? onboardingData;

  const WeightInputScreen({super.key, this.onboardingData});

  @override
  State<WeightInputScreen> createState() => _WeightInputScreenState();
}

class _WeightInputScreenState extends State<WeightInputScreen>
    with SingleTickerProviderStateMixin {
  late String _selectedUnit;
  late double _selectedWeight;

  late AnimationController _fadeController;
  late Animation<double> _fadeAnimation;

  @override
  void initState() {
    super.initState();

    // Inherit unit from height screen: cm → kg, ft → lbs
    final heightUnit = widget.onboardingData?.heightUnit;
    if (heightUnit == 'ft') {
      _selectedUnit = 'lbs';
    } else {
      _selectedUnit = 'kg';
    }

    // Override with previously stored weight unit if available
    if (widget.onboardingData?.weightUnit != null) {
      _selectedUnit = widget.onboardingData!.weightUnit!;
    }

    // Set default weight based on unit
    if (widget.onboardingData?.weightKg != null) {
      final storedKg = widget.onboardingData!.weightKg!;
      _selectedWeight = _selectedUnit == 'lbs' ? storedKg * 2.20462 : storedKg;
    } else {
      _selectedWeight = _selectedUnit == 'kg' ? 70.0 : 154.0;
    }

    _fadeController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 600),
    )..forward();
    _fadeAnimation = CurvedAnimation(
      parent: _fadeController,
      curve: Curves.easeOut,
    );
  }

  @override
  void dispose() {
    _fadeController.dispose();
    super.dispose();
  }

  double get _weightInKg {
    if (_selectedUnit == 'kg') return _selectedWeight;
    return _selectedWeight / 2.20462;
  }

  bool get _isValidWeight {
    final kg = _weightInKg;
    return kg >= 20 && kg <= 300;
  }

  void _onUnitChanged(String unit) {
    setState(() {
      if (unit == 'lbs' && _selectedUnit == 'kg') {
        _selectedWeight = (_selectedWeight * 2.20462).roundToDouble();
      } else if (unit == 'kg' && _selectedUnit == 'lbs') {
        _selectedWeight = (_selectedWeight / 2.20462).roundToDouble();
      }
      _selectedUnit = unit;
    });
  }

  void _onContinue() {
    if (!_isValidWeight) return;
    HapticFeedback.mediumImpact();
    final data = (widget.onboardingData ?? OnboardingData()).copyWith(
      weightKg: _weightInKg,
      weightUnit: _selectedUnit,
    );
    // Navigate to Target Body Fat screen (new step)
    Navigator.of(context).pushNamed('/target-body-fat-screen', arguments: data);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: SafeArea(
        child: FadeTransition(
          opacity: _fadeAnimation,
          child: Padding(
            padding: EdgeInsets.symmetric(horizontal: 4.w, vertical: 2.h),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                _buildHeader(),
                SizedBox(height: 4.h),
                _buildTitleSection(),
                SizedBox(height: 2.h),
                _buildWeightDisplay(),
                SizedBox(height: 2.h),
                Center(
                  child: WeightUnitToggleWidget(
                    selectedUnit: _selectedUnit,
                    onUnitChanged: _onUnitChanged,
                  ),
                ),
                SizedBox(height: 1.5.h),
                Expanded(
                  child: AnimatedSwitcher(
                    duration: const Duration(milliseconds: 300),
                    transitionBuilder: (child, animation) =>
                        FadeTransition(opacity: animation, child: child),
                    child: WeightPickerWidget(
                      key: ValueKey(_selectedUnit),
                      selectedWeight: _selectedWeight,
                      unit: _selectedUnit,
                      onWeightChanged: (val) =>
                          setState(() => _selectedWeight = val),
                    ),
                  ),
                ),
                _buildValidationNote(),
                SizedBox(height: 2.h),
                _buildContinueButton(),
                SizedBox(height: 1.h),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildHeader() {
    return Row(
      children: [
        GestureDetector(
          onTap: () => Navigator.of(context).pop(),
          child: Container(
            width: 10.w,
            height: 10.w,
            decoration: BoxDecoration(
              color: const Color(0xFFF8F9FA),
              borderRadius: BorderRadius.circular(12.0),
              border: Border.all(color: const Color(0xFFE2E8F0)),
            ),
            child: const Icon(
              Icons.arrow_back_ios_new_rounded,
              color: Color(0xFF1B365D),
              size: 18,
            ),
          ),
        ),
        SizedBox(width: 3.w),
        Expanded(
          child: OnboardingProgressWidget(currentStep: 6, totalSteps: 8),
        ),
      ],
    );
  }

  Widget _buildTitleSection() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        ShaderMask(
          shaderCallback: (bounds) => const LinearGradient(
            colors: [Color(0xFF1B365D), Color(0xFF6C5CE7)],
            begin: Alignment.centerLeft,
            end: Alignment.centerRight,
          ).createShader(bounds),
          child: Text(
            "What's your weight?",
            style: GoogleFonts.plusJakartaSans(
              fontSize: 20.sp > 28 ? 28 : 20.sp,
              fontWeight: FontWeight.w800,
              color: Colors.white,
              height: 1.2,
            ),
          ),
        ),
        SizedBox(height: 1.h),
        Text(
          'Your weight enables personalized calorie\ntargets and body composition benchmarks.',
          style: GoogleFonts.plusJakartaSans(
            fontSize: 12.sp > 15 ? 15 : 12.sp,
            fontWeight: FontWeight.w400,
            color: const Color(0xFF636E72),
            height: 1.5,
          ),
        ),
      ],
    );
  }

  Widget _buildWeightDisplay() {
    final displayText = '${_selectedWeight.round()} $_selectedUnit';

    return Center(
      child: AnimatedSwitcher(
        duration: const Duration(milliseconds: 200),
        transitionBuilder: (child, animation) =>
            ScaleTransition(scale: animation, child: child),
        child: Container(
          key: ValueKey(displayText),
          padding: EdgeInsets.symmetric(horizontal: 8.w, vertical: 1.5.h),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(20.0),
            gradient: const LinearGradient(
              colors: [Color(0xFF6C5CE7), Color(0xFF74B9FF)],
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
            ),
            boxShadow: [
              BoxShadow(
                color: const Color(0xFF6C5CE7).withValues(alpha: 0.3),
                blurRadius: 20,
                offset: const Offset(0, 8),
              ),
            ],
          ),
          child: Text(
            displayText,
            style: GoogleFonts.plusJakartaSans(
              fontSize: 20.sp > 32 ? 32 : 20.sp,
              fontWeight: FontWeight.w900,
              color: Colors.white,
              letterSpacing: -0.5,
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildValidationNote() {
    return Center(
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          const Icon(
            Icons.info_outline_rounded,
            size: 14,
            color: Color(0xFF636E72),
          ),
          SizedBox(width: 1.w),
          Text(
            'Valid range: 30–200 kg (66–440 lbs)',
            style: GoogleFonts.plusJakartaSans(
              fontSize: 10.sp > 12 ? 12 : 10.sp,
              fontWeight: FontWeight.w400,
              color: const Color(0xFF636E72),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildContinueButton() {
    return GestureDetector(
      onTap: _isValidWeight ? _onContinue : null,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 200),
        width: double.infinity,
        height: 7.h > 60 ? 60 : 7.h,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(16.0),
          gradient: _isValidWeight
              ? const LinearGradient(
                  colors: [Color(0xFF6C5CE7), Color(0xFF74B9FF)],
                  begin: Alignment.centerLeft,
                  end: Alignment.centerRight,
                )
              : const LinearGradient(
                  colors: [Color(0xFFB2BEC3), Color(0xFFDFE6E9)],
                  begin: Alignment.centerLeft,
                  end: Alignment.centerRight,
                ),
          boxShadow: _isValidWeight
              ? [
                  BoxShadow(
                    color: const Color(0xFF6C5CE7).withValues(alpha: 0.35),
                    blurRadius: 16,
                    offset: const Offset(0, 6),
                  ),
                ]
              : [],
        ),
        child: Center(
          child: Text(
            'Continue',
            style: GoogleFonts.plusJakartaSans(
              fontSize: 14.sp > 17 ? 17 : 14.sp,
              fontWeight: FontWeight.w700,
              color: Colors.white,
            ),
          ),
        ),
      ),
    );
  }
}
