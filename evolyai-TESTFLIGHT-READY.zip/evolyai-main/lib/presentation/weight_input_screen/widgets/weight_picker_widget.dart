import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:sizer/sizer.dart';

class WeightPickerWidget extends StatefulWidget {
  final double selectedWeight;
  final String unit; // 'kg' or 'lbs'
  final ValueChanged<double> onWeightChanged;

  const WeightPickerWidget({
    super.key,
    required this.selectedWeight,
    required this.unit,
    required this.onWeightChanged,
  });

  @override
  State<WeightPickerWidget> createState() => _WeightPickerWidgetState();
}

class _WeightPickerWidgetState extends State<WeightPickerWidget> {
  late FixedExtentScrollController _scrollController;

  int get _minValue => widget.unit == 'kg' ? 30 : 66;
  int get _maxValue => widget.unit == 'kg' ? 200 : 440;
  int get _count => _maxValue - _minValue + 1;

  int get _currentIndex {
    final val = widget.selectedWeight.round().clamp(_minValue, _maxValue);
    return val - _minValue;
  }

  @override
  void initState() {
    super.initState();
    _scrollController = FixedExtentScrollController(initialItem: _currentIndex);
  }

  @override
  void didUpdateWidget(WeightPickerWidget oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (oldWidget.unit != widget.unit) {
      WidgetsBinding.instance.addPostFrameCallback((_) {
        if (_scrollController.hasClients) {
          _scrollController.jumpToItem(_currentIndex);
        }
      });
    }
  }

  @override
  void dispose() {
    _scrollController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    const double itemExtent = 52.0;
    const double pickerHeight = 240.0;
    final unitLabel = widget.unit == 'kg' ? 'kg' : 'lbs';
    final unitIcon = widget.unit == 'kg'
        ? Icons.monitor_weight_outlined
        : Icons.scale_outlined;

    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(unitIcon, size: 16, color: const Color(0xFF6C5CE7)),
            const SizedBox(width: 6),
            Text(
              'Weight ($unitLabel)',
              style: GoogleFonts.plusJakartaSans(
                fontSize: 13,
                fontWeight: FontWeight.w600,
                color: const Color(0xFF636E72),
              ),
            ),
          ],
        ),
        const SizedBox(height: 12),
        SizedBox(
          height: pickerHeight,
          child: Stack(
            alignment: Alignment.center,
            children: [
              // Selection highlight
              Container(
                height: itemExtent,
                margin: EdgeInsets.symmetric(horizontal: 8.w),
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(14.0),
                  gradient: const LinearGradient(
                    colors: [Color(0xFFF0EDFF), Color(0xFFE8F4FF)],
                    begin: Alignment.centerLeft,
                    end: Alignment.centerRight,
                  ),
                  border: Border.all(
                    color: const Color(0xFF6C5CE7).withValues(alpha: 0.25),
                    width: 1.5,
                  ),
                ),
              ),
              // Picker
              ListWheelScrollView.useDelegate(
                controller: _scrollController,
                itemExtent: itemExtent,
                perspective: 0.001,
                diameterRatio: 4.0,
                overAndUnderCenterOpacity: 1.0,
                physics: const BouncingScrollPhysics(),
                onSelectedItemChanged: (index) {
                  HapticFeedback.selectionClick();
                  widget.onWeightChanged((index + _minValue).toDouble());
                },
                childDelegate: ListWheelChildBuilderDelegate(
                  childCount: _count,
                  builder: (context, index) {
                    final value = index + _minValue;
                    final isSelected = value == widget.selectedWeight.round();
                    return Center(
                      child: AnimatedDefaultTextStyle(
                        duration: const Duration(milliseconds: 150),
                        style: isSelected
                            ? GoogleFonts.plusJakartaSans(
                                fontSize: 22,
                                fontWeight: FontWeight.w800,
                                color: const Color(0xFF6C5CE7),
                              )
                            : GoogleFonts.plusJakartaSans(
                                fontSize: 16,
                                fontWeight: FontWeight.w400,
                                color: const Color(0xFFB2BEC3),
                              ),
                        child: Text('$value'),
                      ),
                    );
                  },
                ),
              ),
              // Top fade
              Positioned(
                top: 0,
                left: 0,
                right: 0,
                height: 70,
                child: IgnorePointer(
                  child: Container(
                    decoration: const BoxDecoration(
                      gradient: LinearGradient(
                        begin: Alignment.topCenter,
                        end: Alignment.bottomCenter,
                        colors: [Color(0xFFFFFFFF), Color(0x00FFFFFF)],
                      ),
                    ),
                  ),
                ),
              ),
              // Bottom fade
              Positioned(
                bottom: 0,
                left: 0,
                right: 0,
                height: 70,
                child: IgnorePointer(
                  child: Container(
                    decoration: const BoxDecoration(
                      gradient: LinearGradient(
                        begin: Alignment.bottomCenter,
                        end: Alignment.topCenter,
                        colors: [Color(0xFFFFFFFF), Color(0x00FFFFFF)],
                      ),
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }
}
