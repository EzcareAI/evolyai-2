import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:sizer/sizer.dart';

import '../../models/onboarding_data.dart';
import '../goal_selection_screen/widgets/onboarding_progress_widget.dart';
import './widgets/silhouette_diagram_widget.dart';
import './widgets/requirement_item_widget.dart';
import '../../routes/app_routes.dart';

class CameraInstructionsScreen extends StatefulWidget {
  final OnboardingData? onboardingData;

  const CameraInstructionsScreen({super.key, this.onboardingData});

  @override
  State<CameraInstructionsScreen> createState() =>
      _CameraInstructionsScreenState();
}

class _CameraInstructionsScreenState extends State<CameraInstructionsScreen>
    with SingleTickerProviderStateMixin {
  late AnimationController _entryController;
  late Animation<double> _fadeAnimation;
  late Animation<Offset> _slideAnimation;

  final List<Map<String, dynamic>> _requirements = [
    {
      'icon': Icons.wb_sunny_rounded,
      'title': 'Good lighting',
      'description': 'Stand in a well-lit area, facing a light source',
      'color': const Color(0xFFF39C12),
    },
    {
      'icon': Icons.accessibility_new_rounded,
      'title': 'Tight-fitting clothes',
      'description': 'Wear form-fitting clothes for accurate measurements',
      'color': const Color(0xFF6C5CE7),
    },
    {
      'icon': Icons.self_improvement_rounded,
      'title': 'Neutral posture',
      'description': 'Stand tall, arms slightly away from body',
      'color': const Color(0xFF00B894),
    },
    {
      'icon': Icons.person_rounded,
      'title': 'Body fully visible',
      'description': 'Ensure head to toe is within the camera frame',
      'color': const Color(0xFF0984E3),
    },
  ];

  @override
  void initState() {
    super.initState();
    _entryController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 600),
    )..forward();
    _fadeAnimation = CurvedAnimation(
      parent: _entryController,
      curve: Curves.easeOut,
    );
    _slideAnimation =
        Tween<Offset>(begin: const Offset(0.05, 0), end: Offset.zero).animate(
          CurvedAnimation(parent: _entryController, curve: Curves.easeOutCubic),
        );
  }

  @override
  void dispose() {
    _entryController.dispose();
    super.dispose();
  }

  void _onTakePhotos() {
    HapticFeedback.mediumImpact();
    Navigator.of(
      context,
    ).pushNamed(AppRoutes.cameraCapture, arguments: widget.onboardingData);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: SafeArea(
        child: FadeTransition(
          opacity: _fadeAnimation,
          child: SlideTransition(
            position: _slideAnimation,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Padding(
                  padding: EdgeInsets.symmetric(horizontal: 4.w, vertical: 2.h),
                  child: _buildHeader(),
                ),
                Expanded(
                  child: SingleChildScrollView(
                    padding: EdgeInsets.symmetric(horizontal: 4.w),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        _buildTitleSection(),
                        SizedBox(height: 2.h),
                        const SilhouetteDiagramWidget(),
                        SizedBox(height: 2.h),
                        _buildRequirementsSection(),
                        SizedBox(height: 4.h),
                      ],
                    ),
                  ),
                ),
                Padding(
                  padding: EdgeInsets.fromLTRB(4.w, 1.h, 4.w, 3.h),
                  child: _buildTakePhotosButton(),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildHeader() {
    final isStandalone = widget.onboardingData?.standaloneMode ?? false;
    return Row(
      children: [
        GestureDetector(
          onTap: () {
            HapticFeedback.lightImpact();
            Navigator.of(context).pop();
          },
          child: Container(
            width: 10.w,
            height: 10.w,
            decoration: BoxDecoration(
              color: const Color(0xFFF8F9FA),
              borderRadius: BorderRadius.circular(12.0),
              border: Border.all(color: const Color(0xFFE2E8F0)),
            ),
            child: const Icon(
              Icons.arrow_back_ios_new_rounded,
              color: Color(0xFF1B365D),
              size: 18,
            ),
          ),
        ),
        if (!isStandalone) ...[
          SizedBox(width: 3.w),
          Expanded(
            child: OnboardingProgressWidget(currentStep: 14, totalSteps: 16),
          ),
        ],
      ],
    );
  }

  Widget _buildTitleSection() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        ShaderMask(
          shaderCallback: (bounds) => const LinearGradient(
            colors: [Color(0xFF1B365D), Color(0xFF6C5CE7)],
            begin: Alignment.centerLeft,
            end: Alignment.centerRight,
          ).createShader(bounds),
          child: Text(
            'Photo Instructions',
            style: GoogleFonts.plusJakartaSans(
              fontSize: 20.sp > 28 ? 28 : 20.sp,
              fontWeight: FontWeight.w800,
              color: Colors.white,
              height: 1.2,
            ),
          ),
        ),
        SizedBox(height: 0.8.h),
        Text(
          'Accurate positioning ensures the most precise body composition results.',
          style: GoogleFonts.plusJakartaSans(
            fontSize: 12.sp > 15 ? 15 : 12.sp,
            fontWeight: FontWeight.w400,
            color: const Color(0xFF636E72),
            height: 1.5,
          ),
        ),
      ],
    );
  }

  Widget _buildRequirementsSection() {
    return Container(
      padding: EdgeInsets.all(4.w),
      decoration: BoxDecoration(
        color: const Color(0xFFFAFAFF),
        borderRadius: BorderRadius.circular(16.0),
        border: Border.all(color: const Color(0xFFE2E8F0)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'Requirements',
            style: GoogleFonts.plusJakartaSans(
              fontSize: 13.sp > 16 ? 16 : 13.sp,
              fontWeight: FontWeight.w700,
              color: const Color(0xFF1B365D),
            ),
          ),
          SizedBox(height: 1.5.h),
          ...List.generate(_requirements.length, (index) {
            final req = _requirements[index];
            return Column(
              children: [
                RequirementItemWidget(
                  icon: req['icon'] as IconData,
                  title: req['title'] as String,
                  description: req['description'] as String,
                  iconColor: req['color'] as Color,
                ),
                if (index < _requirements.length - 1)
                  Padding(
                    padding: EdgeInsets.symmetric(vertical: 1.h),
                    child: Divider(color: const Color(0xFFE2E8F0), height: 1),
                  ),
              ],
            );
          }),
        ],
      ),
    );
  }

  Widget _buildTakePhotosButton() {
    return SizedBox(
      width: double.infinity,
      height: 6.5.h,
      child: DecoratedBox(
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(16.0),
          gradient: const LinearGradient(
            colors: [Color(0xFF6C5CE7), Color(0xFF8B5CF6)],
            begin: Alignment.centerLeft,
            end: Alignment.centerRight,
          ),
          boxShadow: [
            BoxShadow(
              color: const Color(0xFF6C5CE7).withValues(alpha: 0.4),
              blurRadius: 16,
              offset: const Offset(0, 6),
            ),
          ],
        ),
        child: ElevatedButton.icon(
          onPressed: _onTakePhotos,
          icon: const Icon(
            Icons.camera_alt_rounded,
            color: Colors.white,
            size: 20,
          ),
          label: Text(
            'Take Photos',
            style: GoogleFonts.plusJakartaSans(
              fontSize: 14.sp > 17 ? 17 : 14.sp,
              fontWeight: FontWeight.w700,
              color: Colors.white,
              letterSpacing: 0.3,
            ),
          ),
          style: ElevatedButton.styleFrom(
            backgroundColor: Colors.transparent,
            shadowColor: Colors.transparent,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(16.0),
            ),
          ),
        ),
      ),
    );
  }
}
