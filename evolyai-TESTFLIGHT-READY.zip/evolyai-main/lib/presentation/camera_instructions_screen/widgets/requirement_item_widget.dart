import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:sizer/sizer.dart';

class RequirementItemWidget extends StatelessWidget {
  final IconData icon;
  final String title;
  final String description;
  final Color iconColor;

  const RequirementItemWidget({
    super.key,
    required this.icon,
    required this.title,
    required this.description,
    required this.iconColor,
  });

  @override
  Widget build(BuildContext context) {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Container(
          width: 10.w,
          height: 10.w,
          decoration: BoxDecoration(
            color: iconColor.withValues(alpha: 0.12),
            borderRadius: BorderRadius.circular(10.0),
          ),
          child: Icon(icon, color: iconColor, size: 18),
        ),
        SizedBox(width: 3.w),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                title,
                style: GoogleFonts.plusJakartaSans(
                  fontSize: 12.sp > 15 ? 15 : 12.sp,
                  fontWeight: FontWeight.w700,
                  color: const Color(0xFF1B365D),
                ),
              ),
              SizedBox(height: 0.3.h),
              Text(
                description,
                style: GoogleFonts.plusJakartaSans(
                  fontSize: 10.sp > 12 ? 12 : 10.sp,
                  fontWeight: FontWeight.w400,
                  color: const Color(0xFF636E72),
                  height: 1.4,
                ),
              ),
            ],
          ),
        ),
        const Icon(
          Icons.check_circle_rounded,
          color: Color(0xFF6C5CE7),
          size: 20,
        ),
      ],
    );
  }
}
