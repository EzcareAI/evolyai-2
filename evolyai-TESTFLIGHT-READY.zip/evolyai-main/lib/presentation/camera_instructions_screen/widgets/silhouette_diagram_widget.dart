import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:sizer/sizer.dart';

class SilhouetteDiagramWidget extends StatefulWidget {
  const SilhouetteDiagramWidget({super.key});

  @override
  State<SilhouetteDiagramWidget> createState() =>
      _SilhouetteDiagramWidgetState();
}

class _SilhouetteDiagramWidgetState extends State<SilhouetteDiagramWidget>
    with SingleTickerProviderStateMixin {
  late AnimationController _pulseController;
  late Animation<double> _pulseAnimation;

  @override
  void initState() {
    super.initState();
    _pulseController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1800),
    )..repeat(reverse: true);
    _pulseAnimation = Tween<double>(begin: 0.85, end: 1.0).animate(
      CurvedAnimation(parent: _pulseController, curve: Curves.easeInOut),
    );
  }

  @override
  void dispose() {
    _pulseController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: EdgeInsets.all(3.w),
      decoration: BoxDecoration(
        color: const Color(0xFFF8F7FF),
        borderRadius: BorderRadius.circular(20.0),
        border: Border.all(color: const Color(0xFFE2E8F0)),
      ),
      child: Row(
        children: [
          Expanded(child: _buildPanel('Front View', _buildFrontSilhouette())),
          SizedBox(width: 2.w),
          Container(width: 1, height: 25.h, color: const Color(0xFFE2E8F0)),
          SizedBox(width: 2.w),
          Expanded(child: _buildPanel('Side View', _buildSideSilhouette())),
        ],
      ),
    );
  }

  Widget _buildPanel(String label, Widget silhouette) {
    return Column(
      children: [
        Container(
          padding: EdgeInsets.symmetric(horizontal: 3.w, vertical: 0.5.h),
          decoration: BoxDecoration(
            color: const Color(0xFF6C5CE7).withValues(alpha: 0.1),
            borderRadius: BorderRadius.circular(8.0),
          ),
          child: Text(
            label,
            style: GoogleFonts.plusJakartaSans(
              fontSize: 10.sp > 12 ? 12 : 10.sp,
              fontWeight: FontWeight.w700,
              color: const Color(0xFF6C5CE7),
            ),
          ),
        ),
        SizedBox(height: 1.h),
        silhouette,
      ],
    );
  }

  Widget _buildFrontSilhouette() {
    return AnimatedBuilder(
      animation: _pulseAnimation,
      builder: (context, child) {
        return Stack(
          alignment: Alignment.center,
          children: [
            CustomPaint(
              size: Size(20.w, 22.h),
              painter: _FrontSilhouettePainter(opacity: _pulseAnimation.value),
            ),
            // Left annotation - arms out
            Positioned(left: 0, top: 6.h, child: _buildAnnotation('Arms\nout')),
            // Right annotation - feet apart
            Positioned(
              right: 0,
              bottom: 2.h,
              child: _buildAnnotation('Hip\nwidth'),
            ),
          ],
        );
      },
    );
  }

  Widget _buildSideSilhouette() {
    return AnimatedBuilder(
      animation: _pulseAnimation,
      builder: (context, child) {
        return Stack(
          alignment: Alignment.center,
          children: [
            CustomPaint(
              size: Size(20.w, 22.h),
              painter: _SideSilhouettePainter(opacity: _pulseAnimation.value),
            ),
            // Top annotation - straight posture
            Positioned(
              right: 0,
              top: 1.h,
              child: _buildAnnotation('Stand\nstraight'),
            ),
            // Bottom annotation - feet together
            Positioned(
              right: 0,
              bottom: 2.h,
              child: _buildAnnotation('Feet\ntogether'),
            ),
          ],
        );
      },
    );
  }

  Widget _buildAnnotation(String text) {
    return Container(
      padding: EdgeInsets.symmetric(horizontal: 1.5.w, vertical: 0.4.h),
      decoration: BoxDecoration(
        color: const Color(0xFF6C5CE7),
        borderRadius: BorderRadius.circular(6.0),
        boxShadow: [
          BoxShadow(
            color: const Color(0xFF6C5CE7).withValues(alpha: 0.3),
            blurRadius: 6,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: Text(
        text,
        textAlign: TextAlign.center,
        style: GoogleFonts.plusJakartaSans(
          fontSize: 8.sp > 9 ? 9 : 8.sp,
          fontWeight: FontWeight.w600,
          color: Colors.white,
          height: 1.2,
        ),
      ),
    );
  }
}

class _FrontSilhouettePainter extends CustomPainter {
  final double opacity;
  _FrontSilhouettePainter({required this.opacity});

  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = const Color(0xFF4ECDC4).withValues(alpha: opacity * 0.85)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 2.5
      ..strokeCap = StrokeCap.round
      ..strokeJoin = StrokeJoin.round;

    final fillPaint = Paint()
      ..color = const Color(0xFF4ECDC4).withValues(alpha: opacity * 0.12)
      ..style = PaintingStyle.fill;

    final cx = size.width / 2;

    // Head
    final headRadius = size.width * 0.13;
    final headCenter = Offset(cx, size.height * 0.08);
    canvas.drawCircle(headCenter, headRadius, fillPaint);
    canvas.drawCircle(headCenter, headRadius, paint);

    // Neck
    canvas.drawLine(
      Offset(cx - size.width * 0.04, size.height * 0.14),
      Offset(cx - size.width * 0.04, size.height * 0.19),
      paint,
    );
    canvas.drawLine(
      Offset(cx + size.width * 0.04, size.height * 0.14),
      Offset(cx + size.width * 0.04, size.height * 0.19),
      paint,
    );

    // Torso
    final torsoPath = Path()
      ..moveTo(cx - size.width * 0.18, size.height * 0.19)
      ..lineTo(cx + size.width * 0.18, size.height * 0.19)
      ..lineTo(cx + size.width * 0.14, size.height * 0.52)
      ..lineTo(cx - size.width * 0.14, size.height * 0.52)
      ..close();
    canvas.drawPath(torsoPath, fillPaint);
    canvas.drawPath(torsoPath, paint);

    // Left arm
    canvas.drawLine(
      Offset(cx - size.width * 0.18, size.height * 0.22),
      Offset(cx - size.width * 0.38, size.height * 0.42),
      paint,
    );
    canvas.drawLine(
      Offset(cx - size.width * 0.38, size.height * 0.42),
      Offset(cx - size.width * 0.36, size.height * 0.56),
      paint,
    );

    // Right arm
    canvas.drawLine(
      Offset(cx + size.width * 0.18, size.height * 0.22),
      Offset(cx + size.width * 0.38, size.height * 0.42),
      paint,
    );
    canvas.drawLine(
      Offset(cx + size.width * 0.38, size.height * 0.42),
      Offset(cx + size.width * 0.36, size.height * 0.56),
      paint,
    );

    // Left leg
    canvas.drawLine(
      Offset(cx - size.width * 0.08, size.height * 0.52),
      Offset(cx - size.width * 0.12, size.height * 0.76),
      paint,
    );
    canvas.drawLine(
      Offset(cx - size.width * 0.12, size.height * 0.76),
      Offset(cx - size.width * 0.14, size.height * 0.98),
      paint,
    );

    // Right leg
    canvas.drawLine(
      Offset(cx + size.width * 0.08, size.height * 0.52),
      Offset(cx + size.width * 0.12, size.height * 0.76),
      paint,
    );
    canvas.drawLine(
      Offset(cx + size.width * 0.12, size.height * 0.76),
      Offset(cx + size.width * 0.14, size.height * 0.98),
      paint,
    );
  }

  @override
  bool shouldRepaint(_FrontSilhouettePainter old) => old.opacity != opacity;
}

class _SideSilhouettePainter extends CustomPainter {
  final double opacity;
  _SideSilhouettePainter({required this.opacity});

  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = const Color(0xFF4ECDC4).withValues(alpha: opacity * 0.85)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 2.5
      ..strokeCap = StrokeCap.round
      ..strokeJoin = StrokeJoin.round;

    final fillPaint = Paint()
      ..color = const Color(0xFF4ECDC4).withValues(alpha: opacity * 0.12)
      ..style = PaintingStyle.fill;

    final cx = size.width / 2;

    // Head
    final headRadius = size.width * 0.12;
    final headCenter = Offset(cx + size.width * 0.02, size.height * 0.08);
    canvas.drawCircle(headCenter, headRadius, fillPaint);
    canvas.drawCircle(headCenter, headRadius, paint);

    // Neck
    canvas.drawLine(
      Offset(cx, size.height * 0.14),
      Offset(cx, size.height * 0.19),
      paint,
    );

    // Torso (slight S-curve for side view)
    final torsoPath = Path()
      ..moveTo(cx - size.width * 0.08, size.height * 0.19)
      ..cubicTo(
        cx + size.width * 0.12,
        size.height * 0.25,
        cx + size.width * 0.10,
        size.height * 0.38,
        cx + size.width * 0.06,
        size.height * 0.52,
      )
      ..lineTo(cx - size.width * 0.06, size.height * 0.52)
      ..cubicTo(
        cx - size.width * 0.10,
        size.height * 0.38,
        cx - size.width * 0.12,
        size.height * 0.25,
        cx - size.width * 0.08,
        size.height * 0.19,
      )
      ..close();
    canvas.drawPath(torsoPath, fillPaint);
    canvas.drawPath(torsoPath, paint);

    // Arm (side view - slightly forward)
    canvas.drawLine(
      Offset(cx - size.width * 0.06, size.height * 0.22),
      Offset(cx - size.width * 0.10, size.height * 0.42),
      paint,
    );
    canvas.drawLine(
      Offset(cx - size.width * 0.10, size.height * 0.42),
      Offset(cx - size.width * 0.08, size.height * 0.56),
      paint,
    );

    // Legs (side view)
    canvas.drawLine(
      Offset(cx, size.height * 0.52),
      Offset(cx + size.width * 0.02, size.height * 0.76),
      paint,
    );
    canvas.drawLine(
      Offset(cx + size.width * 0.02, size.height * 0.76),
      Offset(cx + size.width * 0.04, size.height * 0.98),
      paint,
    );
    canvas.drawLine(
      Offset(cx - size.width * 0.02, size.height * 0.52),
      Offset(cx - size.width * 0.04, size.height * 0.76),
      paint,
    );
    canvas.drawLine(
      Offset(cx - size.width * 0.04, size.height * 0.76),
      Offset(cx - size.width * 0.02, size.height * 0.98),
      paint,
    );
  }

  @override
  bool shouldRepaint(_SideSilhouettePainter old) => old.opacity != opacity;
}
