import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:sizer/sizer.dart';

import '../../models/onboarding_data.dart';
import '../goal_selection_screen/widgets/onboarding_progress_widget.dart';
import './widgets/motivation_card_widget.dart';
import '../../routes/app_routes.dart';

class MotivationScreen extends StatefulWidget {
  final OnboardingData? onboardingData;

  const MotivationScreen({super.key, this.onboardingData});

  @override
  State<MotivationScreen> createState() => _MotivationScreenState();
}

class _MotivationScreenState extends State<MotivationScreen>
    with SingleTickerProviderStateMixin {
  String? _selectedMotivation;

  late AnimationController _entryController;
  late Animation<double> _fadeAnimation;
  late Animation<Offset> _slideAnimation;

  final List<Map<String, String>> _motivationOptions = [
    {
      'id': 'look_better',
      'title': 'Look better',
      'subtitle': 'Improve my appearance and feel confident',
      'emoji': '🪞',
    },
    {
      'id': 'lose_weight',
      'title': 'Lose weight',
      'subtitle': 'Reduce body fat and reach my ideal weight',
      'emoji': '⚖️',
    },
    {
      'id': 'track_fitness',
      'title': 'Track fitness',
      'subtitle': 'Monitor progress and hit performance goals',
      'emoji': '📊',
    },
    {
      'id': 'curiosity',
      'title': 'Curiosity',
      'subtitle': 'Explore what AI body scanning can do',
      'emoji': '💡',
    },
  ];

  @override
  void initState() {
    super.initState();
    _selectedMotivation = widget.onboardingData?.motivation;
    _entryController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 600),
    )..forward();
    _fadeAnimation = CurvedAnimation(
      parent: _entryController,
      curve: Curves.easeOut,
    );
    _slideAnimation =
        Tween<Offset>(begin: const Offset(0.05, 0), end: Offset.zero).animate(
          CurvedAnimation(parent: _entryController, curve: Curves.easeOutCubic),
        );
  }

  @override
  void dispose() {
    _entryController.dispose();
    super.dispose();
  }

  void _onContinue() {
    if (_selectedMotivation == null) return;
    HapticFeedback.mediumImpact();
    final data = (widget.onboardingData ?? OnboardingData()).copyWith(
      motivation: _selectedMotivation,
    );
    Navigator.of(context).pushNamed(AppRoutes.socialProof, arguments: data);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: SafeArea(
        child: FadeTransition(
          opacity: _fadeAnimation,
          child: SlideTransition(
            position: _slideAnimation,
            child: Padding(
              padding: EdgeInsets.symmetric(horizontal: 4.w, vertical: 2.h),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  _buildHeader(),
                  SizedBox(height: 3.h),
                  _buildTitleSection(),
                  SizedBox(height: 3.h),
                  Expanded(
                    child: ListView.separated(
                      physics: const BouncingScrollPhysics(),
                      itemCount: _motivationOptions.length,
                      separatorBuilder: (_, __) => SizedBox(height: 1.5.h),
                      itemBuilder: (context, index) {
                        final option = _motivationOptions[index];
                        return MotivationCardWidget(
                          title: option['title']!,
                          subtitle: option['subtitle']!,
                          emoji: option['emoji']!,
                          isSelected: _selectedMotivation == option['id'],
                          onTap: () {
                            setState(() {
                              _selectedMotivation = option['id'];
                            });
                          },
                        );
                      },
                    ),
                  ),
                  SizedBox(height: 2.h),
                  _buildContinueButton(),
                  SizedBox(height: 1.h),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildHeader() {
    return Row(
      children: [
        GestureDetector(
          onTap: () {
            HapticFeedback.lightImpact();
            Navigator.of(context).pop();
          },
          child: Container(
            width: 10.w,
            height: 10.w,
            decoration: BoxDecoration(
              color: const Color(0xFFF8F9FA),
              borderRadius: BorderRadius.circular(12.0),
              border: Border.all(color: const Color(0xFFE2E8F0)),
            ),
            child: const Icon(
              Icons.arrow_back_ios_new_rounded,
              color: Color(0xFF1B365D),
              size: 18,
            ),
          ),
        ),
        SizedBox(width: 3.w),
        Expanded(
          child: OnboardingProgressWidget(currentStep: 9, totalSteps: 16),
        ),
      ],
    );
  }

  Widget _buildTitleSection() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        ShaderMask(
          shaderCallback: (bounds) => const LinearGradient(
            colors: [Color(0xFF1B365D), Color(0xFF6C5CE7)],
            begin: Alignment.centerLeft,
            end: Alignment.centerRight,
          ).createShader(bounds),
          child: Text(
            'What motivates you?',
            style: GoogleFonts.plusJakartaSans(
              fontSize: 20.sp > 28 ? 28 : 20.sp,
              fontWeight: FontWeight.w800,
              color: Colors.white,
              height: 1.2,
            ),
          ),
        ),
        SizedBox(height: 1.h),
        Text(
          'We\'ll personalize your experience to keep you on track and inspired.',
          style: GoogleFonts.plusJakartaSans(
            fontSize: 12.sp > 15 ? 15 : 12.sp,
            fontWeight: FontWeight.w400,
            color: const Color(0xFF636E72),
            height: 1.5,
          ),
        ),
      ],
    );
  }

  Widget _buildContinueButton() {
    final isEnabled = _selectedMotivation != null;
    return SizedBox(
      width: double.infinity,
      height: 6.5.h,
      child: AnimatedOpacity(
        opacity: isEnabled ? 1.0 : 0.5,
        duration: const Duration(milliseconds: 200),
        child: DecoratedBox(
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(16.0),
            gradient: isEnabled
                ? const LinearGradient(
                    colors: [Color(0xFF6C5CE7), Color(0xFF8B5CF6)],
                    begin: Alignment.centerLeft,
                    end: Alignment.centerRight,
                  )
                : const LinearGradient(
                    colors: [Color(0xFFB2AECF), Color(0xFFB2AECF)],
                  ),
            boxShadow: isEnabled
                ? [
                    BoxShadow(
                      color: const Color(0xFF6C5CE7).withValues(alpha: 0.4),
                      blurRadius: 16,
                      offset: const Offset(0, 6),
                    ),
                  ]
                : [],
          ),
          child: ElevatedButton(
            onPressed: isEnabled ? _onContinue : null,
            style: ElevatedButton.styleFrom(
              backgroundColor: Colors.transparent,
              disabledBackgroundColor: Colors.transparent,
              shadowColor: Colors.transparent,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(16.0),
              ),
            ),
            child: Text(
              'Continue',
              style: GoogleFonts.plusJakartaSans(
                fontSize: 14.sp > 17 ? 17 : 14.sp,
                fontWeight: FontWeight.w700,
                color: Colors.white,
                letterSpacing: 0.3,
              ),
            ),
          ),
        ),
      ),
    );
  }
}
