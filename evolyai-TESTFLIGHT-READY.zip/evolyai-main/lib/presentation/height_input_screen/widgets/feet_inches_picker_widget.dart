import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:sizer/sizer.dart';

class FeetInchesPicker extends StatefulWidget {
  final int selectedFeet;
  final int selectedInches;
  final ValueChanged<int> onFeetChanged;
  final ValueChanged<int> onInchesChanged;

  const FeetInchesPicker({
    super.key,
    required this.selectedFeet,
    required this.selectedInches,
    required this.onFeetChanged,
    required this.onInchesChanged,
  });

  @override
  State<FeetInchesPicker> createState() => _FeetInchesPickerState();
}

class _FeetInchesPickerState extends State<FeetInchesPicker> {
  late FixedExtentScrollController _feetController;
  late FixedExtentScrollController _inchesController;

  static const int _minFeet = 3;
  static const int _maxFeet = 8;
  static const int _minInches = 0;
  static const int _maxInches = 11;

  @override
  void initState() {
    super.initState();
    _feetController = FixedExtentScrollController(
      initialItem: widget.selectedFeet.clamp(_minFeet, _maxFeet) - _minFeet,
    );
    _inchesController = FixedExtentScrollController(
      initialItem: widget.selectedInches.clamp(_minInches, _maxInches),
    );
  }

  @override
  void dispose() {
    _feetController.dispose();
    _inchesController.dispose();
    super.dispose();
  }

  Widget _buildPickerColumn({
    required FixedExtentScrollController controller,
    required int count,
    required int offset,
    required int selectedValue,
    required ValueChanged<int> onChanged,
    required String label,
    required IconData icon,
  }) {
    const double itemExtent = 52.0;
    const double pickerHeight = 240.0;

    return Expanded(
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(icon, size: 14, color: const Color(0xFF6C5CE7)),
              const SizedBox(width: 4),
              Text(
                label,
                style: GoogleFonts.plusJakartaSans(
                  fontSize: 12,
                  fontWeight: FontWeight.w600,
                  color: const Color(0xFF636E72),
                ),
              ),
            ],
          ),
          const SizedBox(height: 10),
          SizedBox(
            height: pickerHeight,
            child: Stack(
              alignment: Alignment.center,
              children: [
                // Selection highlight
                Container(
                  height: itemExtent,
                  margin: EdgeInsets.symmetric(horizontal: 2.w),
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(14.0),
                    gradient: const LinearGradient(
                      colors: [Color(0xFFF0EDFF), Color(0xFFE8F4FF)],
                      begin: Alignment.centerLeft,
                      end: Alignment.centerRight,
                    ),
                    border: Border.all(
                      color: const Color(0xFF6C5CE7).withValues(alpha: 0.25),
                      width: 1.5,
                    ),
                  ),
                ),
                // Picker
                ListWheelScrollView.useDelegate(
                  controller: controller,
                  itemExtent: itemExtent,
                  perspective: 0.001,
                  diameterRatio: 4.0,
                  overAndUnderCenterOpacity: 1.0,
                  physics: const BouncingScrollPhysics(),
                  onSelectedItemChanged: (index) {
                    HapticFeedback.selectionClick();
                    onChanged(index + offset);
                  },
                  childDelegate: ListWheelChildBuilderDelegate(
                    childCount: count,
                    builder: (context, index) {
                      final value = index + offset;
                      final isSelected = value == selectedValue;
                      return Center(
                        child: AnimatedDefaultTextStyle(
                          duration: const Duration(milliseconds: 150),
                          style: isSelected
                              ? GoogleFonts.plusJakartaSans(
                                  fontSize: 22,
                                  fontWeight: FontWeight.w800,
                                  color: const Color(0xFF6C5CE7),
                                )
                              : GoogleFonts.plusJakartaSans(
                                  fontSize: 16,
                                  fontWeight: FontWeight.w400,
                                  color: const Color(0xFFB2BEC3),
                                ),
                          child: Text('$value'),
                        ),
                      );
                    },
                  ),
                ),
                // Top fade
                Positioned(
                  top: 0,
                  left: 0,
                  right: 0,
                  height: 70,
                  child: IgnorePointer(
                    child: Container(
                      decoration: const BoxDecoration(
                        gradient: LinearGradient(
                          begin: Alignment.topCenter,
                          end: Alignment.bottomCenter,
                          colors: [Color(0xFFFFFFFF), Color(0x00FFFFFF)],
                        ),
                      ),
                    ),
                  ),
                ),
                // Bottom fade
                Positioned(
                  bottom: 0,
                  left: 0,
                  right: 0,
                  height: 70,
                  child: IgnorePointer(
                    child: Container(
                      decoration: const BoxDecoration(
                        gradient: LinearGradient(
                          begin: Alignment.bottomCenter,
                          end: Alignment.topCenter,
                          colors: [Color(0xFFFFFFFF), Color(0x00FFFFFF)],
                        ),
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        _buildPickerColumn(
          controller: _feetController,
          count: _maxFeet - _minFeet + 1,
          offset: _minFeet,
          selectedValue: widget.selectedFeet,
          onChanged: widget.onFeetChanged,
          label: 'Feet (ft)',
          icon: Icons.height_outlined,
        ),
        SizedBox(width: 2.w),
        _buildPickerColumn(
          controller: _inchesController,
          count: _maxInches - _minInches + 1,
          offset: _minInches,
          selectedValue: widget.selectedInches,
          onChanged: widget.onInchesChanged,
          label: 'Inches (in)',
          icon: Icons.straighten_outlined,
        ),
      ],
    );
  }
}
