import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:sizer/sizer.dart';

class CmPickerWidget extends StatefulWidget {
  final int selectedCm;
  final ValueChanged<int> onCmChanged;

  const CmPickerWidget({
    super.key,
    required this.selectedCm,
    required this.onCmChanged,
  });

  @override
  State<CmPickerWidget> createState() => _CmPickerWidgetState();
}

class _CmPickerWidgetState extends State<CmPickerWidget> {
  late FixedExtentScrollController _scrollController;
  static const int _minCm = 100;
  static const int _maxCm = 250;

  @override
  void initState() {
    super.initState();
    final initialIndex = widget.selectedCm.clamp(_minCm, _maxCm) - _minCm;
    _scrollController = FixedExtentScrollController(initialItem: initialIndex);
  }

  @override
  void didUpdateWidget(CmPickerWidget oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (oldWidget.selectedCm != widget.selectedCm) {
      final index = widget.selectedCm.clamp(_minCm, _maxCm) - _minCm;
      WidgetsBinding.instance.addPostFrameCallback((_) {
        if (_scrollController.hasClients) {
          _scrollController.jumpToItem(index);
        }
      });
    }
  }

  @override
  void dispose() {
    _scrollController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    const double itemExtent = 52.0;
    const double pickerHeight = 240.0;

    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Icon(
              Icons.height_outlined,
              size: 16,
              color: Color(0xFF6C5CE7),
            ),
            const SizedBox(width: 6),
            Text(
              'Height (cm)',
              style: GoogleFonts.plusJakartaSans(
                fontSize: 13,
                fontWeight: FontWeight.w600,
                color: const Color(0xFF636E72),
              ),
            ),
          ],
        ),
        const SizedBox(height: 12),
        SizedBox(
          height: pickerHeight,
          child: Stack(
            alignment: Alignment.center,
            children: [
              // Selection highlight
              Container(
                height: itemExtent,
                margin: EdgeInsets.symmetric(horizontal: 8.w),
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(14.0),
                  gradient: const LinearGradient(
                    colors: [Color(0xFFF0EDFF), Color(0xFFE8F4FF)],
                    begin: Alignment.centerLeft,
                    end: Alignment.centerRight,
                  ),
                  border: Border.all(
                    color: const Color(0xFF6C5CE7).withValues(alpha: 0.25),
                    width: 1.5,
                  ),
                ),
              ),
              // Picker
              ListWheelScrollView.useDelegate(
                controller: _scrollController,
                itemExtent: itemExtent,
                perspective: 0.001,
                diameterRatio: 4.0,
                overAndUnderCenterOpacity: 1.0,
                physics: const BouncingScrollPhysics(),
                onSelectedItemChanged: (index) {
                  HapticFeedback.selectionClick();
                  widget.onCmChanged(index + _minCm);
                },
                childDelegate: ListWheelChildBuilderDelegate(
                  childCount: _maxCm - _minCm + 1,
                  builder: (context, index) {
                    final cm = index + _minCm;
                    final isSelected = cm == widget.selectedCm;
                    return Center(
                      child: AnimatedDefaultTextStyle(
                        duration: const Duration(milliseconds: 150),
                        style: isSelected
                            ? GoogleFonts.plusJakartaSans(
                                fontSize: 22,
                                fontWeight: FontWeight.w800,
                                color: const Color(0xFF6C5CE7),
                              )
                            : GoogleFonts.plusJakartaSans(
                                fontSize: 16,
                                fontWeight: FontWeight.w400,
                                color: const Color(0xFFB2BEC3),
                              ),
                        child: Text('$cm'),
                      ),
                    );
                  },
                ),
              ),
              // Top fade
              Positioned(
                top: 0,
                left: 0,
                right: 0,
                height: 70,
                child: IgnorePointer(
                  child: Container(
                    decoration: const BoxDecoration(
                      gradient: LinearGradient(
                        begin: Alignment.topCenter,
                        end: Alignment.bottomCenter,
                        colors: [Color(0xFFFFFFFF), Color(0x00FFFFFF)],
                      ),
                    ),
                  ),
                ),
              ),
              // Bottom fade
              Positioned(
                bottom: 0,
                left: 0,
                right: 0,
                height: 70,
                child: IgnorePointer(
                  child: Container(
                    decoration: const BoxDecoration(
                      gradient: LinearGradient(
                        begin: Alignment.bottomCenter,
                        end: Alignment.topCenter,
                        colors: [Color(0xFFFFFFFF), Color(0x00FFFFFF)],
                      ),
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }
}
