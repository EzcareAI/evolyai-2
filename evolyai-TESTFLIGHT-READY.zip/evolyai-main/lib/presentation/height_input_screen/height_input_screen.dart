import 'dart:ui';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:sizer/sizer.dart';

import '../../models/onboarding_data.dart';
import '../goal_selection_screen/widgets/onboarding_progress_widget.dart';
import './widgets/height_unit_toggle_widget.dart';
import './widgets/cm_picker_widget.dart';
import './widgets/feet_inches_picker_widget.dart';

class HeightInputScreen extends StatefulWidget {
  final OnboardingData? onboardingData;

  const HeightInputScreen({super.key, this.onboardingData});

  @override
  State<HeightInputScreen> createState() => _HeightInputScreenState();
}

class _HeightInputScreenState extends State<HeightInputScreen>
    with SingleTickerProviderStateMixin {
  late String _selectedUnit;
  int _selectedCm = 170;
  int _selectedFeet = 5;
  int _selectedInches = 7;

  late AnimationController _fadeController;
  late Animation<double> _fadeAnimation;

  @override
  void initState() {
    super.initState();

    // Auto-detect locale for default unit
    final locale = PlatformDispatcher.instance.locale;
    final imperialLocales = ['en_US', 'en_LR', 'en_MM'];
    final isImperial = imperialLocales.any(
      (l) =>
          locale.toString().startsWith(l.split('_')[0]) &&
          locale.countryCode == l.split('_')[1],
    );
    _selectedUnit = isImperial ? 'ft' : 'cm';

    // Restore previous values if available
    if (widget.onboardingData?.heightUnit != null) {
      _selectedUnit = widget.onboardingData!.heightUnit!;
    }
    if (widget.onboardingData?.heightCm != null) {
      _selectedCm = widget.onboardingData!.heightCm!.round();
    }
    if (widget.onboardingData?.heightFeet != null) {
      _selectedFeet = widget.onboardingData!.heightFeet!;
    }
    if (widget.onboardingData?.heightInches != null) {
      _selectedInches = widget.onboardingData!.heightInches!;
    }

    _fadeController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 600),
    )..forward();
    _fadeAnimation = CurvedAnimation(
      parent: _fadeController,
      curve: Curves.easeOut,
    );
  }

  @override
  void dispose() {
    _fadeController.dispose();
    super.dispose();
  }

  double get _heightInCm {
    if (_selectedUnit == 'cm') return _selectedCm.toDouble();
    return (_selectedFeet * 30.48) + (_selectedInches * 2.54);
  }

  bool get _isValidHeight {
    final cm = _heightInCm;
    return cm >= 100 && cm <= 250;
  }

  void _onUnitChanged(String unit) {
    setState(() {
      _selectedUnit = unit;
    });
  }

  void _onContinue() {
    if (!_isValidHeight) return;
    HapticFeedback.mediumImpact();
    final data = (widget.onboardingData ?? OnboardingData()).copyWith(
      heightCm: _heightInCm,
      heightUnit: _selectedUnit,
      heightFeet: _selectedFeet,
      heightInches: _selectedInches,
    );
    Navigator.of(context).pushNamed('/weight-input-screen', arguments: data);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: SafeArea(
        child: FadeTransition(
          opacity: _fadeAnimation,
          child: Padding(
            padding: EdgeInsets.symmetric(horizontal: 4.w, vertical: 2.h),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                _buildHeader(),
                SizedBox(height: 4.h),
                _buildTitleSection(),
                SizedBox(height: 2.h),
                _buildHeightDisplay(),
                SizedBox(height: 2.h),
                Center(
                  child: HeightUnitToggleWidget(
                    selectedUnit: _selectedUnit,
                    onUnitChanged: _onUnitChanged,
                  ),
                ),
                SizedBox(height: 1.5.h),
                Expanded(
                  child: AnimatedSwitcher(
                    duration: const Duration(milliseconds: 300),
                    transitionBuilder: (child, animation) =>
                        FadeTransition(opacity: animation, child: child),
                    child: _selectedUnit == 'cm'
                        ? CmPickerWidget(
                            key: const ValueKey('cm'),
                            selectedCm: _selectedCm,
                            onCmChanged: (val) =>
                                setState(() => _selectedCm = val),
                          )
                        : FeetInchesPicker(
                            key: const ValueKey('ft'),
                            selectedFeet: _selectedFeet,
                            selectedInches: _selectedInches,
                            onFeetChanged: (val) =>
                                setState(() => _selectedFeet = val),
                            onInchesChanged: (val) =>
                                setState(() => _selectedInches = val),
                          ),
                  ),
                ),
                _buildValidationNote(),
                SizedBox(height: 2.h),
                _buildContinueButton(),
                SizedBox(height: 1.h),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildHeader() {
    return Row(
      children: [
        GestureDetector(
          onTap: () => Navigator.of(context).pop(),
          child: Container(
            width: 10.w,
            height: 10.w,
            decoration: BoxDecoration(
              color: const Color(0xFFF8F9FA),
              borderRadius: BorderRadius.circular(12.0),
              border: Border.all(color: const Color(0xFFE2E8F0)),
            ),
            child: const Icon(
              Icons.arrow_back_ios_new_rounded,
              color: Color(0xFF1B365D),
              size: 18,
            ),
          ),
        ),
        SizedBox(width: 3.w),
        Expanded(
          child: OnboardingProgressWidget(currentStep: 5, totalSteps: 8),
        ),
      ],
    );
  }

  Widget _buildTitleSection() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        ShaderMask(
          shaderCallback: (bounds) => const LinearGradient(
            colors: [Color(0xFF1B365D), Color(0xFF6C5CE7)],
            begin: Alignment.centerLeft,
            end: Alignment.centerRight,
          ).createShader(bounds),
          child: Text(
            "What's your height?",
            style: GoogleFonts.plusJakartaSans(
              fontSize: 20.sp > 28 ? 28 : 20.sp,
              fontWeight: FontWeight.w800,
              color: Colors.white,
              height: 1.2,
            ),
          ),
        ),
        SizedBox(height: 1.h),
        Text(
          'Accurate height data improves your body\ncomposition and BMI analysis precision.',
          style: GoogleFonts.plusJakartaSans(
            fontSize: 12.sp > 15 ? 15 : 12.sp,
            fontWeight: FontWeight.w400,
            color: const Color(0xFF636E72),
            height: 1.5,
          ),
        ),
      ],
    );
  }

  Widget _buildHeightDisplay() {
    final displayText = _selectedUnit == 'cm'
        ? '$_selectedCm cm'
        : '$_selectedFeet\' $_selectedInches"';

    return Center(
      child: AnimatedSwitcher(
        duration: const Duration(milliseconds: 200),
        transitionBuilder: (child, animation) =>
            ScaleTransition(scale: animation, child: child),
        child: Container(
          key: ValueKey(displayText),
          padding: EdgeInsets.symmetric(horizontal: 8.w, vertical: 1.5.h),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(20.0),
            gradient: const LinearGradient(
              colors: [Color(0xFF6C5CE7), Color(0xFF74B9FF)],
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
            ),
            boxShadow: [
              BoxShadow(
                color: const Color(0xFF6C5CE7).withValues(alpha: 0.3),
                blurRadius: 20,
                offset: const Offset(0, 8),
              ),
            ],
          ),
          child: Text(
            displayText,
            style: GoogleFonts.plusJakartaSans(
              fontSize: 20.sp > 32 ? 32 : 20.sp,
              fontWeight: FontWeight.w900,
              color: Colors.white,
              letterSpacing: -0.5,
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildValidationNote() {
    return Center(
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          const Icon(
            Icons.info_outline_rounded,
            size: 14,
            color: Color(0xFF636E72),
          ),
          SizedBox(width: 1.w),
          Text(
            'Valid range: 100–250 cm (3\'3" – 8\'2")',
            style: GoogleFonts.plusJakartaSans(
              fontSize: 10.sp > 12 ? 12 : 10.sp,
              fontWeight: FontWeight.w400,
              color: const Color(0xFF636E72),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildContinueButton() {
    return GestureDetector(
      onTap: _isValidHeight ? _onContinue : null,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 200),
        width: double.infinity,
        height: 7.h > 60 ? 60 : 7.h,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(16.0),
          gradient: _isValidHeight
              ? const LinearGradient(
                  colors: [Color(0xFF6C5CE7), Color(0xFF74B9FF)],
                  begin: Alignment.centerLeft,
                  end: Alignment.centerRight,
                )
              : const LinearGradient(
                  colors: [Color(0xFFB2BEC3), Color(0xFFDFE6E9)],
                  begin: Alignment.centerLeft,
                  end: Alignment.centerRight,
                ),
          boxShadow: _isValidHeight
              ? [
                  BoxShadow(
                    color: const Color(0xFF6C5CE7).withValues(alpha: 0.35),
                    blurRadius: 16,
                    offset: const Offset(0, 6),
                  ),
                ]
              : [],
        ),
        child: Center(
          child: Text(
            'Continue',
            style: GoogleFonts.plusJakartaSans(
              fontSize: 14.sp > 17 ? 17 : 14.sp,
              fontWeight: FontWeight.w700,
              color: Colors.white,
            ),
          ),
        ),
      ),
    );
  }
}
