import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:sizer/sizer.dart';

import '../../models/onboarding_data.dart';
import '../goal_selection_screen/widgets/onboarding_progress_widget.dart';

class TargetBodyFatScreen extends StatefulWidget {
  final OnboardingData? onboardingData;

  const TargetBodyFatScreen({super.key, this.onboardingData});

  @override
  State<TargetBodyFatScreen> createState() => _TargetBodyFatScreenState();
}

class _TargetBodyFatScreenState extends State<TargetBodyFatScreen>
    with SingleTickerProviderStateMixin {
  late double _targetBodyFat;
  late AnimationController _fadeController;
  late Animation<double> _fadeAnimation;
  late FixedExtentScrollController _scrollController;

  // 0.5% increments
  static const double _step = 0.5;

  double get _minFat => _isMale ? 6.0 : 14.0;
  double get _maxFat => 35.0;

  int get _itemCount => ((_maxFat - _minFat) / _step).round() + 1;

  double _indexToValue(int index) => _minFat + index * _step;
  int _valueToIndex(double value) =>
      ((value - _minFat) / _step).round().clamp(0, _itemCount - 1);

  bool get _isMale =>
      (widget.onboardingData?.gender?.toLowerCase() ?? 'male') == 'male';

  _FatCategory get _category => _categoryFor(_targetBodyFat);

  @override
  void initState() {
    super.initState();
    final goal = widget.onboardingData?.goal?.toLowerCase() ?? '';
    if (goal.contains('athletic')) {
      _targetBodyFat = _isMale ? 10.0 : 18.0;
    } else if (goal.contains('muscle')) {
      _targetBodyFat = _isMale ? 12.0 : 20.0;
    } else if (goal.contains('lose') || goal.contains('fat')) {
      _targetBodyFat = _isMale ? 15.0 : 22.0;
    } else {
      _targetBodyFat = _isMale ? 15.0 : 22.0;
    }

    if (widget.onboardingData?.targetBodyFatPercent != null) {
      _targetBodyFat = widget.onboardingData!.targetBodyFatPercent!;
    }

    _scrollController = FixedExtentScrollController(
      initialItem: _valueToIndex(_targetBodyFat),
    );

    _fadeController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 600),
    )..forward();
    _fadeAnimation = CurvedAnimation(
      parent: _fadeController,
      curve: Curves.easeOut,
    );
  }

  @override
  void dispose() {
    _fadeController.dispose();
    _scrollController.dispose();
    super.dispose();
  }

  _FatCategory _categoryFor(double fat) {
    if (_isMale) {
      if (fat < 10) {
        return _FatCategory(
          'Essential',
          const Color(0xFF00B4D8),
          Icons.bolt_rounded,
        );
      }
      if (fat < 14) {
        return _FatCategory(
          'Athletic',
          const Color(0xFF6C5CE7),
          Icons.fitness_center_rounded,
        );
      }
      if (fat < 18) {
        return _FatCategory(
          'Fit',
          const Color(0xFF00CEC9),
          Icons.directions_run_rounded,
        );
      }
      if (fat < 25) {
        return _FatCategory(
          'Average',
          const Color(0xFFFDAA5D),
          Icons.person_rounded,
        );
      }
      return _FatCategory(
        'Above Average',
        const Color(0xFFE17055),
        Icons.trending_up_rounded,
      );
    } else {
      if (fat < 18) {
        return _FatCategory(
          'Essential',
          const Color(0xFF00B4D8),
          Icons.bolt_rounded,
        );
      }
      if (fat < 22) {
        return _FatCategory(
          'Athletic',
          const Color(0xFF6C5CE7),
          Icons.fitness_center_rounded,
        );
      }
      if (fat < 26) {
        return _FatCategory(
          'Fit',
          const Color(0xFF00CEC9),
          Icons.directions_run_rounded,
        );
      }
      if (fat < 32) {
        return _FatCategory(
          'Average',
          const Color(0xFFFDAA5D),
          Icons.person_rounded,
        );
      }
      return _FatCategory(
        'Above Average',
        const Color(0xFFE17055),
        Icons.trending_up_rounded,
      );
    }
  }

  void _onContinue() {
    HapticFeedback.mediumImpact();
    final data = (widget.onboardingData ?? OnboardingData()).copyWith(
      targetBodyFatPercent: _targetBodyFat,
    );
    Navigator.of(
      context,
    ).pushNamed('/great-start-dopamine-screen', arguments: data);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: SafeArea(
        child: FadeTransition(
          opacity: _fadeAnimation,
          child: Padding(
            padding: EdgeInsets.symmetric(horizontal: 4.w, vertical: 2.h),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                _buildHeader(),
                SizedBox(height: 3.h),
                _buildTitleSection(),
                SizedBox(height: 2.h),
                _buildValueDisplay(),
                SizedBox(height: 2.h),
                _buildCategoryBadge(),
                SizedBox(height: 2.h),
                _buildWheelPicker(),
                const Spacer(),
                _buildInfoNote(),
                SizedBox(height: 2.h),
                _buildContinueButton(),
                SizedBox(height: 1.h),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildHeader() {
    return Row(
      children: [
        GestureDetector(
          onTap: () => Navigator.of(context).pop(),
          child: Container(
            width: 10.w,
            height: 10.w,
            decoration: BoxDecoration(
              color: const Color(0xFFF8F9FA),
              borderRadius: BorderRadius.circular(12.0),
              border: Border.all(color: const Color(0xFFE2E8F0)),
            ),
            child: const Icon(
              Icons.arrow_back_ios_new_rounded,
              color: Color(0xFF1B365D),
              size: 18,
            ),
          ),
        ),
        SizedBox(width: 3.w),
        Expanded(
          child: OnboardingProgressWidget(currentStep: 7, totalSteps: 8),
        ),
      ],
    );
  }

  Widget _buildTitleSection() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        ShaderMask(
          shaderCallback: (bounds) => const LinearGradient(
            colors: [Color(0xFF1B365D), Color(0xFF6C5CE7)],
            begin: Alignment.centerLeft,
            end: Alignment.centerRight,
          ).createShader(bounds),
          child: Text(
            'What\'s your target\nbody fat?',
            style: GoogleFonts.plusJakartaSans(
              fontSize: 20.sp > 28 ? 28 : 20.sp,
              fontWeight: FontWeight.w800,
              color: Colors.white,
              height: 1.2,
            ),
          ),
        ),
        SizedBox(height: 0.8.h),
        Text(
          'Set a realistic goal. Evoly AI will track your\nprogress toward this target.',
          style: GoogleFonts.plusJakartaSans(
            fontSize: 12.sp > 15 ? 15 : 12.sp,
            fontWeight: FontWeight.w400,
            color: const Color(0xFF636E72),
            height: 1.5,
          ),
        ),
      ],
    );
  }

  Widget _buildValueDisplay() {
    final cat = _category;
    return Center(
      child: AnimatedSwitcher(
        duration: const Duration(milliseconds: 200),
        transitionBuilder: (child, animation) =>
            ScaleTransition(scale: animation, child: child),
        child: Container(
          key: ValueKey((_targetBodyFat * 2).round()),
          padding: EdgeInsets.symmetric(horizontal: 8.w, vertical: 1.5.h),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(24.0),
            gradient: LinearGradient(
              colors: [
                const Color(0xFF6C5CE7),
                cat.color.withValues(alpha: 0.8),
              ],
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
            ),
            boxShadow: [
              BoxShadow(
                color: const Color(0xFF6C5CE7).withValues(alpha: 0.3),
                blurRadius: 24,
                offset: const Offset(0, 10),
              ),
            ],
          ),
          child: Row(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              Text(
                _targetBodyFat.toStringAsFixed(1),
                style: GoogleFonts.plusJakartaSans(
                  fontSize: 22.sp > 38 ? 38 : 22.sp,
                  fontWeight: FontWeight.w900,
                  color: Colors.white,
                  letterSpacing: -1,
                ),
              ),
              Padding(
                padding: const EdgeInsets.only(bottom: 4),
                child: Text(
                  '%',
                  style: GoogleFonts.plusJakartaSans(
                    fontSize: 14.sp > 20 ? 20 : 14.sp,
                    fontWeight: FontWeight.w700,
                    color: Colors.white.withValues(alpha: 0.85),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildCategoryBadge() {
    final cat = _category;
    return Center(
      child: AnimatedSwitcher(
        duration: const Duration(milliseconds: 250),
        transitionBuilder: (child, animation) =>
            FadeTransition(opacity: animation, child: child),
        child: Container(
          key: ValueKey(cat.label),
          padding: EdgeInsets.symmetric(horizontal: 4.w, vertical: 0.8.h),
          decoration: BoxDecoration(
            color: cat.color.withValues(alpha: 0.1),
            borderRadius: BorderRadius.circular(50.0),
            border: Border.all(color: cat.color.withValues(alpha: 0.3)),
          ),
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              Icon(cat.icon, color: cat.color, size: 16),
              SizedBox(width: 1.5.w),
              Text(
                cat.label,
                style: GoogleFonts.plusJakartaSans(
                  fontSize: 11.sp > 14 ? 14 : 11.sp,
                  fontWeight: FontWeight.w700,
                  color: cat.color,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildWheelPicker() {
    const double itemExtent = 52.0;
    const double pickerHeight = 220.0;

    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        // Label above wheel
        Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Icon(
              Icons.percent_rounded,
              size: 16,
              color: Color(0xFF6C5CE7),
            ),
            const SizedBox(width: 6),
            Text(
              'Masse Grasse (%)',
              style: GoogleFonts.plusJakartaSans(
                fontSize: 13,
                fontWeight: FontWeight.w600,
                color: const Color(0xFF636E72),
              ),
            ),
          ],
        ),
        const SizedBox(height: 12),
        SizedBox(
          height: pickerHeight,
          child: Stack(
            alignment: Alignment.center,
            children: [
              // Selection highlight band
              Container(
                height: itemExtent,
                margin: EdgeInsets.symmetric(horizontal: 8.w),
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(14.0),
                  gradient: const LinearGradient(
                    colors: [Color(0xFFF0EDFF), Color(0xFFE8F4FF)],
                    begin: Alignment.centerLeft,
                    end: Alignment.centerRight,
                  ),
                  border: Border.all(
                    color: const Color(0xFF6C5CE7).withValues(alpha: 0.25),
                    width: 1.5,
                  ),
                ),
              ),
              // Wheel picker
              ListWheelScrollView.useDelegate(
                controller: _scrollController,
                itemExtent: itemExtent,
                perspective: 0.001,
                diameterRatio: 4.0,
                overAndUnderCenterOpacity: 1.0,
                physics: const BouncingScrollPhysics(),
                onSelectedItemChanged: (index) {
                  HapticFeedback.selectionClick();
                  setState(() => _targetBodyFat = _indexToValue(index));
                },
                childDelegate: ListWheelChildBuilderDelegate(
                  childCount: _itemCount,
                  builder: (context, index) {
                    final value = _indexToValue(index);
                    final isSelected = (value - _targetBodyFat).abs() < 0.01;
                    return Center(
                      child: AnimatedDefaultTextStyle(
                        duration: const Duration(milliseconds: 150),
                        style: isSelected
                            ? GoogleFonts.plusJakartaSans(
                                fontSize: 22,
                                fontWeight: FontWeight.w800,
                                color: const Color(0xFF6C5CE7),
                              )
                            : GoogleFonts.plusJakartaSans(
                                fontSize: 16,
                                fontWeight: FontWeight.w400,
                                color: const Color(0xFFB2BEC3),
                              ),
                        child: Text(value.toStringAsFixed(1)),
                      ),
                    );
                  },
                ),
              ),
              // Top fade — subtle white
              Positioned(
                top: 0,
                left: 0,
                right: 0,
                height: 70,
                child: IgnorePointer(
                  child: Container(
                    decoration: const BoxDecoration(
                      gradient: LinearGradient(
                        begin: Alignment.topCenter,
                        end: Alignment.bottomCenter,
                        colors: [Color(0xFFFFFFFF), Color(0x00FFFFFF)],
                      ),
                    ),
                  ),
                ),
              ),
              // Bottom fade — subtle white
              Positioned(
                bottom: 0,
                left: 0,
                right: 0,
                height: 70,
                child: IgnorePointer(
                  child: Container(
                    decoration: const BoxDecoration(
                      gradient: LinearGradient(
                        begin: Alignment.bottomCenter,
                        end: Alignment.topCenter,
                        colors: [Color(0xFFFFFFFF), Color(0x00FFFFFF)],
                      ),
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }

  Widget _buildInfoNote() {
    return Container(
      padding: EdgeInsets.symmetric(horizontal: 3.w, vertical: 1.5.h),
      decoration: BoxDecoration(
        color: const Color(0xFFF0EEFF),
        borderRadius: BorderRadius.circular(14.0),
        border: Border.all(
          color: const Color(0xFF6C5CE7).withValues(alpha: 0.2),
        ),
      ),
      child: Row(
        children: [
          const Icon(
            Icons.auto_awesome_rounded,
            color: Color(0xFF6C5CE7),
            size: 18,
          ),
          SizedBox(width: 2.w),
          Expanded(
            child: Text(
              'Evoly AI will personalize your plan and track progress toward this goal.',
              style: GoogleFonts.plusJakartaSans(
                fontSize: 10.sp > 12 ? 12 : 10.sp,
                color: const Color(0xFF6C5CE7),
                fontWeight: FontWeight.w500,
                height: 1.4,
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildContinueButton() {
    return GestureDetector(
      onTap: _onContinue,
      child: Container(
        width: double.infinity,
        height: 7.h > 60 ? 60 : 7.h,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(16.0),
          gradient: const LinearGradient(
            colors: [Color(0xFF6C5CE7), Color(0xFF74B9FF)],
            begin: Alignment.centerLeft,
            end: Alignment.centerRight,
          ),
          boxShadow: [
            BoxShadow(
              color: const Color(0xFF6C5CE7).withValues(alpha: 0.35),
              blurRadius: 16,
              offset: const Offset(0, 6),
            ),
          ],
        ),
        child: Center(
          child: Text(
            'Continue',
            style: GoogleFonts.plusJakartaSans(
              fontSize: 14.sp > 17 ? 17 : 14.sp,
              fontWeight: FontWeight.w700,
              color: Colors.white,
            ),
          ),
        ),
      ),
    );
  }
}

class _FatCategory {
  final String label;
  final Color color;
  final IconData icon;
  const _FatCategory(this.label, this.color, this.icon);
}
