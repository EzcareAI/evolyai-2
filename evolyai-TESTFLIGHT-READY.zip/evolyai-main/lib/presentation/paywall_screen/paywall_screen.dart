import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:sizer/sizer.dart';

import '../../models/onboarding_data.dart';
import '../../routes/app_routes.dart';
import '../../services/supabase_service.dart';
import '../rescan_result_screen/rescan_result_screen.dart';

class PaywallScreen extends StatefulWidget {
  final OnboardingData? onboardingData;

  const PaywallScreen({super.key, this.onboardingData});

  @override
  State<PaywallScreen> createState() => _PaywallScreenState();
}

class _PaywallScreenState extends State<PaywallScreen>
    with TickerProviderStateMixin {
  bool _selectedYearly = true;
  bool _selectedFounders = true; // founders offer selected by default
  bool _isLoading = false;

  // Founders counter — starts at 0 on launch day.
  // Increment _foundersTaken manually (or via RevenueCat webhook) as sales come in.
  static const int _foundersTotal = 300;
  static const int _foundersTaken = 0; // ← UPDATE this daily until RevenueCat live
  int get _foundersLeft => _foundersTotal - _foundersTaken;

  late AnimationController _entryController;
  late AnimationController _pulseController;
  late Animation<double> _fadeAnimation;
  late Animation<Offset> _slideAnimation;
  late Animation<double> _pulseAnimation;

  @override
  void initState() {
    super.initState();
    _entryController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 600),
    )..forward();
    _fadeAnimation = CurvedAnimation(
      parent: _entryController,
      curve: Curves.easeOut,
    );
    _slideAnimation =
        Tween<Offset>(begin: const Offset(0, 0.05), end: Offset.zero).animate(
          CurvedAnimation(parent: _entryController, curve: Curves.easeOutCubic),
        );
    _pulseController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1800),
    )..repeat(reverse: true);
    _pulseAnimation = Tween<double>(begin: 0.97, end: 1.03).animate(
      CurvedAnimation(parent: _pulseController, curve: Curves.easeInOut),
    );
  }

  @override
  void dispose() {
    _entryController.dispose();
    _pulseController.dispose();
    super.dispose();
  }

  Future<bool> _onWillPop() async {
    // Show fallback offer instead of going back
    final result = await Navigator.of(
      context,
    ).pushNamed(AppRoutes.paywallFallback, arguments: widget.onboardingData);
    // If user claimed offer or dismissed, handle accordingly
    return false;
  }

  Future<void> _onSubscribe() async {
    HapticFeedback.mediumImpact();
    setState(() => _isLoading = true);

    String productId;
    if (_selectedYearly && _selectedFounders && _foundersLeft > 0) {
      productId = 'yearly_29_99'; // founders offer
    } else if (_selectedYearly) {
      productId = 'yearly_39_99';
    } else {
      productId = 'weekly_5_99';
    }

    try {
      await SupabaseService.instance.activateSubscription(
        productId: productId,
        provider: 'in_app',
      );
      debugPrint('[Paywall] Subscription activated: $productId');
    } catch (e) {
      debugPrint('[Paywall] Subscription error: $e');
    }

    if (!mounted) return;
    setState(() => _isLoading = false);
    _navigateAfterPaywall();
  }

  void _navigateAfterPaywall() {
    final scanResult = widget.onboardingData?.scanResult;
    if (scanResult != null) {
      // Route through rescan result screen so user sees their completed scan card
      Navigator.of(context).pushNamedAndRemoveUntil(
        AppRoutes.rescanResult,
        (route) => false,
        arguments: RescanResultArgs(
          newResult: scanResult,
          onboardingData: widget.onboardingData,
        ),
      );
    } else {
      Navigator.of(context).pushNamedAndRemoveUntil(
        AppRoutes.homeDashboard,
        (route) => false,
        arguments: widget.onboardingData,
      );
    }
  }

  void _onClose() {
    HapticFeedback.lightImpact();
    Navigator.of(
      context,
    ).pushNamed(AppRoutes.paywallFallback, arguments: widget.onboardingData);
  }

  @override
  Widget build(BuildContext context) {
    return PopScope(
      canPop: false,
      onPopInvokedWithResult: (didPop, result) async {
        if (!didPop) {
          _onClose();
        }
      },
      child: Scaffold(
        backgroundColor: const Color(0xFF0A0A14),
        body: FadeTransition(
          opacity: _fadeAnimation,
          child: SlideTransition(
            position: _slideAnimation,
            child: SafeArea(
              child: Column(
                children: [
                  _buildHeader(),
                  Expanded(
                    child: SingleChildScrollView(
                      padding: EdgeInsets.symmetric(horizontal: 4.w),
                      child: Column(
                        children: [
                          SizedBox(height: 1.h),
                          _buildHeroSection(),
                          SizedBox(height: 2.h),
                          _buildFeaturesList(),
                          SizedBox(height: 2.h),
                          _buildPlanSelector(),
                          SizedBox(height: 2.h),
                          _buildTestimonial(),
                          SizedBox(height: 2.h),
                        ],
                      ),
                    ),
                  ),
                  _buildBottomCTA(),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildHeader() {
    return Padding(
      padding: EdgeInsets.symmetric(horizontal: 4.w, vertical: 1.5.h),
      child: Row(
        children: [
          const Spacer(),
          GestureDetector(
            onTap: _onClose,
            child: Container(
              width: 9.w,
              height: 9.w,
              decoration: BoxDecoration(
                color: Colors.white.withValues(alpha: 0.1),
                shape: BoxShape.circle,
                border: Border.all(color: Colors.white.withValues(alpha: 0.15)),
              ),
              child: Icon(
                Icons.close_rounded,
                color: Colors.white.withValues(alpha: 0.7),
                size: 18,
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildHeroSection() {
    return Column(
      children: [
        AnimatedBuilder(
          animation: _pulseAnimation,
          builder: (context, child) {
            return Transform.scale(
              scale: _pulseAnimation.value,
              child: Container(
                width: 20.w,
                height: 20.w,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  gradient: const LinearGradient(
                    colors: [Color(0xFF6C5CE7), Color(0xFF74B9FF)],
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                  ),
                  boxShadow: [
                    BoxShadow(
                      color: const Color(0xFF6C5CE7).withValues(alpha: 0.5),
                      blurRadius: 30,
                      spreadRadius: 4,
                    ),
                  ],
                ),
                child: const Icon(
                  Icons.auto_awesome_rounded,
                  color: Colors.white,
                  size: 36,
                ),
              ),
            );
          },
        ),
        SizedBox(height: 2.h),
        ShaderMask(
          shaderCallback: (bounds) => const LinearGradient(
            colors: [Color(0xFFFFFFFF), Color(0xFF74B9FF)],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ).createShader(bounds),
          child: Text(
            'Débloquez votre analyse\ncorporelle complète',
            textAlign: TextAlign.center,
            style: GoogleFonts.plusJakartaSans(
              fontSize: 20.sp > 28 ? 28 : 20.sp,
              fontWeight: FontWeight.w800,
              color: Colors.white,
              height: 1.2,
            ),
          ),
        ),
        SizedBox(height: 1.h),
        Text(
          'Découvrez votre composition corporelle réelle\ngrâce à l\'analyse IA par segments',
          textAlign: TextAlign.center,
          style: GoogleFonts.plusJakartaSans(
            fontSize: 11.sp > 14 ? 14 : 11.sp,
            color: Colors.white.withValues(alpha: 0.6),
            height: 1.5,
          ),
        ),
      ],
    );
  }

  Widget _buildFeaturesList() {
    final features = [
      (
        Icons.analytics_rounded,
        'Analyse corporelle complète',
        'Masse grasse, masse maigre, masse grasse',
      ),
      (
        Icons.pie_chart_rounded,
        'Décomposition par zones',
        'Bras, jambes, tronc séparément',
      ),
      (
        Icons.trending_up_rounded,
        'Suivi de progression',
        'Évolution visible scan après scan',
      ),
      (
        Icons.compare_arrows_rounded,
        'Comparaison de scans',
        'Avant/après côte à côte',
      ),
      (
        Icons.description_rounded,
        'Rapports premium',
        'Rapport PDF détaillé de composition',
      ),
      (Icons.lock_open_rounded, 'Scans illimités', 'Scannez aussi souvent que vous voulez'),
    ];

    return Container(
      padding: EdgeInsets.all(4.w),
      decoration: BoxDecoration(
        color: Colors.white.withValues(alpha: 0.05),
        borderRadius: BorderRadius.circular(20.0),
        border: Border.all(color: Colors.white.withValues(alpha: 0.08)),
      ),
      child: Column(
        children: features.map((f) {
          return Padding(
            padding: EdgeInsets.symmetric(vertical: 0.8.h),
            child: Row(
              children: [
                Container(
                  width: 9.w,
                  height: 9.w,
                  decoration: BoxDecoration(
                    color: const Color(0xFF6C5CE7).withValues(alpha: 0.15),
                    borderRadius: BorderRadius.circular(10.0),
                  ),
                  child: Icon(f.$1, color: const Color(0xFF6C5CE7), size: 18),
                ),
                SizedBox(width: 3.w),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        f.$2,
                        style: GoogleFonts.plusJakartaSans(
                          fontSize: 11.sp > 14 ? 14 : 11.sp,
                          fontWeight: FontWeight.w700,
                          color: Colors.white,
                        ),
                      ),
                      Text(
                        f.$3,
                        style: GoogleFonts.plusJakartaSans(
                          fontSize: 9.sp > 11 ? 11 : 9.sp,
                          color: Colors.white.withValues(alpha: 0.5),
                        ),
                      ),
                    ],
                  ),
                ),
                const Icon(
                  Icons.check_circle_rounded,
                  color: Color(0xFF00B894),
                  size: 18,
                ),
              ],
            ),
          );
        }).toList(),
      ),
    );
  }

  Widget _buildPlanSelector() {
    final bool foundersAvailable = _foundersLeft > 0;
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        // ── Founders offer (shown only while stock available) ──
        if (foundersAvailable) ...[
          GestureDetector(
            onTap: () {
              HapticFeedback.selectionClick();
              setState(() {
                _selectedYearly = true;
                _selectedFounders = true;
              });
            },
            child: AnimatedContainer(
              duration: const Duration(milliseconds: 250),
              width: double.infinity,
              padding: EdgeInsets.all(4.w),
              decoration: BoxDecoration(
                gradient: (_selectedYearly && _selectedFounders)
                    ? const LinearGradient(
                        colors: [Color(0xFFFFD700), Color(0xFFFFA500)],
                        begin: Alignment.topLeft,
                        end: Alignment.bottomRight,
                      )
                    : null,
                color: (_selectedYearly && _selectedFounders)
                    ? null
                    : Colors.white.withValues(alpha: 0.05),
                borderRadius: BorderRadius.circular(16.0),
                border: Border.all(
                  color: (_selectedYearly && _selectedFounders)
                      ? const Color(0xFFFFD700)
                      : const Color(0xFFFFD700).withValues(alpha: 0.4),
                  width: (_selectedYearly && _selectedFounders) ? 2 : 1,
                ),
                boxShadow: (_selectedYearly && _selectedFounders)
                    ? [
                        BoxShadow(
                          color: const Color(0xFFFFD700).withValues(alpha: 0.35),
                          blurRadius: 20,
                          offset: const Offset(0, 6),
                        ),
                      ]
                    : null,
              ),
              child: Row(
                children: [
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          children: [
                            Text(
                              'Offre Fondateurs',
                              style: GoogleFonts.plusJakartaSans(
                                fontSize: 13.sp > 16 ? 16 : 13.sp,
                                fontWeight: FontWeight.w800,
                                color: (_selectedYearly && _selectedFounders)
                                    ? const Color(0xFF1B1B1B)
                                    : Colors.white,
                              ),
                            ),
                            SizedBox(width: 2.w),
                            Container(
                              padding: EdgeInsets.symmetric(
                                horizontal: 2.w,
                                vertical: 0.3.h,
                              ),
                              decoration: BoxDecoration(
                                color: const Color(0xFF1B1B1B).withValues(alpha: 0.15),
                                borderRadius: BorderRadius.circular(6.0),
                              ),
                              child: Text(
                                '300 PREMIERS',
                                style: GoogleFonts.plusJakartaSans(
                                  fontSize: 7.sp > 9 ? 9 : 7.sp,
                                  fontWeight: FontWeight.w800,
                                  color: (_selectedYearly && _selectedFounders)
                                      ? const Color(0xFF1B1B1B)
                                      : const Color(0xFFFFD700),
                                  letterSpacing: 0.5,
                                ),
                              ),
                            ),
                          ],
                        ),
                        SizedBox(height: 0.4.h),
                        Text(
                          '29.99€/an  •  économisez 25%',
                          style: GoogleFonts.plusJakartaSans(
                            fontSize: 10.sp > 12 ? 12 : 10.sp,
                            color: (_selectedYearly && _selectedFounders)
                                ? const Color(0xFF1B1B1B).withValues(alpha: 0.7)
                                : Colors.white.withValues(alpha: 0.7),
                          ),
                        ),
                        SizedBox(height: 0.3.h),
                        // Founders counter bar
                        Row(
                          children: [
                            Expanded(
                              child: ClipRRect(
                                borderRadius: BorderRadius.circular(4),
                                child: LinearProgressIndicator(
                                  value: _foundersTaken / _foundersTotal,
                                  backgroundColor: Colors.black.withValues(alpha: 0.2),
                                  valueColor: const AlwaysStoppedAnimation(Color(0xFFFF6B6B)),
                                  minHeight: 4,
                                ),
                              ),
                            ),
                            SizedBox(width: 2.w),
                            Text(
                              '$_foundersLeft restantes',
                              style: GoogleFonts.plusJakartaSans(
                                fontSize: 8.sp > 10 ? 10 : 8.sp,
                                fontWeight: FontWeight.w700,
                                color: const Color(0xFFFF6B6B),
                              ),
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.end,
                    children: [
                      Text(
                        '29.99€',
                        style: GoogleFonts.plusJakartaSans(
                          fontSize: 16.sp > 22 ? 22 : 16.sp,
                          fontWeight: FontWeight.w900,
                          color: (_selectedYearly && _selectedFounders)
                              ? const Color(0xFF1B1B1B)
                              : Colors.white,
                        ),
                      ),
                      Text(
                        'par an',
                        style: GoogleFonts.plusJakartaSans(
                          fontSize: 9.sp > 11 ? 11 : 9.sp,
                          color: (_selectedYearly && _selectedFounders)
                              ? const Color(0xFF1B1B1B).withValues(alpha: 0.6)
                              : Colors.white.withValues(alpha: 0.6),
                        ),
                      ),
                    ],
                  ),
                  SizedBox(width: 2.w),
                  AnimatedContainer(
                    duration: const Duration(milliseconds: 200),
                    width: 6.w,
                    height: 6.w,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      color: (_selectedYearly && _selectedFounders)
                          ? const Color(0xFF1B1B1B)
                          : Colors.transparent,
                      border: Border.all(
                        color: (_selectedYearly && _selectedFounders)
                            ? const Color(0xFF1B1B1B)
                            : Colors.white.withValues(alpha: 0.4),
                        width: 2,
                      ),
                    ),
                    child: (_selectedYearly && _selectedFounders)
                        ? const Icon(
                            Icons.check_rounded,
                            color: Color(0xFFFFD700),
                            size: 14,
                          )
                        : null,
                  ),
                ],
              ),
            ),
          ),
          SizedBox(height: 1.5.h),
        ],

        // ── Yearly plan (normal price) ──
        GestureDetector(
          onTap: () {
            HapticFeedback.selectionClick();
            setState(() {
              _selectedYearly = true;
              _selectedFounders = false;
            });
          },
          child: AnimatedContainer(
            duration: const Duration(milliseconds: 250),
            width: double.infinity,
            padding: EdgeInsets.all(4.w),
            decoration: BoxDecoration(
              gradient: (_selectedYearly && !_selectedFounders)
                  ? const LinearGradient(
                      colors: [Color(0xFF6C5CE7), Color(0xFF4834D4)],
                      begin: Alignment.topLeft,
                      end: Alignment.bottomRight,
                    )
                  : null,
              color: (_selectedYearly && !_selectedFounders)
                  ? null
                  : Colors.white.withValues(alpha: 0.05),
              borderRadius: BorderRadius.circular(16.0),
              border: Border.all(
                color: (_selectedYearly && !_selectedFounders)
                    ? const Color(0xFF6C5CE7)
                    : Colors.white.withValues(alpha: 0.15),
                width: (_selectedYearly && !_selectedFounders) ? 2 : 1,
              ),
              boxShadow: (_selectedYearly && !_selectedFounders)
                  ? [
                      BoxShadow(
                        color: const Color(0xFF6C5CE7).withValues(alpha: 0.4),
                        blurRadius: 20,
                        offset: const Offset(0, 6),
                      ),
                    ]
                  : null,
            ),
            child: Row(
              children: [
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'Plan Annuel',
                        style: GoogleFonts.plusJakartaSans(
                          fontSize: 13.sp > 16 ? 16 : 13.sp,
                          fontWeight: FontWeight.w800,
                          color: Colors.white,
                        ),
                      ),
                      SizedBox(height: 0.4.h),
                      Text(
                        '39.99€/an  •  soit 0.77€/semaine',
                        style: GoogleFonts.plusJakartaSans(
                          fontSize: 10.sp > 12 ? 12 : 10.sp,
                          color: Colors.white.withValues(alpha: 0.75),
                        ),
                      ),
                      SizedBox(height: 0.3.h),
                      Text(
                        'Économisez 87%',
                        style: GoogleFonts.plusJakartaSans(
                          fontSize: 9.sp > 11 ? 11 : 9.sp,
                          color: const Color(0xFF00B894),
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                    ],
                  ),
                ),
                Column(
                  crossAxisAlignment: CrossAxisAlignment.end,
                  children: [
                    Text(
                      '39.99€',
                      style: GoogleFonts.plusJakartaSans(
                        fontSize: 16.sp > 22 ? 22 : 16.sp,
                        fontWeight: FontWeight.w900,
                        color: Colors.white,
                      ),
                    ),
                    Text(
                      'par an',
                      style: GoogleFonts.plusJakartaSans(
                        fontSize: 9.sp > 11 ? 11 : 9.sp,
                        color: Colors.white.withValues(alpha: 0.6),
                      ),
                    ),
                  ],
                ),
                SizedBox(width: 2.w),
                AnimatedContainer(
                  duration: const Duration(milliseconds: 200),
                  width: 6.w,
                  height: 6.w,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    color: (_selectedYearly && !_selectedFounders)
                        ? Colors.white
                        : Colors.transparent,
                    border: Border.all(
                      color: (_selectedYearly && !_selectedFounders)
                          ? Colors.white
                          : Colors.white.withValues(alpha: 0.4),
                      width: 2,
                    ),
                  ),
                  child: (_selectedYearly && !_selectedFounders)
                      ? Icon(
                          Icons.check_rounded,
                          color: const Color(0xFF6C5CE7),
                          size: 14,
                        )
                      : null,
                ),
              ],
            ),
          ),
        ),
        SizedBox(height: 1.5.h),

        // ── Weekly plan ──
        GestureDetector(
          onTap: () {
            HapticFeedback.selectionClick();
            setState(() {
              _selectedYearly = false;
              _selectedFounders = false;
            });
          },
          child: AnimatedContainer(
            duration: const Duration(milliseconds: 250),
            width: double.infinity,
            padding: EdgeInsets.all(4.w),
            decoration: BoxDecoration(
              color: !_selectedYearly
                  ? Colors.white.withValues(alpha: 0.1)
                  : Colors.white.withValues(alpha: 0.04),
              borderRadius: BorderRadius.circular(16.0),
              border: Border.all(
                color: !_selectedYearly
                    ? Colors.white.withValues(alpha: 0.4)
                    : Colors.white.withValues(alpha: 0.1),
                width: !_selectedYearly ? 1.5 : 1,
              ),
            ),
            child: Row(
              children: [
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'Plan Hebdomadaire',
                        style: GoogleFonts.plusJakartaSans(
                          fontSize: 13.sp > 16 ? 16 : 13.sp,
                          fontWeight: FontWeight.w700,
                          color: Colors.white,
                        ),
                      ),
                      SizedBox(height: 0.3.h),
                      Text(
                        'Résiliable à tout moment',
                        style: GoogleFonts.plusJakartaSans(
                          fontSize: 9.sp > 11 ? 11 : 9.sp,
                          color: Colors.white.withValues(alpha: 0.5),
                        ),
                      ),
                    ],
                  ),
                ),
                Column(
                  crossAxisAlignment: CrossAxisAlignment.end,
                  children: [
                    Text(
                      '5.99€',
                      style: GoogleFonts.plusJakartaSans(
                        fontSize: 16.sp > 22 ? 22 : 16.sp,
                        fontWeight: FontWeight.w900,
                        color: Colors.white,
                      ),
                    ),
                    Text(
                      'par semaine',
                      style: GoogleFonts.plusJakartaSans(
                        fontSize: 9.sp > 11 ? 11 : 9.sp,
                        color: Colors.white.withValues(alpha: 0.6),
                      ),
                    ),
                  ],
                ),
                SizedBox(width: 2.w),
                AnimatedContainer(
                  duration: const Duration(milliseconds: 200),
                  width: 6.w,
                  height: 6.w,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    color: !_selectedYearly ? Colors.white : Colors.transparent,
                    border: Border.all(
                      color: !_selectedYearly
                          ? Colors.white
                          : Colors.white.withValues(alpha: 0.3),
                      width: 2,
                    ),
                  ),
                  child: !_selectedYearly
                      ? const Icon(
                          Icons.check_rounded,
                          color: Color(0xFF0A0A14),
                          size: 14,
                        )
                      : null,
                ),
              ],
            ),
          ),
        ),
      ],
    );
  }
          child: AnimatedContainer(
            duration: const Duration(milliseconds: 250),
            width: double.infinity,
            padding: EdgeInsets.all(4.w),
            decoration: BoxDecoration(
              gradient: _selectedYearly
                  ? const LinearGradient(
                      colors: [Color(0xFF6C5CE7), Color(0xFF4834D4)],
                      begin: Alignment.topLeft,
                      end: Alignment.bottomRight,
                    )
                  : null,
              color: _selectedYearly
                  ? null
                  : Colors.white.withValues(alpha: 0.05),
              borderRadius: BorderRadius.circular(16.0),
              border: Border.all(
                color: _selectedYearly
                    ? const Color(0xFF6C5CE7)
                    : Colors.white.withValues(alpha: 0.15),
                width: _selectedYearly ? 2 : 1,
              ),
              boxShadow: _selectedYearly
                  ? [
                      BoxShadow(
                        color: const Color(0xFF6C5CE7).withValues(alpha: 0.4),
                        blurRadius: 20,
                        offset: const Offset(0, 6),
                      ),
                    ]
                  : null,
            ),
            child: Row(
              children: [
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        children: [
                          Text(
                            'Yearly Plan',
                            style: GoogleFonts.plusJakartaSans(
                              fontSize: 13.sp > 16 ? 16 : 13.sp,
                              fontWeight: FontWeight.w800,
                              color: Colors.white,
                            ),
                          ),
                          SizedBox(width: 2.w),
                          Container(
                            padding: EdgeInsets.symmetric(
                              horizontal: 2.w,
                              vertical: 0.3.h,
                            ),
                            decoration: BoxDecoration(
                              color: const Color(
                                0xFFFFD700,
                              ).withValues(alpha: 0.2),
                              borderRadius: BorderRadius.circular(6.0),
                              border: Border.all(
                                color: const Color(
                                  0xFFFFD700,
                                ).withValues(alpha: 0.5),
                              ),
                            ),
                            child: Text(
                              'MOST POPULAR',
                              style: GoogleFonts.plusJakartaSans(
                                fontSize: 7.sp > 9 ? 9 : 7.sp,
                                fontWeight: FontWeight.w800,
                                color: const Color(0xFFFFD700),
                                letterSpacing: 0.5,
                              ),
                            ),
                          ),
                        ],
                      ),
                      SizedBox(height: 0.4.h),
                      Text(
                        '\$39.99 / year  •  Save 87%',
                        style: GoogleFonts.plusJakartaSans(
                          fontSize: 10.sp > 12 ? 12 : 10.sp,
                          color: Colors.white.withValues(alpha: 0.75),
                        ),
                      ),
                      SizedBox(height: 0.3.h),
                      Text(
                        'Only \$0.77/week',
                        style: GoogleFonts.plusJakartaSans(
                          fontSize: 9.sp > 11 ? 11 : 9.sp,
                          color: const Color(0xFF00B894),
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                    ],
                  ),
                ),
                Column(
                  crossAxisAlignment: CrossAxisAlignment.end,
                  children: [
                    Text(
                      '\$39.99',
                      style: GoogleFonts.plusJakartaSans(
                        fontSize: 16.sp > 22 ? 22 : 16.sp,
                        fontWeight: FontWeight.w900,
                        color: Colors.white,
                      ),
                    ),
                    Text(
                      'per year',
                      style: GoogleFonts.plusJakartaSans(
                        fontSize: 9.sp > 11 ? 11 : 9.sp,
                        color: Colors.white.withValues(alpha: 0.6),
                      ),
                    ),
                  ],
                ),
                SizedBox(width: 2.w),
                AnimatedContainer(
                  duration: const Duration(milliseconds: 200),
                  width: 6.w,
                  height: 6.w,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    color: _selectedYearly ? Colors.white : Colors.transparent,
                    border: Border.all(
                      color: _selectedYearly
                          ? Colors.white
                          : Colors.white.withValues(alpha: 0.4),
                      width: 2,
                    ),
                  ),
                  child: _selectedYearly
                      ? Icon(
                          Icons.check_rounded,
                          color: const Color(0xFF6C5CE7),
                          size: 14,
                        )
                      : null,
                ),
              ],
            ),
          ),
        ),
        SizedBox(height: 1.5.h),
        // Weekly plan
        GestureDetector(
          onTap: () {
            HapticFeedback.selectionClick();
            setState(() => _selectedYearly = false);
          },
          child: AnimatedContainer(
            duration: const Duration(milliseconds: 250),
            width: double.infinity,
            padding: EdgeInsets.all(4.w),
            decoration: BoxDecoration(
              color: !_selectedYearly
                  ? Colors.white.withValues(alpha: 0.1)
                  : Colors.white.withValues(alpha: 0.04),
              borderRadius: BorderRadius.circular(16.0),
              border: Border.all(
                color: !_selectedYearly
                    ? Colors.white.withValues(alpha: 0.4)
                    : Colors.white.withValues(alpha: 0.1),
                width: !_selectedYearly ? 1.5 : 1,
              ),
            ),
            child: Row(
              children: [
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'Weekly Plan',
                        style: GoogleFonts.plusJakartaSans(
                          fontSize: 13.sp > 16 ? 16 : 13.sp,
                          fontWeight: FontWeight.w700,
                          color: Colors.white,
                        ),
                      ),
                      SizedBox(height: 0.3.h),
                      Text(
                        'Cancel anytime',
                        style: GoogleFonts.plusJakartaSans(
                          fontSize: 9.sp > 11 ? 11 : 9.sp,
                          color: Colors.white.withValues(alpha: 0.5),
                        ),
                      ),
                    ],
                  ),
                ),
                Column(
                  crossAxisAlignment: CrossAxisAlignment.end,
                  children: [
                    Text(
                      '\$5.99',
                      style: GoogleFonts.plusJakartaSans(
                        fontSize: 16.sp > 22 ? 22 : 16.sp,
                        fontWeight: FontWeight.w900,
                        color: Colors.white,
                      ),
                    ),
                    Text(
                      'per week',
                      style: GoogleFonts.plusJakartaSans(
                        fontSize: 9.sp > 11 ? 11 : 9.sp,
                        color: Colors.white.withValues(alpha: 0.6),
                      ),
                    ),
                  ],
                ),
                SizedBox(width: 2.w),
                AnimatedContainer(
                  duration: const Duration(milliseconds: 200),
                  width: 6.w,
                  height: 6.w,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    color: !_selectedYearly ? Colors.white : Colors.transparent,
                    border: Border.all(
                      color: !_selectedYearly
                          ? Colors.white
                          : Colors.white.withValues(alpha: 0.3),
                      width: 2,
                    ),
                  ),
                  child: !_selectedYearly
                      ? const Icon(
                          Icons.check_rounded,
                          color: Color(0xFF0A0A14),
                          size: 14,
                        )
                      : null,
                ),
              ],
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildTestimonial() {
    return Container(
      padding: EdgeInsets.all(4.w),
      decoration: BoxDecoration(
        color: Colors.white.withValues(alpha: 0.04),
        borderRadius: BorderRadius.circular(16.0),
        border: Border.all(color: Colors.white.withValues(alpha: 0.07)),
      ),
      child: Column(
        children: [
          Row(
            children: [
              ...List.generate(
                5,
                (_) => const Icon(
                  Icons.star_rounded,
                  color: Color(0xFFFFD700),
                  size: 16,
                ),
              ),
              SizedBox(width: 2.w),
              // ⚠ Removed fake "2,400+ reviews" — Apple bans for this.
              // Replace with real beta tester count before App Store submission.
              Text(
                'Bêta testeurs',
                style: GoogleFonts.plusJakartaSans(
                  fontSize: 10.sp > 12 ? 12 : 10.sp,
                  color: Colors.white.withValues(alpha: 0.6),
                ),
              ),
            ],
          ),
          SizedBox(height: 1.h),
          Text(
            '"J\'ai perdu 8% de masse grasse en 3 mois grâce au suivi hebdomadaire. L\'analyse IA est bluffante — enfin un vrai outil de composition corporelle."',
            style: GoogleFonts.plusJakartaSans(
              fontSize: 10.sp > 13 ? 13 : 10.sp,
              color: Colors.white.withValues(alpha: 0.75),
              fontStyle: FontStyle.italic,
              height: 1.5,
            ),
          ),
          SizedBox(height: 0.8.h),
          Align(
            alignment: Alignment.centerRight,
            child: Text(
              '— Alex M., bêta testeur',
              style: GoogleFonts.plusJakartaSans(
                fontSize: 9.sp > 11 ? 11 : 9.sp,
                color: Colors.white.withValues(alpha: 0.45),
                fontWeight: FontWeight.w600,
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildBottomCTA() {
    return Container(
      padding: EdgeInsets.fromLTRB(4.w, 1.5.h, 4.w, 3.h),
      decoration: BoxDecoration(
        color: const Color(0xFF0A0A14),
        border: Border(
          top: BorderSide(color: Colors.white.withValues(alpha: 0.07)),
        ),
      ),
      child: Column(
        children: [
          SizedBox(
            width: double.infinity,
            height: 6.5.h,
            child: DecoratedBox(
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(16.0),
                gradient: const LinearGradient(
                  colors: [Color(0xFF6C5CE7), Color(0xFF4834D4)],
                  begin: Alignment.centerLeft,
                  end: Alignment.centerRight,
                ),
                boxShadow: [
                  BoxShadow(
                    color: const Color(0xFF6C5CE7).withValues(alpha: 0.5),
                    blurRadius: 20,
                    offset: const Offset(0, 6),
                  ),
                ],
              ),
              child: ElevatedButton(
                onPressed: _isLoading ? null : _onSubscribe,
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.transparent,
                  shadowColor: Colors.transparent,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(16.0),
                  ),
                ),
                child: _isLoading
                    ? const SizedBox(
                        width: 22,
                        height: 22,
                        child: CircularProgressIndicator(
                          color: Colors.white,
                          strokeWidth: 2.5,
                        ),
                      )
                    : Text(
                        _selectedYearly
                            ? (_selectedFounders && _foundersLeft > 0
                                ? 'Offre Fondateurs — 29.99€/an'
                                : 'Plan Annuel — 39.99€/an')
                            : 'Plan Hebdomadaire — 5.99€/sem',
                        style: GoogleFonts.plusJakartaSans(
                          fontSize: 13.sp > 16 ? 16 : 13.sp,
                          fontWeight: FontWeight.w800,
                          color: Colors.white,
                        ),
                      ),
              ),
            ),
          ),
          SizedBox(height: 1.h),
          Text(
            'Résiliable à tout moment · Paiement sécurisé · Sans frais cachés',
            textAlign: TextAlign.center,
            style: GoogleFonts.plusJakartaSans(
              fontSize: 9.sp > 11 ? 11 : 9.sp,
              color: Colors.white.withValues(alpha: 0.4),
            ),
          ),
          SizedBox(height: 1.2.h),
          // ── Restore Purchases — OBLIGATOIRE Apple (règle 3.1.1) ──
          GestureDetector(
            onTap: _isLoading ? null : _onRestorePurchases,
            child: Text(
              'Restaurer mes achats',
              textAlign: TextAlign.center,
              style: GoogleFonts.plusJakartaSans(
                fontSize: 9.sp > 11 ? 11 : 9.sp,
                color: Colors.white.withValues(alpha: 0.55),
                decoration: TextDecoration.underline,
                decorationColor: Colors.white.withValues(alpha: 0.3),
              ),
            ),
          ),
          SizedBox(height: 1.h),
          // ── Terms & Privacy — OBLIGATOIRE Apple ──
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              GestureDetector(
                onTap: () => Navigator.of(context).pushNamed('/terms-of-use'),
                child: Text(
                  'Conditions d\'utilisation',
                  style: GoogleFonts.plusJakartaSans(
                    fontSize: 8.sp > 10 ? 10 : 8.sp,
                    color: Colors.white.withValues(alpha: 0.35),
                    decoration: TextDecoration.underline,
                    decorationColor: Colors.white.withValues(alpha: 0.2),
                  ),
                ),
              ),
              Text(
                '  ·  ',
                style: GoogleFonts.plusJakartaSans(
                  fontSize: 8.sp > 10 ? 10 : 8.sp,
                  color: Colors.white.withValues(alpha: 0.25),
                ),
              ),
              GestureDetector(
                onTap: () => Navigator.of(context).pushNamed('/privacy-policy'),
                child: Text(
                  'Politique de confidentialité',
                  style: GoogleFonts.plusJakartaSans(
                    fontSize: 8.sp > 10 ? 10 : 8.sp,
                    color: Colors.white.withValues(alpha: 0.35),
                    decoration: TextDecoration.underline,
                    decorationColor: Colors.white.withValues(alpha: 0.2),
                  ),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  // ── Restore Purchases (placeholder — remplacer par RevenueCat.restorePurchases() au lancement) ──
  Future<void> _onRestorePurchases() async {
    setState(() => _isLoading = true);
    try {
      // TODO: remplacer par Purchases.restorePurchases() une fois RevenueCat intégré
      final isPremium = await SupabaseService.instance.checkSubscriptionStatus();
      if (!mounted) return;
      if (isPremium) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(
              'Abonnement restauré avec succès ✓',
              style: GoogleFonts.plusJakartaSans(fontWeight: FontWeight.w600),
            ),
            backgroundColor: const Color(0xFF00B894),
            behavior: SnackBarBehavior.floating,
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
          ),
        );
        _navigateAfterPaywall();
      } else {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(
              'Aucun abonnement actif trouvé',
              style: GoogleFonts.plusJakartaSans(),
            ),
            backgroundColor: const Color(0xFFE17055),
            behavior: SnackBarBehavior.floating,
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
          ),
        );
      }
    } catch (e) {
      debugPrint('[Paywall] Restore error: $e');
    } finally {
      if (mounted) setState(() => _isLoading = false);
    }
  }
}
