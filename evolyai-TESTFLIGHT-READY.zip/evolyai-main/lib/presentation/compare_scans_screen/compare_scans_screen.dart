import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:sizer/sizer.dart';

import '../../widgets/custom_icon_widget.dart';
import '../../services/supabase_service.dart';

class CompareScansScreen extends StatefulWidget {
  const CompareScansScreen({super.key});

  @override
  State<CompareScansScreen> createState() => _CompareScansScreenState();
}

class _CompareScansScreenState extends State<CompareScansScreen>
    with SingleTickerProviderStateMixin {
  late AnimationController _animController;
  late Animation<double> _fadeAnim;
  late Animation<Offset> _slideAnim;

  bool _isLoading = true;
  String? _errorMessage;

  // Real scan data loaded from Supabase
  _ScanData? _beforeScan;
  _ScanData? _afterScan;

  @override
  void initState() {
    super.initState();
    _animController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 600),
    );
    _fadeAnim = CurvedAnimation(parent: _animController, curve: Curves.easeOut);
    _slideAnim = Tween<Offset>(
      begin: const Offset(0, 0.06),
      end: Offset.zero,
    ).animate(CurvedAnimation(parent: _animController, curve: Curves.easeOut));
    _loadScans();
  }

  Future<void> _loadScans() async {
    setState(() {
      _isLoading = true;
      _errorMessage = null;
    });
    try {
      final results = await SupabaseService.instance.fetchScanResultHistory(
        limit: 20,
      );
      if (!mounted) return;

      if (results.length < 2) {
        setState(() {
          _isLoading = false;
          _errorMessage = results.isEmpty
              ? 'Aucun scan trouvé. Effectuez au moins deux scans pour comparer.'
              : 'Il vous faut au moins 2 scans pour comparer. Effectuez un autre scan pour débloquer cette fonctionnalité.';
        });
        return;
      }

      // results are newest-first; "after" = index 0 (latest), "before" = oldest available
      final afterResult = results.first;
      final beforeResult = results.last;

      _afterScan = _ScanData(
        label: 'Après',
        date: _formatDate(afterResult.createdAt),
        bodyFat: afterResult.bodyFatPercent ?? 0.0,
        leanMass: afterResult.leanMassEstimate ?? 0.0,
        fatMass: afterResult.fatMass ?? 0.0,
        weight:
            (afterResult.leanMassEstimate ?? 0.0) +
            (afterResult.fatMass ?? 0.0),
        zones: {
          'Bras Gauche': afterResult.leftArmPercent ?? 0.0,
          'Bras Droit': afterResult.rightArmPercent ?? 0.0,
          'Haut du Corps': afterResult.upperBodyPercent ?? 0.0,
          'Jambe Gauche': afterResult.leftLegPercent ?? 0.0,
          'Jambe Droite': afterResult.rightLegPercent ?? 0.0,
        },
      );

      _beforeScan = _ScanData(
        label: 'Avant',
        date: _formatDate(beforeResult.createdAt),
        bodyFat: beforeResult.bodyFatPercent ?? 0.0,
        leanMass: beforeResult.leanMassEstimate ?? 0.0,
        fatMass: beforeResult.fatMass ?? 0.0,
        weight:
            (beforeResult.leanMassEstimate ?? 0.0) +
            (beforeResult.fatMass ?? 0.0),
        zones: {
          'Bras Gauche': beforeResult.leftArmPercent ?? 0.0,
          'Bras Droit': beforeResult.rightArmPercent ?? 0.0,
          'Haut du Corps': beforeResult.upperBodyPercent ?? 0.0,
          'Jambe Gauche': beforeResult.leftLegPercent ?? 0.0,
          'Jambe Droite': beforeResult.rightLegPercent ?? 0.0,
        },
      );

      setState(() => _isLoading = false);
      _animController.forward();
    } catch (e) {
      debugPrint('[CompareScans] _loadScans error: $e');
      if (mounted) {
        setState(() {
          _isLoading = false;
          _errorMessage = 'Could not load scan data. Please try again.';
        });
      }
    }
  }

  String _formatDate(DateTime? dt) {
    if (dt == null) return '--';
    const months = [
      'Jan',
      'Feb',
      'Mar',
      'Apr',
      'May',
      'Jun',
      'Jul',
      'Aug',
      'Sep',
      'Oct',
      'Nov',
      'Dec',
    ];
    return '${months[dt.month - 1]} ${dt.day}, ${dt.year}';
  }

  @override
  void dispose() {
    _animController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return Scaffold(
      backgroundColor: theme.scaffoldBackgroundColor,
      body: CustomScrollView(
        slivers: [
          // App bar
          SliverAppBar(
            expandedHeight: 12.h,
            pinned: true,
            backgroundColor: theme.scaffoldBackgroundColor,
            elevation: 0,
            leading: GestureDetector(
              onTap: () {
                HapticFeedback.selectionClick();
                Navigator.pop(context);
              },
              child: Container(
                margin: EdgeInsets.all(2.w),
                decoration: BoxDecoration(
                  color: theme.cardColor,
                  shape: BoxShape.circle,
                  boxShadow: [
                    BoxShadow(
                      color: Colors.black.withValues(alpha: 0.06),
                      blurRadius: 8,
                    ),
                  ],
                ),
                child: Center(
                  child: CustomIconWidget(
                    iconName: 'arrow_back_ios_new',
                    color: theme.colorScheme.onSurface,
                    size: 18,
                  ),
                ),
              ),
            ),
            flexibleSpace: FlexibleSpaceBar(
              titlePadding: EdgeInsets.only(left: 14.w, bottom: 1.5.h),
              title: Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'Comparer les Scans',
                    style: GoogleFonts.manrope(
                      fontSize: 14.sp,
                      fontWeight: FontWeight.w800,
                      color: theme.colorScheme.onSurface,
                    ),
                  ),
                  Text(
                    'Track your transformation',
                    style: GoogleFonts.dmSans(
                      fontSize: 9.sp,
                      color: theme.colorScheme.onSurfaceVariant,
                      fontWeight: FontWeight.w400,
                    ),
                  ),
                ],
              ),
            ),
          ),
          SliverToBoxAdapter(
            child: _isLoading
                ? SizedBox(
                    height: 60.h,
                    child: const Center(
                      child: CircularProgressIndicator(
                        color: Color(0xFF6C5CE7),
                      ),
                    ),
                  )
                : _errorMessage != null
                ? _buildErrorState(theme)
                : FadeTransition(
                    opacity: _fadeAnim,
                    child: SlideTransition(
                      position: _slideAnim,
                      child: Padding(
                        padding: EdgeInsets.symmetric(horizontal: 4.w),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            SizedBox(height: 1.h),
                            // Overall improvement banner
                            _ImprovementBanner(
                              before: _beforeScan!,
                              after: _afterScan!,
                              theme: theme,
                            ),
                            SizedBox(height: 2.h),
                            // Key metrics comparison
                            _SectionTitle(title: 'Métriques clés', theme: theme),
                            SizedBox(height: 1.h),
                            _MetricsComparisonCard(
                              before: _beforeScan!,
                              after: _afterScan!,
                              theme: theme,
                            ),
                            SizedBox(height: 2.h),
                            // Side-by-side body zones
                            _SectionTitle(
                              title: 'Comparaison par zones',
                              theme: theme,
                            ),
                            SizedBox(height: 1.h),
                            _ZoneComparisonCard(
                              before: _beforeScan!,
                              after: _afterScan!,
                              theme: theme,
                            ),
                            SizedBox(height: 2.h),
                            // Body silhouette side by side
                            _SectionTitle(
                              title: 'Analyse corporelle côte à côte',
                              theme: theme,
                            ),
                            SizedBox(height: 1.h),
                            _SideBySideSilhouettes(
                              before: _beforeScan!,
                              after: _afterScan!,
                              theme: theme,
                            ),
                            SizedBox(height: 3.h),
                          ],
                        ),
                      ),
                    ),
                  ),
          ),
        ],
      ),
    );
  }

  Widget _buildErrorState(ThemeData theme) {
    return SizedBox(
      height: 60.h,
      child: Center(
        child: Padding(
          padding: EdgeInsets.symmetric(horizontal: 8.w),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Container(
                width: 20.w,
                height: 20.w,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: const Color(0xFF6C5CE7).withValues(alpha: 0.12),
                ),
                child: const Icon(
                  Icons.compare_arrows_rounded,
                  color: Color(0xFF6C5CE7),
                  size: 36,
                ),
              ),
              SizedBox(height: 2.h),
              Text(
                _errorMessage!,
                style: GoogleFonts.dmSans(
                  fontSize: 11.sp,
                  color: theme.colorScheme.onSurfaceVariant,
                  fontWeight: FontWeight.w500,
                ),
                textAlign: TextAlign.center,
              ),
              SizedBox(height: 2.h),
              GestureDetector(
                onTap: _loadScans,
                child: Container(
                  padding: EdgeInsets.symmetric(
                    horizontal: 6.w,
                    vertical: 1.5.h,
                  ),
                  decoration: BoxDecoration(
                    gradient: const LinearGradient(
                      colors: [Color(0xFF6C5CE7), Color(0xFF8B7CF6)],
                    ),
                    borderRadius: BorderRadius.circular(14.0),
                  ),
                  child: Text(
                    'Retry',
                    style: GoogleFonts.manrope(
                      fontSize: 11.sp,
                      fontWeight: FontWeight.w700,
                      color: Colors.white,
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

// ─── Data Model ───────────────────────────────────────────────────────────────

class _ScanData {
  final String label;
  final String date;
  final double bodyFat;
  final double leanMass;
  final double fatMass;
  final double weight;
  final Map<String, double> zones;

  const _ScanData({
    required this.label,
    required this.date,
    required this.bodyFat,
    required this.leanMass,
    required this.fatMass,
    required this.weight,
    required this.zones,
  });
}

// ─── Improvement Banner ───────────────────────────────────────────────────────

class _ImprovementBanner extends StatelessWidget {
  final _ScanData before;
  final _ScanData after;
  final ThemeData theme;

  const _ImprovementBanner({
    required this.before,
    required this.after,
    required this.theme,
  });

  @override
  Widget build(BuildContext context) {
    final fatDelta = after.bodyFat - before.bodyFat;
    final leanDelta = after.leanMass - before.leanMass;
    final improved = fatDelta < 0;

    return Container(
      width: double.infinity,
      padding: EdgeInsets.all(4.w),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: improved
              ? [const Color(0xFF6C5CE7), const Color(0xFF00D4AA)]
              : [const Color(0xFFFF7043), const Color(0xFFFFB347)],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(20.0),
        boxShadow: [
          BoxShadow(
            color:
                (improved ? const Color(0xFF6C5CE7) : const Color(0xFFFF7043))
                    .withValues(alpha: 0.30),
            blurRadius: 20,
            offset: const Offset(0, 8),
          ),
        ],
      ),
      child: Row(
        children: [
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  improved ? '🎉 Great Progress!' : '💪 Keep Going!',
                  style: GoogleFonts.manrope(
                    fontSize: 14.sp,
                    fontWeight: FontWeight.w800,
                    color: Colors.white,
                  ),
                ),
                SizedBox(height: 0.5.h),
                Text(
                  improved
                      ? 'You\'ve lost ${fatDelta.abs().toStringAsFixed(1)}% body fat and gained ${leanDelta.toStringAsFixed(1)} kg lean mass'
                      : 'Stay consistent — every scan counts',
                  style: GoogleFonts.dmSans(
                    fontSize: 9.5.sp,
                    color: Colors.white.withValues(alpha: 0.88),
                    fontWeight: FontWeight.w400,
                  ),
                ),
                SizedBox(height: 1.h),
                Row(
                  children: [
                    _MiniDelta(
                      label: 'Masse Grasse',
                      delta: fatDelta,
                      unit: '%',
                      invertPositive: true,
                    ),
                    SizedBox(width: 3.w),
                    _MiniDelta(
                      label: 'Masse Maigre',
                      delta: leanDelta,
                      unit: ' kg',
                      invertPositive: false,
                    ),
                  ],
                ),
              ],
            ),
          ),
          Container(
            width: 14.w,
            height: 14.w,
            decoration: BoxDecoration(
              color: Colors.white.withValues(alpha: 0.18),
              shape: BoxShape.circle,
            ),
            child: Center(
              child: Text(
                improved ? '🔥' : '⚡',
                style: TextStyle(fontSize: 16.sp),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _MiniDelta extends StatelessWidget {
  final String label;
  final double delta;
  final String unit;
  final bool invertPositive;

  const _MiniDelta({
    required this.label,
    required this.delta,
    required this.unit,
    required this.invertPositive,
  });

  bool get _isGood => invertPositive ? delta < 0 : delta > 0;

  @override
  Widget build(BuildContext context) {
    final sign = delta > 0 ? '+' : '';
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
      decoration: BoxDecoration(
        color: Colors.white.withValues(alpha: 0.20),
        borderRadius: BorderRadius.circular(8.0),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(
            _isGood ? Icons.arrow_downward : Icons.arrow_upward,
            color: Colors.white,
            size: 12,
          ),
          const SizedBox(width: 3),
          Text(
            '$label: $sign${delta.toStringAsFixed(1)}$unit',
            style: GoogleFonts.dmSans(
              fontSize: 8.5.sp,
              color: Colors.white,
              fontWeight: FontWeight.w600,
            ),
          ),
        ],
      ),
    );
  }
}

// ─── Section Title ────────────────────────────────────────────────────────────

class _SectionTitle extends StatelessWidget {
  final String title;
  final ThemeData theme;

  const _SectionTitle({required this.title, required this.theme});

  @override
  Widget build(BuildContext context) {
    return Text(
      title,
      style: GoogleFonts.manrope(
        fontSize: 12.sp,
        fontWeight: FontWeight.w700,
        color: theme.colorScheme.onSurface,
      ),
    );
  }
}

// ─── Metrics Comparison Card ──────────────────────────────────────────────────

class _MetricsComparisonCard extends StatelessWidget {
  final _ScanData before;
  final _ScanData after;
  final ThemeData theme;

  const _MetricsComparisonCard({
    required this.before,
    required this.after,
    required this.theme,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: EdgeInsets.all(4.w),
      decoration: BoxDecoration(
        color: theme.cardColor,
        borderRadius: BorderRadius.circular(20.0),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: 0.06),
            blurRadius: 16,
            offset: const Offset(0, 6),
          ),
        ],
      ),
      child: Column(
        children: [
          // Header row
          Row(
            children: [
              Expanded(child: SizedBox()),
              Expanded(
                flex: 2,
                child: Row(
                  children: [
                    Expanded(
                      child: _ScanDateBadge(
                        label: before.label,
                        date: before.date,
                        color: const Color(0xFF74B9FF),
                        theme: theme,
                      ),
                    ),
                    SizedBox(width: 2.w),
                    Expanded(
                      child: _ScanDateBadge(
                        label: after.label,
                        date: after.date,
                        color: const Color(0xFF6C5CE7),
                        theme: theme,
                      ),
                    ),
                    SizedBox(width: 2.w),
                    Expanded(
                      child: Center(
                        child: Text(
                          'Variation',
                          style: GoogleFonts.dmSans(
                            fontSize: 8.sp,
                            fontWeight: FontWeight.w600,
                            color: theme.colorScheme.onSurfaceVariant,
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
          SizedBox(height: 1.5.h),
          _MetricRow(
            label: 'Masse Grasse',
            icon: 'water_drop',
            iconColor: const Color(0xFFFF7043),
            beforeValue: before.bodyFat,
            afterValue: after.bodyFat,
            unit: '%',
            invertPositive: true,
            theme: theme,
          ),
          _Divider(theme: theme),
          _MetricRow(
            label: 'Masse Maigre',
            icon: 'fitness_center',
            iconColor: const Color(0xFF6C5CE7),
            beforeValue: before.leanMass,
            afterValue: after.leanMass,
            unit: ' kg',
            invertPositive: false,
            theme: theme,
          ),
          _Divider(theme: theme),
          _MetricRow(
            label: 'Masse Grasse kg',
            icon: 'monitor_weight',
            iconColor: const Color(0xFFFFB347),
            beforeValue: before.fatMass,
            afterValue: after.fatMass,
            unit: ' kg',
            invertPositive: true,
            theme: theme,
          ),
        ],
      ),
    );
  }
}

class _ScanDateBadge extends StatelessWidget {
  final String label;
  final String date;
  final Color color;
  final ThemeData theme;

  const _ScanDateBadge({
    required this.label,
    required this.date,
    required this.color,
    required this.theme,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: EdgeInsets.symmetric(horizontal: 2.w, vertical: 0.6.h),
      decoration: BoxDecoration(
        color: color.withValues(alpha: 0.12),
        borderRadius: BorderRadius.circular(10.0),
      ),
      child: Column(
        children: [
          Text(
            label,
            style: GoogleFonts.manrope(
              fontSize: 9.sp,
              fontWeight: FontWeight.w700,
              color: color,
            ),
          ),
          Text(
            date,
            style: GoogleFonts.dmSans(
              fontSize: 7.sp,
              color: theme.colorScheme.onSurfaceVariant,
            ),
            overflow: TextOverflow.ellipsis,
          ),
        ],
      ),
    );
  }
}

class _MetricRow extends StatelessWidget {
  final String label;
  final String icon;
  final Color iconColor;
  final double beforeValue;
  final double afterValue;
  final String unit;
  final bool invertPositive;
  final ThemeData theme;

  const _MetricRow({
    required this.label,
    required this.icon,
    required this.iconColor,
    required this.beforeValue,
    required this.afterValue,
    required this.unit,
    required this.invertPositive,
    required this.theme,
  });

  bool get _isImprovement =>
      invertPositive ? afterValue < beforeValue : afterValue > beforeValue;

  @override
  Widget build(BuildContext context) {
    final delta = afterValue - beforeValue;
    final sign = delta > 0 ? '+' : '';
    final deltaColor = _isImprovement
        ? const Color(0xFF00D4AA)
        : const Color(0xFFFF6B6B);

    return Padding(
      padding: EdgeInsets.symmetric(vertical: 1.h),
      child: Row(
        children: [
          // Label
          Expanded(
            child: Row(
              children: [
                Container(
                  width: 7.w,
                  height: 7.w,
                  decoration: BoxDecoration(
                    color: iconColor.withValues(alpha: 0.12),
                    borderRadius: BorderRadius.circular(8.0),
                  ),
                  child: Center(
                    child: CustomIconWidget(
                      iconName: icon,
                      color: iconColor,
                      size: 14,
                    ),
                  ),
                ),
                SizedBox(width: 2.w),
                Text(
                  label,
                  style: GoogleFonts.dmSans(
                    fontSize: 9.sp,
                    fontWeight: FontWeight.w600,
                    color: theme.colorScheme.onSurface,
                  ),
                ),
              ],
            ),
          ),
          // Before / After / Delta
          Expanded(
            flex: 2,
            child: Row(
              children: [
                Expanded(
                  child: Center(
                    child: Text(
                      '${beforeValue.toStringAsFixed(1)}$unit',
                      style: GoogleFonts.manrope(
                        fontSize: 10.sp,
                        fontWeight: FontWeight.w600,
                        color: theme.colorScheme.onSurface.withValues(
                          alpha: 0.65,
                        ),
                      ),
                    ),
                  ),
                ),
                SizedBox(width: 2.w),
                Expanded(
                  child: Center(
                    child: Text(
                      '${afterValue.toStringAsFixed(1)}$unit',
                      style: GoogleFonts.manrope(
                        fontSize: 10.sp,
                        fontWeight: FontWeight.w700,
                        color: theme.colorScheme.onSurface,
                      ),
                    ),
                  ),
                ),
                SizedBox(width: 2.w),
                Expanded(
                  child: Center(
                    child: Container(
                      padding: const EdgeInsets.symmetric(
                        horizontal: 6,
                        vertical: 3,
                      ),
                      decoration: BoxDecoration(
                        color: deltaColor.withValues(alpha: 0.12),
                        borderRadius: BorderRadius.circular(8.0),
                      ),
                      child: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Icon(
                            _isImprovement
                                ? Icons.trending_down
                                : Icons.trending_up,
                            color: deltaColor,
                            size: 12,
                          ),
                          const SizedBox(width: 2),
                          Flexible(
                            child: Text(
                              '$sign${delta.toStringAsFixed(1)}',
                              style: GoogleFonts.manrope(
                                fontSize: 8.sp,
                                fontWeight: FontWeight.w700,
                                color: deltaColor,
                              ),
                              overflow: TextOverflow.ellipsis,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _Divider extends StatelessWidget {
  final ThemeData theme;
  const _Divider({required this.theme});

  @override
  Widget build(BuildContext context) {
    return Divider(
      color: theme.colorScheme.onSurface.withValues(alpha: 0.06),
      height: 1,
    );
  }
}

// ─── Zone Comparison Card ─────────────────────────────────────────────────────

class _ZoneComparisonCard extends StatelessWidget {
  final _ScanData before;
  final _ScanData after;
  final ThemeData theme;

  const _ZoneComparisonCard({
    required this.before,
    required this.after,
    required this.theme,
  });

  Color _zoneColor(double value) {
    if (value < 12) return const Color(0xFF00D4AA);
    if (value < 20) return const Color(0xFF74B9FF);
    if (value < 28) return const Color(0xFFFFB347);
    return const Color(0xFFFF6B6B);
  }

  @override
  Widget build(BuildContext context) {
    final zones = [
      'Bras Gauche',
      'Bras Droit',
      'Haut du Corps',
      'Jambe Gauche',
      'Jambe Droite',
    ];

    return Container(
      padding: EdgeInsets.all(4.w),
      decoration: BoxDecoration(
        color: theme.cardColor,
        borderRadius: BorderRadius.circular(20.0),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: 0.06),
            blurRadius: 16,
            offset: const Offset(0, 6),
          ),
        ],
      ),
      child: Column(
        children: [
          // Header
          Row(
            children: [
              Expanded(
                flex: 2,
                child: Text(
                  'Zone',
                  style: GoogleFonts.dmSans(
                    fontSize: 9.sp,
                    fontWeight: FontWeight.w600,
                    color: theme.colorScheme.onSurfaceVariant,
                  ),
                ),
              ),
              Expanded(
                child: Center(
                  child: Text(
                    'Avant',
                    style: GoogleFonts.dmSans(
                      fontSize: 9.sp,
                      fontWeight: FontWeight.w600,
                      color: const Color(0xFF74B9FF),
                    ),
                  ),
                ),
              ),
              Expanded(
                child: Center(
                  child: Text(
                    'Après',
                    style: GoogleFonts.dmSans(
                      fontSize: 9.sp,
                      fontWeight: FontWeight.w600,
                      color: const Color(0xFF6C5CE7),
                    ),
                  ),
                ),
              ),
              Expanded(
                child: Center(
                  child: Text(
                    'Δ',
                    style: GoogleFonts.manrope(
                      fontSize: 10.sp,
                      fontWeight: FontWeight.w700,
                      color: theme.colorScheme.onSurfaceVariant,
                    ),
                  ),
                ),
              ),
            ],
          ),
          SizedBox(height: 1.h),
          ...zones.map((zone) {
            final bVal = before.zones[zone] ?? 0;
            final aVal = after.zones[zone] ?? 0;
            final delta = aVal - bVal;
            final improved = delta < 0;
            final deltaColor = improved
                ? const Color(0xFF00D4AA)
                : const Color(0xFFFF6B6B);

            return Column(
              children: [
                Padding(
                  padding: EdgeInsets.symmetric(vertical: 0.8.h),
                  child: Row(
                    children: [
                      Expanded(
                        flex: 2,
                        child: Row(
                          children: [
                            Container(
                              width: 8,
                              height: 8,
                              decoration: BoxDecoration(
                                color: _zoneColor(aVal),
                                shape: BoxShape.circle,
                              ),
                            ),
                            SizedBox(width: 2.w),
                            Flexible(
                              child: Text(
                                zone,
                                style: GoogleFonts.dmSans(
                                  fontSize: 9.sp,
                                  fontWeight: FontWeight.w500,
                                  color: theme.colorScheme.onSurface,
                                ),
                                overflow: TextOverflow.ellipsis,
                              ),
                            ),
                          ],
                        ),
                      ),
                      Expanded(
                        child: Center(
                          child: Text(
                            '${bVal.toStringAsFixed(1)}%',
                            style: GoogleFonts.manrope(
                              fontSize: 9.5.sp,
                              fontWeight: FontWeight.w500,
                              color: theme.colorScheme.onSurface.withValues(
                                alpha: 0.55,
                              ),
                            ),
                          ),
                        ),
                      ),
                      Expanded(
                        child: Center(
                          child: Text(
                            '${aVal.toStringAsFixed(1)}%',
                            style: GoogleFonts.manrope(
                              fontSize: 9.5.sp,
                              fontWeight: FontWeight.w700,
                              color: theme.colorScheme.onSurface,
                            ),
                          ),
                        ),
                      ),
                      Expanded(
                        child: Center(
                          child: Row(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              Icon(
                                improved
                                    ? Icons.arrow_downward
                                    : Icons.arrow_upward,
                                color: deltaColor,
                                size: 12,
                              ),
                              const SizedBox(width: 2),
                              Text(
                                '${delta.abs().toStringAsFixed(1)}%',
                                style: GoogleFonts.manrope(
                                  fontSize: 9.sp,
                                  fontWeight: FontWeight.w700,
                                  color: deltaColor,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
                if (zone != zones.last) _Divider(theme: theme),
              ],
            );
          }),
        ],
      ),
    );
  }
}

// ─── Side-by-Side Silhouettes ─────────────────────────────────────────────────

class _SideBySideSilhouettes extends StatelessWidget {
  final _ScanData before;
  final _ScanData after;
  final ThemeData theme;

  const _SideBySideSilhouettes({
    required this.before,
    required this.after,
    required this.theme,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: EdgeInsets.all(4.w),
      decoration: BoxDecoration(
        color: theme.cardColor,
        borderRadius: BorderRadius.circular(20.0),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: 0.06),
            blurRadius: 16,
            offset: const Offset(0, 6),
          ),
        ],
      ),
      child: Row(
        children: [
          Expanded(
            child: Column(
              children: [
                _ScanLabel(
                  label: 'Avant',
                  date: before.date,
                  color: const Color(0xFF74B9FF),
                  theme: theme,
                ),
                SizedBox(height: 1.h),
                SizedBox(
                  height: 28.h,
                  child: CustomPaint(
                    size: Size(double.infinity, 28.h),
                    painter: _CompareSilhouettePainter(
                      zones: before.zones,
                      theme: theme,
                      opacity: 0.55,
                    ),
                  ),
                ),
                SizedBox(height: 1.h),
                Text(
                  'Body Fat: ${before.bodyFat.toStringAsFixed(1)}%',
                  style: GoogleFonts.manrope(
                    fontSize: 9.sp,
                    fontWeight: FontWeight.w700,
                    color: const Color(0xFF74B9FF),
                  ),
                ),
              ],
            ),
          ),
          Container(
            width: 1,
            height: 32.h,
            color: theme.colorScheme.onSurface.withValues(alpha: 0.08),
          ),
          Expanded(
            child: Column(
              children: [
                _ScanLabel(
                  label: 'Après',
                  date: after.date,
                  color: const Color(0xFF6C5CE7),
                  theme: theme,
                ),
                SizedBox(height: 1.h),
                SizedBox(
                  height: 28.h,
                  child: CustomPaint(
                    size: Size(double.infinity, 28.h),
                    painter: _CompareSilhouettePainter(
                      zones: after.zones,
                      theme: theme,
                      opacity: 0.75,
                    ),
                  ),
                ),
                SizedBox(height: 1.h),
                Text(
                  'Body Fat: ${after.bodyFat.toStringAsFixed(1)}%',
                  style: GoogleFonts.manrope(
                    fontSize: 9.sp,
                    fontWeight: FontWeight.w700,
                    color: const Color(0xFF6C5CE7),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _ScanLabel extends StatelessWidget {
  final String label;
  final String date;
  final Color color;
  final ThemeData theme;

  const _ScanLabel({
    required this.label,
    required this.date,
    required this.color,
    required this.theme,
  });

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Container(
          padding: EdgeInsets.symmetric(horizontal: 3.w, vertical: 0.4.h),
          decoration: BoxDecoration(
            color: color.withValues(alpha: 0.12),
            borderRadius: BorderRadius.circular(8.0),
          ),
          child: Text(
            label,
            style: GoogleFonts.manrope(
              fontSize: 10.sp,
              fontWeight: FontWeight.w700,
              color: color,
            ),
          ),
        ),
        SizedBox(height: 0.3.h),
        Text(
          date,
          style: GoogleFonts.dmSans(
            fontSize: 8.sp,
            color: theme.colorScheme.onSurfaceVariant,
          ),
        ),
      ],
    );
  }
}

/// Compact silhouette painter for compare view
class _CompareSilhouettePainter extends CustomPainter {
  final Map<String, double> zones;
  final ThemeData theme;
  final double opacity;

  const _CompareSilhouettePainter({
    required this.zones,
    required this.theme,
    required this.opacity,
  });

  Color _zoneColor(String zone) {
    final val = zones[zone] ?? 0;
    if (zone == 'Haut du Corps') return const Color(0xFFFFD93D);
    if (val < 12) return const Color(0xFF00D4AA);
    if (val < 20) return const Color(0xFF74B9FF);
    if (val < 28) return const Color(0xFFFFB347);
    return const Color(0xFFFF6B6B);
  }

  Paint _fill(String zone) => Paint()
    ..color = _zoneColor(zone).withValues(alpha: opacity)
    ..style = PaintingStyle.fill;

  Paint get _outline => Paint()
    ..color = theme.colorScheme.onSurface.withValues(alpha: 0.12)
    ..style = PaintingStyle.stroke
    ..strokeWidth = 0.8;

  @override
  void paint(Canvas canvas, Size size) {
    final w = size.width;
    final h = size.height;

    // Head
    final headPaint = Paint()
      ..color = theme.colorScheme.onSurface.withValues(alpha: 0.18)
      ..style = PaintingStyle.fill;
    canvas.drawOval(
      Rect.fromCenter(
        center: Offset(w * 0.5, h * 0.07),
        width: w * 0.26,
        height: h * 0.13,
      ),
      headPaint,
    );

    // Neck
    final neckPath = Path()
      ..moveTo(w * 0.44, h * 0.132)
      ..lineTo(w * 0.56, h * 0.132)
      ..lineTo(w * 0.545, h * 0.165)
      ..lineTo(w * 0.455, h * 0.165)
      ..close();
    canvas.drawPath(
      neckPath,
      Paint()
        ..color = theme.colorScheme.onSurface.withValues(alpha: 0.14)
        ..style = PaintingStyle.fill,
    );

    // Torso
    final torsoPath = Path()
      ..moveTo(w * 0.22, h * 0.165)
      ..cubicTo(w * 0.18, h * 0.175, w * 0.16, h * 0.185, w * 0.20, h * 0.195)
      ..cubicTo(w * 0.22, h * 0.25, w * 0.24, h * 0.32, w * 0.26, h * 0.38)
      ..cubicTo(w * 0.27, h * 0.42, w * 0.28, h * 0.46, w * 0.30, h * 0.50)
      ..lineTo(w * 0.70, h * 0.50)
      ..cubicTo(w * 0.72, h * 0.46, w * 0.73, h * 0.42, w * 0.74, h * 0.38)
      ..cubicTo(w * 0.76, h * 0.32, w * 0.78, h * 0.25, w * 0.80, h * 0.195)
      ..cubicTo(w * 0.84, h * 0.185, w * 0.82, h * 0.175, w * 0.78, h * 0.195)
      ..close();
    canvas.drawPath(torsoPath, _fill('Haut du Corps'));
    canvas.drawPath(torsoPath, _outline);

    // Bras Gauche
    final leftArm = Path()
      ..moveTo(w * 0.22, h * 0.165)
      ..cubicTo(w * 0.12, h * 0.185, w * 0.07, h * 0.22, w * 0.04, h * 0.30)
      ..cubicTo(w * 0.02, h * 0.36, w * 0.03, h * 0.42, w * 0.06, h * 0.455)
      ..lineTo(w * 0.115, h * 0.455)
      ..cubicTo(w * 0.10, h * 0.42, w * 0.10, h * 0.36, w * 0.12, h * 0.30)
      ..cubicTo(w * 0.15, h * 0.23, w * 0.18, h * 0.20, w * 0.22, h * 0.195)
      ..close();
    canvas.drawPath(leftArm, _fill('Bras Gauche'));
    canvas.drawPath(leftArm, _outline);

    // Bras Droit
    final rightArm = Path()
      ..moveTo(w * 0.78, h * 0.165)
      ..cubicTo(w * 0.88, h * 0.185, w * 0.93, h * 0.22, w * 0.96, h * 0.30)
      ..cubicTo(w * 0.98, h * 0.36, w * 0.97, h * 0.42, w * 0.94, h * 0.455)
      ..lineTo(w * 0.885, h * 0.455)
      ..cubicTo(w * 0.90, h * 0.42, w * 0.90, h * 0.36, w * 0.88, h * 0.30)
      ..cubicTo(w * 0.85, h * 0.23, w * 0.82, h * 0.20, w * 0.78, h * 0.195)
      ..close();
    canvas.drawPath(rightArm, _fill('Bras Droit'));
    canvas.drawPath(rightArm, _outline);

    // Jambe Gauche
    final leftLeg = Path()
      ..moveTo(w * 0.29, h * 0.505)
      ..lineTo(w * 0.49, h * 0.505)
      ..cubicTo(w * 0.49, h * 0.58, w * 0.48, h * 0.65, w * 0.46, h * 0.72)
      ..cubicTo(w * 0.44, h * 0.80, w * 0.43, h * 0.87, w * 0.43, h * 0.93)
      ..lineTo(w * 0.36, h * 0.93)
      ..cubicTo(w * 0.35, h * 0.87, w * 0.33, h * 0.80, w * 0.32, h * 0.72)
      ..cubicTo(w * 0.28, h * 0.65, w * 0.28, h * 0.58, w * 0.29, h * 0.505)
      ..close();
    canvas.drawPath(leftLeg, _fill('Jambe Gauche'));
    canvas.drawPath(leftLeg, _outline);

    // Right Leg
    final rightLeg = Path()
      ..moveTo(w * 0.51, h * 0.505)
      ..lineTo(w * 0.71, h * 0.505)
      ..cubicTo(w * 0.72, h * 0.58, w * 0.71, h * 0.65, w * 0.68, h * 0.72)
      ..cubicTo(w * 0.67, h * 0.80, w * 0.65, h * 0.87, w * 0.64, h * 0.93)
      ..lineTo(w * 0.57, h * 0.93)
      ..cubicTo(w * 0.57, h * 0.87, w * 0.56, h * 0.80, w * 0.54, h * 0.72)
      ..cubicTo(w * 0.52, h * 0.65, w * 0.51, h * 0.58, w * 0.51, h * 0.505)
      ..close();
    canvas.drawPath(rightLeg, _fill('Jambe Droite'));
    canvas.drawPath(rightLeg, _outline);
  }

  @override
  bool shouldRepaint(_CompareSilhouettePainter old) =>
      old.zones != zones || old.opacity != opacity;
}
