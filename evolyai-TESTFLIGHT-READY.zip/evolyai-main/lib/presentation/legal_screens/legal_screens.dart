import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:sizer/sizer.dart';

class PrivacyPolicyScreen extends StatelessWidget {
  const PrivacyPolicyScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return _LegalScreen(
      title: 'Privacy Policy',
      lastUpdated: 'March 2025',
      sections: const [
        _LegalSection(
          heading: 'Introduction',
          body:
              'Evoly AI ("we", "our", or "us") is committed to protecting your personal information. This Privacy Policy explains how we collect, use, and safeguard your data when you use our application.',
        ),
        _LegalSection(
          heading: 'Information We Collect',
          body:
              'We collect information you provide directly, such as your name, email address, age, height, weight, and fitness goals during onboarding. We also collect body composition data derived from photos you submit for AI analysis.',
        ),
        _LegalSection(
          heading: 'How We Use Your Information',
          body:
              'Your data is used to:\n• Provide personalized body composition analysis\n• Track your progress over time\n• Improve our AI models and services\n• Send you relevant notifications (with your consent)\n• Comply with legal obligations',
        ),
        _LegalSection(
          heading: 'Data Storage & Security',
          body:
              'Your data is stored securely using Supabase infrastructure with industry-standard encryption. Photos submitted for analysis are processed and not permanently stored on our servers. We implement appropriate technical and organizational measures to protect your data.',
        ),
        _LegalSection(
          heading: 'Data Sharing',
          body:
              'We do not sell your personal data. We may share anonymized, aggregated data for research purposes. We may share data with service providers who assist in operating our application, subject to confidentiality agreements.',
        ),
        _LegalSection(
          heading: 'Your Rights',
          body:
              'You have the right to:\n• Access your personal data\n• Correct inaccurate data\n• Request deletion of your data\n• Withdraw consent at any time\n• Export your data\n\nTo exercise these rights, use the Settings screen or contact us at support@evolyai.com.',
        ),
        _LegalSection(
          heading: 'Cookies & Analytics',
          body:
              'We use minimal analytics to understand app usage patterns. No third-party advertising cookies are used. You can opt out of analytics in Settings.',
        ),
        _LegalSection(
          heading: 'Children\'s Privacy',
          body:
              'Our service is not directed to children under 13. We do not knowingly collect personal information from children under 13.',
        ),
        _LegalSection(
          heading: 'Changes to This Policy',
          body:
              'We may update this Privacy Policy from time to time. We will notify you of significant changes via the app or email.',
        ),
        _LegalSection(
          heading: 'Contact Us',
          body:
              'For privacy-related questions, contact us at:\nsupport@evolyai.com\n\nEvoly AI\nhttps://easybodyai8931.builtwithrocket.new',
        ),
      ],
    );
  }
}

class TermsOfUseScreen extends StatelessWidget {
  const TermsOfUseScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return _LegalScreen(
      title: 'Terms of Use',
      lastUpdated: 'March 2025',
      sections: const [
        _LegalSection(
          heading: 'Acceptance of Terms',
          body:
              'By downloading, installing, or using Evoly AI, you agree to be bound by these Terms of Use. If you do not agree to these terms, please do not use the application.',
        ),
        _LegalSection(
          heading: 'Description of Service',
          body:
              'Evoly AI provides AI-powered body composition analysis using photos. The service is intended for informational and fitness tracking purposes only and does not constitute medical advice.',
        ),
        _LegalSection(
          heading: 'User Accounts',
          body:
              'You must create an account to use Evoly AI. You are responsible for maintaining the confidentiality of your account credentials and for all activities that occur under your account.',
        ),
        _LegalSection(
          heading: 'Acceptable Use',
          body:
              'You agree not to:\n• Use the service for any unlawful purpose\n• Submit photos of other individuals without their consent\n• Attempt to reverse-engineer or hack the application\n• Use the service to harass or harm others\n• Misrepresent your identity or affiliation',
        ),
        _LegalSection(
          heading: 'AI Analysis Disclaimer',
          body:
              'Body composition estimates provided by Evoly AI are approximations based on AI analysis of photos. Results may vary and should not be used as a substitute for professional medical assessment. Always consult a healthcare professional for medical decisions.',
        ),
        _LegalSection(
          heading: 'Subscription & Payments',
          body:
              'Evoly AI offers free and premium subscription tiers. Premium features require a paid subscription. Subscriptions auto-renew unless cancelled. Refunds are handled in accordance with the applicable app store policies.',
        ),
        _LegalSection(
          heading: 'Intellectual Property',
          body:
              'All content, features, and functionality of Evoly AI are owned by us and protected by applicable intellectual property laws. You may not copy, modify, or distribute our content without permission.',
        ),
        _LegalSection(
          heading: 'Limitation of Liability',
          body:
              'To the maximum extent permitted by law, Evoly AI shall not be liable for any indirect, incidental, special, or consequential damages arising from your use of the service.',
        ),
        _LegalSection(
          heading: 'Termination',
          body:
              'We reserve the right to suspend or terminate your account if you violate these Terms. You may delete your account at any time from the Settings screen.',
        ),
        _LegalSection(
          heading: 'Governing Law',
          body:
              'These Terms are governed by applicable law. Any disputes shall be resolved through binding arbitration or in the courts of the applicable jurisdiction.',
        ),
        _LegalSection(
          heading: 'Contact',
          body:
              'For questions about these Terms, contact us at:\nsupport@evolyai.com',
        ),
      ],
    );
  }
}

class SupportScreen extends StatelessWidget {
  const SupportScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return _LegalScreen(
      title: 'Support',
      lastUpdated: null,
      sections: const [
        _LegalSection(
          heading: 'Contact Us',
          body:
              'We\'re here to help! Reach out to our support team:\n\n📧 Email: support@evolyai.com\n\nWe typically respond within 24–48 hours.',
        ),
        _LegalSection(
          heading: 'Frequently Asked Questions',
          body:
              'Q: How accurate is the body fat analysis?\nA: Our AI provides estimates with approximately ±3–5% accuracy compared to DEXA scans. Results are best used for tracking trends over time.\n\nQ: How often should I scan?\nA: We recommend scanning every 2–4 weeks for meaningful progress tracking.\n\nQ: Can I use Evoly AI without a premium subscription?\nA: Yes! The free tier includes basic body composition analysis. Premium unlocks detailed reports, progress charts, and unlimited scans.',
        ),
        _LegalSection(
          heading: 'Scan Tips',
          body:
              'For best results:\n• Wear form-fitting clothing or minimal clothing\n• Stand in good lighting against a plain background\n• Take front and side photos from the same distance\n• Scan at the same time of day for consistent results\n• Avoid scanning immediately after exercise or meals',
        ),
        _LegalSection(
          heading: 'Account Issues',
          body:
              'If you\'re having trouble with your account:\n• Forgot password: Use the "Forgot Password" option on the login screen\n• Delete account: Go to Settings → Delete Account\n• Export data: Go to Settings → Export My Data\n\nFor other account issues, contact support@evolyai.com',
        ),
        _LegalSection(
          heading: 'Technical Issues',
          body:
              'If the app is not working correctly:\n• Ensure you have a stable internet connection\n• Try closing and reopening the app\n• Check that your app is up to date\n• Restart your device\n\nIf issues persist, please email us with a description of the problem and your device model.',
        ),
        _LegalSection(
          heading: 'Privacy & Data',
          body:
              'For questions about your data or to request data deletion, please review our Privacy Policy or contact us at support@evolyai.com.\n\nYou can also delete your account and all associated data directly from Settings.',
        ),
      ],
    );
  }
}

// ─── Shared Legal Screen Layout ───────────────────────────────────────────────

class _LegalScreen extends StatelessWidget {
  final String title;
  final String? lastUpdated;
  final List<_LegalSection> sections;

  const _LegalScreen({
    required this.title,
    required this.lastUpdated,
    required this.sections,
  });

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Scaffold(
      backgroundColor: theme.scaffoldBackgroundColor,
      body: SafeArea(
        child: Column(
          children: [
            // Header
            Padding(
              padding: EdgeInsets.symmetric(horizontal: 4.w, vertical: 1.5.h),
              child: Row(
                children: [
                  GestureDetector(
                    onTap: () => Navigator.of(context).pop(),
                    child: Container(
                      width: 10.w,
                      height: 10.w,
                      decoration: BoxDecoration(
                        color: const Color(0xFFF8F9FA),
                        borderRadius: BorderRadius.circular(50),
                        border: Border.all(color: const Color(0xFFE2E8F0)),
                      ),
                      child: const Icon(
                        Icons.arrow_back_ios_new_rounded,
                        size: 16,
                        color: Color(0xFF2D3436),
                      ),
                    ),
                  ),
                  SizedBox(width: 3.w),
                  Expanded(
                    child: Text(
                      title,
                      style: GoogleFonts.dmSans(
                        fontSize: 16.sp > 20 ? 20 : 16.sp,
                        fontWeight: FontWeight.w700,
                        color: theme.colorScheme.onSurface,
                      ),
                    ),
                  ),
                ],
              ),
            ),
            const Divider(height: 1),
            // Content
            Expanded(
              child: ListView(
                padding: EdgeInsets.symmetric(horizontal: 4.w, vertical: 2.h),
                children: [
                  if (lastUpdated != null) ...[
                    Text(
                      'Last updated: $lastUpdated',
                      style: GoogleFonts.dmSans(
                        fontSize: 10.sp > 12 ? 12 : 10.sp,
                        color: const Color(0xFFB2BEC3),
                      ),
                    ),
                    SizedBox(height: 2.h),
                  ],
                  ...sections.map((s) => _SectionWidget(section: s)),
                  SizedBox(height: 4.h),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _LegalSection {
  final String heading;
  final String body;
  const _LegalSection({required this.heading, required this.body});
}

class _SectionWidget extends StatelessWidget {
  final _LegalSection section;
  const _SectionWidget({required this.section});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsets.only(bottom: 2.5.h),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            section.heading,
            style: GoogleFonts.dmSans(
              fontSize: 13.sp > 16 ? 16 : 13.sp,
              fontWeight: FontWeight.w700,
              color: const Color(0xFF1B365D),
            ),
          ),
          SizedBox(height: 0.8.h),
          Text(
            section.body,
            style: GoogleFonts.dmSans(
              fontSize: 11.sp > 14 ? 14 : 11.sp,
              fontWeight: FontWeight.w400,
              color: const Color(0xFF636E72),
              height: 1.6,
            ),
          ),
        ],
      ),
    );
  }
}
