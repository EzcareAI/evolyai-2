import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:sizer/sizer.dart';

import '../../models/onboarding_data.dart';
import '../goal_selection_screen/widgets/onboarding_progress_widget.dart';
import '../../routes/app_routes.dart';

// ─── Brand Colors ─────────────────────────────────────────────────────────────
const _kPurple = Color(0xFF7C5CFC);
const _kPurpleLight = Color(0xFF9B7FFF);
const _kPurpleDark = Color(0xFF5A3FD6);
const _kPurpleGlow = Color(0xFF6C5CE7);
const _kBg = Color(0xFF0E0A1F);
const _kCard = Color(0xFF16112E);
const _kCardBorder = Color(0xFF2A2050);
const _kFaded = Color(0xFF4A3F6B);
const _kNegative = Color(0xFF6B5B8A);
const _kNegativeLight = Color(0xFF8B7BAA);

class GreatStartDopamineScreen extends StatefulWidget {
  final OnboardingData? onboardingData;

  const GreatStartDopamineScreen({super.key, this.onboardingData});

  @override
  State<GreatStartDopamineScreen> createState() =>
      _GreatStartDopamineScreenState();
}

class _GreatStartDopamineScreenState extends State<GreatStartDopamineScreen>
    with TickerProviderStateMixin {
  late AnimationController _controller;
  late AnimationController _glowController;
  late Animation<double> _fadeAnimation;
  late Animation<double> _slideAnimation;
  late Animation<double> _lineAnimation;
  late Animation<double> _labelAnimation;
  late Animation<double> _glowAnimation;

  @override
  void initState() {
    super.initState();
    HapticFeedback.lightImpact();

    _controller = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 2200),
    );

    _glowController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 2000),
    )..repeat(reverse: true);

    _fadeAnimation = CurvedAnimation(
      parent: _controller,
      curve: const Interval(0.0, 0.3, curve: Curves.easeOut),
    );
    _slideAnimation = CurvedAnimation(
      parent: _controller,
      curve: const Interval(0.0, 0.35, curve: Curves.easeOutCubic),
    );
    _lineAnimation = CurvedAnimation(
      parent: _controller,
      curve: const Interval(0.15, 0.85, curve: Curves.easeInOut),
    );
    _labelAnimation = CurvedAnimation(
      parent: _controller,
      curve: const Interval(0.82, 1.0, curve: Curves.easeOutBack),
    );
    _glowAnimation = CurvedAnimation(
      parent: _glowController,
      curve: Curves.easeInOut,
    );

    _controller.forward();
  }

  @override
  void dispose() {
    _controller.dispose();
    _glowController.dispose();
    super.dispose();
  }

  void _onContinue() {
    HapticFeedback.mediumImpact();
    Navigator.of(
      context,
    ).pushNamed(AppRoutes.activityLevel, arguments: widget.onboardingData);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _kBg,
      body: SafeArea(
        child: Column(
          children: [
            // ── Header ──
            Padding(
              padding: EdgeInsets.fromLTRB(5.w, 2.h, 5.w, 0),
              child: FadeTransition(
                opacity: _fadeAnimation,
                child: Row(
                  children: [
                    GestureDetector(
                      onTap: () {
                        HapticFeedback.lightImpact();
                        Navigator.of(context).pop();
                      },
                      child: Container(
                        width: 10.w,
                        height: 10.w,
                        decoration: BoxDecoration(
                          color: _kCard,
                          borderRadius: BorderRadius.circular(50),
                          border: Border.all(color: _kCardBorder, width: 1),
                        ),
                        child: const Icon(
                          Icons.arrow_back_ios_new_rounded,
                          color: Colors.white70,
                          size: 15,
                        ),
                      ),
                    ),
                    SizedBox(width: 3.w),
                    Expanded(
                      child: OnboardingProgressWidget(
                        currentStep: 7,
                        totalSteps: 16,
                      ),
                    ),
                  ],
                ),
              ),
            ),

            SizedBox(height: 3.h),

            // ── Title block ──
            Padding(
              padding: EdgeInsets.symmetric(horizontal: 5.w),
              child: AnimatedBuilder(
                animation: _slideAnimation,
                builder: (context, child) {
                  return Opacity(
                    opacity: _slideAnimation.value.clamp(0.0, 1.0),
                    child: Transform.translate(
                      offset: Offset(0, 20 * (1 - _slideAnimation.value)),
                      child: child,
                    ),
                  );
                },
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    // Pill badge
                    Container(
                      padding: const EdgeInsets.symmetric(
                        horizontal: 12,
                        vertical: 5,
                      ),
                      decoration: BoxDecoration(
                        gradient: const LinearGradient(
                          colors: [Color(0xFF7C5CFC), Color(0xFF5A3FD6)],
                        ),
                        borderRadius: BorderRadius.circular(50),
                      ),
                      child: Text(
                        'Proven Results',
                        style: GoogleFonts.dmSans(
                          fontSize: 9.sp > 11 ? 11 : 9.sp,
                          fontWeight: FontWeight.w600,
                          color: Colors.white,
                          letterSpacing: 0.3,
                        ),
                      ),
                    ),
                    SizedBox(height: 1.2.h),
                    RichText(
                      text: TextSpan(
                        children: [
                          TextSpan(
                            text: 'Evoly AI\n',
                            style: GoogleFonts.dmSans(
                              fontSize: 17.sp > 26 ? 26 : 17.sp,
                              fontWeight: FontWeight.w800,
                              color: _kPurpleLight,
                              height: 1.1,
                              letterSpacing: -0.5,
                            ),
                          ),
                          TextSpan(
                            text: 'changes everything long-term',
                            style: GoogleFonts.dmSans(
                              fontSize: 17.sp > 26 ? 26 : 17.sp,
                              fontWeight: FontWeight.w800,
                              color: Colors.white,
                              height: 1.1,
                              letterSpacing: -0.5,
                            ),
                          ),
                        ],
                      ),
                    ),
                    SizedBox(height: 0.8.h),
                    Text(
                      'See the difference AI makes on your body composition',
                      style: GoogleFonts.dmSans(
                        fontSize: 10.sp > 13 ? 13 : 10.sp,
                        fontWeight: FontWeight.w400,
                        color: Colors.white54,
                        height: 1.4,
                      ),
                    ),
                  ],
                ),
              ),
            ),

            SizedBox(height: 2.5.h),

            // ── Chart card ──
            Expanded(
              child: Padding(
                padding: EdgeInsets.symmetric(horizontal: 4.w),
                child: AnimatedBuilder(
                  animation: _fadeAnimation,
                  builder: (context, child) => Opacity(
                    opacity: _fadeAnimation.value.clamp(0.0, 1.0),
                    child: child,
                  ),
                  child: Container(
                    width: double.infinity,
                    padding: EdgeInsets.fromLTRB(4.w, 2.5.h, 4.w, 2.h),
                    decoration: BoxDecoration(
                      color: _kCard,
                      borderRadius: BorderRadius.circular(24.0),
                      border: Border.all(color: _kCardBorder, width: 1),
                      boxShadow: [
                        BoxShadow(
                          color: _kPurple.withValues(alpha: 0.12),
                          blurRadius: 30,
                          spreadRadius: 0,
                          offset: const Offset(0, 8),
                        ),
                      ],
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        // Card header
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Text(
                              '% Masse Grasse',
                              style: GoogleFonts.dmSans(
                                fontSize: 11.sp > 14 ? 14 : 11.sp,
                                fontWeight: FontWeight.w700,
                                color: Colors.white,
                              ),
                            ),
                            Container(
                              padding: const EdgeInsets.symmetric(
                                horizontal: 10,
                                vertical: 4,
                              ),
                              decoration: BoxDecoration(
                                color: _kPurple.withValues(alpha: 0.15),
                                borderRadius: BorderRadius.circular(20),
                                border: Border.all(
                                  color: _kPurple.withValues(alpha: 0.3),
                                  width: 1,
                                ),
                              ),
                              child: Text(
                                '6 months',
                                style: GoogleFonts.dmSans(
                                  fontSize: 8.sp > 10 ? 10 : 8.sp,
                                  fontWeight: FontWeight.w600,
                                  color: _kPurpleLight,
                                ),
                              ),
                            ),
                          ],
                        ),

                        SizedBox(height: 2.h),

                        // Chart area
                        Expanded(
                          child: AnimatedBuilder(
                            animation: Listenable.merge([
                              _lineAnimation,
                              _labelAnimation,
                              _glowAnimation,
                            ]),
                            builder: (context, _) {
                              return CustomPaint(
                                painter: _PremiumChartPainter(
                                  lineProgress: _lineAnimation.value,
                                  labelProgress: _labelAnimation.value,
                                  glowPulse: _glowAnimation.value,
                                ),
                                size: Size.infinite,
                              );
                            },
                          ),
                        ),

                        SizedBox(height: 1.5.h),

                        // X-axis labels
                        Padding(
                          padding: EdgeInsets.symmetric(horizontal: 1.w),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              _xLabel('Now'),
                              _xLabel('Month 2'),
                              _xLabel('Month 4'),
                              _xLabel('Month 6'),
                            ],
                          ),
                        ),

                        SizedBox(height: 2.h),

                        // Legend row
                        Row(
                          children: [
                            _LegendDot(color: _kPurple, label: 'Avec Evoly AI'),
                            SizedBox(width: 5.w),
                            _LegendDot(
                              color: _kNegativeLight,
                              label: 'Without Evoly AI',
                              faded: true,
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ),

            SizedBox(height: 2.h),

            // ── Bottom CTA ──
            Padding(
              padding: EdgeInsets.fromLTRB(5.w, 0, 5.w, 2.h),
              child: FadeTransition(
                opacity: _fadeAnimation,
                child: Column(
                  children: [
                    // Trust line
                    Text(
                      '78% of users maintain their results 6 months after',
                      textAlign: TextAlign.center,
                      style: GoogleFonts.dmSans(
                        fontSize: 9.sp > 11 ? 11 : 9.sp,
                        fontWeight: FontWeight.w400,
                        color: Colors.white38,
                        height: 1.5,
                      ),
                    ),
                    SizedBox(height: 1.5.h),
                    // Continue button
                    AnimatedBuilder(
                      animation: _glowAnimation,
                      builder: (context, child) {
                        return Container(
                          width: double.infinity,
                          height: 6.5.h,
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(50),
                            boxShadow: [
                              BoxShadow(
                                color: _kPurple.withValues(
                                  alpha: 0.35 + 0.15 * _glowAnimation.value,
                                ),
                                blurRadius: 20 + 8 * _glowAnimation.value,
                                spreadRadius: 0,
                              ),
                            ],
                          ),
                          child: child,
                        );
                      },
                      child: ElevatedButton(
                        onPressed: _onContinue,
                        style: ElevatedButton.styleFrom(
                          backgroundColor: _kPurple,
                          foregroundColor: Colors.white,
                          elevation: 0,
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(50.0),
                          ),
                        ),
                        child: Text(
                          'Continue',
                          style: GoogleFonts.dmSans(
                            fontSize: 13.sp > 16 ? 16 : 13.sp,
                            fontWeight: FontWeight.w700,
                            color: Colors.white,
                            letterSpacing: 0.2,
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _xLabel(String text) {
    return Text(
      text,
      style: GoogleFonts.dmSans(
        fontSize: 8.sp > 10 ? 10 : 8.sp,
        fontWeight: FontWeight.w500,
        color: Colors.white30,
      ),
    );
  }
}

// ─── Premium Chart Painter ────────────────────────────────────────────────────

class _PremiumChartPainter extends CustomPainter {
  final double lineProgress;
  final double labelProgress;
  final double glowPulse;

  _PremiumChartPainter({
    required this.lineProgress,
    required this.labelProgress,
    required this.glowPulse,
  });

  // Evaluate a cubic bezier at parameter t
  Offset _cubicBezier(Offset p0, Offset p1, Offset p2, Offset p3, double t) {
    final mt = 1 - t;
    return Offset(
      mt * mt * mt * p0.dx +
          3 * mt * mt * t * p1.dx +
          3 * mt * t * t * p2.dx +
          t * t * t * p3.dx,
      mt * mt * mt * p0.dy +
          3 * mt * mt * t * p1.dy +
          3 * mt * t * t * p2.dy +
          t * t * t * p3.dy,
    );
  }

  // Build a partial cubic bezier path up to progress [0..1]
  Path _partialCubicPath(
    Offset p0,
    Offset p1,
    Offset p2,
    Offset p3,
    double progress,
  ) {
    final path = Path();
    if (progress <= 0) return path;
    final steps = 60;
    final maxT = progress.clamp(0.0, 1.0);
    path.moveTo(p0.dx, p0.dy);
    for (int i = 1; i <= steps; i++) {
      final t = (i / steps) * maxT;
      final pt = _cubicBezier(p0, p1, p2, p3, t);
      path.lineTo(pt.dx, pt.dy);
    }
    return path;
  }

  @override
  void paint(Canvas canvas, Size size) {
    final w = size.width;
    final h = size.height;

    // ── Grid lines (subtle) ──
    final gridPaint = Paint()
      ..color = Colors.white.withValues(alpha: 0.05)
      ..strokeWidth = 1;
    for (int i = 1; i <= 3; i++) {
      final y = h * i / 4;
      canvas.drawLine(Offset(0, y), Offset(w, y), gridPaint);
    }

    // ── Curve definitions ──
    // Both start at same point (left, middle-ish)
    final start = Offset(0, h * 0.42);

    // "With Evoly AI" — purple — goes DOWN (body fat decreasing = good)
    // Ends well below center, crosses the other line around 40% width
    final aiEnd = Offset(w, h * 0.88);
    final aiCtrl1 = Offset(w * 0.28, h * 0.42); // stays flat initially
    final aiCtrl2 = Offset(w * 0.55, h * 0.78); // then curves down strongly

    // "Without Evoly AI" — faded purple — goes UP (body fat increasing = bad)
    // Ends above center, crosses the AI line around 40% width
    final noAiEnd = Offset(w, h * 0.08);
    final noAiCtrl1 = Offset(w * 0.28, h * 0.42); // same start direction
    final noAiCtrl2 = Offset(w * 0.55, h * 0.18); // curves up strongly

    // ── Draw "Without AI" fill (very subtle) ──
    if (lineProgress > 0.02) {
      final fillPath = _partialCubicPath(
        start,
        noAiCtrl1,
        noAiCtrl2,
        noAiEnd,
        lineProgress,
      );
      final currentEnd = _cubicBezier(
        start,
        noAiCtrl1,
        noAiCtrl2,
        noAiEnd,
        lineProgress,
      );
      fillPath.lineTo(currentEnd.dx, h);
      fillPath.lineTo(0, h);
      fillPath.close();

      final fillPaint = Paint()
        ..shader = LinearGradient(
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
          colors: [
            _kNegative.withValues(alpha: 0.12),
            _kNegative.withValues(alpha: 0.0),
          ],
        ).createShader(Rect.fromLTWH(0, 0, w, h))
        ..style = PaintingStyle.fill;
      canvas.drawPath(fillPath, fillPaint);
    }

    // ── Draw "With AI" fill (purple gradient) ──
    if (lineProgress > 0.02) {
      final fillPath = _partialCubicPath(
        start,
        aiCtrl1,
        aiCtrl2,
        aiEnd,
        lineProgress,
      );
      final currentEnd = _cubicBezier(
        start,
        aiCtrl1,
        aiCtrl2,
        aiEnd,
        lineProgress,
      );
      fillPath.lineTo(currentEnd.dx, h);
      fillPath.lineTo(0, h);
      fillPath.close();

      final fillPaint = Paint()
        ..shader = LinearGradient(
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
          colors: [
            _kPurple.withValues(alpha: 0.22),
            _kPurple.withValues(alpha: 0.0),
          ],
        ).createShader(Rect.fromLTWH(0, 0, w, h))
        ..style = PaintingStyle.fill;
      canvas.drawPath(fillPath, fillPaint);
    }

    // ── Draw "Without AI" line (dashed, faded) ──
    final noAiPath = _partialCubicPath(
      start,
      noAiCtrl1,
      noAiCtrl2,
      noAiEnd,
      lineProgress,
    );
    final noAiPaint = Paint()
      ..color = _kNegativeLight.withValues(alpha: 0.7)
      ..strokeWidth = 2.0
      ..style = PaintingStyle.stroke
      ..strokeCap = StrokeCap.round;

    // Draw as dashed line
    _drawDashedPath(canvas, noAiPath, noAiPaint, dashLength: 8, gapLength: 5);

    // ── Draw "With AI" line (solid purple with glow) ──
    final aiPath = _partialCubicPath(
      start,
      aiCtrl1,
      aiCtrl2,
      aiEnd,
      lineProgress,
    );

    // Glow layer
    final aiGlowPaint = Paint()
      ..color = _kPurple.withValues(alpha: 0.25 + 0.1 * glowPulse)
      ..strokeWidth = 7.0
      ..style = PaintingStyle.stroke
      ..strokeCap = StrokeCap.round
      ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 6);
    canvas.drawPath(aiPath, aiGlowPaint);

    // Main line
    final aiPaint = Paint()
      ..shader = LinearGradient(
        begin: Alignment.centerLeft,
        end: Alignment.centerRight,
        colors: [_kPurpleLight, _kPurple, _kPurpleDark],
      ).createShader(Rect.fromLTWH(0, 0, w, h))
      ..strokeWidth = 3.0
      ..style = PaintingStyle.stroke
      ..strokeCap = StrokeCap.round;
    canvas.drawPath(aiPath, aiPaint);

    // ── Start dot ──
    _drawDot(
      canvas,
      start,
      _kPurpleLight,
      5.5,
      Colors.white.withValues(alpha: 0.9),
    );

    // ── End dots + labels (appear after animation) ──
    if (lineProgress >= 0.98) {
      final aiCurrentEnd = _cubicBezier(start, aiCtrl1, aiCtrl2, aiEnd, 1.0);
      final noAiCurrentEnd = _cubicBezier(
        start,
        noAiCtrl1,
        noAiCtrl2,
        noAiEnd,
        1.0,
      );

      // AI end dot
      _drawDot(
        canvas,
        aiCurrentEnd,
        _kPurple,
        5.5,
        Colors.white.withValues(alpha: 0.95),
      );

      // No-AI end dot
      _drawDot(
        canvas,
        noAiCurrentEnd,
        _kNegativeLight,
        4.5,
        Colors.white.withValues(alpha: 0.7),
      );

      // Labels with scale animation
      if (labelProgress > 0) {
        final scale = labelProgress.clamp(0.0, 1.0);

        // AI label: "-8% body fat"
        _drawEndLabel(
          canvas,
          aiCurrentEnd,
          '-8%',
          'body fat',
          _kPurple,
          _kPurpleLight,
          scale,
          alignLeft: false,
          above: false,
        );

        // No-AI label: "+2%"
        _drawEndLabel(
          canvas,
          noAiCurrentEnd,
          '+2%',
          'no tracking',
          _kNegative,
          _kNegativeLight,
          scale,
          alignLeft: false,
          above: true,
        );
      }
    }
  }

  void _drawDot(
    Canvas canvas,
    Offset center,
    Color borderColor,
    double radius,
    Color fillColor,
  ) {
    final fill = Paint()
      ..color = fillColor
      ..style = PaintingStyle.fill;
    final border = Paint()
      ..color = borderColor
      ..style = PaintingStyle.stroke
      ..strokeWidth = 2;
    canvas.drawCircle(center, radius, fill);
    canvas.drawCircle(center, radius, border);
  }

  void _drawEndLabel(
    Canvas canvas,
    Offset anchor,
    String mainText,
    String subText,
    Color bgColor,
    Color textColor,
    double scale, {
    required bool alignLeft,
    required bool above,
  }) {
    final mainSpan = TextSpan(
      text: mainText,
      style: GoogleFonts.dmSans(
        fontSize: 13,
        fontWeight: FontWeight.w800,
        color: textColor,
      ),
    );
    final subSpan = TextSpan(
      text: subText,
      style: GoogleFonts.dmSans(
        fontSize: 9,
        fontWeight: FontWeight.w500,
        color: textColor.withValues(alpha: 0.75),
      ),
    );

    final mainPainter = TextPainter(
      text: mainSpan,
      textDirection: TextDirection.ltr,
    )..layout();
    final subPainter = TextPainter(
      text: subSpan,
      textDirection: TextDirection.ltr,
    )..layout();

    final labelW = math.max(mainPainter.width, subPainter.width) + 16;
    final labelH = mainPainter.height + subPainter.height + 10;

    final offsetX = alignLeft ? -(labelW + 10) : -(labelW / 2);
    final offsetY = above ? -(labelH + 12) : 12.0;

    final rect = Rect.fromLTWH(
      anchor.dx + offsetX,
      anchor.dy + offsetY,
      labelW,
      labelH,
    );

    canvas.save();
    canvas.translate(rect.center.dx, rect.center.dy);
    canvas.scale(scale);
    canvas.translate(-rect.center.dx, -rect.center.dy);

    // Background pill
    final bgPaint = Paint()
      ..color = bgColor.withValues(alpha: 0.85)
      ..style = PaintingStyle.fill;
    final borderPaint = Paint()
      ..color = textColor.withValues(alpha: 0.4)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1;

    final rrect = RRect.fromRectAndRadius(rect, const Radius.circular(10));
    canvas.drawRRect(rrect, bgPaint);
    canvas.drawRRect(rrect, borderPaint);

    // Main text
    mainPainter.paint(
      canvas,
      Offset(rect.left + (labelW - mainPainter.width) / 2, rect.top + 5),
    );
    // Sub text
    subPainter.paint(
      canvas,
      Offset(
        rect.left + (labelW - subPainter.width) / 2,
        rect.top + 5 + mainPainter.height + 2,
      ),
    );

    canvas.restore();
  }

  void _drawDashedPath(
    Canvas canvas,
    Path path,
    Paint paint, {
    double dashLength = 10,
    double gapLength = 5,
  }) {
    final metrics = path.computeMetrics();
    for (final metric in metrics) {
      double distance = 0;
      bool draw = true;
      while (distance < metric.length) {
        final len = draw ? dashLength : gapLength;
        final end = (distance + len).clamp(0.0, metric.length);
        if (draw) {
          canvas.drawPath(metric.extractPath(distance, end), paint);
        }
        distance += len;
        draw = !draw;
      }
    }
  }

  @override
  bool shouldRepaint(_PremiumChartPainter old) =>
      old.lineProgress != lineProgress ||
      old.labelProgress != labelProgress ||
      old.glowPulse != glowPulse;
}

// ─── Legend Dot ───────────────────────────────────────────────────────────────

class _LegendDot extends StatelessWidget {
  final Color color;
  final String label;
  final bool faded;

  const _LegendDot({
    required this.color,
    required this.label,
    this.faded = false,
  });

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        Container(
          width: 8,
          height: 8,
          decoration: BoxDecoration(
            color: faded ? Colors.transparent : color,
            shape: BoxShape.circle,
            border: Border.all(color: color, width: faded ? 1.5 : 0),
          ),
        ),
        const SizedBox(width: 6),
        Text(
          label,
          style: GoogleFonts.dmSans(
            fontSize: 9.sp > 11 ? 11 : 9.sp,
            fontWeight: FontWeight.w500,
            color: faded ? Colors.white38 : Colors.white70,
          ),
        ),
      ],
    );
  }
}
