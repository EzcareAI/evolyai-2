import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:sizer/sizer.dart';

class AnimatedProgressBarWidget extends StatefulWidget {
  final double targetProgress;
  final Duration duration;

  const AnimatedProgressBarWidget({
    super.key,
    required this.targetProgress,
    this.duration = const Duration(milliseconds: 1200),
  });

  @override
  State<AnimatedProgressBarWidget> createState() =>
      _AnimatedProgressBarWidgetState();
}

class _AnimatedProgressBarWidgetState extends State<AnimatedProgressBarWidget>
    with SingleTickerProviderStateMixin {
  late AnimationController _controller;
  late Animation<double> _progressAnimation;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(vsync: this, duration: widget.duration);
    _progressAnimation = Tween<double>(
      begin: 0.0,
      end: widget.targetProgress,
    ).animate(CurvedAnimation(parent: _controller, curve: Curves.easeOutCubic));
    Future.delayed(const Duration(milliseconds: 300), () {
      if (mounted) _controller.forward();
    });
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: _progressAnimation,
      builder: (context, child) {
        final percent = (_progressAnimation.value * 100).round();
        return Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  'Progress',
                  style: GoogleFonts.plusJakartaSans(
                    fontSize: 12.sp > 14 ? 14 : 12.sp,
                    fontWeight: FontWeight.w500,
                    color: const Color(0xFF636E72),
                  ),
                ),
                Text(
                  '$percent%',
                  style: GoogleFonts.plusJakartaSans(
                    fontSize: 14.sp > 18 ? 18 : 14.sp,
                    fontWeight: FontWeight.w800,
                    color: const Color(0xFF6C5CE7),
                  ),
                ),
              ],
            ),
            SizedBox(height: 1.2.h),
            Container(
              height: 14,
              decoration: BoxDecoration(
                color: const Color(0xFFEDE9FE),
                borderRadius: BorderRadius.circular(20.0),
              ),
              child: Stack(
                children: [
                  FractionallySizedBox(
                    widthFactor: _progressAnimation.value,
                    child: Container(
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(20.0),
                        gradient: const LinearGradient(
                          colors: [Color(0xFF6C5CE7), Color(0xFFA78BFA)],
                          begin: Alignment.centerLeft,
                          end: Alignment.centerRight,
                        ),
                        boxShadow: [
                          BoxShadow(
                            color: const Color(
                              0xFF6C5CE7,
                            ).withValues(alpha: 0.5),
                            blurRadius: 8,
                            offset: const Offset(0, 2),
                          ),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],
        );
      },
    );
  }
}
