import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

class FloatingParticleWidget extends StatefulWidget {
  final double size;
  final Color color;
  final Duration duration;
  final Offset startOffset;

  const FloatingParticleWidget({
    super.key,
    required this.size,
    required this.color,
    required this.duration,
    required this.startOffset,
  });

  @override
  State<FloatingParticleWidget> createState() => _FloatingParticleWidgetState();
}

class _FloatingParticleWidgetState extends State<FloatingParticleWidget>
    with SingleTickerProviderStateMixin {
  late AnimationController _controller;
  late Animation<double> _opacityAnimation;
  late Animation<Offset> _positionAnimation;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(vsync: this, duration: widget.duration)
      ..repeat(reverse: true);
    _opacityAnimation = Tween<double>(
      begin: 0.0,
      end: 0.7,
    ).animate(CurvedAnimation(parent: _controller, curve: Curves.easeInOut));
    _positionAnimation = Tween<Offset>(
      begin: widget.startOffset,
      end: widget.startOffset + const Offset(0, -0.05),
    ).animate(CurvedAnimation(parent: _controller, curve: Curves.easeInOut));
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return SlideTransition(
      position: _positionAnimation,
      child: FadeTransition(
        opacity: _opacityAnimation,
        child: Container(
          width: widget.size,
          height: widget.size,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            color: widget.color,
          ),
        ),
      ),
    );
  }
}

class CelebrationParticlesWidget extends StatelessWidget {
  const CelebrationParticlesWidget({super.key});

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: double.infinity,
      height: 20.h,
      child: Stack(
        children: [
          Positioned(
            left: 10.w,
            top: 2.h,
            child: FloatingParticleWidget(
              size: 8,
              color: const Color(0xFF6C5CE7).withValues(alpha: 0.6),
              duration: const Duration(milliseconds: 1800),
              startOffset: Offset.zero,
            ),
          ),
          Positioned(
            left: 25.w,
            top: 5.h,
            child: FloatingParticleWidget(
              size: 5,
              color: const Color(0xFFA78BFA).withValues(alpha: 0.5),
              duration: const Duration(milliseconds: 2200),
              startOffset: Offset.zero,
            ),
          ),
          Positioned(
            right: 15.w,
            top: 1.h,
            child: FloatingParticleWidget(
              size: 10,
              color: const Color(0xFF6C5CE7).withValues(alpha: 0.4),
              duration: const Duration(milliseconds: 2000),
              startOffset: Offset.zero,
            ),
          ),
          Positioned(
            right: 30.w,
            top: 8.h,
            child: FloatingParticleWidget(
              size: 6,
              color: const Color(0xFFDDD6FE).withValues(alpha: 0.8),
              duration: const Duration(milliseconds: 1600),
              startOffset: Offset.zero,
            ),
          ),
          Positioned(
            left: 45.w,
            top: 3.h,
            child: FloatingParticleWidget(
              size: 4,
              color: const Color(0xFF6C5CE7).withValues(alpha: 0.5),
              duration: const Duration(milliseconds: 2400),
              startOffset: Offset.zero,
            ),
          ),
          Center(
            child: Container(
              width: 28.w,
              height: 28.w,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                gradient: RadialGradient(
                  colors: [
                    const Color(0xFF6C5CE7).withValues(alpha: 0.15),
                    const Color(0xFF6C5CE7).withValues(alpha: 0.0),
                  ],
                ),
              ),
              child: Center(
                child: Text(
                  '🎉',
                  style: TextStyle(fontSize: 16.sp > 40 ? 40 : 16.sp),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
