import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:sizer/sizer.dart';

import '../../core/app_export.dart';
import '../../models/onboarding_data.dart';
import '../../services/local_cache_service.dart';
import '../../services/supabase_service.dart';
import '../../services/sync_service.dart';
import './widgets/badges_section_widget.dart';
import './widgets/body_analysis_module_widget.dart';
import './widgets/premium_report_widget.dart';
import './widgets/quick_stats_row_widget.dart';
import './widgets/split_hero_card_widget.dart';
import './widgets/unlock_banner_widget.dart';

class HomeDashboardInitialPage extends StatefulWidget {
  final OnboardingData? onboardingData;

  const HomeDashboardInitialPage({super.key, this.onboardingData});

  @override
  State<HomeDashboardInitialPage> createState() =>
      _HomeDashboardInitialPageState();
}

class _HomeDashboardInitialPageState extends State<HomeDashboardInitialPage> {
  bool _isRefreshing = false;
  bool _isPremium = false;
  bool _isLoading = true;
  bool _hasScans = false;

  ScanResultModel? _latestResult;
  ProfileModel? _profile;

  // Milestone states
  bool _hasFirstScan = false;
  bool _hasSevenDayStreak = false;
  bool _hasConsistentProgress = false;
  bool _hasGoalReached = false;

  StreamSubscription<List<ScanResultModel>>? _scanStreamSub;

  @override
  void initState() {
    super.initState();
    _loadData();
    _subscribeScanStream();
  }

  void _subscribeScanStream() {
    _scanStreamSub = SupabaseService.instance.watchScanResults().listen((
      results,
    ) {
      // Only reload when a new scan arrives (list grew or first result changed)
      final newLatest = results.isNotEmpty ? results.first : null;
      final currentId = _latestResult?.id;
      if (newLatest?.id != currentId) {
        debugPrint('[Home] Real-time scan update detected — reloading');
        _loadData();
      }
    }, onError: (e) => debugPrint('[Home] scan stream error: $e'));
  }

  @override
  void dispose() {
    _scanStreamSub?.cancel();
    super.dispose();
  }

  Future<void> _loadData() async {
    setState(() => _isLoading = true);
    try {
      // If we arrived from onboarding and the scan result was already saved
      // during AI processing, seed the state immediately so the dashboard
      // renders the real data without waiting for a Supabase round-trip.
      final incomingScan = widget.onboardingData?.scanResult;
      if (incomingScan != null && _latestResult == null) {
        debugPrint(
          '[Home] Using onboarding scanResult directly: id=${incomingScan.id}, bodyFat=${incomingScan.bodyFatPercent}',
        );
        setState(() {
          _latestResult = incomingScan;
          _hasScans = true;
        });
      }

      final results = await Future.wait([
        SupabaseService.instance.fetchLatestScanResult(),
        SupabaseService.instance.fetchProfile(),
        SupabaseService.instance.checkSubscriptionStatus(),
        SupabaseService.instance.fetchScanHistory(limit: 30),
      ]);
      if (mounted) {
        // Prefer the freshly fetched result; fall back to the onboarding scan
        // that was seeded above if Supabase still hasn't propagated the row.
        ScanResultModel? fetchedResult = results[0] as ScanResultModel?;

        // If Supabase returned null (or an empty result) but we came from onboarding,
        // retry — the row may still be propagating.
        final bool needsRetry = (fetchedResult == null ||
            (fetchedResult.bodyFatPercent ?? 0) <= 0) &&
            widget.onboardingData != null;
        if (needsRetry) {
          const retryDelays = [2, 4, 6]; // seconds
          for (final delay in retryDelays) {
            if (!mounted) break;
            debugPrint(
              '[Home] fetchLatestScanResult returned null after onboarding — retrying in ${delay}s',
            );
            await Future.delayed(Duration(seconds: delay));
            if (!mounted) break;
            fetchedResult = await SupabaseService.instance
                .fetchLatestScanResult();
            if (fetchedResult != null) {
              debugPrint(
                '[Home] Retry succeeded: found scan id=${fetchedResult.id}',
              );
              break;
            }
          }
        }

        // ── CRITICAL FIX: Prefer a fetched result that has real data.
        // If Supabase returned something with bodyFatPercent > 0, use it.
        // Otherwise, fall back to the in-memory scan from onboarding so we
        // never show the empty state when the user just completed a scan.
        final bool fetchedIsValid = fetchedResult != null &&
            (fetchedResult.bodyFatPercent ?? 0) > 0;
        final latestResult = fetchedIsValid
            ? fetchedResult
            : (incomingScan != null ? incomingScan : fetchedResult);
        final profile = results[1] as ProfileModel?;
        final scanHistory = results[3] as List<ScanModel>;

        debugPrint(
          '[Home] fetchLatestScanResult: ${fetchedResult != null ? "found (id=${fetchedResult.id}, bodyFat=${fetchedResult.bodyFatPercent})" : "null"}',
        );
        debugPrint('[Home] scanHistory count: ${scanHistory.length}');
        if (latestResult == null) {
          debugPrint(
            '[Home] Empty state reason: fetchLatestScanResult returned null — no scan_results rows for this user',
          );
        }

        // Cache for offline use
        if (latestResult != null) {
          await LocalCacheService.instance.cacheLatestScan(
            latestResult.toJson(),
          );
        }
        if (profile != null) {
          await LocalCacheService.instance.cacheProfile(profile.toJson());
        }

        final milestones = _computeMilestones(
          scanHistory: scanHistory,
          latestResult: latestResult,
          onboardingData: widget.onboardingData,
        );
        if (mounted) {
          setState(() {
            _latestResult = latestResult;
            _profile = profile;
            _isPremium = results[2] as bool;
            _hasScans = latestResult != null;
            _hasFirstScan = milestones['firstScan'] as bool;
            _hasSevenDayStreak = milestones['sevenDayStreak'] as bool;
            _hasConsistentProgress = milestones['consistentProgress'] as bool;
            _hasGoalReached = milestones['goalReached'] as bool;
            _isLoading = false;
          });
        }
      }
    } catch (e) {
      debugPrint('[Home] _loadData error: $e');
      // Network failure — try local cache
      final cachedScan = await LocalCacheService.instance.getCachedLatestScan();
      final cachedProfile = await LocalCacheService.instance.getCachedProfile();
      if (mounted) {
        ScanResultModel? cachedResult;
        ProfileModel? cachedProfileModel;
        if (cachedScan != null) {
          try {
            cachedResult = ScanResultModel.fromJson(cachedScan);
          } catch (_) {}
        }
        if (cachedProfile != null) {
          try {
            cachedProfileModel = ProfileModel.fromJson(cachedProfile);
          } catch (_) {}
        }

        // Fall back to the onboarding scan if cache is empty
        final incomingScan = widget.onboardingData?.scanResult;
        final resolvedResult = cachedResult ?? incomingScan;

        debugPrint(
          '[Home] Using cached data: scan=${resolvedResult != null}, profile=${cachedProfileModel != null}',
        );
        if (resolvedResult == null) {
          debugPrint(
            '[Home] Empty state reason: network error and no cached scan available',
          );
        }
        setState(() {
          _latestResult = resolvedResult;
          _profile = cachedProfileModel;
          _hasScans = resolvedResult != null;
          _isLoading = false;
        });
        if (cachedResult != null) {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(
              content: const Text('Données en cache — vous êtes hors ligne'),
              behavior: SnackBarBehavior.floating,
              backgroundColor: const Color(0xFFE17055),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(10),
              ),
              duration: const Duration(seconds: 3),
            ),
          );
        } else {
          setState(() => _isLoading = false);
        }
      }
    }
  }

  /// Compute milestone unlock states from scan history
  Map<String, bool> _computeMilestones({
    required List<ScanModel> scanHistory,
    required ScanResultModel? latestResult,
    required OnboardingData? onboardingData,
  }) {
    final int scanCount = scanHistory.length;

    // First Scan: unlocked after at least 1 scan (also true if latestResult exists
    // even when scanHistory hasn't propagated yet, e.g. right after onboarding)
    final bool firstScan = scanCount >= 1 || latestResult != null;

    // 7-Day Streak: user scanned on 7 consecutive days
    bool sevenDayStreak = false;
    if (scanCount >= 7) {
      // Get unique scan dates (date only, no time)
      final scanDates =
          scanHistory
              .where((s) => s.createdAt != null)
              .map((s) {
                final d = s.createdAt!;
                return DateTime(d.year, d.month, d.day);
              })
              .toSet()
              .toList()
            ..sort((a, b) => b.compareTo(a)); // newest first

      if (scanDates.length >= 7) {
        int streak = 1;
        int maxStreak = 1;
        for (int i = 1; i < scanDates.length; i++) {
          final diff = scanDates[i - 1].difference(scanDates[i]).inDays;
          if (diff == 1) {
            streak++;
            if (streak > maxStreak) maxStreak = streak;
          } else {
            streak = 1;
          }
        }
        sevenDayStreak = maxStreak >= 7;
      }
    }

    // Consistent Progress: at least 3 scans completed
    final bool consistentProgress = scanCount >= 3;

    // Goal Reached: check if body fat is within goal range based on onboarding goal
    bool goalReached = false;
    if (latestResult != null && latestResult.bodyFatPercent != null) {
      final bf = latestResult.bodyFatPercent!;
      final goal = onboardingData?.goal?.toLowerCase() ?? '';
      if (goal.contains('lose') || goal.contains('fat')) {
        // Goal: lose fat — reached if body fat < 20%
        goalReached = bf < 20.0;
      } else if (goal.contains('muscle') || goal.contains('build')) {
        // Goal: build muscle — reached if lean mass is high (body fat < 15%)
        goalReached = bf < 15.0;
      } else if (goal.contains('maintain')) {
        // Goal: maintain — reached if body fat is in healthy range
        goalReached = bf >= 10.0 && bf <= 25.0;
      } else {
        // Default: any scan result with body score >= 70
        goalReached = (latestResult.bodyScore ?? 0) >= 70.0;
      }
    }

    return {
      'firstScan': firstScan,
      'sevenDayStreak': sevenDayStreak,
      'consistentProgress': consistentProgress,
      'goalReached': goalReached,
    };
  }

  Map<String, dynamic> get _scanData {
    if (_latestResult != null) {
      final lm = _latestResult!.leanMassEstimate ?? 68.2;
      final bf = _latestResult!.bodyFatPercent ?? 18.4;
      final totalW = lm / (1 - (bf / 100));
      return {
        "bodyFatPercentage": bf,
        "bodyCategory": _latestResult!.bodyCategory ?? 'Athletic',
        "leanMass": lm,
        "lastScanDate": _formatDate(_latestResult!.createdAt),
        "goalAlignment": 82,
        "progressChange": -1.2,
        "fatMass": (totalW * bf / 100),
        "totalWeight": totalW,
      };
    }
    final data = widget.onboardingData;
    double bodyFat = 18.4;
    double leanMass = 68.2;
    String bodyCategory = 'Athletic';
    double totalWeight = 80.0;
    if (data != null && data.weightKg != null && data.gender != null) {
      final isMale = data.gender?.toLowerCase() == 'male';
      final baseBodyFat = isMale ? 18.0 : 25.0;
      final activityBonus = _activityBonus(data.activityLevel);
      bodyFat = (baseBodyFat - activityBonus).clamp(8.0, 40.0);
      totalWeight = data.weightKg ?? 80.0;
      leanMass = (totalWeight * (1 - bodyFat / 100));
      bodyCategory = _bodyCategory(bodyFat, isMale);
    }
    return {
      "bodyFatPercentage": bodyFat,
      "bodyCategory": bodyCategory,
      "leanMass": leanMass,
      "lastScanDate": _todayDate(),
      "goalAlignment": 82,
      "progressChange": -1.2,
      "fatMass": (totalWeight * bodyFat / 100),
      "totalWeight": totalWeight,
    };
  }

  String _formatDate(DateTime? dt) {
    if (dt == null) return _todayDate();
    return '${dt.day.toString().padLeft(2, '0')}/${dt.month.toString().padLeft(2, '0')}/${dt.year}';
  }

  double _activityBonus(String? activity) {
    if (activity == null) return 0;
    if (activity.contains('5')) return 4.0;
    if (activity.contains('3') || activity.contains('4')) return 2.5;
    if (activity.contains('1') || activity.contains('2')) return 1.0;
    return 0;
  }

  String _bodyCategory(double bodyFat, bool isMale) {
    if (isMale) {
      if (bodyFat < 10) return 'Essential';
      if (bodyFat < 14) return 'Athletic';
      if (bodyFat < 18) return 'Fit';
      if (bodyFat < 25) return 'Average';
      return 'Above Average';
    } else {
      if (bodyFat < 14) return 'Essential';
      if (bodyFat < 21) return 'Athletic';
      if (bodyFat < 25) return 'Fit';
      if (bodyFat < 32) return 'Average';
      return 'Above Average';
    }
  }

  String _todayDate() {
    final now = DateTime.now();
    return '${now.day.toString().padLeft(2, '0')}/${now.month.toString().padLeft(2, '0')}/${now.year}';
  }

  Future<void> _onRefresh() async {
    HapticFeedback.mediumImpact();
    setState(() => _isRefreshing = true);
    await _loadData();
    setState(() => _isRefreshing = false);
    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: const Text('Données synchronisées'),
          behavior: SnackBarBehavior.floating,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(12),
          ),
          duration: const Duration(seconds: 2),
        ),
      );
    }
  }

  void _navigateToScan() {
    if (!_isPremium && _hasScans) {
      // Non-premium users who already have a scan must go through paywall first
      debugPrint(
        '[Home] Non-premium user tapped Scan Again — routing to paywall',
      );
      Navigator.of(
        context,
        rootNavigator: true,
      ).pushNamed('/paywall', arguments: widget.onboardingData);
      return;
    }
    // Premium users or first scan: go to camera instructions in standalone mode
    debugPrint(
      '[Home] Navigating to camera instructions (standaloneMode=true)',
    );
    final scanData = (widget.onboardingData ?? OnboardingData()).copyWith(
      standaloneMode: true,
    );
    Navigator.of(
      context,
      rootNavigator: true,
    ).pushNamed('/camera-instructions-screen', arguments: scanData);
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    if (_isLoading) {
      return Scaffold(
        backgroundColor: theme.scaffoldBackgroundColor,
        body: const Center(
          child: CircularProgressIndicator(color: Color(0xFF6C5CE7)),
        ),
      );
    }

    // If no scans exist, redirect to scan flow instead of showing broken empty state
    if (!_hasScans) {
      // Check if user just came from onboarding — if so, redirect to scan flow
      return Scaffold(
        backgroundColor: theme.scaffoldBackgroundColor,
        body: SafeArea(
          child: Center(
            child: Padding(
              padding: EdgeInsets.symmetric(horizontal: 6.w),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Container(
                    width: 22.w,
                    height: 22.w,
                    decoration: const BoxDecoration(
                      shape: BoxShape.circle,
                      gradient: LinearGradient(
                        colors: [Color(0xFF6C5CE7), Color(0xFF74B9FF)],
                        begin: Alignment.topLeft,
                        end: Alignment.bottomRight,
                      ),
                    ),
                    child: const Icon(
                      Icons.camera_alt_rounded,
                      color: Colors.white,
                      size: 36,
                    ),
                  ),
                  SizedBox(height: 3.h),
                  Text(
                    'Complétez votre premier scan',
                    style: GoogleFonts.manrope(
                      fontSize: 16.sp,
                      fontWeight: FontWeight.w700,
                      color: theme.colorScheme.onSurface,
                    ),
                    textAlign: TextAlign.center,
                  ),
                  SizedBox(height: 1.h),
                  Text(
                    'Faites un scan corporel pour voir votre tableau de bord personnalisé.',
                    style: GoogleFonts.dmSans(
                      fontSize: 12.sp,
                      color: theme.colorScheme.onSurfaceVariant,
                      height: 1.5,
                    ),
                    textAlign: TextAlign.center,
                  ),
                  SizedBox(height: 4.h),
                  GestureDetector(
                    onTap: () {
                      HapticFeedback.mediumImpact();
                      _navigateToScan();
                    },
                    child: Container(
                      padding: EdgeInsets.symmetric(
                        horizontal: 8.w,
                        vertical: 1.8.h,
                      ),
                      decoration: BoxDecoration(
                        gradient: const LinearGradient(
                          colors: [Color(0xFF6C5CE7), Color(0xFF4834D4)],
                          begin: Alignment.centerLeft,
                          end: Alignment.centerRight,
                        ),
                        borderRadius: BorderRadius.circular(16.0),
                        boxShadow: [
                          BoxShadow(
                            color: const Color(
                              0xFF6C5CE7,
                            ).withValues(alpha: 0.4),
                            blurRadius: 20,
                            offset: const Offset(0, 8),
                          ),
                        ],
                      ),
                      child: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          CustomIconWidget(
                            iconName: 'camera_alt',
                            color: Colors.white,
                            size: 20,
                          ),
                          SizedBox(width: 2.w),
                          Text(
                            'Démarrer mon premier scan',
                            style: GoogleFonts.manrope(
                              fontSize: 13.sp,
                              color: Colors.white,
                              fontWeight: FontWeight.w700,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      );
    }

    return Scaffold(
      backgroundColor: theme.scaffoldBackgroundColor,
      body: SafeArea(
        child: RefreshIndicator(
          onRefresh: _onRefresh,
          color: const Color(0xFF6C5CE7),
          child: _buildContent(theme),
        ),
      ),
      bottomNavigationBar: _buildScanCTA(theme),
    );
  }

  Widget _buildScanCTA(ThemeData theme) {
    return Container(
      padding: EdgeInsets.fromLTRB(4.w, 1.h, 4.w, 3.h),
      decoration: BoxDecoration(
        color: theme.scaffoldBackgroundColor,
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: 0.06),
            blurRadius: 12,
            offset: const Offset(0, -4),
          ),
        ],
      ),
      child: GestureDetector(
        onTap: () {
          HapticFeedback.lightImpact();
          _navigateToScan();
        },
        child: Container(
          width: double.infinity,
          padding: EdgeInsets.symmetric(vertical: 1.8.h),
          decoration: BoxDecoration(
            gradient: const LinearGradient(
              colors: [Color(0xFF6C5CE7), Color(0xFF4834D4)],
              begin: Alignment.centerLeft,
              end: Alignment.centerRight,
            ),
            borderRadius: BorderRadius.circular(16.0),
            boxShadow: [
              BoxShadow(
                color: const Color(0xFF6C5CE7).withValues(alpha: 0.4),
                blurRadius: 20,
                offset: const Offset(0, 8),
              ),
            ],
          ),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              CustomIconWidget(
                iconName: 'camera_alt',
                color: Colors.white,
                size: 20,
              ),
              SizedBox(width: 2.w),
              Text(
                'Scanner à nouveau',
                style: GoogleFonts.manrope(
                  fontSize: 13.sp,
                  color: Colors.white,
                  fontWeight: FontWeight.w700,
                  letterSpacing: 0.3,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildContent(ThemeData theme) {
    final scan = _scanData;
    return CustomScrollView(
      physics: const AlwaysScrollableScrollPhysics(),
      slivers: [
        SliverToBoxAdapter(
          child: Padding(
            padding: EdgeInsets.symmetric(horizontal: 4.w, vertical: 2.h),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                _buildGreetingHeader(theme),
                SizedBox(height: 2.h),
                SplitHeroCardWidget(
                  bodyFatPercentage: scan["bodyFatPercentage"] as double,
                  bodyCategory: scan["bodyCategory"] as String,
                  progressChange: scan["progressChange"] as double,
                  lastScanDate: scan["lastScanDate"] as String,
                ),
                SizedBox(height: 2.h),
                QuickStatsRowWidget(
                  leanMass: scan["leanMass"] as double,
                  goalAlignment: scan["goalAlignment"] as int,
                  fatMass: scan["fatMass"] as double,
                ),
                SizedBox(height: 2.5.h),
                BodyAnalysisModuleWidget(
                  bodyFatPercentage: scan["bodyFatPercentage"] as double,
                  leanMass: scan["leanMass"] as double,
                  totalWeight: scan["totalWeight"] as double,
                ),
                SizedBox(height: 2.5.h),
                BadgesSectionWidget(
                  hasFirstScan: _hasFirstScan,
                  hasSevenDayStreak: _hasSevenDayStreak,
                  hasConsistentProgress: _hasConsistentProgress,
                  hasGoalReached: _hasGoalReached,
                ),
                SizedBox(height: 2.5.h),
                PremiumReportWidget(isPremium: _isPremium),
                SizedBox(height: 2.h),
                if (!_isPremium)
                  UnlockBannerWidget(
                    onUnlockTap: () => setState(() => _isPremium = true),
                  ),
                SizedBox(height: 2.h),
              ],
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildGreetingHeader(ThemeData theme) {
    final data = widget.onboardingData;
    final displayName = _profile?.fullName?.isNotEmpty == true
        ? _profile!.fullName!.split(' ').first
        : null;

    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                displayName != null
                    ? 'Hey, $displayName 👋'
                    : (data != null ? 'Bonjour 👋' : 'Bonjour 👋'),
                style: GoogleFonts.manrope(
                  fontSize: 16.sp,
                  fontWeight: FontWeight.w800,
                  color: theme.colorScheme.onSurface,
                ),
                overflow: TextOverflow.ellipsis,
              ),
              SizedBox(height: 0.3.h),
              Text(
                'Votre rapport corporel est prêt',
                style: GoogleFonts.dmSans(
                  fontSize: 10.sp,
                  color: theme.colorScheme.onSurfaceVariant,
                  fontWeight: FontWeight.w400,
                ),
              ),
            ],
          ),
        ),
        SizedBox(width: 3.w),
        // Only show sync status chip — remove unused share and profile icons
        ListenableBuilder(
          listenable: SyncService.instance,
          builder: (_, __) =>
              _HomeSyncChip(status: SyncService.instance.status),
        ),
      ],
    );
  }

  String? _formatGoalLabel(String? goal) {
    if (goal == null) return null;
    switch (goal.toLowerCase()) {
      case 'lose_fat':
      case 'lose fat':
        return 'Your Fat Loss Journey';
      case 'build_muscle':
      case 'build muscle':
        return 'Your Muscle Journey';
      case 'maintain':
        return 'Your Maintenance Plan';
      case 'track_fitness':
      case 'track fitness':
        return 'Your Fitness Report';
      default:
        return 'Your Body Report';
    }
  }
}

// ─── Home Sync Chip ───────────────────────────────────────────────────────────

class _HomeSyncChip extends StatelessWidget {
  final SyncStatus status;
  const _HomeSyncChip({required this.status});

  @override
  Widget build(BuildContext context) {
    Color color;
    IconData icon;
    String tooltip;
    bool showSpinner = false;

    switch (status) {
      case SyncStatus.syncing:
        color = const Color(0xFFFDCB6E);
        icon = Icons.sync_rounded;
        tooltip = 'Synchronisation…';
        showSpinner = true;
        break;
      case SyncStatus.offline:
        color = const Color(0xFFE53E3E);
        icon = Icons.cloud_off_rounded;
        tooltip = 'Hors ligne — données sauvegardées';
        break;
      case SyncStatus.pending:
        color = const Color(0xFFFDCB6E);
        icon = Icons.cloud_upload_rounded;
        tooltip = 'Sync en attente';
        break;
      case SyncStatus.synced:
        color = const Color(0xFF00B894);
        icon = Icons.cloud_done_rounded;
        tooltip = 'Données synchronisées';
        break;
    }

    return Tooltip(
      message: tooltip,
      child: Stack(
        clipBehavior: Clip.none,
        children: [
          Container(
            padding: const EdgeInsets.all(6),
            decoration: BoxDecoration(
              color: color.withValues(alpha: 0.12),
              shape: BoxShape.circle,
              border: Border.all(color: color.withValues(alpha: 0.3)),
            ),
            child: showSpinner
                ? SizedBox(
                    width: 14,
                    height: 14,
                    child: CircularProgressIndicator(
                      strokeWidth: 1.5,
                      valueColor: AlwaysStoppedAnimation<Color>(color),
                    ),
                  )
                : Icon(icon, size: 14, color: color),
          ),
          // Pending count badge
          if (status == SyncStatus.pending)
            Positioned(
              top: -3,
              right: -3,
              child: Container(
                width: 10,
                height: 10,
                decoration: BoxDecoration(
                  color: const Color(0xFFFDCB6E),
                  shape: BoxShape.circle,
                  border: Border.all(
                    color: Theme.of(context).scaffoldBackgroundColor,
                    width: 1.5,
                  ),
                ),
              ),
            ),
        ],
      ),
    );
  }
}
