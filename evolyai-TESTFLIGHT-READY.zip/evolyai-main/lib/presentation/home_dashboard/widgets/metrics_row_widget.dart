import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

import '../../../core/app_export.dart';
import '../../../widgets/custom_icon_widget.dart';

class MetricsRowWidget extends StatelessWidget {
  final double leanMass;
  final int goalAlignment;
  final String bodyCategory;

  const MetricsRowWidget({
    super.key,
    required this.leanMass,
    required this.goalAlignment,
    required this.bodyCategory,
  });

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return Row(
      children: [
        Expanded(
          child: _MetricCard(
            icon: 'fitness_center',
            label: 'Masse Maigre',
            value: '${leanMass.toStringAsFixed(1)} kg',
            color: const Color(0xFF6C5CE7),
            theme: theme,
          ),
        ),
        SizedBox(width: 3.w),
        Expanded(
          child: _MetricCard(
            icon: 'track_changes',
            label: 'Objectif',
            value: '$goalAlignment%',
            color: const Color(0xFF00B894),
            theme: theme,
          ),
        ),
        SizedBox(width: 3.w),
        Expanded(
          child: _MetricCard(
            icon: 'category',
            label: 'Catégorie',
            value: bodyCategory,
            color: const Color(0xFF74B9FF),
            theme: theme,
          ),
        ),
      ],
    );
  }
}

class _MetricCard extends StatelessWidget {
  final String icon;
  final String label;
  final String value;
  final Color color;
  final ThemeData theme;

  const _MetricCard({
    required this.icon,
    required this.label,
    required this.value,
    required this.color,
    required this.theme,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: EdgeInsets.symmetric(vertical: 2.h, horizontal: 2.w),
      decoration: BoxDecoration(
        color: theme.cardColor,
        borderRadius: BorderRadius.circular(16),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: 0.05),
            blurRadius: 10,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: Column(
        children: [
          Container(
            width: 9.w,
            height: 9.w,
            decoration: BoxDecoration(
              color: color.withValues(alpha: 0.12),
              shape: BoxShape.circle,
            ),
            child: Center(
              child: CustomIconWidget(iconName: icon, color: color, size: 18),
            ),
          ),
          SizedBox(height: 1.h),
          Text(
            value,
            style: theme.textTheme.titleSmall?.copyWith(
              fontWeight: FontWeight.w700,
              fontSize: 11.sp,
            ),
            overflow: TextOverflow.ellipsis,
            maxLines: 1,
          ),
          SizedBox(height: 0.3.h),
          Text(
            label,
            style: theme.textTheme.labelSmall?.copyWith(
              color: theme.colorScheme.onSurfaceVariant,
            ),
            overflow: TextOverflow.ellipsis,
            maxLines: 1,
          ),
        ],
      ),
    );
  }
}
