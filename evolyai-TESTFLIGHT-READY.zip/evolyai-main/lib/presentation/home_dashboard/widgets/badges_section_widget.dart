import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:sizer/sizer.dart';

class BadgesSectionWidget extends StatefulWidget {
  final bool hasFirstScan;
  final bool hasSevenDayStreak;
  final bool hasConsistentProgress;
  final bool hasGoalReached;

  const BadgesSectionWidget({
    super.key,
    this.hasFirstScan = true,
    this.hasSevenDayStreak = false,
    this.hasConsistentProgress = false,
    this.hasGoalReached = false,
  });

  @override
  State<BadgesSectionWidget> createState() => _BadgesSectionWidgetState();
}

class _BadgesSectionWidgetState extends State<BadgesSectionWidget>
    with TickerProviderStateMixin {
  late List<AnimationController> _controllers;
  late List<Animation<double>> _scaleAnims;
  late List<Animation<double>> _glowAnims;
  late List<bool> _unlocked;

  final List<_BadgeData> _badges = const [
    _BadgeData(
      title: 'Premier Scan',
      subtitle: 'Votre premier scan corporel effectué',
      icon: '🏆',
      color: Color(0xFFFFD700),
      glowColor: Color(0xFFFFD700),
    ),
    _BadgeData(
      title: 'Série 7 jours',
      subtitle: '7 jours de scan consécutifs',
      icon: '🔥',
      color: Color(0xFFFF6B35),
      glowColor: Color(0xFFFF6B35),
    ),
    _BadgeData(
      title: 'Progression',
      subtitle: '3 scans en amélioration',
      icon: '📈',
      color: Color(0xFF00D4AA),
      glowColor: Color(0xFF00D4AA),
    ),
    _BadgeData(
      title: 'Objectif',
      subtitle: 'Cible de masse grasse atteinte',
      icon: '🎯',
      color: Color(0xFF6C5CE7),
      glowColor: Color(0xFF6C5CE7),
    ),
  ];

  @override
  void initState() {
    super.initState();
    _unlocked = [
      widget.hasFirstScan,
      widget.hasSevenDayStreak,
      widget.hasConsistentProgress,
      widget.hasGoalReached,
    ];

    _controllers = List.generate(
      4,
      (i) => AnimationController(
        vsync: this,
        duration: const Duration(milliseconds: 600),
      ),
    );

    _scaleAnims = _controllers.map((c) {
      return Tween<double>(
        begin: 0.7,
        end: 1.0,
      ).animate(CurvedAnimation(parent: c, curve: Curves.elasticOut));
    }).toList();

    _glowAnims = _controllers.map((c) {
      return Tween<double>(begin: 0.0, end: 1.0).animate(
        CurvedAnimation(
          parent: c,
          curve: const Interval(0.4, 1.0, curve: Curves.easeOut),
        ),
      );
    }).toList();

    // Staggered entrance for unlocked badges
    for (int i = 0; i < 4; i++) {
      if (_unlocked[i]) {
        Future.delayed(Duration(milliseconds: 150 * i), () {
          if (mounted) {
            HapticFeedback.lightImpact();
            _controllers[i].forward();
          }
        });
      }
    }
  }

  @override
  void dispose() {
    for (final c in _controllers) {
      c.dispose();
    }
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return Container(
      width: double.infinity,
      padding: EdgeInsets.all(4.w),
      decoration: BoxDecoration(
        color: theme.cardColor,
        borderRadius: BorderRadius.circular(20.0),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: 0.06),
            blurRadius: 16,
            offset: const Offset(0, 6),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Text(
                'Jalons',
                style: GoogleFonts.manrope(
                  fontSize: 13.sp,
                  fontWeight: FontWeight.w700,
                  color: theme.colorScheme.onSurface,
                ),
              ),
              SizedBox(width: 2.w),
              Container(
                padding: EdgeInsets.symmetric(horizontal: 2.w, vertical: 0.3.h),
                decoration: BoxDecoration(
                  color: const Color(0xFF6C5CE7).withValues(alpha: 0.12),
                  borderRadius: BorderRadius.circular(8.0),
                ),
                child: Text(
                  '${_unlocked.where((u) => u).length}/4',
                  style: GoogleFonts.manrope(
                    fontSize: 8.sp,
                    fontWeight: FontWeight.w700,
                    color: const Color(0xFF6C5CE7),
                  ),
                ),
              ),
            ],
          ),
          SizedBox(height: 0.4.h),
          Text(
            'Débloquez des badges en atteignant vos objectifs',
            style: GoogleFonts.dmSans(
              fontSize: 9.sp,
              color: theme.colorScheme.onSurfaceVariant,
              fontWeight: FontWeight.w400,
            ),
          ),
          SizedBox(height: 2.h),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: List.generate(4, (i) {
              return _unlocked[i]
                  ? _UnlockedBadge(
                      badge: _badges[i],
                      scaleAnim: _scaleAnims[i],
                      glowAnim: _glowAnims[i],
                      theme: theme,
                    )
                  : _LockedBadge(badge: _badges[i], theme: theme);
            }),
          ),
        ],
      ),
    );
  }
}

class _BadgeData {
  final String title;
  final String subtitle;
  final String icon;
  final Color color;
  final Color glowColor;

  const _BadgeData({
    required this.title,
    required this.subtitle,
    required this.icon,
    required this.color,
    required this.glowColor,
  });
}

class _UnlockedBadge extends StatelessWidget {
  final _BadgeData badge;
  final Animation<double> scaleAnim;
  final Animation<double> glowAnim;
  final ThemeData theme;

  const _UnlockedBadge({
    required this.badge,
    required this.scaleAnim,
    required this.glowAnim,
    required this.theme,
  });

  @override
  Widget build(BuildContext context) {
    return Expanded(
      child: Padding(
        padding: EdgeInsets.symmetric(horizontal: 1.w),
        child: AnimatedBuilder(
          animation: scaleAnim,
          builder: (context, child) {
            return Transform.scale(
              scale: scaleAnim.value,
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  AnimatedBuilder(
                    animation: glowAnim,
                    builder: (context, _) {
                      return Container(
                        width: 14.w,
                        height: 14.w,
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          gradient: RadialGradient(
                            colors: [
                              badge.color.withValues(alpha: 0.25),
                              badge.color.withValues(alpha: 0.08),
                            ],
                          ),
                          border: Border.all(
                            color: badge.color.withValues(
                              alpha: 0.5 + 0.4 * glowAnim.value,
                            ),
                            width: 2.0,
                          ),
                          boxShadow: [
                            BoxShadow(
                              color: badge.glowColor.withValues(
                                alpha: 0.35 * glowAnim.value,
                              ),
                              blurRadius: 12,
                              spreadRadius: 2,
                            ),
                          ],
                        ),
                        child: Center(
                          child: Text(
                            badge.icon,
                            style: TextStyle(fontSize: 14.sp),
                          ),
                        ),
                      );
                    },
                  ),
                  SizedBox(height: 0.8.h),
                  Text(
                    badge.title,
                    style: GoogleFonts.manrope(
                      fontSize: 7.5.sp,
                      fontWeight: FontWeight.w700,
                      color: theme.colorScheme.onSurface,
                    ),
                    textAlign: TextAlign.center,
                    maxLines: 2,
                    overflow: TextOverflow.ellipsis,
                  ),
                ],
              ),
            );
          },
        ),
      ),
    );
  }
}

class _LockedBadge extends StatelessWidget {
  final _BadgeData badge;
  final ThemeData theme;

  const _LockedBadge({required this.badge, required this.theme});

  @override
  Widget build(BuildContext context) {
    return Expanded(
      child: Padding(
        padding: EdgeInsets.symmetric(horizontal: 1.w),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              width: 14.w,
              height: 14.w,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: theme.colorScheme.surfaceContainerHighest.withValues(
                  alpha: 0.4,
                ),
                border: Border.all(
                  color: theme.colorScheme.outline.withValues(alpha: 0.2),
                  width: 1.5,
                ),
              ),
              child: Center(
                child: Text('🔒', style: TextStyle(fontSize: 12.sp)),
              ),
            ),
            SizedBox(height: 0.8.h),
            Text(
              badge.title,
              style: GoogleFonts.manrope(
                fontSize: 7.5.sp,
                fontWeight: FontWeight.w600,
                color: theme.colorScheme.onSurfaceVariant.withValues(
                  alpha: 0.6,
                ),
              ),
              textAlign: TextAlign.center,
              maxLines: 2,
              overflow: TextOverflow.ellipsis,
            ),
          ],
        ),
      ),
    );
  }
}
