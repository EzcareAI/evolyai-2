import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:sizer/sizer.dart';

import '../../../core/app_export.dart';
import '../../../models/onboarding_data.dart';
import '../../../widgets/custom_icon_widget.dart';

class BodyScanCtaWidget extends StatelessWidget {
  final ThemeData theme;
  final bool isPremium;
  final bool hasExistingScans;
  final OnboardingData? onboardingData;

  const BodyScanCtaWidget({
    super.key,
    required this.theme,
    this.isPremium = false,
    this.hasExistingScans = false,
    this.onboardingData,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () {
        HapticFeedback.lightImpact();
        if (!isPremium && hasExistingScans) {
          // Non-premium with existing scans → paywall BEFORE camera
          debugPrint(
            '[BodyScanCta] Non-premium rescan — routing to paywall first',
          );
          Navigator.of(
            context,
            rootNavigator: true,
          ).pushNamed('/paywall', arguments: onboardingData);
          return;
        }
        // Premium or first scan → standalone camera instructions (no onboarding labels)
        debugPrint(
          '[BodyScanCta] Navigating to standalone camera instructions',
        );
        final scanData = (onboardingData ?? OnboardingData()).copyWith(
          standaloneMode: true,
        );
        Navigator.of(
          context,
          rootNavigator: true,
        ).pushNamed('/camera-instructions-screen', arguments: scanData);
      },
      child: Container(
        width: double.infinity,
        padding: EdgeInsets.all(4.w),
        decoration: BoxDecoration(
          color: const Color(0xFFF8F9FA),
          borderRadius: BorderRadius.circular(16),
          border: Border.all(
            color: const Color(0xFF6C5CE7).withValues(alpha: 0.3),
          ),
        ),
        child: Row(
          children: [
            Container(
              width: 14.w,
              height: 14.w,
              decoration: BoxDecoration(
                gradient: const LinearGradient(
                  colors: [Color(0xFF6C5CE7), Color(0xFF74B9FF)],
                ),
                borderRadius: BorderRadius.circular(14),
              ),
              child: Center(
                child: CustomIconWidget(
                  iconName: 'camera_alt',
                  color: Colors.white,
                  size: 24,
                ),
              ),
            ),
            SizedBox(width: 3.w),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    hasExistingScans ? 'Scanner à nouveau' : 'Scanner mon corps',
                    style: theme.textTheme.titleSmall?.copyWith(
                      fontWeight: FontWeight.w700,
                      color: const Color(0xFF2D3436),
                    ),
                  ),
                  Text(
                    'Take front & side photos for AI analysis',
                    style: theme.textTheme.bodySmall?.copyWith(
                      color: const Color(0xFF636E72),
                    ),
                    overflow: TextOverflow.ellipsis,
                  ),
                ],
              ),
            ),
            if (!isPremium && hasExistingScans)
              Container(
                padding: EdgeInsets.symmetric(horizontal: 2.w, vertical: 0.4.h),
                decoration: BoxDecoration(
                  color: const Color(0xFF6C5CE7).withValues(alpha: 0.1),
                  borderRadius: BorderRadius.circular(8),
                ),
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    const Icon(
                      Icons.lock_rounded,
                      color: Color(0xFF6C5CE7),
                      size: 12,
                    ),
                    SizedBox(width: 1.w),
                    Text(
                      'Premium',
                      style: theme.textTheme.labelSmall?.copyWith(
                        color: const Color(0xFF6C5CE7),
                        fontWeight: FontWeight.w700,
                        fontSize: 9,
                      ),
                    ),
                  ],
                ),
              )
            else
              CustomIconWidget(
                iconName: 'arrow_forward_ios',
                color: const Color(0xFF6C5CE7),
                size: 16,
              ),
          ],
        ),
      ),
    );
  }
}
