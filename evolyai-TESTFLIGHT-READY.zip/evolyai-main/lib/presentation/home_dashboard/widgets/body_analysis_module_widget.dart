import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:sizer/sizer.dart';

class BodyAnalysisModuleWidget extends StatefulWidget {
  final double bodyFatPercentage;
  final double leanMass;
  final double totalWeight;

  const BodyAnalysisModuleWidget({
    super.key,
    required this.bodyFatPercentage,
    required this.leanMass,
    required this.totalWeight,
  });

  @override
  State<BodyAnalysisModuleWidget> createState() =>
      _BodyAnalysisModuleWidgetState();
}

class _BodyAnalysisModuleWidgetState extends State<BodyAnalysisModuleWidget>
    with TickerProviderStateMixin {
  int _selectedTab = 0;
  String? _highlightedZone;

  // Tab switch fade
  late AnimationController _animController;
  late Animation<double> _fadeAnim;

  // Tap highlight pulse (only plays when a zone is tapped)
  late AnimationController _pulseController;
  late Animation<double> _pulseAnim;

  Map<String, double> get _bodyFatZones {
    final bf = widget.bodyFatPercentage;
    return {
      'Bras Gauche': (bf * 0.72).clamp(5.0, 35.0),
      'Bras Droit': (bf * 0.74).clamp(5.0, 35.0),
      'Haut du Corps': (bf * 1.18).clamp(8.0, 45.0),
      'Jambe Gauche': (bf * 0.95).clamp(6.0, 40.0),
      'Jambe Droite': (bf * 0.93).clamp(6.0, 40.0),
    };
  }

  Map<String, double> get _leanMassZones {
    final lm = widget.leanMass;
    final total = widget.totalWeight > 0 ? widget.totalWeight : 1.0;
    return {
      'Bras Gauche': ((lm * 0.08) / total * 100).clamp(2.0, 18.0),
      'Bras Droit': ((lm * 0.085) / total * 100).clamp(2.0, 18.0),
      'Haut du Corps': ((lm * 0.42) / total * 100).clamp(10.0, 55.0),
      'Jambe Gauche': ((lm * 0.215) / total * 100).clamp(5.0, 35.0),
      'Jambe Droite': ((lm * 0.22) / total * 100).clamp(5.0, 35.0),
    };
  }

  Map<String, double> get _activeZones =>
      _selectedTab == 0 ? _bodyFatZones : _leanMassZones;

  String _unit(String zone) => '%';

  Color _zoneColor(double value, bool isFat) {
    if (isFat) {
      if (value < 12) return const Color(0xFF00D4AA);
      if (value < 20) return const Color(0xFF74B9FF);
      if (value < 28) return const Color(0xFFFFB347);
      return const Color(0xFFFF6B6B);
    } else {
      if (value < 5) return const Color(0xFF74B9FF);
      if (value < 15) return const Color(0xFF6C5CE7);
      if (value < 30) return const Color(0xFF00D4AA);
      return const Color(0xFF00B894);
    }
  }

  /// Distinct fixed colors per zone for consistent identification
  Color _zoneDistinctColor(String zone) {
    switch (zone) {
      case 'Bras Gauche':
        return const Color(0xFF6C5CE7); // purple
      case 'Bras Droit':
        return const Color(0xFF0984E3); // blue
      case 'Haut du Corps':
        return const Color(0xFF00B894); // teal
      case 'Jambe Gauche':
        return const Color(0xFFFDCB6E); // amber
      case 'Jambe Droite':
        return const Color(0xFFE17055); // orange
      default:
        return const Color(0xFF6C5CE7);
    }
  }

  @override
  void initState() {
    super.initState();

    _animController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 400),
    );
    _fadeAnim = CurvedAnimation(
      parent: _animController,
      curve: Curves.easeInOut,
    );
    _animController.forward();

    // Pulse — only used when a zone is tapped
    _pulseController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1800),
    );
    _pulseAnim = Tween<double>(begin: 1.0, end: 1.06).animate(
      CurvedAnimation(parent: _pulseController, curve: Curves.easeInOut),
    );
  }

  @override
  void dispose() {
    _animController.dispose();
    _pulseController.dispose();
    super.dispose();
  }

  void _switchTab(int index) {
    if (_selectedTab == index) return;
    HapticFeedback.selectionClick();
    _animController.reverse().then((_) {
      setState(() {
        _selectedTab = index;
        _highlightedZone = null;
      });
      _pulseController.stop();
      _animController.forward();
    });
  }

  void _onZoneTap(String zone) {
    HapticFeedback.mediumImpact();
    setState(() {
      _highlightedZone = _highlightedZone == zone ? null : zone;
    });
    if (_highlightedZone != null) {
      _pulseController.repeat(reverse: true);
    } else {
      _pulseController.stop();
      _pulseController.reset();
    }
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final isFat = _selectedTab == 0;
    final zones = _activeZones;
    final isAnyZoneTapped = _highlightedZone != null;

    return Container(
      width: double.infinity,
      padding: EdgeInsets.all(4.w),
      decoration: BoxDecoration(
        color: theme.cardColor,
        borderRadius: BorderRadius.circular(20.0),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: 0.06),
            blurRadius: 16,
            offset: const Offset(0, 6),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Header row
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'Analyse Corporelle',
                    style: GoogleFonts.manrope(
                      fontSize: 13.sp,
                      fontWeight: FontWeight.w700,
                      color: theme.colorScheme.onSurface,
                    ),
                  ),
                  Text(
                    'Tap a zone to highlight',
                    style: GoogleFonts.dmSans(
                      fontSize: 9.sp,
                      color: theme.colorScheme.onSurfaceVariant,
                      fontWeight: FontWeight.w400,
                    ),
                  ),
                ],
              ),
              // Segmented toggle
              Container(
                padding: const EdgeInsets.all(3),
                decoration: BoxDecoration(
                  color: theme.colorScheme.surfaceContainerHighest.withValues(
                    alpha: 0.5,
                  ),
                  borderRadius: BorderRadius.circular(12.0),
                ),
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    _ToggleTab(
                      label: 'Masse Grasse',
                      isSelected: _selectedTab == 0,
                      onTap: () => _switchTab(0),
                      theme: theme,
                    ),
                    SizedBox(width: 1.w),
                    _ToggleTab(
                      label: 'Masse Maigre',
                      isSelected: _selectedTab == 1,
                      onTap: () => _switchTab(1),
                      theme: theme,
                    ),
                  ],
                ),
              ),
            ],
          ),
          SizedBox(height: 2.5.h),
          // Body silhouette with labels
          FadeTransition(
            opacity: _fadeAnim,
            child: AnimatedSwitcher(
              duration: const Duration(milliseconds: 400),
              transitionBuilder: (child, animation) =>
                  FadeTransition(opacity: animation, child: child),
              child: _SilhouetteWithLabels(
                key: ValueKey('$_selectedTab-$_highlightedZone'),
                zones: zones,
                isFat: isFat,
                theme: theme,
                unit: _unit(''),
                zoneColorFn: _zoneColor,
                highlightedZone: _highlightedZone,
                onZoneTap: _onZoneTap,
                pulseAnim: _pulseAnim,
                isAnyZoneTapped: isAnyZoneTapped,
              ),
            ),
          ),
          SizedBox(height: 1.5.h),
          // Legend
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: isFat
                ? [
                    _LegendDot(
                      color: const Color(0xFF00D4AA),
                      label: 'Low',
                      theme: theme,
                    ),
                    SizedBox(width: 3.w),
                    _LegendDot(
                      color: const Color(0xFF74B9FF),
                      label: 'Moderate',
                      theme: theme,
                    ),
                    SizedBox(width: 3.w),
                    _LegendDot(
                      color: const Color(0xFFFFB347),
                      label: 'High',
                      theme: theme,
                    ),
                  ]
                : [
                    _LegendDot(
                      color: const Color(0xFF6C5CE7),
                      label: 'Light',
                      theme: theme,
                    ),
                    SizedBox(width: 3.w),
                    _LegendDot(
                      color: const Color(0xFF00D4AA),
                      label: 'Moderate',
                      theme: theme,
                    ),
                    SizedBox(width: 3.w),
                    _LegendDot(
                      color: const Color(0xFF00B894),
                      label: 'Dense',
                      theme: theme,
                    ),
                  ],
          ),
          // Highlighted zone detail card
          if (_highlightedZone != null) ...[
            SizedBox(height: 1.5.h),
            _ZoneDetailCard(
              zone: _highlightedZone!,
              value: zones[_highlightedZone!] ?? 0,
              unit: _unit(''),
              color: _zoneColor(zones[_highlightedZone!] ?? 0, isFat),
              isFat: isFat,
              theme: theme,
            ),
          ],
        ],
      ),
    );
  }
}

/// Zone detail card shown when a zone is tapped
class _ZoneDetailCard extends StatelessWidget {
  final String zone;
  final double value;
  final String unit;
  final Color color;
  final bool isFat;
  final ThemeData theme;

  const _ZoneDetailCard({
    required this.zone,
    required this.value,
    required this.unit,
    required this.color,
    required this.isFat,
    required this.theme,
  });

  String get _statusLabel {
    if (isFat) {
      if (value < 12) return 'Excellent';
      if (value < 20) return 'Good';
      if (value < 28) return 'Moderate';
      return 'High';
    } else {
      if (value < 5) return 'Light';
      if (value < 15) return 'Moderate';
      if (value < 30) return 'Good';
      return 'Dense';
    }
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedContainer(
      duration: const Duration(milliseconds: 300),
      curve: Curves.easeOutCubic,
      padding: EdgeInsets.symmetric(horizontal: 3.w, vertical: 1.2.h),
      decoration: BoxDecoration(
        color: color.withValues(alpha: 0.10),
        borderRadius: BorderRadius.circular(14.0),
        border: Border.all(color: color.withValues(alpha: 0.30), width: 1.5),
      ),
      child: Row(
        children: [
          Container(
            width: 10.w,
            height: 10.w,
            decoration: BoxDecoration(
              color: color.withValues(alpha: 0.18),
              shape: BoxShape.circle,
            ),
            child: Center(
              child: Text(
                '${value.toStringAsFixed(1)}$unit',
                style: GoogleFonts.manrope(
                  fontSize: 8.sp,
                  fontWeight: FontWeight.w800,
                  color: color,
                ),
              ),
            ),
          ),
          SizedBox(width: 3.w),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  zone,
                  style: GoogleFonts.manrope(
                    fontSize: 11.sp,
                    fontWeight: FontWeight.w700,
                    color: theme.colorScheme.onSurface,
                  ),
                ),
                Text(
                  isFat
                      ? 'Body Fat — $_statusLabel'
                      : 'Lean Mass — $_statusLabel',
                  style: GoogleFonts.dmSans(
                    fontSize: 9.sp,
                    color: color,
                    fontWeight: FontWeight.w500,
                  ),
                ),
              ],
            ),
          ),
          Container(
            padding: EdgeInsets.symmetric(horizontal: 2.w, vertical: 0.4.h),
            decoration: BoxDecoration(
              color: color.withValues(alpha: 0.15),
              borderRadius: BorderRadius.circular(8.0),
            ),
            child: Text(
              _statusLabel,
              style: GoogleFonts.dmSans(
                fontSize: 8.sp,
                fontWeight: FontWeight.w700,
                color: color,
              ),
            ),
          ),
        ],
      ),
    );
  }
}

/// Silhouette centered with labels: left labels on left, right labels on right,
/// Upper Body label overlaid directly on torso center — no box, plain text.
class _SilhouetteWithLabels extends StatelessWidget {
  final Map<String, double> zones;
  final bool isFat;
  final ThemeData theme;
  final String unit;
  final Color Function(double, bool) zoneColorFn;
  final String? highlightedZone;
  final void Function(String) onZoneTap;
  final Animation<double> pulseAnim;
  final bool isAnyZoneTapped;

  const _SilhouetteWithLabels({
    super.key,
    required this.zones,
    required this.isFat,
    required this.theme,
    required this.unit,
    required this.zoneColorFn,
    required this.highlightedZone,
    required this.onZoneTap,
    required this.pulseAnim,
    required this.isAnyZoneTapped,
  });

  @override
  Widget build(BuildContext context) {
    final double silhH = 36.h;
    final double silhW = 28.w;
    final double sideW = 24.w;

    const double armMidFrac = 0.30;
    const double legMidFrac = 0.70;

    // Use distinct fixed colors per zone for consistent identification
    const Color leftArmColor = Color(0xFF6C5CE7); // purple
    const Color rightArmColor = Color(0xFF0984E3); // blue
    const Color upperBodyColor = Color(0xFF00B894); // teal
    const Color leftLegColor = Color(0xFFFDCB6E); // amber
    const Color rightLegColor = Color(0xFFE17055); // orange

    return SizedBox(
      height: silhH,
      child: Stack(
        alignment: Alignment.center,
        children: [
          Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // LEFT labels
              SizedBox(
                width: sideW,
                height: silhH,
                child: Stack(
                  children: [
                    Positioned(
                      top: silhH * armMidFrac - 14,
                      right: 0,
                      child: _TappableZoneLabel(
                        label: 'Bras Gauche',
                        value: zones['Bras Gauche'] ?? 0,
                        unit: unit,
                        color: leftArmColor,
                        theme: theme,
                        alignRight: true,
                        isHighlighted: highlightedZone == 'Bras Gauche',
                        onTap: () => onZoneTap('Bras Gauche'),
                        pulseAnim: pulseAnim,
                        isHighlightedZone: highlightedZone == 'Bras Gauche',
                      ),
                    ),
                    Positioned(
                      top: silhH * legMidFrac - 14,
                      right: 0,
                      child: _TappableZoneLabel(
                        label: 'Jambe Gauche',
                        value: zones['Jambe Gauche'] ?? 0,
                        unit: unit,
                        color: leftLegColor,
                        theme: theme,
                        alignRight: true,
                        isHighlighted: highlightedZone == 'Jambe Gauche',
                        onTap: () => onZoneTap('Jambe Gauche'),
                        pulseAnim: pulseAnim,
                        isHighlightedZone: highlightedZone == 'Jambe Gauche',
                      ),
                    ),
                  ],
                ),
              ),
              SizedBox(width: 1.5.w),
              // Center silhouette
              GestureDetector(
                onTapDown: (details) {
                  final localPos = details.localPosition;
                  final h = silhH;
                  final w = silhW;
                  final x = localPos.dx / w;
                  final y = localPos.dy / h;
                  if (y < 0.13) return;
                  if (y >= 0.13 && y <= 0.48) {
                    if (x < 0.20) {
                      onZoneTap('Bras Gauche');
                    } else if (x > 0.80) {
                      onZoneTap('Bras Droit');
                    } else {
                      onZoneTap('Haut du Corps');
                    }
                  } else if (y > 0.48) {
                    if (x < 0.50) {
                      onZoneTap('Jambe Gauche');
                    } else {
                      onZoneTap('Jambe Droite');
                    }
                  }
                },
                child: SizedBox(
                  width: silhW,
                  height: silhH,
                  child: CustomPaint(
                    size: Size(silhW, silhH),
                    painter: _RealisticBodySilhouettePainter(
                      zones: zones,
                      isFat: isFat,
                      theme: theme,
                      highlightedZone: highlightedZone,
                    ),
                  ),
                ),
              ),
              SizedBox(width: 1.5.w),
              // RIGHT labels
              SizedBox(
                width: sideW,
                height: silhH,
                child: Stack(
                  children: [
                    Positioned(
                      top: silhH * armMidFrac - 14,
                      left: 0,
                      child: _TappableZoneLabel(
                        label: 'Bras Droit',
                        value: zones['Bras Droit'] ?? 0,
                        unit: unit,
                        color: rightArmColor,
                        theme: theme,
                        alignRight: false,
                        isHighlighted: highlightedZone == 'Bras Droit',
                        onTap: () => onZoneTap('Bras Droit'),
                        pulseAnim: pulseAnim,
                        isHighlightedZone: highlightedZone == 'Bras Droit',
                      ),
                    ),
                    Positioned(
                      top: silhH * legMidFrac - 14,
                      left: 0,
                      child: _TappableZoneLabel(
                        label: 'Jambe Droite',
                        value: zones['Jambe Droite'] ?? 0,
                        unit: unit,
                        color: rightLegColor,
                        theme: theme,
                        alignRight: false,
                        isHighlighted: highlightedZone == 'Jambe Droite',
                        onTap: () => onZoneTap('Jambe Droite'),
                        pulseAnim: pulseAnim,
                        isHighlightedZone: highlightedZone == 'Jambe Droite',
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
          // Upper Body label — precisely centered on torso
          Positioned.fill(
            child: Align(
              alignment: const Alignment(0.0, -0.30),
              child: GestureDetector(
                onTap: () => onZoneTap('Haut du Corps'),
                child: _UpperBodyPlainLabel(
                  value: zones['Haut du Corps'] ?? 0,
                  unit: unit,
                  color: upperBodyColor,
                  theme: theme,
                  isHighlighted: highlightedZone == 'Haut du Corps',
                  pulseAnim: pulseAnim,
                  isHighlightedZone: highlightedZone == 'Haut du Corps',
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

/// Upper Body label — plain text only, no background box, centered on torso.
/// Only animates when this zone is highlighted (tapped).
class _UpperBodyPlainLabel extends StatelessWidget {
  final double value;
  final String unit;
  final Color color;
  final ThemeData theme;
  final bool isHighlighted;
  final Animation<double> pulseAnim;
  final bool isHighlightedZone;

  const _UpperBodyPlainLabel({
    required this.value,
    required this.unit,
    required this.color,
    required this.theme,
    required this.isHighlighted,
    required this.pulseAnim,
    required this.isHighlightedZone,
  });

  @override
  Widget build(BuildContext context) {
    const Color labelColor = Colors.black;

    Widget content = AnimatedScale(
      scale: isHighlighted ? 1.12 : 1.0,
      duration: const Duration(milliseconds: 200),
      curve: Curves.easeOutBack,
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Text(
            'Upper',
            style: GoogleFonts.dmSans(
              fontSize: 9.sp,
              fontWeight: FontWeight.w700,
              color: labelColor,
              shadows: [
                Shadow(
                  color: Colors.white.withValues(alpha: 0.7),
                  blurRadius: 4,
                  offset: const Offset(0, 1),
                ),
              ],
            ),
          ),
          Text(
            'Body',
            style: GoogleFonts.dmSans(
              fontSize: 9.sp,
              fontWeight: FontWeight.w700,
              color: labelColor,
              shadows: [
                Shadow(
                  color: Colors.white.withValues(alpha: 0.7),
                  blurRadius: 4,
                  offset: const Offset(0, 1),
                ),
              ],
            ),
          ),
          Text(
            '${value.toStringAsFixed(1)}$unit',
            style: GoogleFonts.manrope(
              fontSize: 10.5.sp,
              fontWeight: FontWeight.w800,
              color: labelColor,
              shadows: [
                Shadow(
                  color: Colors.white.withValues(alpha: 0.7),
                  blurRadius: 4,
                  offset: const Offset(0, 1),
                ),
              ],
            ),
          ),
        ],
      ),
    );

    // Only apply pulse animation when this specific zone is highlighted
    if (isHighlightedZone) {
      return AnimatedBuilder(
        animation: pulseAnim,
        builder: (context, child) =>
            Transform.scale(scale: pulseAnim.value, child: child),
        child: content,
      );
    }
    return content;
  }
}

/// Tappable zone label — stable when not tapped, animates only on tap.
class _TappableZoneLabel extends StatelessWidget {
  final String label;
  final double value;
  final String unit;
  final Color color;
  final ThemeData theme;
  final bool alignRight;
  final bool isHighlighted;
  final VoidCallback onTap;
  final Animation<double> pulseAnim;
  final bool isHighlightedZone;

  const _TappableZoneLabel({
    required this.label,
    required this.value,
    required this.unit,
    required this.color,
    required this.theme,
    required this.alignRight,
    required this.isHighlighted,
    required this.onTap,
    required this.pulseAnim,
    required this.isHighlightedZone,
  });

  @override
  Widget build(BuildContext context) {
    Widget content = GestureDetector(
      onTap: onTap,
      child: AnimatedScale(
        scale: isHighlighted ? 1.12 : 1.0,
        duration: const Duration(milliseconds: 200),
        curve: Curves.easeOutBack,
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 250),
          padding: isHighlighted
              ? EdgeInsets.symmetric(horizontal: 1.5.w, vertical: 0.3.h)
              : EdgeInsets.zero,
          decoration: isHighlighted
              ? BoxDecoration(
                  color: color.withValues(alpha: 0.15),
                  borderRadius: BorderRadius.circular(8.0),
                  boxShadow: [
                    BoxShadow(
                      color: color.withValues(alpha: 0.35),
                      blurRadius: 8,
                      spreadRadius: 1,
                    ),
                  ],
                )
              : null,
          child: Column(
            crossAxisAlignment: alignRight
                ? CrossAxisAlignment.end
                : CrossAxisAlignment.start,
            mainAxisSize: MainAxisSize.min,
            children: [
              Text(
                label,
                style: GoogleFonts.dmSans(
                  fontSize: 9.sp,
                  fontWeight: isHighlighted ? FontWeight.w700 : FontWeight.w600,
                  color: isHighlighted ? color : theme.colorScheme.onSurface,
                ),
                textAlign: alignRight ? TextAlign.right : TextAlign.left,
              ),
              Text(
                '${value.toStringAsFixed(1)}$unit',
                style: GoogleFonts.manrope(
                  fontSize: 10.sp,
                  fontWeight: FontWeight.w700,
                  color: color,
                ),
                textAlign: alignRight ? TextAlign.right : TextAlign.left,
              ),
            ],
          ),
        ),
      ),
    );

    // Only apply pulse animation when this specific zone is highlighted
    if (isHighlightedZone) {
      return AnimatedBuilder(
        animation: pulseAnim,
        builder: (context, child) =>
            Transform.scale(scale: pulseAnim.value, child: child),
        child: content,
      );
    }
    return content;
  }
}

class _ToggleTab extends StatelessWidget {
  final String label;
  final bool isSelected;
  final VoidCallback onTap;
  final ThemeData theme;

  const _ToggleTab({
    required this.label,
    required this.isSelected,
    required this.onTap,
    required this.theme,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 200),
        padding: EdgeInsets.symmetric(horizontal: 2.5.w, vertical: 0.7.h),
        decoration: BoxDecoration(
          color: isSelected ? const Color(0xFF6C5CE7) : Colors.transparent,
          borderRadius: BorderRadius.circular(9.0),
          boxShadow: isSelected
              ? [
                  BoxShadow(
                    color: const Color(0xFF6C5CE7).withValues(alpha: 0.3),
                    blurRadius: 8,
                    offset: const Offset(0, 2),
                  ),
                ]
              : null,
        ),
        child: Text(
          label,
          style: GoogleFonts.dmSans(
            fontSize: 9.sp,
            fontWeight: FontWeight.w600,
            color: isSelected
                ? Colors.white
                : theme.colorScheme.onSurfaceVariant,
          ),
        ),
      ),
    );
  }
}

class _LegendDot extends StatelessWidget {
  final Color color;
  final String label;
  final ThemeData theme;

  const _LegendDot({
    required this.color,
    required this.label,
    required this.theme,
  });

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        Container(
          width: 8,
          height: 8,
          decoration: BoxDecoration(color: color, shape: BoxShape.circle),
        ),
        SizedBox(width: 1.w),
        Text(
          label,
          style: GoogleFonts.dmSans(
            fontSize: 8.5.sp,
            color: theme.colorScheme.onSurfaceVariant,
            fontWeight: FontWeight.w400,
          ),
        ),
      ],
    );
  }
}

/// Premium realistic human body silhouette with natural proportions.
/// Supports zone highlighting with glow effect.
class _RealisticBodySilhouettePainter extends CustomPainter {
  final Map<String, double> zones;
  final bool isFat;
  final ThemeData theme;
  final String? highlightedZone;

  _RealisticBodySilhouettePainter({
    required this.zones,
    required this.isFat,
    required this.theme,
    this.highlightedZone,
  });

  /// Distinct fixed colors per zone for consistent visual identification
  Color _zoneColor(String zone) {
    switch (zone) {
      case 'Bras Gauche':
        return const Color(0xFF6C5CE7); // purple
      case 'Bras Droit':
        return const Color(0xFF0984E3); // blue
      case 'Haut du Corps':
        return const Color(0xFF00B894); // teal
      case 'Jambe Gauche':
        return const Color(0xFFFDCB6E); // amber
      case 'Jambe Droite':
        return const Color(0xFFE17055); // orange
      default:
        return const Color(0xFF6C5CE7);
    }
  }

  Paint _zonePaint(String zone) {
    final color = _zoneColor(zone);
    final isHighlighted = highlightedZone == zone;
    final isIdle = highlightedZone == null;
    return Paint()
      ..color = color.withValues(
        alpha: isHighlighted ? 0.80 : (isIdle ? 0.55 : 0.40),
      )
      ..style = PaintingStyle.fill
      ..maskFilter = isHighlighted
          ? const MaskFilter.blur(BlurStyle.normal, 6)
          : null;
  }

  Paint _outlinePaint(String zone) {
    final color = _zoneColor(zone);
    final isHighlighted = highlightedZone == zone;
    return Paint()
      ..color = isHighlighted
          ? color.withValues(alpha: 0.90)
          : color.withValues(alpha: 0.35)
      ..style = PaintingStyle.stroke
      ..strokeWidth = isHighlighted ? 2.0 : 1.2
      ..strokeJoin = StrokeJoin.round
      ..strokeCap = StrokeCap.round;
  }

  @override
  void paint(Canvas canvas, Size size) {
    final w = size.width;
    final h = size.height;

    final defaultOutline = Paint()
      ..color = theme.colorScheme.onSurface.withValues(alpha: 0.15)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1.0
      ..strokeJoin = StrokeJoin.round
      ..strokeCap = StrokeCap.round;

    // ── HEAD ──
    final headPaint = Paint()
      ..color = theme.colorScheme.onSurface.withValues(alpha: 0.20)
      ..style = PaintingStyle.fill;
    final headPath = Path()
      ..addOval(
        Rect.fromCenter(
          center: Offset(w * 0.5, h * 0.07),
          width: w * 0.26,
          height: h * 0.13,
        ),
      );
    canvas.drawPath(headPath, headPaint);
    canvas.drawPath(headPath, defaultOutline);

    // ── NECK ──
    final neckPaint = Paint()
      ..color = theme.colorScheme.onSurface.withValues(alpha: 0.16)
      ..style = PaintingStyle.fill;
    final neckPath = Path()
      ..moveTo(w * 0.44, h * 0.132)
      ..lineTo(w * 0.56, h * 0.132)
      ..lineTo(w * 0.545, h * 0.165)
      ..lineTo(w * 0.455, h * 0.165)
      ..close();
    canvas.drawPath(neckPath, neckPaint);

    // ── TORSO (Upper Body) ──
    final torsoPath = Path()
      ..moveTo(w * 0.22, h * 0.165)
      ..cubicTo(w * 0.18, h * 0.175, w * 0.16, h * 0.185, w * 0.20, h * 0.195)
      ..cubicTo(w * 0.22, h * 0.25, w * 0.24, h * 0.32, w * 0.26, h * 0.38)
      ..cubicTo(w * 0.27, h * 0.42, w * 0.28, h * 0.46, w * 0.30, h * 0.50)
      ..lineTo(w * 0.70, h * 0.50)
      ..cubicTo(w * 0.72, h * 0.46, w * 0.73, h * 0.42, w * 0.74, h * 0.38)
      ..cubicTo(w * 0.76, h * 0.32, w * 0.78, h * 0.25, w * 0.80, h * 0.195)
      ..cubicTo(w * 0.84, h * 0.185, w * 0.82, h * 0.175, w * 0.78, h * 0.165)
      ..close();
    canvas.drawPath(torsoPath, _zonePaint('Haut du Corps'));
    canvas.drawPath(torsoPath, _outlinePaint('Haut du Corps'));

    // ── LEFT ARM ──
    final leftArmPath = Path()
      ..moveTo(w * 0.22, h * 0.165)
      ..cubicTo(w * 0.12, h * 0.185, w * 0.07, h * 0.22, w * 0.04, h * 0.30)
      ..cubicTo(w * 0.02, h * 0.36, w * 0.03, h * 0.42, w * 0.06, h * 0.455)
      ..lineTo(w * 0.115, h * 0.455)
      ..cubicTo(w * 0.10, h * 0.42, w * 0.10, h * 0.36, w * 0.12, h * 0.30)
      ..cubicTo(w * 0.15, h * 0.23, w * 0.18, h * 0.20, w * 0.22, h * 0.195)
      ..close();
    canvas.drawPath(leftArmPath, _zonePaint('Bras Gauche'));
    canvas.drawPath(leftArmPath, _outlinePaint('Bras Gauche'));

    // ── RIGHT ARM ──
    final rightArmPath = Path()
      ..moveTo(w * 0.78, h * 0.165)
      ..cubicTo(w * 0.88, h * 0.185, w * 0.93, h * 0.22, w * 0.96, h * 0.30)
      ..cubicTo(w * 0.98, h * 0.36, w * 0.97, h * 0.42, w * 0.94, h * 0.455)
      ..lineTo(w * 0.885, h * 0.455)
      ..cubicTo(w * 0.90, h * 0.42, w * 0.90, h * 0.36, w * 0.88, h * 0.30)
      ..cubicTo(w * 0.85, h * 0.23, w * 0.82, h * 0.20, w * 0.78, h * 0.195)
      ..close();
    canvas.drawPath(rightArmPath, _zonePaint('Bras Droit'));
    canvas.drawPath(rightArmPath, _outlinePaint('Bras Droit'));

    // ── LEFT LEG ──
    final leftLegPath = Path()
      ..moveTo(w * 0.29, h * 0.505)
      ..lineTo(w * 0.49, h * 0.505)
      ..cubicTo(w * 0.49, h * 0.58, w * 0.48, h * 0.65, w * 0.46, h * 0.72)
      ..cubicTo(w * 0.44, h * 0.80, w * 0.43, h * 0.87, w * 0.43, h * 0.93)
      ..lineTo(w * 0.36, h * 0.93)
      ..cubicTo(w * 0.35, h * 0.87, w * 0.33, h * 0.80, w * 0.32, h * 0.72)
      ..cubicTo(w * 0.28, h * 0.65, w * 0.28, h * 0.58, w * 0.29, h * 0.505)
      ..close();
    canvas.drawPath(leftLegPath, _zonePaint('Jambe Gauche'));
    canvas.drawPath(leftLegPath, _outlinePaint('Jambe Gauche'));

    // ── RIGHT LEG ──
    final rightLegPath = Path()
      ..moveTo(w * 0.51, h * 0.505)
      ..lineTo(w * 0.71, h * 0.505)
      ..cubicTo(w * 0.72, h * 0.58, w * 0.71, h * 0.65, w * 0.68, h * 0.72)
      ..cubicTo(w * 0.67, h * 0.80, w * 0.65, h * 0.87, w * 0.64, h * 0.93)
      ..lineTo(w * 0.57, h * 0.93)
      ..cubicTo(w * 0.57, h * 0.87, w * 0.56, h * 0.80, w * 0.54, h * 0.72)
      ..cubicTo(w * 0.52, h * 0.65, w * 0.51, h * 0.58, w * 0.51, h * 0.505)
      ..close();
    canvas.drawPath(rightLegPath, _zonePaint('Jambe Droite'));
    canvas.drawPath(rightLegPath, _outlinePaint('Jambe Droite'));

    // ── FEET ──
    final footPaint = Paint()
      ..color = theme.colorScheme.onSurface.withValues(alpha: 0.14)
      ..style = PaintingStyle.fill;
    final leftFootPath = Path()
      ..moveTo(w * 0.34, h * 0.93)
      ..lineTo(w * 0.45, h * 0.93)
      ..cubicTo(w * 0.47, h * 0.955, w * 0.47, h * 0.975, w * 0.44, h * 0.98)
      ..lineTo(w * 0.32, h * 0.98)
      ..cubicTo(w * 0.30, h * 0.975, w * 0.31, h * 0.955, w * 0.34, h * 0.93)
      ..close();
    canvas.drawPath(leftFootPath, footPaint);
    final rightFootPath = Path()
      ..moveTo(w * 0.55, h * 0.93)
      ..lineTo(w * 0.66, h * 0.93)
      ..cubicTo(w * 0.69, h * 0.955, w * 0.70, h * 0.975, w * 0.68, h * 0.98)
      ..lineTo(w * 0.53, h * 0.98)
      ..cubicTo(w * 0.53, h * 0.975, w * 0.53, h * 0.955, w * 0.55, h * 0.93)
      ..close();
    canvas.drawPath(rightFootPath, footPaint);
  }

  @override
  bool shouldRepaint(_RealisticBodySilhouettePainter oldDelegate) =>
      oldDelegate.zones != zones ||
      oldDelegate.isFat != isFat ||
      oldDelegate.highlightedZone != highlightedZone;
}
