import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:sizer/sizer.dart';

import '../../../widgets/custom_icon_widget.dart';

class QuickStatsRowWidget extends StatelessWidget {
  final double leanMass;
  final int goalAlignment;
  final double fatMass;

  const QuickStatsRowWidget({
    super.key,
    required this.leanMass,
    required this.goalAlignment,
    required this.fatMass,
  });

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return Row(
      children: [
        Expanded(
          child: _StatCard(
            icon: 'fitness_center',
            label: 'Masse Maigre',
            value: leanMass.toStringAsFixed(1),
            unit: 'kg',
            accentColor: const Color(0xFF6C5CE7),
            theme: theme,
          ),
        ),
        SizedBox(width: 2.5.w),
        Expanded(
          child: _StatCard(
            icon: 'track_changes',
            label: 'Objectif',
            value: '$goalAlignment',
            unit: '%',
            accentColor: const Color(0xFF00C48C),
            theme: theme,
          ),
        ),
        SizedBox(width: 2.5.w),
        Expanded(
          child: _StatCard(
            icon: 'local_fire_department',
            label: 'Masse Grasse',
            value: fatMass.toStringAsFixed(1),
            unit: 'kg',
            accentColor: const Color(0xFFFF7043),
            theme: theme,
          ),
        ),
      ],
    );
  }
}

class _StatCard extends StatelessWidget {
  final String icon;
  final String label;
  final String value;
  final String unit;
  final Color accentColor;
  final ThemeData theme;

  const _StatCard({
    required this.icon,
    required this.label,
    required this.value,
    required this.unit,
    required this.accentColor,
    required this.theme,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: EdgeInsets.symmetric(vertical: 2.2.h, horizontal: 2.w),
      decoration: BoxDecoration(
        color: theme.cardColor,
        borderRadius: BorderRadius.circular(16.0),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: 0.06),
            blurRadius: 12,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          // Icon circle
          Container(
            width: 11.w,
            height: 11.w,
            decoration: BoxDecoration(
              color: accentColor.withValues(alpha: 0.14),
              shape: BoxShape.circle,
            ),
            child: Center(
              child: CustomIconWidget(
                iconName: icon,
                color: accentColor,
                size: 20,
              ),
            ),
          ),
          SizedBox(height: 1.h),
          // Value + unit
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              Flexible(
                child: Text(
                  value,
                  style: GoogleFonts.manrope(
                    fontSize: 15.sp,
                    fontWeight: FontWeight.w800,
                    color: accentColor,
                    height: 1.0,
                  ),
                  overflow: TextOverflow.ellipsis,
                  maxLines: 1,
                ),
              ),
              Padding(
                padding: const EdgeInsets.only(bottom: 2),
                child: Text(
                  unit,
                  style: GoogleFonts.dmSans(
                    fontSize: 9.sp,
                    fontWeight: FontWeight.w600,
                    color: theme.colorScheme.onSurfaceVariant,
                  ),
                ),
              ),
            ],
          ),
          SizedBox(height: 0.5.h),
          Text(
            label,
            style: GoogleFonts.dmSans(
              fontSize: 8.sp,
              color: theme.colorScheme.onSurfaceVariant,
              fontWeight: FontWeight.w500,
            ),
            overflow: TextOverflow.ellipsis,
            maxLines: 1,
            textAlign: TextAlign.center,
          ),
        ],
      ),
    );
  }
}
