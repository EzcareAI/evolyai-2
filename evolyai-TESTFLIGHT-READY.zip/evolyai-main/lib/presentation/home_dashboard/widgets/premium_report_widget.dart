import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:sizer/sizer.dart';

import '../../../widgets/custom_icon_widget.dart';

class PremiumReportWidget extends StatelessWidget {
  final bool isPremium;

  const PremiumReportWidget({super.key, required this.isPremium});

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            Text(
              'Rapports Premium',
              style: GoogleFonts.manrope(
                fontSize: 13.sp,
                fontWeight: FontWeight.w700,
                color: theme.colorScheme.onSurface,
              ),
            ),
            SizedBox(width: 2.w),
            if (isPremium)
              Container(
                padding: EdgeInsets.symmetric(horizontal: 2.w, vertical: 0.3.h),
                decoration: BoxDecoration(
                  gradient: const LinearGradient(
                    colors: [Color(0xFF6C5CE7), Color(0xFF74B9FF)],
                  ),
                  borderRadius: BorderRadius.circular(8.0),
                ),
                child: Text(
                  'PRO',
                  style: GoogleFonts.manrope(
                    fontSize: 8.sp,
                    color: Colors.white,
                    fontWeight: FontWeight.w700,
                  ),
                ),
              ),
          ],
        ),
        SizedBox(height: 1.5.h),
        GridView.count(
          crossAxisCount: 2,
          shrinkWrap: true,
          physics: const NeverScrollableScrollPhysics(),
          crossAxisSpacing: 2.5.w,
          mainAxisSpacing: 1.5.h,
          childAspectRatio: 2.2,
          children: [
            _PremiumCard(
              icon: 'pie_chart',
              title: 'Composition',
              isPremium: isPremium,
              theme: theme,
              color: const Color(0xFF6C5CE7),
            ),
            _PremiumCard(
              icon: 'trending_up',
              title: 'Progression',
              isPremium: isPremium,
              theme: theme,
              color: const Color(0xFF00D4AA),
            ),
            _PremiumCard(
              icon: 'emoji_events',
              title: 'Objectif',
              isPremium: isPremium,
              theme: theme,
              color: const Color(0xFFFFB347),
            ),
            _PremiumCard(
              icon: 'compare_arrows',
              title: 'Comparaison',
              isPremium: isPremium,
              theme: theme,
              color: const Color(0xFF74B9FF),
              onTap: () => Navigator.pushNamed(context, '/compare-scans'),
            ),
          ],
        ),
      ],
    );
  }
}

class _PremiumCard extends StatelessWidget {
  final String icon;
  final String title;
  final bool isPremium;
  final ThemeData theme;
  final Color color;
  final VoidCallback? onTap;

  const _PremiumCard({
    required this.icon,
    required this.title,
    required this.isPremium,
    required this.theme,
    required this.color,
    this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: EdgeInsets.symmetric(horizontal: 3.w, vertical: 1.2.h),
        decoration: BoxDecoration(
          color: theme.cardColor,
          borderRadius: BorderRadius.circular(14.0),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withValues(alpha: 0.04),
              blurRadius: 8,
              offset: const Offset(0, 2),
            ),
          ],
        ),
        child: Row(
          children: [
            Container(
              width: 8.w,
              height: 8.w,
              decoration: BoxDecoration(
                color: color.withValues(alpha: 0.12),
                borderRadius: BorderRadius.circular(8.0),
              ),
              child: Center(
                child: CustomIconWidget(iconName: icon, color: color, size: 16),
              ),
            ),
            SizedBox(width: 2.w),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Text(
                    title,
                    style: GoogleFonts.dmSans(
                      fontSize: 9.sp,
                      fontWeight: FontWeight.w600,
                      color: theme.colorScheme.onSurface,
                    ),
                    overflow: TextOverflow.ellipsis,
                    maxLines: 2,
                  ),
                ],
              ),
            ),
            isPremium
                ? CustomIconWidget(
                    iconName: 'chevron_right',
                    color: theme.colorScheme.onSurfaceVariant.withValues(
                      alpha: 0.5,
                    ),
                    size: 14,
                  )
                : CustomIconWidget(
                    iconName: 'lock',
                    color: theme.colorScheme.onSurfaceVariant.withValues(
                      alpha: 0.4,
                    ),
                    size: 14,
                  ),
          ],
        ),
      ),
    );
  }
}
