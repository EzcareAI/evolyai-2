import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

import '../../../core/app_export.dart';
import '../../../widgets/custom_icon_widget.dart';

class RecentScanWidget extends StatelessWidget {
  final Map<String, dynamic> userData;
  final ThemeData theme;

  const RecentScanWidget({
    super.key,
    required this.userData,
    required this.theme,
  });

  @override
  Widget build(BuildContext context) {
    final List<Map<String, dynamic>> scanHistory = [
      {
        'date': '10/03/2026',
        'bodyFat': 18.5,
        'category': 'Athlétique',
        'change': -0.5,
      },
      {
        'date': '01/03/2026',
        'bodyFat': 19.0,
        'category': 'Fit',
        'change': -0.8,
      },
      {
        'date': '20/02/2026',
        'bodyFat': 19.8,
        'category': 'Fit',
        'change': -0.2,
      },
    ];

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          'Historique des Scans',
          style: theme.textTheme.titleMedium?.copyWith(
            fontWeight: FontWeight.w700,
            color: const Color(0xFF2D3436),
          ),
        ),
        SizedBox(height: 1.5.h),
        ListView.separated(
          shrinkWrap: true,
          physics: const NeverScrollableScrollPhysics(),
          itemCount: scanHistory.length,
          separatorBuilder: (_, __) => SizedBox(height: 1.h),
          itemBuilder: (context, index) {
            final scan = scanHistory[index];
            final change = scan['change'] as double;
            return Container(
              padding: EdgeInsets.all(3.w),
              decoration: BoxDecoration(
                color: const Color(0xFFF8F9FA),
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: const Color(0xFFE2E8F0)),
              ),
              child: Row(
                children: [
                  Container(
                    width: 10.w,
                    height: 10.w,
                    decoration: BoxDecoration(
                      color: const Color(0xFF6C5CE7).withValues(alpha: 0.1),
                      borderRadius: BorderRadius.circular(10),
                    ),
                    child: Center(
                      child: CustomIconWidget(
                        iconName: 'accessibility_new',
                        color: const Color(0xFF6C5CE7),
                        size: 20,
                      ),
                    ),
                  ),
                  SizedBox(width: 3.w),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          scan['date'] as String,
                          style: theme.textTheme.labelMedium?.copyWith(
                            color: const Color(0xFF636E72),
                          ),
                        ),
                        Text(
                          '${scan['category']} · ${scan['bodyFat']}% masse grasse',
                          style: theme.textTheme.titleSmall?.copyWith(
                            fontWeight: FontWeight.w600,
                            color: const Color(0xFF2D3436),
                          ),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    padding: EdgeInsets.symmetric(
                      horizontal: 2.w,
                      vertical: 0.5.h,
                    ),
                    decoration: BoxDecoration(
                      color: change < 0
                          ? const Color(0xFF00B894).withValues(alpha: 0.1)
                          : const Color(0xFFE53E3E).withValues(alpha: 0.1),
                      borderRadius: BorderRadius.circular(8),
                    ),
                    child: Text(
                      '${change > 0 ? '+' : ''}$change%',
                      style: theme.textTheme.labelSmall?.copyWith(
                        color: change < 0
                            ? const Color(0xFF00B894)
                            : const Color(0xFFE53E3E),
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                  ),
                ],
              ),
            );
          },
        ),
      ],
    );
  }
}
