import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:sizer/sizer.dart';

import '../../../widgets/custom_icon_widget.dart';

class SplitHeroCardWidget extends StatelessWidget {
  final double bodyFatPercentage;
  final String bodyCategory;
  final double progressChange;
  final String lastScanDate;

  const SplitHeroCardWidget({
    super.key,
    required this.bodyFatPercentage,
    required this.bodyCategory,
    required this.progressChange,
    required this.lastScanDate,
  });

  String get _physiqueEmoji {
    switch (bodyCategory.toLowerCase()) {
      case 'athletic':
        return '🔥';
      case 'lean':
      case 'essential':
        return '✨';
      case 'fit':
      case 'balanced':
        return '💪';
      case 'average':
        return '⚡';
      default:
        return '📊';
    }
  }

  @override
  Widget build(BuildContext context) {
    final isPositiveChange = progressChange < 0;

    return GestureDetector(
      onLongPress: () {
        HapticFeedback.mediumImpact();
        _showShareSheet(context);
      },
      child: Container(
        width: double.infinity,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(24.0),
          gradient: const LinearGradient(
            colors: [Color(0xFF0F1B35), Color(0xFF1B2D5A), Color(0xFF2A1B6E)],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            stops: [0.0, 0.5, 1.0],
          ),
          boxShadow: [
            BoxShadow(
              color: const Color(0xFF1B365D).withValues(alpha: 0.45),
              blurRadius: 28,
              offset: const Offset(0, 12),
            ),
          ],
        ),
        child: Stack(
          children: [
            // Decorative circles
            Positioned(
              top: -20,
              right: -20,
              child: Container(
                width: 30.w,
                height: 30.w,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: Colors.white.withValues(alpha: 0.03),
                ),
              ),
            ),
            Positioned(
              bottom: -30,
              left: -10,
              child: Container(
                width: 25.w,
                height: 25.w,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: Colors.white.withValues(alpha: 0.03),
                ),
              ),
            ),
            Padding(
              padding: EdgeInsets.all(4.w),
              child: Column(
                children: [
                  // Top label row
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Container(
                        padding: EdgeInsets.symmetric(
                          horizontal: 2.5.w,
                          vertical: 0.5.h,
                        ),
                        decoration: BoxDecoration(
                          color: Colors.white.withValues(alpha: 0.1),
                          borderRadius: BorderRadius.circular(20.0),
                          border: Border.all(
                            color: Colors.white.withValues(alpha: 0.15),
                          ),
                        ),
                        child: Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            Container(
                              width: 6,
                              height: 6,
                              decoration: const BoxDecoration(
                                color: Color(0xFF00D4AA),
                                shape: BoxShape.circle,
                              ),
                            ),
                            SizedBox(width: 1.5.w),
                            Text(
                              'Dernier Scan · $lastScanDate',
                              style: GoogleFonts.dmSans(
                                fontSize: 9.sp,
                                color: Colors.white.withValues(alpha: 0.7),
                                fontWeight: FontWeight.w500,
                              ),
                            ),
                          ],
                        ),
                      ),
                      GestureDetector(
                        onTap: () => _showShareSheet(context),
                        child: Container(
                          width: 8.w,
                          height: 8.w,
                          decoration: BoxDecoration(
                            color: Colors.white.withValues(alpha: 0.1),
                            shape: BoxShape.circle,
                            border: Border.all(
                              color: Colors.white.withValues(alpha: 0.15),
                            ),
                          ),
                          child: Center(
                            child: CustomIconWidget(
                              iconName: 'ios_share',
                              color: Colors.white.withValues(alpha: 0.8),
                              size: 14,
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                  SizedBox(height: 2.h),
                  // Split columns
                  IntrinsicHeight(
                    child: Row(
                      children: [
                        // Left: Body Fat — larger, more prominent
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                'Masse Grasse',
                                style: GoogleFonts.dmSans(
                                  fontSize: 10.sp,
                                  color: Colors.white.withValues(alpha: 0.65),
                                  fontWeight: FontWeight.w600,
                                  letterSpacing: 0.5,
                                ),
                              ),
                              SizedBox(height: 0.6.h),
                              Row(
                                crossAxisAlignment: CrossAxisAlignment.end,
                                children: [
                                  Text(
                                    bodyFatPercentage.toStringAsFixed(1),
                                    style: GoogleFonts.manrope(
                                      fontSize: 28.sp,
                                      fontWeight: FontWeight.w900,
                                      color: Colors.white,
                                      height: 1.0,
                                    ),
                                  ),
                                  Padding(
                                    padding: EdgeInsets.only(
                                      bottom: 0.6.h,
                                      left: 0.8.w,
                                    ),
                                    child: Text(
                                      '%',
                                      style: GoogleFonts.manrope(
                                        fontSize: 16.sp,
                                        fontWeight: FontWeight.w700,
                                        color: Colors.white.withValues(
                                          alpha: 0.75,
                                        ),
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                              SizedBox(height: 1.h),
                              Container(
                                padding: EdgeInsets.symmetric(
                                  horizontal: 2.w,
                                  vertical: 0.4.h,
                                ),
                                decoration: BoxDecoration(
                                  color: isPositiveChange
                                      ? const Color(
                                          0xFF00D4AA,
                                        ).withValues(alpha: 0.15)
                                      : Colors.redAccent.withValues(
                                          alpha: 0.15,
                                        ),
                                  borderRadius: BorderRadius.circular(8.0),
                                ),
                                child: Row(
                                  mainAxisSize: MainAxisSize.min,
                                  children: [
                                    CustomIconWidget(
                                      iconName: isPositiveChange
                                          ? 'trending_down'
                                          : 'trending_up',
                                      color: isPositiveChange
                                          ? const Color(0xFF00D4AA)
                                          : Colors.redAccent,
                                      size: 12,
                                    ),
                                    SizedBox(width: 1.w),
                                    Text(
                                      '${progressChange.abs().toStringAsFixed(1)}% vs last',
                                      style: GoogleFonts.dmSans(
                                        fontSize: 8.5.sp,
                                        color: isPositiveChange
                                            ? const Color(0xFF00D4AA)
                                            : Colors.redAccent,
                                        fontWeight: FontWeight.w600,
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ],
                          ),
                        ),
                        // Divider
                        Container(
                          width: 1,
                          margin: EdgeInsets.symmetric(horizontal: 3.w),
                          decoration: BoxDecoration(
                            gradient: LinearGradient(
                              colors: [
                                Colors.transparent,
                                Colors.white.withValues(alpha: 0.2),
                                Colors.transparent,
                              ],
                              begin: Alignment.topCenter,
                              end: Alignment.bottomCenter,
                            ),
                          ),
                        ),
                        // Right: Physique Profile — emoji + label inline, bright text
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                'Profil Physique',
                                style: GoogleFonts.dmSans(
                                  fontSize: 10.sp,
                                  color: Colors.white.withValues(alpha: 0.65),
                                  fontWeight: FontWeight.w600,
                                  letterSpacing: 0.5,
                                ),
                              ),
                              SizedBox(height: 1.2.h),
                              // Emoji + category inline on same row
                              Row(
                                crossAxisAlignment: CrossAxisAlignment.center,
                                children: [
                                  Text(
                                    _physiqueEmoji,
                                    style: const TextStyle(fontSize: 26),
                                  ),
                                  SizedBox(width: 2.w),
                                  Expanded(
                                    child: Text(
                                      bodyCategory,
                                      style: GoogleFonts.manrope(
                                        fontSize: 18.sp,
                                        fontWeight: FontWeight.w800,
                                        color: const Color(0xFFFFE566),
                                        height: 1.1,
                                      ),
                                      overflow: TextOverflow.ellipsis,
                                      maxLines: 1,
                                    ),
                                  ),
                                ],
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  void _showShareSheet(BuildContext context) {
    final bodyFat = bodyFatPercentage.toStringAsFixed(1);
    final statsText =
        'Résultats Scan Corporel Evoly AI\n'
        '• Body Fat: $bodyFat%\n'
        '• Physique Profile: $bodyCategory\n'
        '• Last Scan: $lastScanDate\n'
        'Suivi avec Evoly AI';

    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (ctx) {
        final theme = Theme.of(ctx);
        return Container(
          decoration: BoxDecoration(
            color: theme.scaffoldBackgroundColor,
            borderRadius: const BorderRadius.vertical(top: Radius.circular(20)),
          ),
          child: SafeArea(
            child: Padding(
              padding: EdgeInsets.symmetric(vertical: 2.h, horizontal: 4.w),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Container(
                    width: 10.w,
                    height: 0.5.h,
                    decoration: BoxDecoration(
                      color: theme.colorScheme.onSurfaceVariant.withValues(
                        alpha: 0.3,
                      ),
                      borderRadius: BorderRadius.circular(4.0),
                    ),
                  ),
                  SizedBox(height: 2.h),
                  Text(
                    'Partager vos résultats',
                    style: GoogleFonts.manrope(
                      fontSize: 14.sp,
                      fontWeight: FontWeight.w700,
                      color: theme.colorScheme.onSurface,
                    ),
                  ),
                  SizedBox(height: 2.h),
                  _ShareTile(
                    icon: 'share',
                    label: 'Partager',
                    onTap: () {
                      Navigator.pop(ctx);
                      Clipboard.setData(ClipboardData(text: statsText));
                      ScaffoldMessenger.of(context).showSnackBar(
                        SnackBar(
                          content: const Text(
                            'Résultats copiés — collez pour partager !',
                          ),
                          behavior: SnackBarBehavior.floating,
                          backgroundColor: const Color(0xFF6C5CE7),
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(10),
                          ),
                          duration: const Duration(seconds: 2),
                        ),
                      );
                    },
                  ),
                  _ShareTile(
                    icon: 'download',
                    label: 'Sauvegarder',
                    onTap: () {
                      Navigator.pop(ctx);
                      ScaffoldMessenger.of(context).showSnackBar(
                        SnackBar(
                          content: const Text('Screenshot saved to gallery'),
                          behavior: SnackBarBehavior.floating,
                          backgroundColor: const Color(0xFF00B894),
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(10),
                          ),
                          duration: const Duration(seconds: 2),
                        ),
                      );
                    },
                  ),
                  _ShareTile(
                    icon: 'content_copy',
                    label: 'Copy Stats',
                    onTap: () {
                      Navigator.pop(ctx);
                      Clipboard.setData(ClipboardData(text: statsText));
                      ScaffoldMessenger.of(context).showSnackBar(
                        SnackBar(
                          content: const Text('Stats copied to clipboard'),
                          behavior: SnackBarBehavior.floating,
                          backgroundColor: const Color(0xFF6C5CE7),
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(10),
                          ),
                          duration: const Duration(seconds: 2),
                        ),
                      );
                    },
                  ),
                  SizedBox(height: 1.h),
                ],
              ),
            ),
          ),
        );
      },
    );
  }
}

class _ShareTile extends StatelessWidget {
  final String icon;
  final String label;
  final VoidCallback onTap;

  const _ShareTile({
    required this.icon,
    required this.label,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return ListTile(
      leading: CustomIconWidget(
        iconName: icon,
        color: const Color(0xFF6C5CE7),
        size: 22,
      ),
      title: Text(
        label,
        style: GoogleFonts.dmSans(
          fontSize: 12.sp,
          fontWeight: FontWeight.w500,
          color: theme.colorScheme.onSurface,
        ),
      ),
      onTap: onTap,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12.0)),
    );
  }
}
