import 'package:flutter/material.dart';

import '../../models/onboarding_data.dart';
import '../../widgets/custom_bottom_bar.dart';
import './home_dashboard_initial_page.dart';
import '../progress_screen/progress_screen.dart';
import '../settings_screen/settings_screen.dart';

class HomeDashboard extends StatefulWidget {
  final OnboardingData? onboardingData;

  const HomeDashboard({super.key, this.onboardingData});

  @override
  HomeDashboardState createState() => HomeDashboardState();
}

class HomeDashboardState extends State<HomeDashboard> {
  int currentIndex = 0;

  // Keys to force rebuild of tabs when switching to them
  final GlobalKey<_RefreshableHomeState> _homeKey =
      GlobalKey<_RefreshableHomeState>();
  final GlobalKey<_RefreshableProgressState> _progressKey =
      GlobalKey<_RefreshableProgressState>();

  @override
  void initState() {
    super.initState();
    // When arriving from onboarding (onboardingData present), force an immediate
    // data reload after the first frame so the dashboard shows the latest scan.
    if (widget.onboardingData != null) {
      WidgetsBinding.instance.addPostFrameCallback((_) {
        _homeKey.currentState?.reload();
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: IndexedStack(
        index: currentIndex,
        children: [
          _RefreshableHome(
            key: _homeKey,
            onboardingData: widget.onboardingData,
          ),
          _RefreshableProgress(key: _progressKey),
          const SettingsScreen(),
        ],
      ),
      bottomNavigationBar: CustomBottomBar(
        currentIndex: currentIndex,
        onTap: (index) {
          if (currentIndex != index) {
            setState(() => currentIndex = index);
            // Trigger reload when switching to Home or Progress
            if (index == 0) {
              _homeKey.currentState?.reload();
            } else if (index == 1) {
              _progressKey.currentState?.reload();
            }
          }
        },
      ),
    );
  }
}

// ─── Refreshable Home wrapper ─────────────────────────────────────────────────

class _RefreshableHome extends StatefulWidget {
  final OnboardingData? onboardingData;
  const _RefreshableHome({super.key, this.onboardingData});

  @override
  _RefreshableHomeState createState() => _RefreshableHomeState();
}

class _RefreshableHomeState extends State<_RefreshableHome> {
  int _reloadKey = 0;

  void reload() {
    setState(() => _reloadKey++);
  }

  @override
  Widget build(BuildContext context) {
    return HomeDashboardInitialPage(
      key: ValueKey(_reloadKey),
      onboardingData: widget.onboardingData,
    );
  }
}

// ─── Refreshable Progress wrapper ────────────────────────────────────────────

class _RefreshableProgress extends StatefulWidget {
  const _RefreshableProgress({super.key});

  @override
  _RefreshableProgressState createState() => _RefreshableProgressState();
}

class _RefreshableProgressState extends State<_RefreshableProgress> {
  int _reloadKey = 0;

  void reload() {
    setState(() => _reloadKey++);
  }

  @override
  Widget build(BuildContext context) {
    return ProgressScreen(key: ValueKey(_reloadKey));
  }
}
