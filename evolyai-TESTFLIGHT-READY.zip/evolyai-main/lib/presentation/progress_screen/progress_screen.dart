import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:sizer/sizer.dart';

import '../../services/supabase_service.dart';
import '../../services/local_cache_service.dart';
import '../../services/sync_service.dart';
import '../scan_detail_screen/scan_detail_screen.dart';
import '../../routes/app_routes.dart';

class ProgressScreen extends StatefulWidget {
  const ProgressScreen({super.key});

  @override
  State<ProgressScreen> createState() => _ProgressScreenState();
}

class _ProgressScreenState extends State<ProgressScreen>
    with SingleTickerProviderStateMixin {
  late AnimationController _animController;
  late Animation<double> _fadeAnim;

  double? _goalBodyFat;
  bool _goalLoading = true;

  /// Live stream of scan results — drives chart, timeline, and goal progress.
  late final Stream<List<ScanResultModel>> _scanStream;

  // ── Sample data used when user taps "Preview with sample data" ──────────
  static final List<Map<String, dynamic>> _sampleHistory = [
    {
      'date': 'Jan 1, 2025',
      'bodyFat': 24.5,
      'weight': 0.0,
      'category': 'Average',
      'change': 0.0,
    },
    {
      'date': 'Jan 15, 2025',
      'bodyFat': 23.1,
      'weight': 0.0,
      'category': 'Fit',
      'change': -1.4,
    },
    {
      'date': 'Feb 1, 2025',
      'bodyFat': 21.8,
      'weight': 0.0,
      'category': 'Fit',
      'change': -1.3,
    },
    {
      'date': 'Feb 15, 2025',
      'bodyFat': 20.9,
      'weight': 0.0,
      'category': 'Athletic',
      'change': -0.9,
    },
  ];

  /// When non-null the screen shows sample data instead of the stream.
  List<Map<String, dynamic>>? _sampleOverride;

  @override
  void initState() {
    super.initState();
    _animController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 600),
    );
    _fadeAnim = CurvedAnimation(parent: _animController, curve: Curves.easeOut);
    _animController.forward();

    // Broadcast stream so multiple StreamBuilder widgets can share it.
    _scanStream = SupabaseService.instance
        .watchScanResults()
        .asBroadcastStream();

    _loadOnboardingGoal();
  }

  /// Loads only the goal body fat from onboarding answers (no scan fetch needed).
  Future<void> _loadOnboardingGoal() async {
    try {
      final onboarding = await SupabaseService.instance.loadOnboardingAnswers();
      double? goal;
      if (onboarding?.targetBodyFatPercent != null) {
        goal = onboarding!.targetBodyFatPercent;
      } else {
        goal = _goalBodyFatFromOnboarding(onboarding?.goal);
      }
      if (onboarding != null) {
        await LocalCacheService.instance.cacheOnboarding(onboarding.toJson());
      }
      if (mounted)
        setState(() {
          _goalBodyFat = goal;
          _goalLoading = false;
        });
    } catch (e) {
      debugPrint('[Progress] _loadOnboardingGoal error: $e');
      // Try cache fallback
      final cached = await LocalCacheService.instance.getCachedOnboarding();
      double? goal;
      if (cached != null) {
        final cachedTarget = cached['target_body_fat_percent'];
        if (cachedTarget != null) {
          goal = double.tryParse(cachedTarget.toString());
        } else {
          goal = _goalBodyFatFromOnboarding(cached['goal'] as String?);
        }
      }
      if (mounted)
        setState(() {
          _goalBodyFat = goal ?? 15.0;
          _goalLoading = false;
        });
    }
  }

  /// Convert onboarding goal string to a target body fat percentage
  double _goalBodyFatFromOnboarding(String? goal) {
    switch (goal?.toLowerCase()) {
      case 'lose fat':
      case 'lose_fat':
        return 15.0;
      case 'build muscle':
      case 'build_muscle':
        return 12.0;
      case 'maintain':
        return 18.0;
      case 'athletic performance':
      case 'athletic_performance':
        return 10.0;
      default:
        return 15.0;
    }
  }

  void _loadSampleData() {
    HapticFeedback.lightImpact();
    setState(() {
      _sampleOverride = List<Map<String, dynamic>>.from(_sampleHistory);
      _goalBodyFat ??= 15.0;
    });
  }

  String _formatDate(DateTime? dt) {
    if (dt == null) return '--';
    const months = [
      'Jan',
      'Fév',
      'Mar',
      'Avr',
      'Mai',
      'Juin',
      'Juil',
      'Aoû',
      'Sep',
      'Oct',
      'Nov',
      'Déc',
    ];
    return '${months[dt.month - 1]} ${dt.day}, ${dt.year}';
  }

  /// Convert raw ScanResultModel list → display map list with deltas.
  List<Map<String, dynamic>> _mapResults(List<ScanResultModel> results) {
    final mapped = results.map((r) {
      return {
        'date': _formatDate(r.createdAt),
        'bodyFat': r.bodyFatPercent ?? 0.0,
        'leanMass': r.leanMassEstimate != null
            ? (100.0 - (r.bodyFatPercent ?? 0.0))
            : null,
        'weight': 0.0,
        'category': r.bodyCategory ?? '--',
        'change': 0.0,
        'confidenceScore': r.confidenceScore,
        'scanId': r.scanId,
      };
    }).toList();

    for (int i = 1; i < mapped.length; i++) {
      final prev = mapped[i - 1]['bodyFat'] as double;
      final curr = mapped[i]['bodyFat'] as double;
      mapped[i]['change'] = curr - prev;
    }
    return mapped;
  }

  @override
  void dispose() {
    _animController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    // If sample override is active, bypass the stream entirely.
    if (_sampleOverride != null) {
      return Scaffold(
        backgroundColor: theme.scaffoldBackgroundColor,
        body: SafeArea(
          child: FadeTransition(
            opacity: _fadeAnim,
            child: _buildContent(theme, _sampleOverride!),
          ),
        ),
      );
    }

    return Scaffold(
      backgroundColor: theme.scaffoldBackgroundColor,
      body: SafeArea(
        child: StreamBuilder<List<ScanResultModel>>(
          stream: _scanStream,
          builder: (context, snapshot) {
            // Show spinner on first load only (no data yet).
            if (snapshot.connectionState == ConnectionState.waiting &&
                !snapshot.hasData) {
              return const Center(
                child: CircularProgressIndicator(color: Color(0xFF6C5CE7)),
              );
            }

            final results = snapshot.data ?? [];
            final scanHistory = _mapResults(results);

            // Cache latest results for offline use.
            if (results.isNotEmpty) {
              LocalCacheService.instance.cacheScanHistory(
                scanHistory.map((m) => Map<String, dynamic>.from(m)).toList(),
              );
            }

            // Show error/offline snackbar once when stream errors.
            if (snapshot.hasError) {
              WidgetsBinding.instance.addPostFrameCallback((_) {
                if (mounted) {
                  ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(
                      content: const Text(
                        'Données en cache — vous êtes hors ligne',
                      ),
                      behavior: SnackBarBehavior.floating,
                      backgroundColor: const Color(0xFFE17055),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(10),
                      ),
                      duration: const Duration(seconds: 3),
                    ),
                  );
                }
              });
            }

            return FadeTransition(
              opacity: _fadeAnim,
              child: scanHistory.isNotEmpty
                  ? _buildContent(theme, scanHistory)
                  : _buildEmptyState(theme),
            );
          },
        ),
      ),
    );
  }

  Widget _buildEmptyState(ThemeData theme) {
    return Center(
      child: Padding(
        padding: EdgeInsets.symmetric(horizontal: 8.w),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(
              width: 22.w,
              height: 22.w,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                gradient: const LinearGradient(
                  colors: [Color(0xFF6C5CE7), Color(0xFF74B9FF)],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ),
              ),
              child: const Icon(
                Icons.show_chart_rounded,
                color: Colors.white,
                size: 40,
              ),
            ),
            SizedBox(height: 3.h),
            Text(
              'Pas encore de progression',
              style: GoogleFonts.dmSans(
                fontSize: 18.sp,
                fontWeight: FontWeight.w700,
                color: theme.colorScheme.onSurface,
              ),
            ),
            SizedBox(height: 1.h),
            Text(
              'Effectuez votre premier scan pour commencer à suivre votre progression',
              textAlign: TextAlign.center,
              style: GoogleFonts.dmSans(
                fontSize: 13.sp,
                color: theme.colorScheme.onSurfaceVariant,
                height: 1.5,
              ),
            ),
            SizedBox(height: 4.h),
            GestureDetector(
              onTap: () {
                HapticFeedback.mediumImpact();
                Navigator.of(
                  context,
                  rootNavigator: true,
                ).pushNamed('/camera-instructions-screen');
              },
              child: Container(
                padding: EdgeInsets.symmetric(horizontal: 8.w, vertical: 1.8.h),
                decoration: BoxDecoration(
                  gradient: const LinearGradient(
                    colors: [Color(0xFF1B365D), Color(0xFF6C5CE7)],
                    begin: Alignment.centerLeft,
                    end: Alignment.centerRight,
                  ),
                  borderRadius: BorderRadius.circular(14.0),
                  boxShadow: [
                    BoxShadow(
                      color: const Color(0xFF6C5CE7).withValues(alpha: 0.35),
                      blurRadius: 16,
                      offset: const Offset(0, 6),
                    ),
                  ],
                ),
                child: Text(
                  'Faire mon premier scan',
                  style: GoogleFonts.dmSans(
                    fontSize: 14.sp,
                    fontWeight: FontWeight.w600,
                    color: Colors.white,
                  ),
                ),
              ),
            ),
            SizedBox(height: 2.h),
            TextButton(
              onPressed: _loadSampleData,
              child: Text(
                'Aperçu avec données exemples',
                style: GoogleFonts.dmSans(
                  fontSize: 12.sp,
                  color: theme.colorScheme.onSurfaceVariant,
                  decoration: TextDecoration.underline,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildContent(
    ThemeData theme,
    List<Map<String, dynamic>> scanHistory,
  ) {
    return CustomScrollView(
      physics: const BouncingScrollPhysics(),
      slivers: [
        SliverToBoxAdapter(
          child: Padding(
            padding: EdgeInsets.symmetric(horizontal: 4.w, vertical: 2.h),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                _buildHeader(theme, scanHistory),
                SizedBox(height: 2.5.h),
                _buildVioletTopCard(theme, scanHistory),
                SizedBox(height: 2.5.h),
                if (scanHistory.length >= 2) ...[
                  _buildProgressMetrics(theme, scanHistory),
                  SizedBox(height: 2.5.h),
                ],
                _buildBodyFatChart(theme, scanHistory),
                SizedBox(height: 2.5.h),
                _buildGoalProgress(theme, scanHistory),
                SizedBox(height: 2.5.h),
                _buildScanTimeline(theme, scanHistory),
                SizedBox(height: 12.h),
              ],
            ),
          ),
        ),
      ],
    );
  }

  /// Violet top card: Body Fat %, Lean Mass, Fat Mass with delta vs previous scan
  Widget _buildVioletTopCard(
    ThemeData theme,
    List<Map<String, dynamic>> scanHistory,
  ) {
    if (scanHistory.isEmpty) return const SizedBox.shrink();

    final latest = scanHistory.first;
    final prev = scanHistory.length >= 2 ? scanHistory[1] : null;

    final bodyFat = latest['bodyFat'] as double;
    final leanMassRaw = latest['leanMass'] as double?;
    final totalWeight = latest['weight'] as double? ?? 0.0;

    final weightUnit = _weightUnit;

    final leanMassKg = leanMassRaw ?? (totalWeight * (1 - bodyFat / 100));
    final leanMassDisplay = weightUnit == 'lbs'
        ? leanMassKg * 2.20462
        : leanMassKg;
    final fatMassKg = totalWeight * (bodyFat / 100);
    final fatMassDisplay = weightUnit == 'lbs'
        ? fatMassKg * 2.20462
        : fatMassKg;

    final prevBodyFat = prev != null ? prev['bodyFat'] as double : null;
    final prevLeanMassRaw = prev != null ? prev['leanMass'] as double? : null;
    final prevTotalWeight = prev != null
        ? (prev['weight'] as double? ?? 0.0)
        : null;
    final prevLeanMassKg =
        prevLeanMassRaw ??
        (prevTotalWeight != null
            ? prevTotalWeight * (1 - (prevBodyFat ?? bodyFat) / 100)
            : null);
    final prevFatMassKg = prevTotalWeight != null
        ? prevTotalWeight * ((prevBodyFat ?? bodyFat) / 100)
        : null;

    final bfDelta = prevBodyFat != null ? bodyFat - prevBodyFat : null;
    final lmDelta = prevLeanMassKg != null
        ? (weightUnit == 'lbs'
              ? (leanMassKg - prevLeanMassKg) * 2.20462
              : leanMassKg - prevLeanMassKg)
        : null;
    final fmDelta = prevFatMassKg != null
        ? (weightUnit == 'lbs'
              ? (fatMassKg - prevFatMassKg) * 2.20462
              : fatMassKg - prevFatMassKg)
        : null;

    return Container(
      width: double.infinity,
      padding: EdgeInsets.all(4.w),
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          colors: [Color(0xFF1B365D), Color(0xFF6C5CE7)],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(20.0),
        boxShadow: [
          BoxShadow(
            color: const Color(0xFF6C5CE7).withValues(alpha: 0.35),
            blurRadius: 24,
            offset: const Offset(0, 8),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                width: 6,
                height: 6,
                decoration: const BoxDecoration(
                  color: Color(0xFF00D4AA),
                  shape: BoxShape.circle,
                ),
              ),
              SizedBox(width: 2.w),
              Text(
                'Dernier Scan · ${latest['date'] as String}',
                style: GoogleFonts.dmSans(
                  fontSize: 10.sp,
                  color: Colors.white.withValues(alpha: 0.7),
                  fontWeight: FontWeight.w500,
                ),
              ),
            ],
          ),
          SizedBox(height: 2.h),
          Row(
            children: [
              Expanded(
                child: _VioletStatItem(
                  label: 'Masse Grasse',
                  value: '${bodyFat.toStringAsFixed(1)}%',
                  delta: bfDelta != null
                      ? '${bfDelta >= 0 ? '+' : ''}${bfDelta.toStringAsFixed(1)}%'
                      : null,
                  isPositiveDelta: bfDelta != null ? bfDelta < 0 : null,
                  icon: Icons.water_drop_rounded,
                ),
              ),
              Container(
                width: 1,
                height: 8.h,
                color: Colors.white.withValues(alpha: 0.2),
              ),
              Expanded(
                child: _VioletStatItem(
                  label: 'Masse Maigre',
                  value: '${leanMassDisplay.toStringAsFixed(1)} $weightUnit',
                  delta: lmDelta != null
                      ? '${lmDelta >= 0 ? '+' : ''}${lmDelta.toStringAsFixed(1)} $weightUnit'
                      : null,
                  isPositiveDelta: lmDelta != null ? lmDelta > 0 : null,
                  icon: Icons.fitness_center_rounded,
                ),
              ),
              Container(
                width: 1,
                height: 8.h,
                color: Colors.white.withValues(alpha: 0.2),
              ),
              Expanded(
                child: _VioletStatItem(
                  label: 'Masse Grasse kg',
                  value: '${fatMassDisplay.toStringAsFixed(1)} $weightUnit',
                  delta: fmDelta != null
                      ? '${fmDelta >= 0 ? '+' : ''}${fmDelta.toStringAsFixed(1)} $weightUnit'
                      : null,
                  isPositiveDelta: fmDelta != null ? fmDelta < 0 : null,
                  icon: Icons.monitor_weight_outlined,
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  String get _weightUnit => 'kg';

  Widget _buildHeader(ThemeData theme, List<Map<String, dynamic>> scanHistory) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Votre Progression',
              style: GoogleFonts.dmSans(
                fontSize: 18.sp,
                fontWeight: FontWeight.w700,
                color: theme.colorScheme.onSurface,
              ),
            ),
            Text(
              '${scanHistory.length} scan${scanHistory.length == 1 ? '' : 's'} recorded',
              style: GoogleFonts.dmSans(
                fontSize: 12.sp,
                color: theme.colorScheme.onSurfaceVariant,
              ),
            ),
          ],
        ),
        Row(
          children: [
            ListenableBuilder(
              listenable: SyncService.instance,
              builder: (_, __) =>
                  _SyncChip(status: SyncService.instance.status),
            ),
            SizedBox(width: 2.w),
            Container(
              padding: EdgeInsets.symmetric(horizontal: 3.w, vertical: 0.8.h),
              decoration: BoxDecoration(
                color: const Color(0xFF6C5CE7).withValues(alpha: 0.1),
                borderRadius: BorderRadius.circular(20.0),
              ),
              child: Text(
                '${scanHistory.length} scan${scanHistory.length == 1 ? '' : 's'}',
                style: GoogleFonts.dmSans(
                  fontSize: 11.sp,
                  fontWeight: FontWeight.w600,
                  color: const Color(0xFF6C5CE7),
                ),
              ),
            ),
          ],
        ),
      ],
    );
  }

  Widget _buildProgressMetrics(
    ThemeData theme,
    List<Map<String, dynamic>> scanHistory,
  ) {
    if (scanHistory.length < 2) return const SizedBox.shrink();
    final first = scanHistory.last;
    final latest = scanHistory.first;
    final fatChange =
        (latest['bodyFat'] as double) - (first['bodyFat'] as double);
    final weightChange =
        (latest['weight'] as double) - (first['weight'] as double);
    final hasWeightData =
        (first['weight'] as double) > 0.0 || (latest['weight'] as double) > 0.0;
    final fatChangeStr =
        '${fatChange >= 0 ? '+' : ''}${fatChange.toStringAsFixed(1)}%';

    return Row(
      children: [
        Expanded(
          child: _MetricDeltaCard(
            label: 'Masse Grasse',
            value: fatChangeStr,
            subtitle:
                '${(first['bodyFat'] as double).toStringAsFixed(1)}% → ${(latest['bodyFat'] as double).toStringAsFixed(1)}%',
            isPositive: fatChange < 0,
            icon: Icons.water_drop_outlined,
            gradient: const LinearGradient(
              colors: [Color(0xFF6C5CE7), Color(0xFF8B7FF0)],
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
            ),
          ),
        ),
        if (hasWeightData) ...[
          SizedBox(width: 3.w),
          Expanded(
            child: _MetricDeltaCard(
              label: 'Poids',
              value:
                  '${weightChange >= 0 ? '+' : ''}${weightChange.toStringAsFixed(1)} kg',
              subtitle:
                  '${(first['weight'] as double).toStringAsFixed(1)} → ${(latest['weight'] as double).toStringAsFixed(1)} kg',
              isPositive: weightChange < 0,
              icon: Icons.monitor_weight_outlined,
              gradient: const LinearGradient(
                colors: [Color(0xFF00B894), Color(0xFF55EFC4)],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
            ),
          ),
        ],
      ],
    );
  }

  Widget _buildBodyFatChart(
    ThemeData theme,
    List<Map<String, dynamic>> scanHistory,
  ) {
    if (scanHistory.isEmpty) return const SizedBox.shrink();
    final isDark = theme.brightness == Brightness.dark;
    final cardColor = isDark ? const Color(0xFF1E2E4A) : Colors.white;

    return Container(
      padding: EdgeInsets.all(4.w),
      decoration: BoxDecoration(
        color: cardColor,
        borderRadius: BorderRadius.circular(16.0),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: 0.06),
            blurRadius: 16,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                'Évolution Masse Grasse',
                style: GoogleFonts.dmSans(
                  fontSize: 14.sp,
                  fontWeight: FontWeight.w700,
                  color: theme.colorScheme.onSurface,
                ),
              ),
              if (scanHistory.length >= 2)
                Builder(
                  builder: (context) {
                    final first = scanHistory.last['bodyFat'] as double;
                    final latest = scanHistory.first['bodyFat'] as double;
                    final delta = latest - first;
                    final isDown = delta <= 0;
                    return Container(
                      padding: EdgeInsets.symmetric(
                        horizontal: 2.5.w,
                        vertical: 0.5.h,
                      ),
                      decoration: BoxDecoration(
                        color:
                            (isDown
                                    ? const Color(0xFF00B894)
                                    : const Color(0xFFE53E3E))
                                .withValues(alpha: 0.12),
                        borderRadius: BorderRadius.circular(8.0),
                      ),
                      child: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Icon(
                            isDown
                                ? Icons.trending_down_rounded
                                : Icons.trending_up_rounded,
                            color: isDown
                                ? const Color(0xFF00B894)
                                : const Color(0xFFE53E3E),
                            size: 14,
                          ),
                          SizedBox(width: 1.w),
                          Text(
                            '${delta >= 0 ? '+' : ''}${delta.toStringAsFixed(1)}%',
                            style: GoogleFonts.dmSans(
                              fontSize: 11.sp,
                              fontWeight: FontWeight.w600,
                              color: isDown
                                  ? const Color(0xFF00B894)
                                  : const Color(0xFFE53E3E),
                            ),
                          ),
                        ],
                      ),
                    );
                  },
                ),
            ],
          ),
          SizedBox(height: 2.h),
          SizedBox(
            height: 20.h,
            child: CustomPaint(
              painter: _BodyFatChartPainter(
                dataPoints: scanHistory.reversed
                    .map((s) => s['bodyFat'] as double)
                    .toList(),
                isDark: isDark,
              ),
              child: Container(),
            ),
          ),
          SizedBox(height: 1.h),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: scanHistory.reversed
                .map(
                  (s) => Flexible(
                    child: Text(
                      (s['date'] as String).split(',').first,
                      style: GoogleFonts.dmSans(
                        fontSize: 9.sp,
                        color: theme.colorScheme.onSurfaceVariant,
                      ),
                      overflow: TextOverflow.ellipsis,
                    ),
                  ),
                )
                .toList(),
          ),
        ],
      ),
    );
  }

  Widget _buildGoalProgress(
    ThemeData theme,
    List<Map<String, dynamic>> scanHistory,
  ) {
    if (scanHistory.isEmpty) return const SizedBox.shrink();
    final isDark = theme.brightness == Brightness.dark;
    final cardColor = isDark ? const Color(0xFF1E2E4A) : Colors.white;
    final goalFat = _goalBodyFat ?? 15.0;
    final currentFat = scanHistory.first['bodyFat'] as double;
    final startFat = scanHistory.length >= 2
        ? scanHistory.last['bodyFat'] as double
        : currentFat + 5.0;

    double progress;
    if ((startFat - goalFat).abs() < 0.01) {
      progress = 1.0;
    } else {
      progress = ((startFat - currentFat) / (startFat - goalFat)).clamp(
        0.0,
        1.0,
      );
    }

    return Container(
      padding: EdgeInsets.all(4.w),
      decoration: BoxDecoration(
        color: cardColor,
        borderRadius: BorderRadius.circular(16.0),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: 0.06),
            blurRadius: 16,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                'Goal Progress',
                style: GoogleFonts.dmSans(
                  fontSize: 14.sp,
                  fontWeight: FontWeight.w700,
                  color: theme.colorScheme.onSurface,
                ),
              ),
              _goalLoading
                  ? SizedBox(
                      width: 14,
                      height: 14,
                      child: CircularProgressIndicator(
                        strokeWidth: 2,
                        color: const Color(0xFF6C5CE7),
                      ),
                    )
                  : Text(
                      '${(progress * 100).toStringAsFixed(0)}% accompli',
                      style: GoogleFonts.dmSans(
                        fontSize: 12.sp,
                        fontWeight: FontWeight.w600,
                        color: const Color(0xFF6C5CE7),
                      ),
                    ),
            ],
          ),
          SizedBox(height: 0.8.h),
          Text(
            'Objectif : ${goalFat.toStringAsFixed(0)}% de masse grasse',
            style: GoogleFonts.dmSans(
              fontSize: 11.sp,
              color: theme.colorScheme.onSurfaceVariant,
            ),
          ),
          SizedBox(height: 1.8.h),
          Stack(
            children: [
              Container(
                height: 10,
                decoration: BoxDecoration(
                  color: theme.colorScheme.outline.withValues(alpha: 0.2),
                  borderRadius: BorderRadius.circular(8.0),
                ),
              ),
              FractionallySizedBox(
                widthFactor: progress,
                child: Container(
                  height: 10,
                  decoration: BoxDecoration(
                    gradient: const LinearGradient(
                      colors: [Color(0xFF6C5CE7), Color(0xFF74B9FF)],
                    ),
                    borderRadius: BorderRadius.circular(8.0),
                  ),
                ),
              ),
            ],
          ),
          SizedBox(height: 1.5.h),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                'Début : ${startFat.toStringAsFixed(1)}%',
                style: GoogleFonts.dmSans(
                  fontSize: 11.sp,
                  color: theme.colorScheme.onSurfaceVariant,
                ),
              ),
              Text(
                'Maintenant : ${currentFat.toStringAsFixed(1)}%',
                style: GoogleFonts.dmSans(
                  fontSize: 11.sp,
                  fontWeight: FontWeight.w600,
                  color: theme.colorScheme.onSurface,
                ),
              ),
              Text(
                'Cible : ${goalFat.toStringAsFixed(0)}%',
                style: GoogleFonts.dmSans(
                  fontSize: 11.sp,
                  color: const Color(0xFF6C5CE7),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildScanTimeline(
    ThemeData theme,
    List<Map<String, dynamic>> scanHistory,
  ) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          'Historique des Scans',
          style: GoogleFonts.dmSans(
            fontSize: 14.sp,
            fontWeight: FontWeight.w700,
            color: theme.colorScheme.onSurface,
          ),
        ),
        SizedBox(height: 1.5.h),
        ...List.generate(scanHistory.length, (i) {
          final scan = scanHistory[i];
          final isFirst = i == 0;
          return _ScanTimelineCard(scan: scan, isLatest: isFirst, theme: theme);
        }),
      ],
    );
  }
}

// ─── Violet Stat Item ─────────────────────────────────────────────────────────

class _VioletStatItem extends StatelessWidget {
  final String label;
  final String value;
  final String? delta;
  final bool? isPositiveDelta;
  final IconData icon;

  const _VioletStatItem({
    required this.label,
    required this.value,
    this.delta,
    this.isPositiveDelta,
    required this.icon,
  });

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 4),
      child: Column(
        children: [
          Icon(icon, color: Colors.white.withValues(alpha: 0.7), size: 18),
          const SizedBox(height: 6),
          Text(
            value,
            style: GoogleFonts.dmSans(
              fontSize: 14,
              fontWeight: FontWeight.w800,
              color: Colors.white,
            ),
            textAlign: TextAlign.center,
            overflow: TextOverflow.ellipsis,
          ),
          Text(
            label,
            style: GoogleFonts.dmSans(
              fontSize: 9,
              color: Colors.white.withValues(alpha: 0.7),
            ),
            textAlign: TextAlign.center,
          ),
          if (delta != null) ...[
            const SizedBox(height: 4),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
              decoration: BoxDecoration(
                color:
                    (isPositiveDelta == true
                            ? const Color(0xFF00B894)
                            : const Color(0xFFE17055))
                        .withValues(alpha: 0.25),
                borderRadius: BorderRadius.circular(6),
              ),
              child: Text(
                delta!,
                style: GoogleFonts.dmSans(
                  fontSize: 9,
                  fontWeight: FontWeight.w700,
                  color: isPositiveDelta == true
                      ? const Color(0xFF00D4AA)
                      : const Color(0xFFFF7675),
                ),
                textAlign: TextAlign.center,
              ),
            ),
          ],
        ],
      ),
    );
  }
}

// ─── Metric Delta Card ───────────────────────────────────────────────────────

class _MetricDeltaCard extends StatelessWidget {
  final String label;
  final String value;
  final String subtitle;
  final bool isPositive;
  final IconData icon;
  final LinearGradient gradient;

  const _MetricDeltaCard({
    required this.label,
    required this.value,
    required this.subtitle,
    required this.isPositive,
    required this.icon,
    required this.gradient,
  });

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final isDark = theme.brightness == Brightness.dark;

    return Container(
      padding: EdgeInsets.all(3.5.w),
      decoration: BoxDecoration(
        color: isDark ? const Color(0xFF1E2E4A) : Colors.white,
        borderRadius: BorderRadius.circular(16.0),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: 0.06),
            blurRadius: 12,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                padding: const EdgeInsets.all(6),
                decoration: BoxDecoration(
                  gradient: gradient,
                  borderRadius: BorderRadius.circular(8.0),
                ),
                child: Icon(icon, color: Colors.white, size: 14),
              ),
              SizedBox(width: 2.w),
              Text(
                label,
                style: GoogleFonts.dmSans(
                  fontSize: 11.sp,
                  color: theme.colorScheme.onSurfaceVariant,
                ),
              ),
            ],
          ),
          SizedBox(height: 1.h),
          Row(
            children: [
              Icon(
                isPositive
                    ? Icons.arrow_downward_rounded
                    : Icons.arrow_upward_rounded,
                color: isPositive
                    ? const Color(0xFF00B894)
                    : const Color(0xFFE53E3E),
                size: 16,
              ),
              SizedBox(width: 1.w),
              Text(
                value,
                style: GoogleFonts.dmSans(
                  fontSize: 15.sp,
                  fontWeight: FontWeight.w700,
                  color: isPositive
                      ? const Color(0xFF00B894)
                      : const Color(0xFFE53E3E),
                ),
              ),
            ],
          ),
          SizedBox(height: 0.4.h),
          Text(
            subtitle,
            style: GoogleFonts.dmSans(
              fontSize: 9.sp,
              color: theme.colorScheme.onSurfaceVariant,
            ),
            overflow: TextOverflow.ellipsis,
          ),
        ],
      ),
    );
  }
}

// ─── Scan Timeline Card ──────────────────────────────────────────────────────

class _ScanTimelineCard extends StatelessWidget {
  final Map<String, dynamic> scan;
  final bool isLatest;
  final ThemeData theme;

  const _ScanTimelineCard({
    required this.scan,
    required this.isLatest,
    required this.theme,
  });

  @override
  Widget build(BuildContext context) {
    final isDark = theme.brightness == Brightness.dark;
    final change = scan['change'] as double;
    final isImproved = change < 0;
    final bodyFat = scan['bodyFat'] as double;
    final leanMass = scan['leanMass'] as double?;
    final confidenceScore = scan['confidenceScore'] as double?;

    return Padding(
      padding: EdgeInsets.only(bottom: 1.5.h),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Column(
            children: [
              Container(
                width: 12,
                height: 12,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  gradient: isLatest
                      ? const LinearGradient(
                          colors: [Color(0xFF6C5CE7), Color(0xFF74B9FF)],
                        )
                      : null,
                  color: isLatest
                      ? null
                      : theme.colorScheme.outline.withValues(alpha: 0.4),
                ),
              ),
              if (!isLatest)
                Container(
                  width: 2,
                  height: 7.h,
                  color: theme.colorScheme.outline.withValues(alpha: 0.2),
                ),
            ],
          ),
          SizedBox(width: 3.w),
          Expanded(
            child: GestureDetector(
              onTap: () {
                HapticFeedback.lightImpact();
                Navigator.of(context).pushNamed(
                  AppRoutes.scanDetail,
                  arguments: ScanDetailArgs(
                    date: scan['date'] as String,
                    bodyFatPercent: bodyFat,
                    leanMassPercent: leanMass,
                    fatMassPercent: bodyFat,
                    physiqueProfile: scan['category'] as String? ?? '--',
                    confidenceScore: confidenceScore,
                    zonePercentages: _estimateZones(bodyFat),
                  ),
                );
              },
              child: Container(
                padding: EdgeInsets.all(3.5.w),
                decoration: BoxDecoration(
                  color: isDark ? const Color(0xFF1E2E4A) : Colors.white,
                  borderRadius: BorderRadius.circular(14.0),
                  border: isLatest
                      ? Border.all(
                          color: const Color(0xFF6C5CE7).withValues(alpha: 0.4),
                          width: 1.5,
                        )
                      : null,
                  boxShadow: [
                    BoxShadow(
                      color: Colors.black.withValues(alpha: 0.05),
                      blurRadius: 10,
                      offset: const Offset(0, 3),
                    ),
                  ],
                ),
                child: Row(
                  children: [
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(
                            children: [
                              Text(
                                scan['date'] as String,
                                style: GoogleFonts.dmSans(
                                  fontSize: 11.sp,
                                  fontWeight: FontWeight.w600,
                                  color: theme.colorScheme.onSurface,
                                ),
                              ),
                              if (isLatest) ...[
                                SizedBox(width: 2.w),
                                Container(
                                  padding: EdgeInsets.symmetric(
                                    horizontal: 1.5.w,
                                    vertical: 0.2.h,
                                  ),
                                  decoration: BoxDecoration(
                                    color: const Color(
                                      0xFF6C5CE7,
                                    ).withValues(alpha: 0.12),
                                    borderRadius: BorderRadius.circular(6.0),
                                  ),
                                  child: Text(
                                    'Latest',
                                    style: GoogleFonts.dmSans(
                                      fontSize: 9.sp,
                                      fontWeight: FontWeight.w600,
                                      color: const Color(0xFF6C5CE7),
                                    ),
                                  ),
                                ),
                              ],
                            ],
                          ),
                          SizedBox(height: 0.4.h),
                          Text(
                            scan['category'] as String,
                            style: GoogleFonts.dmSans(
                              fontSize: 10.sp,
                              color: theme.colorScheme.onSurfaceVariant,
                            ),
                          ),
                        ],
                      ),
                    ),
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.end,
                      children: [
                        Text(
                          '${(scan['bodyFat'] as double).toStringAsFixed(1)}%',
                          style: GoogleFonts.dmSans(
                            fontSize: 14.sp,
                            fontWeight: FontWeight.w700,
                            color: theme.colorScheme.onSurface,
                          ),
                        ),
                        if (change != 0)
                          Row(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              Icon(
                                isImproved
                                    ? Icons.arrow_downward_rounded
                                    : Icons.arrow_upward_rounded,
                                size: 11,
                                color: isImproved
                                    ? const Color(0xFF00B894)
                                    : const Color(0xFFE53E3E),
                              ),
                              Text(
                                '${change.abs().toStringAsFixed(1)}%',
                                style: GoogleFonts.dmSans(
                                  fontSize: 10.sp,
                                  fontWeight: FontWeight.w600,
                                  color: isImproved
                                      ? const Color(0xFF00B894)
                                      : const Color(0xFFE53E3E),
                                ),
                              ),
                            ],
                          ),
                        Icon(
                          Icons.chevron_right_rounded,
                          size: 16,
                          color: theme.colorScheme.onSurfaceVariant.withValues(
                            alpha: 0.5,
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  /// Estimate zone percentages from overall body fat (approximation when zones not stored)
  Map<String, double> _estimateZones(double bodyFat) {
    return {
      'Bras Gauche': (bodyFat * 0.85).clamp(0.0, 50.0),
      'Bras Droit': (bodyFat * 0.87).clamp(0.0, 50.0),
      'Haut du Corps': (bodyFat * 1.05).clamp(0.0, 50.0),
      'Jambe Gauche': (bodyFat * 0.95).clamp(0.0, 50.0),
      'Jambe Droite': (bodyFat * 0.93).clamp(0.0, 50.0),
    };
  }
}

// ─── Sync Status Chip ─────────────────────────────────────────────────────────

class _SyncChip extends StatelessWidget {
  final SyncStatus status;
  const _SyncChip({required this.status});

  @override
  Widget build(BuildContext context) {
    Color color;
    String label;
    IconData icon;
    switch (status) {
      case SyncStatus.syncing:
        color = const Color(0xFFFDCB6E);
        label = 'Syncing';
        icon = Icons.sync_rounded;
        break;
      case SyncStatus.offline:
        color = const Color(0xFFE53E3E);
        label = 'Offline';
        icon = Icons.cloud_off_rounded;
        break;
      case SyncStatus.synced:
        color = const Color(0xFF00B894);
        label = 'Synced';
        icon = Icons.cloud_done_rounded;
        break;
      case SyncStatus.pending:
        color = const Color(0xFFFDCB6E);
        label = 'Pending';
        icon = Icons.cloud_upload_rounded;
        break;
    }
    return Container(
      padding: EdgeInsets.symmetric(horizontal: 2.5.w, vertical: 0.5.h),
      decoration: BoxDecoration(
        color: color.withValues(alpha: 0.12),
        borderRadius: BorderRadius.circular(20.0),
        border: Border.all(color: color.withValues(alpha: 0.3)),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon, size: 12, color: color),
          SizedBox(width: 1.w),
          Text(
            label,
            style: GoogleFonts.dmSans(
              fontSize: 10.sp,
              fontWeight: FontWeight.w600,
              color: color,
            ),
          ),
        ],
      ),
    );
  }
}

// ─── Body Fat Chart Painter ──────────────────────────────────────────────────

class _BodyFatChartPainter extends CustomPainter {
  final List<double> dataPoints;
  final bool isDark;

  _BodyFatChartPainter({required this.dataPoints, required this.isDark});

  @override
  void paint(Canvas canvas, Size size) {
    if (dataPoints.isEmpty) return;

    // For single point, duplicate it to draw a flat line
    final points = dataPoints.length == 1
        ? [dataPoints.first, dataPoints.first]
        : dataPoints;

    final minVal = points.reduce((a, b) => a < b ? a : b) - 2;
    final maxVal = points.reduce((a, b) => a > b ? a : b) + 2;
    final range = (maxVal - minVal).abs();
    if (range == 0) return;

    // Grid lines
    final gridPaint = Paint()
      ..color = (isDark ? Colors.white : Colors.black).withValues(alpha: 0.06)
      ..strokeWidth = 1;
    for (int i = 0; i <= 4; i++) {
      final y = size.height * i / 4;
      canvas.drawLine(Offset(0, y), Offset(size.width, y), gridPaint);
    }

    // Compute screen positions
    final screenPoints = <Offset>[];
    for (int i = 0; i < points.length; i++) {
      final x = points.length == 1
          ? size.width / 2
          : size.width * i / (points.length - 1);
      final y = size.height - (size.height * (points[i] - minVal) / range);
      screenPoints.add(Offset(x, y));
    }

    // Gradient fill path
    final fillPath = Path();
    fillPath.moveTo(screenPoints.first.dx, size.height);
    if (screenPoints.length == 1) {
      fillPath.lineTo(screenPoints.first.dx, screenPoints.first.dy);
      fillPath.lineTo(screenPoints.first.dx, size.height);
    } else {
      fillPath.lineTo(screenPoints.first.dx, screenPoints.first.dy);
      for (int i = 1; i < screenPoints.length; i++) {
        final prev = screenPoints[i - 1];
        final curr = screenPoints[i];
        final cpX = (prev.dx + curr.dx) / 2;
        fillPath.cubicTo(cpX, prev.dy, cpX, curr.dy, curr.dx, curr.dy);
      }
      fillPath.lineTo(screenPoints.last.dx, size.height);
    }
    fillPath.close();

    final fillPaint = Paint()
      ..shader = LinearGradient(
        colors: [
          const Color(0xFF6C5CE7).withValues(alpha: 0.35),
          const Color(0xFF6C5CE7).withValues(alpha: 0.0),
        ],
        begin: Alignment.topCenter,
        end: Alignment.bottomCenter,
      ).createShader(Rect.fromLTWH(0, 0, size.width, size.height));
    canvas.drawPath(fillPath, fillPaint);

    // Smooth purple line
    final linePaint = Paint()
      ..color = const Color(0xFF6C5CE7)
      ..strokeWidth = 2.5
      ..style = PaintingStyle.stroke
      ..strokeCap = StrokeCap.round
      ..strokeJoin = StrokeJoin.round;

    final linePath = Path();
    linePath.moveTo(screenPoints.first.dx, screenPoints.first.dy);
    if (screenPoints.length == 1) {
      // Single point — draw a small horizontal segment
      linePath.lineTo(screenPoints.first.dx + 1, screenPoints.first.dy);
    } else {
      for (int i = 1; i < screenPoints.length; i++) {
        final prev = screenPoints[i - 1];
        final curr = screenPoints[i];
        final cpX = (prev.dx + curr.dx) / 2;
        linePath.cubicTo(cpX, prev.dy, cpX, curr.dy, curr.dx, curr.dy);
      }
    }
    canvas.drawPath(linePath, linePaint);

    // Dots
    final dotPaint = Paint()
      ..color = const Color(0xFF6C5CE7)
      ..style = PaintingStyle.fill;
    final dotBorderPaint = Paint()
      ..color = isDark ? const Color(0xFF1E2E4A) : Colors.white
      ..style = PaintingStyle.fill;

    for (final p in screenPoints) {
      canvas.drawCircle(p, 5, dotBorderPaint);
      canvas.drawCircle(p, 3.5, dotPaint);
    }

    // Y-axis labels
    final textStyle = TextStyle(
      color: (isDark ? Colors.white : Colors.black).withValues(alpha: 0.4),
      fontSize: 9,
    );
    for (int i = 0; i <= 4; i++) {
      final val = maxVal - (range * i / 4);
      final tp = TextPainter(
        text: TextSpan(text: '${val.toStringAsFixed(0)}%', style: textStyle),
        textDirection: TextDirection.ltr,
      )..layout();
      tp.paint(canvas, Offset(0, size.height * i / 4 + 2));
    }
  }

  @override
  bool shouldRepaint(covariant _BodyFatChartPainter oldDelegate) =>
      oldDelegate.dataPoints != dataPoints || oldDelegate.isDark != isDark;
}
