import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:sizer/sizer.dart';

class OnboardingProgressWidget extends StatelessWidget {
  final int currentStep;
  final int totalSteps;

  const OnboardingProgressWidget({
    super.key,
    required this.currentStep,
    required this.totalSteps,
  });

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Text(
              'Step $currentStep of $totalSteps',
              style: GoogleFonts.plusJakartaSans(
                fontSize: 11.sp > 13 ? 13 : 11.sp,
                fontWeight: FontWeight.w500,
                color: const Color(0xFF636E72),
              ),
            ),
            Text(
              '${((currentStep / totalSteps) * 100).round()}%',
              style: GoogleFonts.plusJakartaSans(
                fontSize: 11.sp > 13 ? 13 : 11.sp,
                fontWeight: FontWeight.w600,
                color: const Color(0xFF6C5CE7),
              ),
            ),
          ],
        ),
        SizedBox(height: 0.8.h),
        ClipRRect(
          borderRadius: BorderRadius.circular(8.0),
          child: LinearProgressIndicator(
            value: currentStep / totalSteps,
            minHeight: 6,
            backgroundColor: const Color(0xFFE2E8F0),
            valueColor: const AlwaysStoppedAnimation<Color>(Color(0xFF6C5CE7)),
          ),
        ),
      ],
    );
  }
}
