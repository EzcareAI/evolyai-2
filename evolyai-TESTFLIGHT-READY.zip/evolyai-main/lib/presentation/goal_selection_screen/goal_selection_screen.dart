import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:sizer/sizer.dart';

import '../../models/onboarding_data.dart';
import './widgets/goal_card_widget.dart';
import './widgets/onboarding_progress_widget.dart';

class GoalSelectionScreen extends StatefulWidget {
  final OnboardingData? onboardingData;

  const GoalSelectionScreen({super.key, this.onboardingData});

  @override
  State<GoalSelectionScreen> createState() => _GoalSelectionScreenState();
}

class _GoalSelectionScreenState extends State<GoalSelectionScreen>
    with SingleTickerProviderStateMixin {
  String? _selectedGoal;
  late AnimationController _fadeController;
  late Animation<double> _fadeAnimation;

  final List<Map<String, dynamic>> _goals = [
    {
      'id': 'lose_fat',
      'title': 'Lose fat',
      'subtitle': 'Burn calories & slim down',
      'icon': Icons.local_fire_department_rounded,
    },
    {
      'id': 'build_muscle',
      'title': 'Build muscle',
      'subtitle': 'Gain strength & mass',
      'icon': Icons.fitness_center_rounded,
    },
    {
      'id': 'stay_fit',
      'title': 'Stay fit',
      'subtitle': 'Maintain & improve health',
      'icon': Icons.favorite_rounded,
    },
    {
      'id': 'curiosity',
      'title': 'Curiosity',
      'subtitle': 'Explore my body data',
      'icon': Icons.psychology_rounded,
    },
  ];

  @override
  void initState() {
    super.initState();
    _selectedGoal = widget.onboardingData?.goal;
    _fadeController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 600),
    )..forward();
    _fadeAnimation = CurvedAnimation(
      parent: _fadeController,
      curve: Curves.easeOut,
    );
  }

  @override
  void dispose() {
    _fadeController.dispose();
    super.dispose();
  }

  void _onContinue() {
    if (_selectedGoal == null) return;
    HapticFeedback.mediumImpact();
    final data = (widget.onboardingData ?? OnboardingData()).copyWith(
      goal: _selectedGoal,
    );
    Navigator.of(
      context,
    ).pushNamed('/gender-selection-screen', arguments: data);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: SafeArea(
        child: FadeTransition(
          opacity: _fadeAnimation,
          child: Padding(
            padding: EdgeInsets.symmetric(horizontal: 4.w, vertical: 2.h),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                _buildHeader(),
                SizedBox(height: 3.h),
                _buildTitleSection(),
                SizedBox(height: 3.h),
                Expanded(child: _buildGoalGrid()),
                SizedBox(height: 2.h),
                _buildContinueButton(),
                SizedBox(height: 1.h),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildHeader() {
    return Row(
      children: [
        GestureDetector(
          onTap: () => Navigator.of(context).pop(),
          child: Container(
            width: 10.w,
            height: 10.w,
            decoration: BoxDecoration(
              color: const Color(0xFFF8F9FA),
              borderRadius: BorderRadius.circular(12.0),
              border: Border.all(color: const Color(0xFFE2E8F0)),
            ),
            child: const Icon(
              Icons.arrow_back_ios_new_rounded,
              color: Color(0xFF1B365D),
              size: 18,
            ),
          ),
        ),
        SizedBox(width: 3.w),
        Expanded(
          child: OnboardingProgressWidget(currentStep: 2, totalSteps: 8),
        ),
      ],
    );
  }

  Widget _buildTitleSection() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        ShaderMask(
          shaderCallback: (bounds) => const LinearGradient(
            colors: [Color(0xFF1B365D), Color(0xFF6C5CE7)],
            begin: Alignment.centerLeft,
            end: Alignment.centerRight,
          ).createShader(bounds),
          child: Text(
            'What is your goal?',
            style: GoogleFonts.plusJakartaSans(
              fontSize: 20.sp > 28 ? 28 : 20.sp,
              fontWeight: FontWeight.w800,
              color: Colors.white,
              height: 1.2,
            ),
          ),
        ),
        SizedBox(height: 1.h),
        Text(
          'We\'ll personalize your AI body analysis\nbased on your fitness goal.',
          style: GoogleFonts.plusJakartaSans(
            fontSize: 12.sp > 15 ? 15 : 12.sp,
            fontWeight: FontWeight.w400,
            color: const Color(0xFF636E72),
            height: 1.5,
          ),
        ),
      ],
    );
  }

  Widget _buildGoalGrid() {
    return GridView.builder(
      physics: const NeverScrollableScrollPhysics(),
      shrinkWrap: true,
      gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: 2,
        crossAxisSpacing: 3.w,
        mainAxisSpacing: 2.h,
        childAspectRatio: 0.9,
      ),
      itemCount: _goals.length,
      itemBuilder: (context, index) {
        final goal = _goals[index];
        return GoalCardWidget(
          title: goal['title'] as String,
          subtitle: goal['subtitle'] as String,
          icon: goal['icon'] as IconData,
          isSelected: _selectedGoal == goal['id'],
          onTap: () {
            setState(() => _selectedGoal = goal['id'] as String);
          },
        );
      },
    );
  }

  Widget _buildContinueButton() {
    final isEnabled = _selectedGoal != null;
    return GestureDetector(
      onTap: isEnabled ? _onContinue : null,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 200),
        width: double.infinity,
        height: 7.h > 60 ? 60 : 7.h,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(16.0),
          gradient: isEnabled
              ? const LinearGradient(
                  colors: [Color(0xFF6C5CE7), Color(0xFF74B9FF)],
                  begin: Alignment.centerLeft,
                  end: Alignment.centerRight,
                )
              : null,
          color: isEnabled ? null : const Color(0xFFE2E8F0),
          boxShadow: isEnabled
              ? [
                  BoxShadow(
                    color: const Color(0xFF6C5CE7).withValues(alpha: 0.35),
                    blurRadius: 16,
                    offset: const Offset(0, 6),
                  ),
                ]
              : null,
        ),
        child: Center(
          child: Text(
            'Continue',
            style: GoogleFonts.plusJakartaSans(
              fontSize: 14.sp > 17 ? 17 : 14.sp,
              fontWeight: FontWeight.w700,
              color: isEnabled ? Colors.white : const Color(0xFFB2BEC3),
            ),
          ),
        ),
      ),
    );
  }
}
