import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:sizer/sizer.dart';
import 'dart:math' as math;

import '../../models/onboarding_data.dart';
import '../../routes/app_routes.dart';
import '../../services/supabase_service.dart';

class OnboardingFinaleScreen extends StatefulWidget {
  final OnboardingData? onboardingData;

  const OnboardingFinaleScreen({super.key, this.onboardingData});

  @override
  State<OnboardingFinaleScreen> createState() => _OnboardingFinaleScreenState();
}

class _OnboardingFinaleScreenState extends State<OnboardingFinaleScreen>
    with TickerProviderStateMixin {
  late AnimationController _entryController;
  late AnimationController _badgeController;
  late AnimationController _confettiController;
  late AnimationController _pulseController;

  late Animation<double> _fadeAnimation;
  late Animation<Offset> _slideAnimation;
  late Animation<double> _badgeScaleAnimation;
  late Animation<double> _badgeRotateAnimation;
  late Animation<double> _confettiAnimation;
  late Animation<double> _pulseAnimation;

  final List<_ConfettiParticle> _particles = [];

  bool _isSaving = false;

  @override
  void initState() {
    super.initState();

    _entryController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 700),
    )..forward();
    _fadeAnimation = CurvedAnimation(
      parent: _entryController,
      curve: Curves.easeOut,
    );
    _slideAnimation =
        Tween<Offset>(begin: const Offset(0, 0.06), end: Offset.zero).animate(
          CurvedAnimation(parent: _entryController, curve: Curves.easeOutCubic),
        );

    _badgeController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 900),
    );
    _badgeScaleAnimation = Tween<double>(begin: 0.0, end: 1.0).animate(
      CurvedAnimation(parent: _badgeController, curve: Curves.elasticOut),
    );
    _badgeRotateAnimation = Tween<double>(begin: -0.1, end: 0.0).animate(
      CurvedAnimation(parent: _badgeController, curve: Curves.easeOutBack),
    );

    _confettiController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 2000),
    );
    _confettiAnimation = CurvedAnimation(
      parent: _confettiController,
      curve: Curves.easeOut,
    );

    _pulseController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1800),
    )..repeat(reverse: true);
    _pulseAnimation = Tween<double>(begin: 0.97, end: 1.03).animate(
      CurvedAnimation(parent: _pulseController, curve: Curves.easeInOut),
    );

    final rng = math.Random();
    for (int i = 0; i < 30; i++) {
      _particles.add(
        _ConfettiParticle(
          x: rng.nextDouble(),
          y: rng.nextDouble() * 0.6,
          size: rng.nextDouble() * 6 + 4,
          color: [
            const Color(0xFF6C5CE7),
            const Color(0xFFFFD700),
            const Color(0xFF00B894),
            const Color(0xFFFF6B6B),
            const Color(0xFF74B9FF),
          ][rng.nextInt(5)],
          angle: rng.nextDouble() * math.pi * 2,
          speed: rng.nextDouble() * 0.4 + 0.2,
        ),
      );
    }

    Future.delayed(const Duration(milliseconds: 300), () {
      if (mounted) {
        _badgeController.forward();
        HapticFeedback.heavyImpact();
      }
    });
    Future.delayed(const Duration(milliseconds: 500), () {
      if (mounted) _confettiController.forward();
    });
  }

  @override
  void dispose() {
    _entryController.dispose();
    _badgeController.dispose();
    _confettiController.dispose();
    _pulseController.dispose();
    super.dispose();
  }

  /// Navigate to auth screen (which then routes to paywall)
  void _onViewResults() async {
    HapticFeedback.mediumImpact();
    setState(() => _isSaving = true);

    try {
      final data = widget.onboardingData;
      if (data != null && SupabaseService.instance.isAuthenticated) {
        final uid = SupabaseService.instance.currentUser!.id;
        debugPrint(
          '[OnboardingFinale] Saving onboarding answers for user: $uid',
        );

        final answers = OnboardingAnswersModel(
          userId: uid,
          goal: data.goal,
          gender: data.gender,
          age: data.age,
          heightValue: data.heightCm,
          heightUnit: data.heightUnit,
          weightValue: data.weightKg,
          weightUnit: data.weightUnit,
          activityLevel: data.activityLevel,
          motivation: data.motivation,
          notificationsEnabled: true,
          targetBodyFatPercent: data.targetBodyFatPercent,
        );
        await SupabaseService.instance.saveOnboardingAnswers(answers);
        debugPrint('[OnboardingFinale] Onboarding answers saved');
      }
    } catch (e) {
      debugPrint('[OnboardingFinale] Error saving onboarding data: $e');
    } finally {
      if (mounted) setState(() => _isSaving = false);
    }

    if (!mounted) return;

    // If already authenticated, go to paywall directly
    if (SupabaseService.instance.isAuthenticated) {
      debugPrint('[OnboardingFinale] User authenticated, routing to paywall');
      Navigator.of(context).pushNamedAndRemoveUntil(
        AppRoutes.paywall,
        (route) => false,
        arguments: widget.onboardingData,
      );
    } else {
      // Go to auth screen first (auth will then route to paywall)
      debugPrint('[OnboardingFinale] User not authenticated, routing to auth');
      Navigator.of(
        context,
      ).pushNamed(AppRoutes.auth, arguments: widget.onboardingData);
    }
  }

  double _activityBonus(String? activity) {
    if (activity == null) return 0;
    if (activity.contains('5')) return 4.0;
    if (activity.contains('3') || activity.contains('4')) return 2.5;
    if (activity.contains('1') || activity.contains('2')) return 1.0;
    return 0;
  }

  String _bodyCategory(double bodyFat, bool isMale) {
    if (isMale) {
      if (bodyFat < 10) return 'Essential';
      if (bodyFat < 14) return 'Athletic';
      if (bodyFat < 18) return 'Fit';
      if (bodyFat < 25) return 'Average';
      return 'Above Average';
    } else {
      if (bodyFat < 14) return 'Essential';
      if (bodyFat < 21) return 'Athletic';
      if (bodyFat < 25) return 'Fit';
      if (bodyFat < 32) return 'Average';
      return 'Above Average';
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF0A0A14),
      body: SafeArea(
        child: FadeTransition(
          opacity: _fadeAnimation,
          child: SlideTransition(
            position: _slideAnimation,
            child: Stack(
              children: [
                AnimatedBuilder(
                  animation: _confettiAnimation,
                  builder: (context, child) {
                    return CustomPaint(
                      size: Size(100.w, 100.h),
                      painter: _ConfettiPainter(
                        particles: _particles,
                        progress: _confettiAnimation.value,
                      ),
                    );
                  },
                ),
                SingleChildScrollView(
                  padding: EdgeInsets.symmetric(horizontal: 4.w, vertical: 2.h),
                  child: Column(
                    children: [
                      SizedBox(height: 2.h),
                      _buildBadge(),
                      SizedBox(height: 2.5.h),
                      _buildCongratulationsText(),
                      SizedBox(height: 3.h),
                      _buildSummaryCard(),
                      SizedBox(height: 2.5.h),
                      _buildDashboardPreview(),
                      SizedBox(height: 3.h),
                      _buildViewResultsButton(),
                      SizedBox(height: 2.h),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildBadge() {
    return ScaleTransition(
      scale: _badgeScaleAnimation,
      child: AnimatedBuilder(
        animation: _badgeRotateAnimation,
        builder: (context, child) {
          return Transform.rotate(
            angle: _badgeRotateAnimation.value,
            child: child,
          );
        },
        child: AnimatedBuilder(
          animation: _pulseAnimation,
          builder: (context, child) {
            return Transform.scale(scale: _pulseAnimation.value, child: child);
          },
          child: Container(
            width: 32.w,
            height: 32.w,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              gradient: const LinearGradient(
                colors: [
                  Color(0xFFFFD700),
                  Color(0xFFFFA500),
                  Color(0xFFFF8C00),
                ],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
              boxShadow: [
                BoxShadow(
                  color: const Color(0xFFFFD700).withValues(alpha: 0.5),
                  blurRadius: 30,
                  spreadRadius: 4,
                ),
              ],
            ),
            child: Stack(
              alignment: Alignment.center,
              children: [
                Container(
                  width: 28.w,
                  height: 28.w,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    border: Border.all(
                      color: Colors.white.withValues(alpha: 0.3),
                      width: 1.5,
                    ),
                  ),
                ),
                Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    const Icon(
                      Icons.emoji_events_rounded,
                      color: Colors.white,
                      size: 36,
                    ),
                    SizedBox(height: 0.5.h),
                    Text(
                      'COMPLETE',
                      style: GoogleFonts.plusJakartaSans(
                        fontSize: 9.sp > 11 ? 11 : 9.sp,
                        fontWeight: FontWeight.w800,
                        color: Colors.white,
                        letterSpacing: 1.5,
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildCongratulationsText() {
    return Column(
      children: [
        ShaderMask(
          shaderCallback: (bounds) => const LinearGradient(
            colors: [Color(0xFFFFD700), Color(0xFFFFA500)],
            begin: Alignment.centerLeft,
            end: Alignment.centerRight,
          ).createShader(bounds),
          child: Text(
            'You\'re all set! 🎉',
            style: GoogleFonts.plusJakartaSans(
              fontSize: 20.sp > 28 ? 28 : 20.sp,
              fontWeight: FontWeight.w800,
              color: Colors.white,
              height: 1.2,
            ),
            textAlign: TextAlign.center,
          ),
        ),
        SizedBox(height: 1.h),
        Text(
          'Your personalized body analysis is ready.\nLet\'s see what your body is telling you.',
          style: GoogleFonts.plusJakartaSans(
            fontSize: 12.sp > 15 ? 15 : 12.sp,
            fontWeight: FontWeight.w400,
            color: Colors.white.withValues(alpha: 0.65),
            height: 1.5,
          ),
          textAlign: TextAlign.center,
        ),
      ],
    );
  }

  Widget _buildSummaryCard() {
    final data = widget.onboardingData;
    final isMale = data?.gender?.toLowerCase() == 'male';
    final baseBodyFat = isMale ? 18.0 : 25.0;
    final activityBonus = _activityBonus(data?.activityLevel);
    final bodyFat = (baseBodyFat - activityBonus).clamp(8.0, 40.0);
    final bodyCategory = _bodyCategory(bodyFat, isMale);

    return Container(
      width: double.infinity,
      padding: EdgeInsets.all(4.w),
      decoration: BoxDecoration(
        color: Colors.white.withValues(alpha: 0.06),
        borderRadius: BorderRadius.circular(20.0),
        border: Border.all(color: Colors.white.withValues(alpha: 0.1)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                padding: EdgeInsets.symmetric(horizontal: 3.w, vertical: 0.6.h),
                decoration: BoxDecoration(
                  color: const Color(0xFF6C5CE7).withValues(alpha: 0.2),
                  borderRadius: BorderRadius.circular(8.0),
                  border: Border.all(
                    color: const Color(0xFF6C5CE7).withValues(alpha: 0.4),
                  ),
                ),
                child: Text(
                  'Your Profile',
                  style: GoogleFonts.plusJakartaSans(
                    fontSize: 10.sp > 12 ? 12 : 10.sp,
                    fontWeight: FontWeight.w700,
                    color: const Color(0xFF6C5CE7),
                  ),
                ),
              ),
              const Spacer(),
              const Icon(
                Icons.check_circle_rounded,
                color: Color(0xFF00B894),
                size: 20,
              ),
              SizedBox(width: 1.w),
              Text(
                '2 photos captured',
                style: GoogleFonts.plusJakartaSans(
                  fontSize: 10.sp > 12 ? 12 : 10.sp,
                  color: const Color(0xFF00B894),
                  fontWeight: FontWeight.w600,
                ),
              ),
            ],
          ),
          SizedBox(height: 2.h),
          Row(
            children: [
              Expanded(
                child: _buildStatItem(
                  icon: Icons.flag_rounded,
                  label: 'Goal',
                  value: _formatGoal(data?.goal),
                  color: const Color(0xFF6C5CE7),
                ),
              ),
              SizedBox(width: 3.w),
              Expanded(
                child: _buildStatItem(
                  icon: Icons.person_rounded,
                  label: 'Gender',
                  value: _capitalize(data?.gender) ?? '--',
                  color: const Color(0xFF74B9FF),
                ),
              ),
            ],
          ),
          SizedBox(height: 1.5.h),
          Row(
            children: [
              Expanded(
                child: _buildStatItem(
                  icon: Icons.straighten_rounded,
                  label: 'Height',
                  value: data?.displayHeight ?? '--',
                  color: const Color(0xFF00B894),
                ),
              ),
              SizedBox(width: 3.w),
              Expanded(
                child: _buildStatItem(
                  icon: Icons.monitor_weight_rounded,
                  label: 'Weight',
                  value: data?.displayWeight ?? '--',
                  color: const Color(0xFFFFA500),
                ),
              ),
            ],
          ),
          SizedBox(height: 1.5.h),
          Row(
            children: [
              Expanded(
                child: _buildStatItem(
                  icon: Icons.fitness_center_rounded,
                  label: 'Activity',
                  value: _formatActivity(data?.activityLevel),
                  color: const Color(0xFFFF6B6B),
                ),
              ),
              SizedBox(width: 3.w),
              Expanded(
                child: _buildStatItem(
                  icon: Icons.camera_alt_rounded,
                  label: 'Photos',
                  value: '2 captured',
                  color: const Color(0xFF00CEC9),
                ),
              ),
            ],
          ),
          SizedBox(height: 1.5.h),
          // Teaser row: body fat and category (blurred)
          Row(
            children: [
              Expanded(
                child: _buildTeaserItem(
                  label: 'Masse Grasse',
                  value: '${bodyFat.toStringAsFixed(1)}%',
                  color: const Color(0xFFFF6B6B),
                  locked: true,
                ),
              ),
              SizedBox(width: 3.w),
              Expanded(
                child: _buildTeaserItem(
                  label: 'Category',
                  value: bodyCategory,
                  color: const Color(0xFF00CEC9),
                  locked: true,
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildStatItem({
    required IconData icon,
    required String label,
    required String value,
    required Color color,
  }) {
    return Container(
      padding: EdgeInsets.symmetric(horizontal: 3.w, vertical: 1.2.h),
      decoration: BoxDecoration(
        color: color.withValues(alpha: 0.08),
        borderRadius: BorderRadius.circular(12.0),
        border: Border.all(color: color.withValues(alpha: 0.2)),
      ),
      child: Row(
        children: [
          Icon(icon, color: color, size: 16),
          SizedBox(width: 2.w),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  label,
                  style: GoogleFonts.plusJakartaSans(
                    fontSize: 9.sp > 11 ? 11 : 9.sp,
                    color: Colors.white.withValues(alpha: 0.5),
                  ),
                ),
                Text(
                  value,
                  style: GoogleFonts.plusJakartaSans(
                    fontSize: 10.sp > 13 ? 13 : 10.sp,
                    color: Colors.white,
                    fontWeight: FontWeight.w700,
                  ),
                  overflow: TextOverflow.ellipsis,
                  maxLines: 1,
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildTeaserItem({
    required String label,
    required String value,
    required Color color,
    required bool locked,
  }) {
    return Container(
      padding: EdgeInsets.symmetric(horizontal: 3.w, vertical: 1.2.h),
      decoration: BoxDecoration(
        color: color.withValues(alpha: 0.06),
        borderRadius: BorderRadius.circular(12.0),
        border: Border.all(color: color.withValues(alpha: 0.15)),
      ),
      child: Row(
        children: [
          Icon(
            locked ? Icons.lock_rounded : Icons.bar_chart_rounded,
            color: color.withValues(alpha: 0.6),
            size: 14,
          ),
          SizedBox(width: 2.w),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  label,
                  style: GoogleFonts.plusJakartaSans(
                    fontSize: 9.sp > 11 ? 11 : 9.sp,
                    color: Colors.white.withValues(alpha: 0.4),
                  ),
                ),
                // Blurred value
                ClipRect(
                  child: ImageFiltered(
                    imageFilter: const ColorFilter.mode(
                      Colors.transparent,
                      BlendMode.clear,
                    ),
                    child: Stack(
                      children: [
                        Text(
                          value,
                          style: GoogleFonts.plusJakartaSans(
                            fontSize: 10.sp > 13 ? 13 : 10.sp,
                            color: color.withValues(alpha: 0.4),
                            fontWeight: FontWeight.w700,
                          ),
                        ),
                        Positioned.fill(
                          child: Container(
                            decoration: BoxDecoration(
                              gradient: LinearGradient(
                                colors: [
                                  Colors.transparent,
                                  const Color(
                                    0xFF0A0A14,
                                  ).withValues(alpha: 0.8),
                                ],
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildDashboardPreview() {
    return Stack(
      children: [
        Container(
          width: double.infinity,
          padding: EdgeInsets.all(4.w),
          decoration: BoxDecoration(
            gradient: LinearGradient(
              colors: [
                const Color(0xFF1B365D).withValues(alpha: 0.8),
                const Color(0xFF6C5CE7).withValues(alpha: 0.6),
              ],
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
            ),
            borderRadius: BorderRadius.circular(20.0),
            border: Border.all(
              color: const Color(0xFF6C5CE7).withValues(alpha: 0.3),
            ),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Text(
                    'Your Dashboard Preview',
                    style: GoogleFonts.plusJakartaSans(
                      fontSize: 12.sp > 15 ? 15 : 12.sp,
                      fontWeight: FontWeight.w700,
                      color: Colors.white.withValues(alpha: 0.9),
                    ),
                  ),
                  const Spacer(),
                  Container(
                    padding: EdgeInsets.symmetric(
                      horizontal: 2.w,
                      vertical: 0.4.h,
                    ),
                    decoration: BoxDecoration(
                      color: const Color(0xFFFFD700).withValues(alpha: 0.2),
                      borderRadius: BorderRadius.circular(6.0),
                    ),
                    child: Text(
                      'UNLOCKING',
                      style: GoogleFonts.plusJakartaSans(
                        fontSize: 8.sp > 10 ? 10 : 8.sp,
                        fontWeight: FontWeight.w700,
                        color: const Color(0xFFFFD700),
                        letterSpacing: 0.8,
                      ),
                    ),
                  ),
                ],
              ),
              SizedBox(height: 1.5.h),
              _buildBlurredMetricRow(
                '% Masse Grasse',
                '??%',
                const Color(0xFF6C5CE7),
              ),
              SizedBox(height: 1.h),
              _buildBlurredMetricRow(
                'Body Category',
                '??????',
                const Color(0xFF00B894),
              ),
              SizedBox(height: 1.h),
              _buildBlurredMetricRow(
                'Masse Maigre',
                '?? kg',
                const Color(0xFF74B9FF),
              ),
              SizedBox(height: 5.h),
            ],
          ),
        ),
        Positioned.fill(
          child: ClipRRect(
            borderRadius: BorderRadius.circular(20.0),
            child: Container(
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [
                    Colors.transparent,
                    const Color(0xFF0A0A14).withValues(alpha: 0.7),
                  ],
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                ),
              ),
            ),
          ),
        ),
        Positioned(
          bottom: 3.h,
          left: 0,
          right: 0,
          child: Center(
            child: Column(
              children: [
                Container(
                  padding: EdgeInsets.all(2.w),
                  decoration: BoxDecoration(
                    color: Colors.white.withValues(alpha: 0.1),
                    shape: BoxShape.circle,
                    border: Border.all(
                      color: Colors.white.withValues(alpha: 0.2),
                    ),
                  ),
                  child: Icon(
                    Icons.lock_open_rounded,
                    color: Colors.white.withValues(alpha: 0.8),
                    size: 20,
                  ),
                ),
                SizedBox(height: 0.8.h),
                Text(
                  'Tap "View Results" to unlock',
                  style: GoogleFonts.plusJakartaSans(
                    fontSize: 10.sp > 12 ? 12 : 10.sp,
                    color: Colors.white.withValues(alpha: 0.6),
                    fontWeight: FontWeight.w500,
                  ),
                ),
              ],
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildBlurredMetricRow(String label, String value, Color color) {
    return Row(
      children: [
        Container(
          width: 3.w,
          height: 3.w,
          decoration: BoxDecoration(
            color: color.withValues(alpha: 0.3),
            shape: BoxShape.circle,
          ),
        ),
        SizedBox(width: 2.w),
        Text(
          label,
          style: GoogleFonts.plusJakartaSans(
            fontSize: 11.sp > 13 ? 13 : 11.sp,
            color: Colors.white.withValues(alpha: 0.6),
          ),
        ),
        const Spacer(),
        Container(
          padding: EdgeInsets.symmetric(horizontal: 2.w, vertical: 0.3.h),
          decoration: BoxDecoration(
            color: color.withValues(alpha: 0.15),
            borderRadius: BorderRadius.circular(6.0),
          ),
          child: Text(
            value,
            style: GoogleFonts.plusJakartaSans(
              fontSize: 11.sp > 13 ? 13 : 11.sp,
              color: color.withValues(alpha: 0.5),
              fontWeight: FontWeight.w700,
              letterSpacing: 2,
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildViewResultsButton() {
    return SizedBox(
      width: double.infinity,
      height: 6.5.h,
      child: DecoratedBox(
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(16.0),
          gradient: const LinearGradient(
            colors: [Color(0xFFFFD700), Color(0xFFFFA500)],
            begin: Alignment.centerLeft,
            end: Alignment.centerRight,
          ),
          boxShadow: [
            BoxShadow(
              color: const Color(0xFFFFD700).withValues(alpha: 0.4),
              blurRadius: 20,
              offset: const Offset(0, 6),
            ),
          ],
        ),
        child: ElevatedButton.icon(
          onPressed: _isSaving ? null : _onViewResults,
          icon: _isSaving
              ? const SizedBox(
                  width: 18,
                  height: 18,
                  child: CircularProgressIndicator(
                    color: Color(0xFF1B1B1B),
                    strokeWidth: 2.5,
                  ),
                )
              : const Icon(Icons.bar_chart_rounded, color: Color(0xFF1B1B1B)),
          label: Text(
            _isSaving ? 'Saving...' : 'View Results',
            style: GoogleFonts.plusJakartaSans(
              fontSize: 14.sp > 17 ? 17 : 14.sp,
              fontWeight: FontWeight.w800,
              color: const Color(0xFF1B1B1B),
            ),
          ),
          style: ElevatedButton.styleFrom(
            backgroundColor: Colors.transparent,
            shadowColor: Colors.transparent,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(16.0),
            ),
          ),
        ),
      ),
    );
  }

  String _formatGoal(String? goal) {
    if (goal == null) return '--';
    switch (goal.toLowerCase()) {
      case 'lose_fat':
      case 'lose fat':
        return 'Lose Fat';
      case 'build_muscle':
      case 'build muscle':
        return 'Build Muscle';
      case 'maintain':
        return 'Maintain';
      case 'track_fitness':
      case 'track fitness':
        return 'Track Fitness';
      default:
        return _capitalize(goal) ?? goal;
    }
  }

  String _formatActivity(String? activity) {
    if (activity == null) return '--';
    if (activity.contains('sedentary') || activity.contains('Sedentary')) {
      return 'Sedentary';
    }
    if (activity.contains('1') || activity.contains('2')) return '1–2x/week';
    if (activity.contains('3') || activity.contains('4')) return '3–4x/week';
    if (activity.contains('5')) return '5+x/week';
    return _capitalize(activity) ?? activity;
  }

  String? _capitalize(String? s) {
    if (s == null || s.isEmpty) return s;
    return s[0].toUpperCase() + s.substring(1).toLowerCase();
  }
}

// ─── Confetti ─────────────────────────────────────────────────────────────────

class _ConfettiParticle {
  final double x, y, size, angle, speed;
  final Color color;
  _ConfettiParticle({
    required this.x,
    required this.y,
    required this.size,
    required this.color,
    required this.angle,
    required this.speed,
  });
}

class _ConfettiPainter extends CustomPainter {
  final List<_ConfettiParticle> particles;
  final double progress;
  _ConfettiPainter({required this.particles, required this.progress});

  @override
  void paint(Canvas canvas, Size size) {
    for (final p in particles) {
      final paint = Paint()
        ..color = p.color.withValues(alpha: 1.0 - progress * 0.8);
      final x = p.x * size.width + math.sin(p.angle + progress * 4) * 20;
      final y = p.y * size.height + progress * size.height * p.speed;
      final rect = Rect.fromCenter(
        center: Offset(x, y),
        width: p.size,
        height: p.size * 0.6,
      );
      canvas.save();
      canvas.translate(x, y);
      canvas.rotate(p.angle + progress * 3);
      canvas.translate(-x, -y);
      canvas.drawRect(rect, paint);
      canvas.restore();
    }
  }

  @override
  bool shouldRepaint(covariant _ConfettiPainter oldDelegate) =>
      oldDelegate.progress != progress;
}
