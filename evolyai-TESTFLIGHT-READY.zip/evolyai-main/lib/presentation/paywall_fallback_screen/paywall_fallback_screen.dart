import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:sizer/sizer.dart';

import '../../models/onboarding_data.dart';
import '../../routes/app_routes.dart';
import '../../services/supabase_service.dart';
import '../rescan_result_screen/rescan_result_screen.dart';

class PaywallFallbackScreen extends StatefulWidget {
  final OnboardingData? onboardingData;

  const PaywallFallbackScreen({super.key, this.onboardingData});

  @override
  State<PaywallFallbackScreen> createState() => _PaywallFallbackScreenState();
}

class _PaywallFallbackScreenState extends State<PaywallFallbackScreen>
    with TickerProviderStateMixin {
  bool _isLoading = false;

  late AnimationController _entryController;
  late AnimationController _urgencyController;
  late Animation<double> _fadeAnimation;
  late Animation<Offset> _slideAnimation;
  late Animation<double> _urgencyAnimation;

  @override
  void initState() {
    super.initState();
    _entryController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 500),
    )..forward();
    _fadeAnimation = CurvedAnimation(
      parent: _entryController,
      curve: Curves.easeOut,
    );
    _slideAnimation =
        Tween<Offset>(begin: const Offset(0, 0.08), end: Offset.zero).animate(
          CurvedAnimation(parent: _entryController, curve: Curves.easeOutCubic),
        );
    _urgencyController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1200),
    )..repeat(reverse: true);
    _urgencyAnimation = Tween<double>(begin: 0.85, end: 1.0).animate(
      CurvedAnimation(parent: _urgencyController, curve: Curves.easeInOut),
    );
  }

  @override
  void dispose() {
    _entryController.dispose();
    _urgencyController.dispose();
    super.dispose();
  }

  Future<void> _onClaimOffer() async {
    HapticFeedback.mediumImpact();
    setState(() => _isLoading = true);

    try {
      await SupabaseService.instance.activateSubscription(
        productId: 'yearly_29_99_special',
        provider: 'in_app',
      );
      debugPrint('[PaywallFallback] Special offer claimed');
    } catch (e) {
      debugPrint('[PaywallFallback] Offer claim error: $e');
    }

    if (!mounted) return;
    setState(() => _isLoading = false);

    _navigateAfterPaywall();
  }

  void _onContinueFree() {
    HapticFeedback.lightImpact();
    debugPrint('[PaywallFallback] User chose free access');
    _navigateAfterPaywall();
  }

  void _navigateAfterPaywall() {
    final scanResult = widget.onboardingData?.scanResult;
    if (scanResult != null) {
      // Route through rescan result screen so user sees their completed scan card
      Navigator.of(context).pushNamedAndRemoveUntil(
        AppRoutes.rescanResult,
        (route) => false,
        arguments: RescanResultArgs(
          newResult: scanResult,
          onboardingData: widget.onboardingData,
        ),
      );
    } else {
      Navigator.of(context).pushNamedAndRemoveUntil(
        AppRoutes.homeDashboard,
        (route) => false,
        arguments: widget.onboardingData,
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return PopScope(
      canPop: false,
      onPopInvokedWithResult: (didPop, result) {
        if (!didPop) _onContinueFree();
      },
      child: Scaffold(
        backgroundColor: const Color(0xFF0A0A14),
        body: FadeTransition(
          opacity: _fadeAnimation,
          child: SlideTransition(
            position: _slideAnimation,
            child: SafeArea(
              child: Padding(
                padding: EdgeInsets.symmetric(horizontal: 4.w, vertical: 2.h),
                child: Column(
                  children: [
                    _buildUrgencyBanner(),
                    SizedBox(height: 2.h),
                    Expanded(
                      child: SingleChildScrollView(
                        child: Column(
                          children: [
                            _buildHero(),
                            SizedBox(height: 2.5.h),
                            _buildOfferCard(),
                            SizedBox(height: 2.h),
                            _buildWhatYouLose(),
                            SizedBox(height: 2.h),
                          ],
                        ),
                      ),
                    ),
                    _buildButtons(),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildUrgencyBanner() {
    return AnimatedBuilder(
      animation: _urgencyAnimation,
      builder: (context, child) {
        return Transform.scale(
          scale: _urgencyAnimation.value,
          child: Container(
            width: double.infinity,
            padding: EdgeInsets.symmetric(vertical: 1.h, horizontal: 4.w),
            decoration: BoxDecoration(
              gradient: const LinearGradient(
                colors: [Color(0xFFFF6B6B), Color(0xFFFF8E53)],
                begin: Alignment.centerLeft,
                end: Alignment.centerRight,
              ),
              borderRadius: BorderRadius.circular(12.0),
            ),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                const Icon(Icons.timer_rounded, color: Colors.white, size: 16),
                SizedBox(width: 2.w),
                Text(
                  'ONE-TIME OFFER · Limited availability',
                  style: GoogleFonts.plusJakartaSans(
                    fontSize: 10.sp > 12 ? 12 : 10.sp,
                    fontWeight: FontWeight.w800,
                    color: Colors.white,
                    letterSpacing: 0.5,
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  Widget _buildHero() {
    return Column(
      children: [
        Container(
          width: 18.w,
          height: 18.w,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            gradient: const LinearGradient(
              colors: [Color(0xFFFFD700), Color(0xFFFFA500)],
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
            ),
            boxShadow: [
              BoxShadow(
                color: const Color(0xFFFFD700).withValues(alpha: 0.4),
                blurRadius: 24,
                spreadRadius: 4,
              ),
            ],
          ),
          child: const Icon(
            Icons.local_offer_rounded,
            color: Colors.white,
            size: 32,
          ),
        ),
        SizedBox(height: 2.h),
        Text(
          'Wait! Special Offer\nJust for You',
          textAlign: TextAlign.center,
          style: GoogleFonts.plusJakartaSans(
            fontSize: 20.sp > 28 ? 28 : 20.sp,
            fontWeight: FontWeight.w800,
            color: Colors.white,
            height: 1.2,
          ),
        ),
        SizedBox(height: 1.h),
        Text(
          'We\'re giving you an exclusive discount\nbefore you go.',
          textAlign: TextAlign.center,
          style: GoogleFonts.plusJakartaSans(
            fontSize: 11.sp > 14 ? 14 : 11.sp,
            color: Colors.white.withValues(alpha: 0.6),
            height: 1.5,
          ),
        ),
      ],
    );
  }

  Widget _buildOfferCard() {
    return Container(
      width: double.infinity,
      padding: EdgeInsets.all(4.w),
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          colors: [Color(0xFF1A1A2E), Color(0xFF16213E)],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(20.0),
        border: Border.all(
          color: const Color(0xFFFFD700).withValues(alpha: 0.4),
          width: 1.5,
        ),
        boxShadow: [
          BoxShadow(
            color: const Color(0xFFFFD700).withValues(alpha: 0.15),
            blurRadius: 20,
            spreadRadius: 2,
          ),
        ],
      ),
      child: Column(
        children: [
          Container(
            padding: EdgeInsets.symmetric(horizontal: 3.w, vertical: 0.6.h),
            decoration: BoxDecoration(
              color: const Color(0xFFFFD700).withValues(alpha: 0.15),
              borderRadius: BorderRadius.circular(8.0),
              border: Border.all(
                color: const Color(0xFFFFD700).withValues(alpha: 0.4),
              ),
            ),
            child: Text(
              '🎁  EXCLUSIVE DISCOUNT',
              style: GoogleFonts.plusJakartaSans(
                fontSize: 10.sp > 12 ? 12 : 10.sp,
                fontWeight: FontWeight.w800,
                color: const Color(0xFFFFD700),
                letterSpacing: 0.8,
              ),
            ),
          ),
          SizedBox(height: 2.h),
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                '39.99€',
                style: GoogleFonts.plusJakartaSans(
                  fontSize: 14.sp > 18 ? 18 : 14.sp,
                  fontWeight: FontWeight.w600,
                  color: Colors.white.withValues(alpha: 0.4),
                  decoration: TextDecoration.lineThrough,
                  decorationColor: Colors.white.withValues(alpha: 0.4),
                ),
              ),
              SizedBox(width: 3.w),
              ShaderMask(
                shaderCallback: (bounds) => const LinearGradient(
                  colors: [Color(0xFFFFD700), Color(0xFFFFA500)],
                ).createShader(bounds),
                child: Text(
                  '29.99€',
                  style: GoogleFonts.plusJakartaSans(
                    fontSize: 28.sp > 44 ? 44 : 28.sp,
                    fontWeight: FontWeight.w900,
                    color: Colors.white,
                  ),
                ),
              ),
            ],
          ),
          Text(
            'par an  ·  économisez 10€ de plus',
            style: GoogleFonts.plusJakartaSans(
              fontSize: 10.sp > 13 ? 13 : 10.sp,
              color: Colors.white.withValues(alpha: 0.6),
            ),
          ),
          SizedBox(height: 1.h),
          Container(
            padding: EdgeInsets.symmetric(horizontal: 3.w, vertical: 0.5.h),
            decoration: BoxDecoration(
              color: const Color(0xFF00B894).withValues(alpha: 0.15),
              borderRadius: BorderRadius.circular(8.0),
            ),
            child: Text(
              'Soit 0.58€/semaine — 90% de réduction',
              style: GoogleFonts.plusJakartaSans(
                fontSize: 10.sp > 12 ? 12 : 10.sp,
                color: const Color(0xFF00B894),
                fontWeight: FontWeight.w700,
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildWhatYouLose() {
    final items = [
      'Full body fat & composition analysis',
      'Body zone breakdown (arms, legs, core)',
      'Progress tracking & scan history',
      'Premium reports & insights',
    ];

    return Container(
      padding: EdgeInsets.all(4.w),
      decoration: BoxDecoration(
        color: Colors.white.withValues(alpha: 0.04),
        borderRadius: BorderRadius.circular(16.0),
        border: Border.all(color: Colors.white.withValues(alpha: 0.07)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'Without Premium you\'ll miss:',
            style: GoogleFonts.plusJakartaSans(
              fontSize: 11.sp > 14 ? 14 : 11.sp,
              fontWeight: FontWeight.w700,
              color: Colors.white.withValues(alpha: 0.7),
            ),
          ),
          SizedBox(height: 1.h),
          ...items.map(
            (item) => Padding(
              padding: EdgeInsets.symmetric(vertical: 0.5.h),
              child: Row(
                children: [
                  const Icon(
                    Icons.lock_rounded,
                    color: Color(0xFFFF6B6B),
                    size: 14,
                  ),
                  SizedBox(width: 2.w),
                  Expanded(
                    child: Text(
                      item,
                      style: GoogleFonts.plusJakartaSans(
                        fontSize: 10.sp > 12 ? 12 : 10.sp,
                        color: Colors.white.withValues(alpha: 0.55),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildButtons() {
    return Column(
      children: [
        SizedBox(
          width: double.infinity,
          height: 6.5.h,
          child: DecoratedBox(
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(16.0),
              gradient: const LinearGradient(
                colors: [Color(0xFFFFD700), Color(0xFFFFA500)],
                begin: Alignment.centerLeft,
                end: Alignment.centerRight,
              ),
              boxShadow: [
                BoxShadow(
                  color: const Color(0xFFFFD700).withValues(alpha: 0.4),
                  blurRadius: 20,
                  offset: const Offset(0, 6),
                ),
              ],
            ),
            child: ElevatedButton(
              onPressed: _isLoading ? null : _onClaimOffer,
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.transparent,
                shadowColor: Colors.transparent,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(16.0),
                ),
              ),
              child: _isLoading
                  ? const SizedBox(
                      width: 22,
                      height: 22,
                      child: CircularProgressIndicator(
                        color: Color(0xFF1B1B1B),
                        strokeWidth: 2.5,
                      ),
                    )
                  : Text(
                      'Offre Fondateurs — 29.99€/an',
                      style: GoogleFonts.plusJakartaSans(
                        fontSize: 13.sp > 16 ? 16 : 13.sp,
                        fontWeight: FontWeight.w800,
                        color: const Color(0xFF1B1B1B),
                      ),
                    ),
            ),
          ),
        ),
        SizedBox(height: 1.5.h),
        GestureDetector(
          onTap: _onContinueFree,
          child: Text(
            'Continue without Premium',
            style: GoogleFonts.plusJakartaSans(
              fontSize: 11.sp > 14 ? 14 : 11.sp,
              color: Colors.white.withValues(alpha: 0.4),
              decoration: TextDecoration.underline,
              decorationColor: Colors.white.withValues(alpha: 0.3),
            ),
          ),
        ),
        SizedBox(height: 1.h),
      ],
    );
  }
}
