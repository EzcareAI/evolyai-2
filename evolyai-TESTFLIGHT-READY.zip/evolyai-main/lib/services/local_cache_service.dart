import 'dart:convert';
import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';

/// Lightweight local cache for scan results and profile data.
/// Also manages a queue of pending write actions to be synced when online.
class LocalCacheService {
  static LocalCacheService? _instance;
  static LocalCacheService get instance => _instance ??= LocalCacheService._();
  LocalCacheService._();

  static const _keyLatestScan = 'cache_latest_scan';
  static const _keyScanHistory = 'cache_scan_history';
  static const _keyProfile = 'cache_profile';
  static const _keyOnboarding = 'cache_onboarding';
  static const _keyPendingQueue = 'cache_pending_queue';

  // ─── Latest Scan Result ───────────────────────────────────────────────────

  Future<void> cacheLatestScan(Map<String, dynamic> data) async {
    try {
      final prefs = await SharedPreferences.getInstance();
      await prefs.setString(_keyLatestScan, jsonEncode(data));
    } catch (e) {
      debugPrint('cacheLatestScan error: $e');
    }
  }

  Future<Map<String, dynamic>?> getCachedLatestScan() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final raw = prefs.getString(_keyLatestScan);
      if (raw == null) return null;
      return jsonDecode(raw) as Map<String, dynamic>;
    } catch (e) {
      debugPrint('getCachedLatestScan error: $e');
      return null;
    }
  }

  // ─── Scan History ─────────────────────────────────────────────────────────

  Future<void> cacheScanHistory(List<Map<String, dynamic>> data) async {
    try {
      final prefs = await SharedPreferences.getInstance();
      await prefs.setString(_keyScanHistory, jsonEncode(data));
    } catch (e) {
      debugPrint('cacheScanHistory error: $e');
    }
  }

  Future<List<Map<String, dynamic>>> getCachedScanHistory() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final raw = prefs.getString(_keyScanHistory);
      if (raw == null) return [];
      final list = jsonDecode(raw) as List<dynamic>;
      return list.cast<Map<String, dynamic>>();
    } catch (e) {
      debugPrint('getCachedScanHistory error: $e');
      return [];
    }
  }

  // ─── Profile ──────────────────────────────────────────────────────────────

  Future<void> cacheProfile(Map<String, dynamic> data) async {
    try {
      final prefs = await SharedPreferences.getInstance();
      await prefs.setString(_keyProfile, jsonEncode(data));
    } catch (e) {
      debugPrint('cacheProfile error: $e');
    }
  }

  Future<Map<String, dynamic>?> getCachedProfile() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final raw = prefs.getString(_keyProfile);
      if (raw == null) return null;
      return jsonDecode(raw) as Map<String, dynamic>;
    } catch (e) {
      debugPrint('getCachedProfile error: $e');
      return null;
    }
  }

  // ─── Onboarding Answers ───────────────────────────────────────────────────

  Future<void> cacheOnboarding(Map<String, dynamic> data) async {
    try {
      final prefs = await SharedPreferences.getInstance();
      await prefs.setString(_keyOnboarding, jsonEncode(data));
    } catch (e) {
      debugPrint('cacheOnboarding error: $e');
    }
  }

  Future<Map<String, dynamic>?> getCachedOnboarding() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final raw = prefs.getString(_keyOnboarding);
      if (raw == null) return null;
      return jsonDecode(raw) as Map<String, dynamic>;
    } catch (e) {
      debugPrint('getCachedOnboarding error: $e');
      return null;
    }
  }

  // ─── Pending Queue ────────────────────────────────────────────────────────

  Future<List<Map<String, dynamic>>> getPendingQueue() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final raw = prefs.getString(_keyPendingQueue);
      if (raw == null) return [];
      final list = jsonDecode(raw) as List<dynamic>;
      return list.cast<Map<String, dynamic>>();
    } catch (e) {
      return [];
    }
  }

  Future<void> enqueueAction(Map<String, dynamic> action) async {
    try {
      final queue = await getPendingQueue();
      queue.add({...action, 'enqueuedAt': DateTime.now().toIso8601String()});
      final prefs = await SharedPreferences.getInstance();
      await prefs.setString(_keyPendingQueue, jsonEncode(queue));
    } catch (e) {
      debugPrint('enqueueAction error: $e');
    }
  }

  Future<void> clearQueue() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      await prefs.remove(_keyPendingQueue);
    } catch (e) {
      debugPrint('clearQueue error: $e');
    }
  }

  Future<void> removeQueueItem(int index) async {
    try {
      final queue = await getPendingQueue();
      if (index >= 0 && index < queue.length) {
        queue.removeAt(index);
        final prefs = await SharedPreferences.getInstance();
        await prefs.setString(_keyPendingQueue, jsonEncode(queue));
      }
    } catch (e) {
      debugPrint('removeQueueItem error: $e');
    }
  }
}
