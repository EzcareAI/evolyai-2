import 'package:connectivity_plus/connectivity_plus.dart';
import 'package:flutter/foundation.dart';

import './local_cache_service.dart';
import './supabase_service.dart';

enum SyncStatus { synced, syncing, offline, pending }

/// Manages network connectivity monitoring and pending action sync.
class SyncService extends ChangeNotifier {
  static SyncService? _instance;
  static SyncService get instance => _instance ??= SyncService._();
  SyncService._();

  SyncStatus _status = SyncStatus.synced;
  SyncStatus get status => _status;

  bool _isOnline = true;
  bool get isOnline => _isOnline;

  int _pendingCount = 0;
  int get pendingCount => _pendingCount;

  void initialize() {
    Connectivity().onConnectivityChanged.listen((results) {
      final wasOffline = !_isOnline;
      _isOnline = results.any((r) => r != ConnectivityResult.none);
      if (_isOnline) {
        if (wasOffline) {
          // Back online — flush the queue
          flushQueue();
        } else {
          _refreshPendingCount();
        }
      } else {
        _setStatus(SyncStatus.offline);
      }
    });

    // Check initial connectivity
    Connectivity().checkConnectivity().then((results) {
      _isOnline = results.any((r) => r != ConnectivityResult.none);
      if (_isOnline) {
        _refreshPendingCount();
      } else {
        _setStatus(SyncStatus.offline);
      }
    });
  }

  Future<void> _refreshPendingCount() async {
    final queue = await LocalCacheService.instance.getPendingQueue();
    _pendingCount = queue.length;
    if (_pendingCount > 0) {
      _setStatus(SyncStatus.pending);
    } else {
      _setStatus(SyncStatus.synced);
    }
  }

  void _setStatus(SyncStatus s) {
    if (_status != s) {
      _status = s;
      notifyListeners();
    }
  }

  /// Enqueue a scan_result write for offline sync
  Future<void> enqueueScanResult(Map<String, dynamic> scanResult) async {
    await LocalCacheService.instance.enqueueAction({
      'type': 'saveScanResult',
      'data': scanResult,
    });
    // Also update the local cache immediately
    await LocalCacheService.instance.cacheLatestScan(scanResult);
    _pendingCount++;
    if (!_isOnline) {
      _setStatus(SyncStatus.offline);
    } else {
      _setStatus(SyncStatus.pending);
    }
    notifyListeners();
  }

  /// Enqueue an onboarding_answers upsert for offline sync
  Future<void> enqueueOnboardingAnswers(Map<String, dynamic> answers) async {
    await LocalCacheService.instance.enqueueAction({
      'type': 'saveOnboardingAnswers',
      'data': answers,
    });
    // Also update the local cache immediately
    await LocalCacheService.instance.cacheOnboarding(answers);
    _pendingCount++;
    if (!_isOnline) {
      _setStatus(SyncStatus.offline);
    } else {
      _setStatus(SyncStatus.pending);
    }
    notifyListeners();
  }

  /// Flush all pending queued actions to Supabase
  Future<void> flushQueue() async {
    if (!_isOnline) return;
    final queue = await LocalCacheService.instance.getPendingQueue();
    if (queue.isEmpty) {
      _pendingCount = 0;
      _setStatus(SyncStatus.synced);
      return;
    }

    _setStatus(SyncStatus.syncing);
    final List<int> processedIndices = [];

    for (int i = 0; i < queue.length; i++) {
      final action = queue[i];
      try {
        final type = action['type'] as String?;
        if (type == 'updateProfile') {
          final updates = Map<String, dynamic>.from(
            action['updates'] as Map<String, dynamic>,
          );
          await SupabaseService.instance.updateProfile(updates);
          processedIndices.add(i);
        } else if (type == 'updateOnboarding') {
          final updates = Map<String, dynamic>.from(
            action['updates'] as Map<String, dynamic>,
          );
          await SupabaseService.instance.updateOnboardingGoal(
            updates['goal'] as String? ?? '',
          );
          processedIndices.add(i);
        } else if (type == 'saveOnboardingAnswers') {
          final data = Map<String, dynamic>.from(
            action['data'] as Map<String, dynamic>,
          );
          final uid = SupabaseService.instance.currentUser?.id;
          if (uid != null) {
            final answers = OnboardingAnswersModel.fromJson({
              ...data,
              'user_id': data['user_id'] ?? uid,
            });
            await SupabaseService.instance.saveOnboardingAnswers(answers);
            processedIndices.add(i);
          }
        } else if (type == 'saveScanResult') {
          // scan_results are written during AI processing — if queued, it means
          // the write failed offline. Re-attempt the upsert via supabase client.
          final data = Map<String, dynamic>.from(
            action['data'] as Map<String, dynamic>,
          );
          final uid = SupabaseService.instance.currentUser?.id;
          if (uid != null) {
            await SupabaseService.instance.client.from('scan_results').upsert({
              ...data,
              'user_id': uid,
            }, onConflict: 'id');
            processedIndices.add(i);
          }
        }
      } catch (e) {
        debugPrint('flushQueue item $i error: $e');
      }
    }

    // Remove processed items from the queue (in reverse order to preserve indices)
    for (final idx in processedIndices.reversed) {
      await LocalCacheService.instance.removeQueueItem(idx);
    }

    final remaining = await LocalCacheService.instance.getPendingQueue();
    _pendingCount = remaining.length;
    _setStatus(
      _isOnline
          ? (_pendingCount > 0 ? SyncStatus.pending : SyncStatus.synced)
          : SyncStatus.offline,
    );
  }
}
