import 'package:flutter/foundation.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:google_sign_in/google_sign_in.dart';
import './local_cache_service.dart';
import './sync_service.dart';

// ─────────────────────────────────────────────
// Models
// ─────────────────────────────────────────────

class ProfileModel {
  final String id;
  final String? email;
  final String? fullName;
  final String? avatarUrl;
  final String? locale;
  final String? country;
  final String heightUnit;
  final String weightUnit;
  final bool onboardingCompleted;
  final DateTime? createdAt;

  ProfileModel({
    required this.id,
    this.email,
    this.fullName,
    this.avatarUrl,
    this.locale,
    this.country,
    this.heightUnit = 'cm',
    this.weightUnit = 'kg',
    this.onboardingCompleted = false,
    this.createdAt,
  });

  factory ProfileModel.fromJson(Map<String, dynamic> json) => ProfileModel(
    id: json['id'] as String,
    email: json['email'] as String?,
    fullName: json['full_name'] as String?,
    avatarUrl: json['avatar_url'] as String?,
    locale: json['locale'] as String?,
    country: json['country'] as String?,
    heightUnit: json['height_unit'] as String? ?? 'cm',
    weightUnit: json['weight_unit'] as String? ?? 'kg',
    onboardingCompleted: json['onboarding_completed'] as bool? ?? false,
    createdAt: json['created_at'] != null
        ? DateTime.tryParse(json['created_at'] as String)
        : null,
  );

  Map<String, dynamic> toJson() => {
    'id': id,
    'email': email,
    'full_name': fullName,
    'avatar_url': avatarUrl,
    'locale': locale,
    'country': country,
    'height_unit': heightUnit,
    'weight_unit': weightUnit,
    'onboarding_completed': onboardingCompleted,
  };
}

class OnboardingAnswersModel {
  final String? id;
  final String userId;
  final String? goal;
  final String? gender;
  final int? age;
  final double? heightValue;
  final String? heightUnit;
  final double? weightValue;
  final String? weightUnit;
  final String? activityLevel;
  final String? motivation;
  final bool notificationsEnabled;
  final double? targetBodyFatPercent; // NEW

  OnboardingAnswersModel({
    this.id,
    required this.userId,
    this.goal,
    this.gender,
    this.age,
    this.heightValue,
    this.heightUnit,
    this.weightValue,
    this.weightUnit,
    this.activityLevel,
    this.motivation,
    this.notificationsEnabled = true,
    this.targetBodyFatPercent,
  });

  factory OnboardingAnswersModel.fromJson(Map<String, dynamic> json) =>
      OnboardingAnswersModel(
        id: json['id'] as String?,
        userId: json['user_id'] as String,
        goal: json['goal'] as String?,
        gender: json['gender'] as String?,
        age: json['age'] as int?,
        heightValue: json['height_value'] != null
            ? double.tryParse(json['height_value'].toString())
            : null,
        heightUnit: json['height_unit'] as String?,
        weightValue: json['weight_value'] != null
            ? double.tryParse(json['weight_value'].toString())
            : null,
        weightUnit: json['weight_unit'] as String?,
        activityLevel: json['activity_level'] as String?,
        motivation: json['motivation'] as String?,
        notificationsEnabled: json['notifications_enabled'] as bool? ?? true,
        targetBodyFatPercent: json['target_body_fat_percent'] != null
            ? double.tryParse(json['target_body_fat_percent'].toString())
            : null,
      );

  Map<String, dynamic> toJson() => {
    'user_id': userId,
    'goal': goal,
    'gender': gender,
    'age': age,
    'height_value': heightValue,
    'height_unit': heightUnit,
    'weight_value': weightValue,
    'weight_unit': weightUnit,
    'activity_level': activityLevel,
    'motivation': motivation,
    'notifications_enabled': notificationsEnabled,
    'target_body_fat_percent': targetBodyFatPercent,
  };
}

class ScanModel {
  final String id;
  final String userId;
  final String frontImageUrl;
  final String? sideImageUrl;
  final String scanStatus;
  final DateTime? createdAt;

  ScanModel({
    required this.id,
    required this.userId,
    required this.frontImageUrl,
    this.sideImageUrl,
    this.scanStatus = 'pending',
    this.createdAt,
  });

  factory ScanModel.fromJson(Map<String, dynamic> json) => ScanModel(
    id: json['id'] as String,
    userId: json['user_id'] as String,
    frontImageUrl: json['front_image_url'] as String,
    sideImageUrl: json['side_image_url'] as String?,
    scanStatus: json['scan_status'] as String? ?? 'pending',
    createdAt: json['created_at'] != null
        ? DateTime.tryParse(json['created_at'] as String)
        : null,
  );
}

class ScanResultModel {
  final String id;
  final String scanId;
  final String userId;
  final double? bodyFatPercent;
  final double? leanMassEstimate;
  final double? fatMass;
  final String? bodyCategory;
  final String? physiqueProfile;
  final double? bodyScore;
  final double? confidenceScore;
  final String? summaryText;
  final double? leftArmPercent;
  final double? rightArmPercent;
  final double? upperBodyPercent;
  final double? leftLegPercent;
  final double? rightLegPercent;
  final DateTime? createdAt;

  ScanResultModel({
    required this.id,
    required this.scanId,
    required this.userId,
    this.bodyFatPercent,
    this.leanMassEstimate,
    this.fatMass,
    this.bodyCategory,
    this.physiqueProfile,
    this.bodyScore,
    this.confidenceScore,
    this.summaryText,
    this.leftArmPercent,
    this.rightArmPercent,
    this.upperBodyPercent,
    this.leftLegPercent,
    this.rightLegPercent,
    this.createdAt,
  });

  factory ScanResultModel.fromJson(Map<String, dynamic> json) =>
      ScanResultModel(
        id: json['id'] as String,
        scanId: json['scan_id'] as String,
        userId: json['user_id'] as String,
        bodyFatPercent: json['body_fat_percent'] != null
            ? double.tryParse(json['body_fat_percent'].toString())
            : null,
        leanMassEstimate: json['lean_mass_estimate'] != null
            ? double.tryParse(json['lean_mass_estimate'].toString())
            : null,
        fatMass: json['fat_mass'] != null
            ? double.tryParse(json['fat_mass'].toString())
            : null,
        bodyCategory: json['body_category'] as String?,
        physiqueProfile: json['physique_profile'] as String?,
        bodyScore: json['body_score'] != null
            ? double.tryParse(json['body_score'].toString())
            : null,
        confidenceScore: json['confidence_score'] != null
            ? double.tryParse(json['confidence_score'].toString())
            : null,
        summaryText: json['summary_text'] as String?,
        leftArmPercent: json['left_arm_percent'] != null
            ? double.tryParse(json['left_arm_percent'].toString())
            : null,
        rightArmPercent: json['right_arm_percent'] != null
            ? double.tryParse(json['right_arm_percent'].toString())
            : null,
        upperBodyPercent: json['upper_body_percent'] != null
            ? double.tryParse(json['upper_body_percent'].toString())
            : null,
        leftLegPercent: json['left_leg_percent'] != null
            ? double.tryParse(json['left_leg_percent'].toString())
            : null,
        rightLegPercent: json['right_leg_percent'] != null
            ? double.tryParse(json['right_leg_percent'].toString())
            : null,
        createdAt: json['created_at'] != null
            ? DateTime.tryParse(json['created_at'] as String)
            : null,
      );

  Map<String, dynamic> toJson() => {
    'scan_id': scanId,
    'user_id': userId,
    'body_fat_percent': bodyFatPercent,
    'lean_mass_estimate': leanMassEstimate,
    'fat_mass': fatMass,
    'body_category': bodyCategory,
    'physique_profile': physiqueProfile,
    'body_score': bodyScore,
    'confidence_score': confidenceScore,
    'summary_text': summaryText,
    'left_arm_percent': leftArmPercent,
    'right_arm_percent': rightArmPercent,
    'upper_body_percent': upperBodyPercent,
    'left_leg_percent': leftLegPercent,
    'right_leg_percent': rightLegPercent,
  };
}

class SubscriptionModel {
  final String id;
  final String userId;
  final String? provider;
  final String? productId;
  final bool entitlementActive;
  final String? trialStatus;
  final DateTime? expiresAt;
  final DateTime? lastSyncedAt;

  SubscriptionModel({
    required this.id,
    required this.userId,
    this.provider,
    this.productId,
    this.entitlementActive = false,
    this.trialStatus,
    this.expiresAt,
    this.lastSyncedAt,
  });

  factory SubscriptionModel.fromJson(Map<String, dynamic> json) =>
      SubscriptionModel(
        id: json['id'] as String,
        userId: json['user_id'] as String,
        provider: json['provider'] as String?,
        productId: json['product_id'] as String?,
        entitlementActive: json['entitlement_active'] as bool? ?? false,
        trialStatus: json['trial_status'] as String?,
        expiresAt: json['expires_at'] != null
            ? DateTime.tryParse(json['expires_at'] as String)
            : null,
        lastSyncedAt: json['last_synced_at'] != null
            ? DateTime.tryParse(json['last_synced_at'] as String)
            : null,
      );
}

// ─────────────────────────────────────────────
// Service
// ─────────────────────────────────────────────

class SupabaseService {
  static SupabaseService? _instance;
  static SupabaseService get instance => _instance ??= SupabaseService._();

  SupabaseService._();

  static const String supabaseUrl = String.fromEnvironment(
    'SUPABASE_URL',
    defaultValue: '',
  );
  static const String supabaseAnonKey = String.fromEnvironment(
    'SUPABASE_ANON_KEY',
    defaultValue: '',
  );

  static Future<void> initialize() async {
    if (supabaseUrl.isEmpty || supabaseAnonKey.isEmpty) {
      throw Exception(
        'SUPABASE_URL and SUPABASE_ANON_KEY must be defined using --dart-define.',
      );
    }
    await Supabase.initialize(url: supabaseUrl, anonKey: supabaseAnonKey);
  }

  SupabaseClient get client => Supabase.instance.client;
  User? get currentUser => client.auth.currentUser;
  bool get isAuthenticated => currentUser != null;
  Stream<AuthState> get authStateChanges => client.auth.onAuthStateChange;

  // ─────────────────────────────────────────────
  // AUTH
  // ─────────────────────────────────────────────

  /// Sign up with email and password
  Future<AuthResponse> signUpWithEmail({
    required String email,
    required String password,
    String? fullName,
  }) async {
    return await client.auth.signUp(
      email: email,
      password: password,
      data: fullName != null ? {'full_name': fullName} : null,
    );
  }

  /// Sign in with email and password
  Future<AuthResponse> signInWithEmail({
    required String email,
    required String password,
  }) async {
    return await client.auth.signInWithPassword(
      email: email,
      password: password,
    );
  }

  /// Sign in with Google (native on mobile, OAuth on web)
  Future<bool> signInWithGoogle() async {
    try {
      if (kIsWeb) {
        await client.auth.signInWithOAuth(
          OAuthProvider.google,
          redirectTo: 'https://easybodyai8931.builtwithrocket.new',
        );
        return true;
      } else {
        const webClientId = String.fromEnvironment(
          'GOOGLE_WEB_CLIENT_ID',
          defaultValue: '',
        );
        final googleSignIn = GoogleSignIn(serverClientId: webClientId);

        GoogleSignInAccount? googleUser = await googleSignIn.signInSilently();
        googleUser ??= await googleSignIn.signIn();
        if (googleUser == null) return false;

        final googleAuth = await googleUser.authentication;
        final idToken = googleAuth.idToken;
        if (idToken == null) throw AuthException('No ID Token found.');

        final response = await client.auth.signInWithIdToken(
          provider: OAuthProvider.google,
          idToken: idToken,
          accessToken: googleAuth.accessToken,
        );
        return response.user != null;
      }
    } catch (e) {
      debugPrint('Google sign-in error: $e');
      rethrow;
    }
  }

  /// Sign in with Apple (iOS/macOS native, OAuth on web)
  Future<bool> signInWithApple() async {
    try {
      await client.auth.signInWithOAuth(
        OAuthProvider.apple,
        redirectTo: kIsWeb
            ? 'https://easybodyai8931.builtwithrocket.new'
            : null,
      );
      return true;
    } catch (e) {
      debugPrint('Apple sign-in error: $e');
      rethrow;
    }
  }

  /// Sign out
  Future<void> signOut() async {
    try {
      if (!kIsWeb) {
        final googleSignIn = GoogleSignIn();
        if (await googleSignIn.isSignedIn()) {
          await googleSignIn.signOut();
        }
      }
    } catch (_) {}
    await client.auth.signOut();
  }

  // ─────────────────────────────────────────────
  // PROFILE
  // ─────────────────────────────────────────────

  /// Fetch the current user's profile
  Future<ProfileModel?> fetchProfile() async {
    final uid = currentUser?.id;
    if (uid == null) return null;
    try {
      final data = await client
          .from('profiles')
          .select()
          .eq('id', uid)
          .maybeSingle();
      if (data == null) return null;
      return ProfileModel.fromJson(data);
    } catch (e) {
      debugPrint('fetchProfile error: $e');
      return null;
    }
  }

  /// Update the current user's profile
  Future<ProfileModel?> updateProfile(Map<String, dynamic> updates) async {
    final uid = currentUser?.id;
    if (uid == null) return null;
    try {
      final data = await client
          .from('profiles')
          .update(updates)
          .eq('id', uid)
          .select()
          .single();
      return ProfileModel.fromJson(data);
    } catch (e) {
      debugPrint('updateProfile error: $e');
      return null;
    }
  }

  /// Ensure a profile row exists (upsert)
  Future<void> ensureProfile() async {
    final user = currentUser;
    if (user == null) return;
    try {
      await client.from('profiles').upsert({
        'id': user.id,
        'email': user.email,
        'full_name': user.userMetadata?['full_name'] ?? '',
        'avatar_url': user.userMetadata?['avatar_url'] ?? '',
        'height_unit': 'cm',
        'weight_unit': 'kg',
        'onboarding_completed': false,
      }, onConflict: 'id');
    } catch (e) {
      debugPrint('ensureProfile error: $e');
    }
  }

  // ─────────────────────────────────────────────
  // ONBOARDING
  // ─────────────────────────────────────────────

  /// Save onboarding answers — caches locally and queues for sync if offline
  Future<bool> saveOnboardingAnswers(OnboardingAnswersModel answers) async {
    final uid = currentUser?.id;
    debugPrint('[SupabaseService] saveOnboardingAnswers called — uid=$uid');
    if (uid == null) {
      debugPrint(
        '[SupabaseService] saveOnboardingAnswers ABORTED — no authenticated user',
      );
      return false;
    }

    // Always cache locally first
    await LocalCacheService.instance.cacheOnboarding(answers.toJson());

    // Check connectivity
    final isOnline = SyncService.instance.isOnline;
    if (!isOnline) {
      debugPrint(
        '[SupabaseService] saveOnboardingAnswers — offline, queuing for sync',
      );
      await SyncService.instance.enqueueOnboardingAnswers(answers.toJson());
      return true;
    }

    try {
      final payload = answers.toJson();
      debugPrint('[SupabaseService] saveOnboardingAnswers payload: $payload');
      final response = await client
          .from('onboarding_answers')
          .upsert(payload, onConflict: 'user_id')
          .select();
      debugPrint(
        '[SupabaseService] saveOnboardingAnswers upsert response: $response',
      );
      // Mark onboarding as completed in profile
      await client
          .from('profiles')
          .update({
            'onboarding_completed': true,
            'height_unit': answers.heightUnit ?? 'cm',
            'weight_unit': answers.weightUnit ?? 'kg',
          })
          .eq('id', uid);
      debugPrint(
        '[SupabaseService] saveOnboardingAnswers — profile updated, returning true',
      );
      return true;
    } catch (e) {
      debugPrint(
        '[SupabaseService] saveOnboardingAnswers upsert error: $e — queuing for retry',
      );
      await SyncService.instance.enqueueOnboardingAnswers(answers.toJson());
      // Fallback: try plain insert, ignore duplicate
      try {
        final insertResponse = await client
            .from('onboarding_answers')
            .insert(answers.toJson())
            .select();
        debugPrint(
          '[SupabaseService] saveOnboardingAnswers insert fallback response: $insertResponse',
        );
        return true;
      } catch (e2) {
        debugPrint(
          '[SupabaseService] saveOnboardingAnswers insert fallback error: $e2',
        );
        return true; // Return true since we queued it for later sync
      }
    }
  }

  /// Load onboarding answers for the current user
  Future<OnboardingAnswersModel?> loadOnboardingAnswers() async {
    final uid = currentUser?.id;
    if (uid == null) return null;
    try {
      final data = await client
          .from('onboarding_answers')
          .select()
          .eq('user_id', uid)
          .order('created_at', ascending: false)
          .limit(1)
          .maybeSingle();
      if (data == null) return null;
      return OnboardingAnswersModel.fromJson(data);
    } catch (e) {
      debugPrint('loadOnboardingAnswers error: $e');
      return null;
    }
  }

  /// Alias for loadOnboardingAnswers — checks if onboarding answers exist
  Future<OnboardingAnswersModel?> fetchOnboardingAnswers() =>
      loadOnboardingAnswers();

  /// Update a specific field in onboarding_answers for the current user
  Future<bool> updateOnboardingGoal(String goal) async {
    final uid = currentUser?.id;
    if (uid == null) return false;
    try {
      await client
          .from('onboarding_answers')
          .update({'goal': goal})
          .eq('user_id', uid);
      return true;
    } catch (e) {
      debugPrint('updateOnboardingGoal error: $e');
      return false;
    }
  }

  /// Update onboarding answers fields
  Future<bool> updateOnboardingAnswers(Map<String, dynamic> updates) async {
    final uid = currentUser?.id;
    if (uid == null) return false;
    try {
      await client
          .from('onboarding_answers')
          .update(updates)
          .eq('user_id', uid);
      return true;
    } catch (e) {
      debugPrint('updateOnboardingAnswers error: $e');
      return false;
    }
  }

  // ─────────────────────────────────────────────
  // STORAGE – Body Scan Photos
  // ─────────────────────────────────────────────

  static const String _scansBucket = 'body-scans';

  /// Upload a scan photo to the private bucket using raw bytes (web + mobile safe).
  /// Returns the storage path on success, null on failure.
  Future<String?> uploadScanPhoto(dynamic file, {required String label}) async {
    final uid = currentUser?.id;
    if (uid == null) return null;
    try {
      String ext = 'jpg';
      Uint8List? bytes;

      // Accept either a dart:io File (mobile) or Uint8List (web/mobile)
      if (file is Uint8List) {
        bytes = file;
      } else {
        // Treat as dart:io File via dynamic invocation — safe because this
        // branch is only reached on non-web platforms where dart:io exists.
        final path = (file as dynamic).path as String;
        ext = path.split('.').last.toLowerCase();
        bytes = await (file as dynamic).readAsBytes() as Uint8List;
      }

      final fileName = '${label}_${DateTime.now().millisecondsSinceEpoch}.$ext';
      final filePath = '$uid/$fileName';

      await client.storage
          .from(_scansBucket)
          .uploadBinary(
            filePath,
            bytes,
            fileOptions: const FileOptions(
              upsert: true,
              contentType: 'image/jpeg',
            ),
          );
      return filePath;
    } catch (e) {
      debugPrint('uploadScanPhoto error: $e');
      return null;
    }
  }

  /// Get a signed URL for a private scan photo (valid 1 hour)
  Future<String?> getScanPhotoUrl(String filePath) async {
    try {
      return await client.storage
          .from(_scansBucket)
          .createSignedUrl(filePath, 3600);
    } catch (e) {
      debugPrint('getScanPhotoUrl error: $e');
      return null;
    }
  }

  // ─────────────────────────────────────────────
  // SCANS
  // ─────────────────────────────────────────────

  /// Create a new scan record
  Future<ScanModel?> createScan({
    required String frontImageUrl,
    String? sideImageUrl,
    String scanStatus = 'pending',
  }) async {
    final uid = currentUser?.id;
    if (uid == null) return null;
    try {
      final data = await client
          .from('scans')
          .insert({
            'user_id': uid,
            'front_image_url': frontImageUrl,
            'side_image_url': sideImageUrl,
            'scan_status': scanStatus,
          })
          .select()
          .single();
      return ScanModel.fromJson(data);
    } catch (e) {
      debugPrint('createScan error: $e');
      return null;
    }
  }

  /// Update scan status
  Future<void> updateScanStatus(String scanId, String status) async {
    try {
      await client
          .from('scans')
          .update({'scan_status': status})
          .eq('id', scanId);
    } catch (e) {
      debugPrint('updateScanStatus error: $e');
    }
  }

  /// Fetch scan history for the current user
  Future<List<ScanModel>> fetchScanHistory({int limit = 20}) async {
    final uid = currentUser?.id;
    if (uid == null) return [];
    try {
      final data = await client
          .from('scans')
          .select()
          .eq('user_id', uid)
          .order('created_at', ascending: false)
          .limit(limit);
      return (data as List)
          .map((e) => ScanModel.fromJson(e as Map<String, dynamic>))
          .toList();
    } catch (e) {
      debugPrint('fetchScanHistory error: $e');
      return [];
    }
  }

  // ─────────────────────────────────────────────
  // SCAN RESULTS
  // ─────────────────────────────────────────────

  /// Save a scan result — caches locally and queues for sync if offline
  Future<ScanResultModel?> saveScanResult(ScanResultModel result) async {
    final uid = currentUser?.id;
    if (uid == null) return null;

    // Always cache locally first
    await LocalCacheService.instance.cacheLatestScan(result.toJson());

    // Check connectivity
    final isOnline = SyncService.instance.isOnline;
    if (!isOnline) {
      debugPrint(
        '[SupabaseService] saveScanResult — offline, queuing for sync',
      );
      await SyncService.instance.enqueueScanResult(result.toJson());
      return result;
    }

    try {
      final data = await client
          .from('scan_results')
          .insert(result.toJson())
          .select()
          .single();
      final saved = ScanResultModel.fromJson(data);
      // Update cache with server-assigned id
      await LocalCacheService.instance.cacheLatestScan(saved.toJson());
      return saved;
    } catch (e) {
      debugPrint('saveScanResult error: $e — queuing for retry');
      await SyncService.instance.enqueueScanResult(result.toJson());
      return result;
    }
  }

  /// Fetch the latest scan result for the current user
  Future<ScanResultModel?> fetchLatestScanResult() async {
    final uid = currentUser?.id;
    if (uid == null) return null;
    try {
      final data = await client
          .from('scan_results')
          .select()
          .eq('user_id', uid)
          .order('created_at', ascending: false)
          .limit(1)
          .maybeSingle();
      if (data == null) return null;
      return ScanResultModel.fromJson(data);
    } catch (e) {
      debugPrint('fetchLatestScanResult error: $e');
      return null;
    }
  }

  /// Fetch scan result history for the current user
  Future<List<ScanResultModel>> fetchScanResultHistory({int limit = 20}) async {
    final uid = currentUser?.id;
    if (uid == null) return [];
    try {
      final data = await client
          .from('scan_results')
          .select()
          .eq('user_id', uid)
          .order('created_at', ascending: false)
          .limit(limit);
      return (data as List)
          .map((e) => ScanResultModel.fromJson(e as Map<String, dynamic>))
          .toList();
    } catch (e) {
      debugPrint('fetchScanResultHistory error: $e');
      return [];
    }
  }

  /// Real-time stream of scan_results for the current user.
  /// Emits a new list whenever a row is inserted, updated, or deleted.
  Stream<List<ScanResultModel>> watchScanResults() {
    final uid = currentUser?.id;
    if (uid == null) return const Stream.empty();
    return client
        .from('scan_results')
        .stream(primaryKey: ['id'])
        .eq('user_id', uid)
        .order('created_at', ascending: false)
        .map((rows) => rows.map((e) => ScanResultModel.fromJson(e)).toList());
  }

  // ─────────────────────────────────────────────
  // SUBSCRIPTIONS
  // ─────────────────────────────────────────────

  /// Check if the current user has an active subscription
  Future<bool> checkSubscriptionStatus() async {
    final uid = currentUser?.id;
    if (uid == null) return false;
    try {
      final data = await client
          .from('subscriptions')
          .select('entitlement_active, expires_at')
          .eq('user_id', uid)
          .order('last_synced_at', ascending: false)
          .limit(1)
          .maybeSingle();
      if (data == null) return false;
      final active = data['entitlement_active'] as bool? ?? false;
      final expiresAt = data['expires_at'] != null
          ? DateTime.tryParse(data['expires_at'] as String)
          : null;
      if (!active) return false;
      if (expiresAt != null && expiresAt.isBefore(DateTime.now())) return false;
      return true;
    } catch (e) {
      debugPrint('checkSubscriptionStatus error: $e');
      return false;
    }
  }

  /// Fetch the current user's subscription
  Future<SubscriptionModel?> fetchSubscription() async {
    final uid = currentUser?.id;
    if (uid == null) return null;
    try {
      final data = await client
          .from('subscriptions')
          .select()
          .eq('user_id', uid)
          .order('last_synced_at', ascending: false)
          .limit(1)
          .maybeSingle();
      if (data == null) return null;
      return SubscriptionModel.fromJson(data);
    } catch (e) {
      debugPrint('fetchSubscription error: $e');
      return null;
    }
  }

  /// Activate a subscription for the current user (upsert)
  Future<bool> activateSubscription({
    required String productId,
    required String provider,
  }) async {
    final uid = currentUser?.id;
    if (uid == null) return false;
    try {
      final expiresAt = productId.contains('yearly')
          ? DateTime.now().add(const Duration(days: 365))
          : DateTime.now().add(const Duration(days: 7));

      await client.from('subscriptions').upsert({
        'user_id': uid,
        'provider': provider,
        'product_id': productId,
        'entitlement_active': true,
        'expires_at': expiresAt.toIso8601String(),
        'last_synced_at': DateTime.now().toIso8601String(),
      }, onConflict: 'user_id');
      debugPrint('[SupabaseService] Subscription activated: $productId');
      return true;
    } catch (e) {
      debugPrint('activateSubscription error: $e');
      return false;
    }
  }

  // ─────────────────────────────────────────────
  // ACCOUNT DELETION
  // ─────────────────────────────────────────────

  /// Delete all user data and auth account
  Future<void> deleteAccount() async {
    final uid = currentUser?.id;
    if (uid == null) return;
    try {
      // Delete scan results first (FK dependency)
      await client.from('scan_results').delete().eq('user_id', uid);
      // Delete scans
      await client.from('scans').delete().eq('user_id', uid);
      // Delete onboarding answers
      await client.from('onboarding_answers').delete().eq('user_id', uid);
      // Delete subscriptions
      await client.from('subscriptions').delete().eq('user_id', uid);
      // Delete profile
      await client.from('profiles').delete().eq('id', uid);
      // Delete auth user
      await client.auth.admin.deleteUser(uid);
    } catch (e) {
      debugPrint('deleteAccount error: $e');
      // Fallback: sign out even if deletion partially fails
      await signOut();
      rethrow;
    }
  }
}
