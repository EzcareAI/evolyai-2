import '../services/supabase_service.dart';

class OnboardingData {
  String? goal;
  String? gender;
  int? age;
  double? heightCm;
  String? heightUnit; // 'cm' or 'ft'
  int? heightFeet;
  int? heightInches;
  double? weightKg;
  String? weightUnit; // 'kg' or 'lbs'
  String? activityLevel;
  String? motivation;
  String? frontPhotoPath;
  String? sidePhotoPath;
  double? targetBodyFatPercent; // NEW: user's target body fat goal

  /// The scan result saved during onboarding AI processing.
  /// Carried through the navigation chain so the dashboard can display it
  /// immediately without waiting for a Supabase fetch.
  ScanResultModel? scanResult;

  /// When true, this scan was triggered from the dashboard (not onboarding).
  bool standaloneMode;

  OnboardingData({
    this.goal,
    this.gender,
    this.age,
    this.heightCm,
    this.heightUnit,
    this.heightFeet,
    this.heightInches,
    this.weightKg,
    this.weightUnit,
    this.activityLevel,
    this.motivation,
    this.frontPhotoPath,
    this.sidePhotoPath,
    this.targetBodyFatPercent,
    this.scanResult,
    this.standaloneMode = false,
  });

  OnboardingData copyWith({
    String? goal,
    String? gender,
    int? age,
    double? heightCm,
    String? heightUnit,
    int? heightFeet,
    int? heightInches,
    double? weightKg,
    String? weightUnit,
    String? activityLevel,
    String? motivation,
    String? frontPhotoPath,
    String? sidePhotoPath,
    double? targetBodyFatPercent,
    ScanResultModel? scanResult,
    bool? standaloneMode,
  }) {
    return OnboardingData(
      goal: goal ?? this.goal,
      gender: gender ?? this.gender,
      age: age ?? this.age,
      heightCm: heightCm ?? this.heightCm,
      heightUnit: heightUnit ?? this.heightUnit,
      heightFeet: heightFeet ?? this.heightFeet,
      heightInches: heightInches ?? this.heightInches,
      weightKg: weightKg ?? this.weightKg,
      weightUnit: weightUnit ?? this.weightUnit,
      activityLevel: activityLevel ?? this.activityLevel,
      motivation: motivation ?? this.motivation,
      frontPhotoPath: frontPhotoPath ?? this.frontPhotoPath,
      sidePhotoPath: sidePhotoPath ?? this.sidePhotoPath,
      targetBodyFatPercent: targetBodyFatPercent ?? this.targetBodyFatPercent,
      scanResult: scanResult ?? this.scanResult,
      standaloneMode: standaloneMode ?? this.standaloneMode,
    );
  }

  String get displayHeight {
    if (heightUnit == 'ft' && heightFeet != null) {
      final inches = heightInches ?? 0;
      return '$heightFeet\'$inches"';
    }
    if (heightCm != null) return '${heightCm!.toStringAsFixed(0)} cm';
    return '--';
  }

  String get displayWeight {
    if (weightKg == null) return '--';
    if (weightUnit == 'lbs') {
      return '${(weightKg! * 2.20462).toStringAsFixed(0)} lbs';
    }
    return '${weightKg!.toStringAsFixed(0)} kg';
  }
}
