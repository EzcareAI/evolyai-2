-- Migration: Add target_body_fat_percent to onboarding_answers
-- This column stores the user's selected target body fat percentage from onboarding

ALTER TABLE public.onboarding_answers
  ADD COLUMN IF NOT EXISTS target_body_fat_percent DOUBLE PRECISION;
