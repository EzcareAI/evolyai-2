-- Ensure onboarding_answers has a unique constraint on user_id
-- Required for upsert (ON CONFLICT user_id) to work correctly

-- Add unique constraint if it doesn't exist
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint
    WHERE conname = 'onboarding_answers_user_id_key'
      AND conrelid = 'public.onboarding_answers'::regclass
  ) THEN
    ALTER TABLE public.onboarding_answers
      ADD CONSTRAINT onboarding_answers_user_id_key UNIQUE (user_id);
  END IF;
END;
$$;

-- Deduplicate: keep only the most recent row per user before adding constraint
-- (runs only if duplicates exist, safe to run multiple times)
DELETE FROM public.onboarding_answers a
USING public.onboarding_answers b
WHERE a.user_id = b.user_id
  AND a.created_at < b.created_at;
