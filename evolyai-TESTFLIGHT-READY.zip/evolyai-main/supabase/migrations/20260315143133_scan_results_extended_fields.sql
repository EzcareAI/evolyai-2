-- Add extended body composition fields to scan_results table
ALTER TABLE public.scan_results
ADD COLUMN IF NOT EXISTS fat_mass NUMERIC,
ADD COLUMN IF NOT EXISTS physique_profile TEXT,
ADD COLUMN IF NOT EXISTS left_arm_percent NUMERIC,
ADD COLUMN IF NOT EXISTS right_arm_percent NUMERIC,
ADD COLUMN IF NOT EXISTS upper_body_percent NUMERIC,
ADD COLUMN IF NOT EXISTS left_leg_percent NUMERIC,
ADD COLUMN IF NOT EXISTS right_leg_percent NUMERIC;
